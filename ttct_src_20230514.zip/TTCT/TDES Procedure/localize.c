#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>

#include "setup.h"
#include "des_data.h"
#include "des_proc.h"
#include "des_supp.h"
#include "tct_curs.h"
//#include "mymalloc.h"
#include "localize.h"
#include "Supred.h"
#include "ttct_io.h"
#include "tct_proc.h"

static INT_B mark = false;//used to check whether use mark information

typedef struct t_part_node {
   INT_T numelts;
   INT_T *next;
} t_part_node;

void loc_copy_des( INT_S *s_dest,state_node **t_dest,
              INT_S s_src,state_node *t_src   )
{
    INT_S i, jj;
    INT_T j, ee;
    INT_B ok;

    *s_dest = s_src;
    *t_dest = newdes(s_src);

    if ((s_src !=0) && (*t_dest == NULL)) {
      mem_result = 1;
      return;
    }

    for (i=0; i < s_src; i++) {
      (*t_dest)[i].marked  = t_src[i].marked;
      (*t_dest)[i].reached = t_src[i].reached;
      (*t_dest)[i].coreach = t_src[i].coreach;
      (*t_dest)[i].vocal   = t_src[i].vocal;
      for (j=0; j < t_src[i].numelts; j++) {
         ee = t_src[i].next[j].data1;
         jj = t_src[i].next[j].data2;
         addordlist1(ee, jj, &(*t_dest)[i].next, (*t_dest)[i].numelts, &ok);
         if (ok) (*t_dest)[i].numelts++;
      }
    }
}

void loc_gentranlist(INT_S s1,
                 state_node *t1,
                 INT_T *s_t1,
                 INT_T **list1)
{
   /* Generate a list of all transition labels used in DES */
   INT_S i;
   INT_T j;
   INT_B ok;

   *s_t1 = 0;
   *list1 = NULL;
   if (s1 == 0L) return;

   for (i=0L; i < s1; i++) {
     for (j=0; j < t1[i].numelts; j++) {
       addordlist(t1[i].next[j].data1, list1, *s_t1, &ok);
       if (ok) (*s_t1)++;
     }
   }
}


void loc_free_par(INT_S *s_par, part_node** par)
{
    INT_S i;
     
    for (i=0; i < *s_par; i++)
       free((*par)[i].next);
    free(*par); 
    *par = NULL;
    *s_par = 0;   
}     
void loc_free_t_par(INT_S *s_par, t_part_node** par)
{
    INT_S i;
     
    for (i=0; i < *s_par; i++)
       free((*par)[i].next);
    free(*par); 
    *par = NULL;
    *s_par = 0;   
} 

void loc_genlist(INT_T slist1, tran_node *list1, INT_T slist2, tran_node *list2,
	     INT_S s1, INT_T *t1, INT_T slist, INT_T *list, INT_S s, state_node **t)
{
   INT_T j1, j2,jj;//, *tmplist;
//   INT_S s_tmplist;
   INT_B ok,Del;
   INT_B forcible;   

   forcible = false;
   //s_tmplist = 0;
   //tmplist = (INT_T*) calloc(max(slist1,slist2), sizeof(INT_T));
   j1 = j2 = 0;
   /* relying on ordered list and TICK = 0*/
   if (slist1 > 0 && slist2 > 0 && 
       (list1[0].data1 == TICK && list2[0].data1 != TICK))
      forcible = true;
   while ((j1 < slist1) && (j2 < slist2)) {
     if (list1[j1].data1 == list2[j2].data1) {
        //tmplist[s_tmplist++] = list1[j1].data1;
        j1++; j2++;
     } else if (list1[j1].data1 > list2[j2].data1) {
        j2++;
     } else {
        if(inlist(list1[j1].data1, list, slist) || (list1[j1].data1 == 0)){
           addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
           if (ok) (*t)[s].numelts++;
        }
        j1++;
     }
   }

   while (j1 < slist1) {
     if(inlist(list1[j1].data1, list, slist) || (list1[j1].data1 == 0)){
       addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
       if (ok) (*t)[s].numelts++;
     }
     j1++;
   }

   Del = true;
   if (forcible) {
      for(jj = 0; jj < slist2; jj ++){
         if(inlist(list2[jj].data1,t1, (INT_T)s1)){
            Del = false;
         }         
      }
      if(Del){
         delete_ordlist1(TICK,(*t)[s].next[0].data2, &(*t)[s].next, (*t)[s].numelts, &ok);
         if(ok) (*t)[s].numelts --;
      }
   }
//}   
   //free(tmplist);
   
}

void loc_condat1(state_node *t1, INT_S s1, INT_S s2, INT_S s3, state_node *t3,
             INT_S s4, INT_T *t4, INT_T slist, INT_T *list, INT_S *s5, state_node **t5,
             INT_S *macro_c)
{
   INT_S state, state1, state2;

   *s5 = s2;
   *t5 = newdes(*s5);
   
   for (state=0; state < s3; state++) {
     state1 = macro_c[state] % s1;
     state2 = macro_c[state] / s1;
     loc_genlist(t1[state1].numelts, t1[state1].next,
             t3[state].numelts, t3[state].next, s4, t4, slist, list, state2, t5);
   }

}
/*For single event localization*/
void loc_genlist2(INT_T slist1, tran_node *list1, INT_T slist2, tran_node *list2,
	     INT_S s1, INT_T *t1, INT_T slist, INT_T *list, INT_S s, state_node **t)
{
   INT_T j1, j2;//,jj;
   INT_B ok;   


   j1 = j2 = 0;
   /* relying on ordered list and TICK = 0*/

   while ((j1 < slist1) && (j2 < slist2)) {
     if (list1[j1].data1 == list2[j2].data1) {
        j1++; j2++;
     } else if (list1[j1].data1 > list2[j2].data1) {
        j2++;
     } else {
        if(inlist(list1[j1].data1, list, slist)){
           addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
           if (ok) (*t)[s].numelts++;
        }
        j1++;
     }
   }

   while (j1 < slist1) {
     if(inlist(list1[j1].data1, list, slist)){
       addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
       if (ok) (*t)[s].numelts++;
     }
     j1++;
   }

}
void loc_condat2(state_node *t1, INT_S s1, INT_S s2, INT_S s3, state_node *t3,
             INT_S s4, INT_T *t4, INT_T slist, INT_T *list, INT_S *s5, state_node **t5,
             INT_S *macro_c)
{
   INT_S state, state1, state2;

   *s5 = s2;
   *t5 = newdes(*s5);
   
   for (state=0; state < s3; state++) {
     state1 = macro_c[state] % s1;
     state2 = macro_c[state] / s1;
     loc_genlist2(t1[state1].numelts, t1[state1].next,
             t3[state].numelts, t3[state].next, s4, t4, slist, list, state2, t5);
   }

}
// For tick localization
void loc_genlist3(INT_T slist1, tran_node *list1, INT_T slist2, tran_node *list2,
	               INT_S s1, INT_T *t1, INT_S s, state_node **t)
{
   INT_T j1, j2,jj;//, *tmplist;
//   INT_S s_tmplist;
   INT_B ok,Del;
   INT_B forcible;   

   forcible = false;
   //s_tmplist = 0;
   //tmplist = (INT_T*) calloc(max(slist1,slist2), sizeof(INT_T));
   j1 = j2 = 0;
   /* relying on ordered list and TICK = 0*/
   if (slist1 > 0 && slist2 > 0 && 
       (list1[0].data1 == TICK && list2[0].data1 != TICK))
      forcible = true;
   while ((j1 < slist1) && (j2 < slist2)) {
     if (list1[j1].data1 == list2[j2].data1) {
        //tmplist[s_tmplist++] = list1[j1].data1;
        j1++; j2++;
     } else if (list1[j1].data1 > list2[j2].data1) {
        j2++;
     } else {
        if(list1[j1].data1 == 0){
           addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
           if (ok) (*t)[s].numelts++;
        }
        j1++;
     }
   }

   while (j1 < slist1) {
     if(list1[j1].data1 == 0){
       addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
       if (ok) (*t)[s].numelts++;
     }
     j1++;
   }

   Del = true;
   if (forcible) {
      for(jj = 0; jj < slist2; jj ++){
         if(inlist(list2[jj].data1,t1, (INT_T)s1)){
            Del = false;
         }         
      }
      if(Del){
         delete_ordlist1(TICK,(*t)[s].next[0].data2, &(*t)[s].next, (*t)[s].numelts, &ok);
         if(ok) (*t)[s].numelts --;
      }
   }
   
}
void loc_condat3(state_node *t1, INT_S s1, INT_S s2, INT_S s3, state_node *t3,
             INT_S s4, INT_T *t4, INT_S *s5, state_node **t5,
             INT_S *macro_c)
{
   INT_S state, state1, state2;

   *s5 = s2;
   *t5 = newdes(*s5);
   
   for (state=0; state < s3; state++) {
     state1 = macro_c[state] % s1;
     state2 = macro_c[state] / s1;
     loc_genlist3(t1[state1].numelts, t1[state1].next,
             t3[state].numelts, t3[state].next, s4, t4, state2, t5);
   }

}


int localize_proc(INT_S sfile, INT_S sloc, 
                        char* name1, char *name2, 
                        char (*names1)[MAX_FILENAME], 
                        char (*names2)[MAX_FILENAME],
                        int mode)
{
    INT_S s1, s2, s3, s4, s5, s6, s7;
    state_node *t1, *t2, *t3, *t4, *t5, *t6, *t7;
    INT_S init,i,j;
    INT_S *macro_ab, *macro_c;
    int result;
    INT_B ok;
    FILE * file;  
//    char temp[MAX_PATH];
    char long_temp_DES[MAX_PATH];
    char long_temp_DAT[MAX_PATH];
    char long_name1[MAX_PATH];
    char long_name2[MAX_PATH];
//    char ch;
    int x,y;
    char names3[20][MAX_PATH];
    char long_name3[MAX_PATH];
    INT_S num_of_states1[20], num_of_states2[20];  
    INT_T slist, *list, sconlist, *conlist, sctemp, *ctemp;
    
    t_part_node *par3, *fpar; 
    INT_S  s_par3, s_fpar;
	INT_T *ft1,*ft2;
	INT_S fs1,fs2;

	INT_S lb; double long cr; 
	INT_T *ft3;
	INT_S fs3;
	    INT_S min, pos_min;
    
    s1 = s2 = s3 = s4 = s5 = s6 = s7 = 0;
    t1 = t2 = t3 = t4 = t5 = t6 = t7 = NULL;    
    
    macro_ab = macro_c = NULL;
    s_par3 = s_fpar = 0;  par3 = fpar = NULL;
    file = NULL;
    slist = sconlist = sctemp = 0; 
    list = conlist = ctemp = NULL;    
    
    /*Initial the temp names3 to store the temp DES file generated by Strong Localization*/
    for(i = 0; i < sloc; i ++){
       strcpy(names3[i],"");
       sprintf(names3[i],"###%d",i);
    }
    
    result = 0;

    //remove("G:\\result.txt");

    s_par3 = sfile;
    par3 = (t_part_node*)calloc(s_par3,sizeof(t_part_node));
    if(par3 == NULL){
       s_par3 = 0;
       mem_result = 1;
       result = -1;
       goto LOC_LABEL;
    }
    
    s_fpar = sfile;
    fpar = (t_part_node*)calloc(s_fpar,sizeof(t_part_node));
    if(fpar == NULL){
       s_fpar = 0;
       mem_result = 1;
       result = -1;
       goto LOC_LABEL;
    }
    
    // check if the forcible events of plant and super are the same.

    
    fs1 = fs2 = 0;
    ft1 = ft2 = NULL;
    
    init = 0L;
    if(gettds(name1,&s1,&init,&t1, &fs1, &ft1) == false){
       result = -1;
       goto LOC_LABEL; 
    }
    for(i = 0; i < sfile; i ++){
       init = 0L;
       if(gettds(names1[i],&s2,&init,&t2,&fs2, &ft2) == false){
          result = -1;
          goto LOC_LABEL;
       }
       loc_gentranlist(s2,t2,&par3[i].numelts,&par3[i].next);
       for(j = 0; j < fs2; j ++){
          addordlist(ft2[j], &fpar[i].next, fpar[i].numelts, &ok);
          if(ok) fpar[i].numelts ++;
       }       
       if(mem_result == 1){
          result = -1;
          goto LOC_LABEL;
       }
       
       freedes(s2,&t2);
       free(ft2);
       s2 = 0; t2 = NULL;
       fs2 = 0; ft2 = NULL;
    }

    init = 0L;  
    if(gettds(name2,&s2,&init,&t2, &fs2, &ft2) == false){
       result = -1;
       goto LOC_LABEL;
    }
    loc_gentranlist(s2,t2,&slist, &list);
    
    if (chk_diff_forcible(s1, t1, (INT_T)fs1, ft1, s2, t2, (INT_T)fs2, ft2)) {
      //move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      result = -1;
      goto LOC_LABEL;
   }

    meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
    //printw("test");

    
    ft3 = NULL; fs3 = 0;
    
    ok = false;
    lb = 0; cr = 0.0;
    for(i = 0; i < sloc; i ++){
       lb = 0; cr = 0.0;
       // Use Condat to generate DAT file at first
       strcpy(long_temp_DAT,"");
       make_filename_ext(long_temp_DAT,names2[i],EXT_DAT);
       
       if(_wherey() > 19){
           clear();
           printw("LOCALIZE");println();
           println();
           printw("(LOCi) = LOCALIZE(PLANT,{PLANT1,PLANT2,...},SPEC)");println();
           println();
           x = _wherex();
           y = _wherey();
           move(22,0); clrtoeol();
           move(23,0); clrtoeol();
           printw("Processing:  Please wait... ");
           refresh();
         
           move(y,x);
           refresh();
       }
       printw("Generating %s%s ...", names2[i], EXT_DES);   
       
       fs3 = fs1;
       ft3 = (INT_T*) calloc(fs1,sizeof(INT_T));
       memcpy(ft3, ft1, sizeof(INT_T) * fs1);
       
       remove_forcible(&fs3, &ft3, slist, list);  
       
       remove_forcible(&fs3, &ft3, par3[i].numelts,par3[i].next);
           
       loc_condat1(t1,s1,s2,s3,t3,fs3, ft3, par3[i].numelts, par3[i].next, &s4,&t4,macro_c);
       
       if (mem_result != 1)
          filetds(names2[i], s4, -1L, t4, 0, NULL);
       //filedes(names2[i],s4,-1,t4);              
       if(!exist(long_temp_DAT)){
          result = -1;
          goto LOC_LABEL;
       }
       
       // Use Supreduce to implement Localize algorithm   
       strcpy(long_temp_DES,"");
       strcpy(long_name1,"");
       strcpy(long_name2,"");
       strcpy(long_name3,"");
       make_filename_ext(long_temp_DES,names2[i],EXT_DES);       
       make_filename_ext(long_name1,name1,EXT_DES);
       make_filename_ext(long_name2,name2,EXT_DES);
       make_filename_ext(long_name3,names3[i],EXT_DES);
       
      // supreduce(long_name1,long_name2,long_temp_DAT, long_temp_DES,&lb,&cr);
       
       // weak condition
       supreduce2(long_name1,long_name2,long_temp_DAT,long_temp_DES,&lb,&cr,&num_of_states1[i]);

       // strong condition
       //if(!ok)
       supreduce1(long_name1,long_name2,long_temp_DAT,long_name3,&lb,&cr,&num_of_states2[i]);  
 
       println();
       if(exist(long_temp_DES) && exist(long_name3))    
           printw("%s%s is generated.\n",names2[i], EXT_DES); 
       else {
           printw("\n%s%s cannot be generated: possible error in data entry.\n",names2[i], EXT_DES);
           result = -1;
           goto LOC_LABEL;
       }
       println(); 
  
       remove(long_temp_DAT);
       freedes(s4,&t4);
       s4 = 0; t4 = NULL;
       free(ft3); ft3 = NULL; 
    }
   

    if(mode == 0){
    //if(!ok){
       min = abs(num_of_states2[0] - num_of_states1[0]);
       pos_min = 0;
       for(i = 1; i < sloc; i ++){
          if(abs(num_of_states2[i] - num_of_states1[i]) < min){
             pos_min = i;
          }
       }
       strcpy(long_name3,"");
       make_filename_ext(long_name3,names3[pos_min],EXT_DES); 
       init = 0L;
       if(exist(long_name3))
           gettds(names3[pos_min],&s4,&init,&t4, &fs3, &ft3);
           
       free(ft3); ft3 = NULL;
       init = 0L;
       filetds(names2[pos_min],s4,init,t4, 0, NULL);
       freedes(s4,&t4);
    //}
       for(i = 0; i < sloc; i ++){
          strcpy(long_name3,"");
          make_filename_ext(long_name3,names3[i],EXT_DES);
          if(exist(long_name3))
             remove(long_name3);

          init = 0L;
          gettds(names2[i], &s4, &init, &t4, &fs3, &ft3);
             
          init = 0L;
          //filetds(names2[i], s4, init, t4, fpar[i].numelts, fpar[i].next);
          filetds(names2[i], s4, init, t4, fs2, ft2);
          freedes(s4, &t4); s4 = 0; t4 = NULL;
          free(ft3); ft3 = NULL;
       }
    //////////////////////////////////////////////////////////////////////////////////
    // clean_up the localized controllers
/*    if(sfile == 1)
       goto LOC_LABEL;
    INT_T ee; INT_S es; INT_S j, k;
    INT_B de_flag;
    for(i = 0; i < sloc; i ++){
       init = 0L;
       getdes(names2[i],&s4,&init,&t4);
       free(list); free(conlist);
       slist = sconlist = 0; list = conlist = NULL;
       for(k = 0; k < t4[0].numelts; k ++){
          if(t4[0].next[k].data2 == 0 && t4[0].next[k].data1 % 2 == 1){
             addordlist(t4[0].next[k].data1,&conlist,sconlist,&ok);
             if(ok) sconlist ++;
          }
       }
       
       for(j = 0; j < s4; j ++){
          for(k = 0; k < t4[j].numelts; k ++){
             ee = t4[j].next[k].data1;
             es = t4[j].next[k].data2;
             if(es != j){
                addordlist(ee,&list,slist,&ok);
                if(ok) slist++;
             } else if(ee %2 == 1){
                if(inlist(ee,conlist,sconlist)){
                   addordlist(ee,&ctemp,sctemp,&ok);
                   if(ok) sctemp ++;
                }
             }
          }  
          free(conlist); sconlist = 0; conlist = NULL;
          loc_unionsets1(ctemp,sctemp,&conlist,&sconlist);
          free(ctemp); sctemp = 0; ctemp = NULL;         
       }
       for(j = 0; j < s4; j ++){
          for(k = 0; k < t4[j].numelts; k ++){
             ee = t4[j].next[k].data1;
             es = t4[j].next[k].data2;
             de_flag = false;
             if(es != j)
                continue;            
             if(!inlist(ee,par3[i].next,par3[i].numelts) && (!inlist(ee,list,slist))){
                de_flag = true;
             }else{
                if(ee %2 == 0 && (!inlist(ee,list,slist))){
                   de_flag = true;
                }else if(ee %2 == 1 && (inlist(ee,conlist,sconlist))){
                   de_flag = true;
                }
             }
             if(de_flag == true){
                addordlist(ee,&ctemp,sctemp,&ok);
                if(ok) sctemp ++;
             }
             
          }
          if(sctemp != 0){
              for(k = 0; k < sctemp; k ++){
                delete_ordlist1(ctemp[k],j,&t4[j].next,t4[j].numelts,&ok);
                if(ok) t4[j].numelts --;
              }
          }
          free(ctemp); sctemp = 0; ctemp = NULL;
       }
       init = 0L;
       filedes(names2[i],s4,init,t4);
       freedes(s4,&t4); s4 = 0; t4 = NULL;
    }*/
    } else{
       for(i = 0; i < sloc; i ++){
          strcpy(long_name3,"");
          make_filename_ext(long_name3,names3[i],EXT_DES);
          if(exist(long_name3)){
             init = 0L;
             gettds(names3[i], &s4, &init, &t4, &fs3, &ft3);
             
             init = 0L;
             //filetds(names2[i], s4, init, t4, fpar[i].numelts, fpar[i].next);
             filetds(names2[i], s4, init, t4, fs2, ft2);
             freedes(s4, &t4); s4 = 0; t4 = NULL;
             free(ft3); ft3 = NULL;
             remove(long_name3);
          }
       }
    }
      
LOC_LABEL:
    
    freedes(s1,&t1);      
    freedes(s2,&t2);  
    freedes(s3,&t3); 
    freedes(s4,&t4);  
    freedes(s5,&t5);
    freedes(s6,&t6);
    freedes(s7,&t7);
    
    loc_free_t_par(&s_par3,&par3);
    loc_free_t_par(&s_fpar,&fpar);
 
    free(macro_ab);
    free(macro_c); 
    
    free(list);
    free(conlist);
    free(ctemp);
    
    free(ft1); 
    free(ft2);
    free(ft3);
    return result;
}


void check_control_equ(INT_S sfile, 
                             char *name1, 
                             char *name2, 
                             char (*names1)[MAX_FILENAME], 
                             char (*names2)[MAX_FILENAME],
                             INT_B *flag)
{
    INT_S s1, s2, s3, s4, s5, s6, s7;
    state_node *t1, *t2, *t3, *t4, *t5, *t6, *t7;
//    INT_S init;//,i;
    INT_S *macro_ab, *macro_c;
//    INT_B ok;
    
    s1 = s2 = s3 = s4 = s5 = s6 = s7 = 0;
    t1 = t2 = t3 = t4 = t5 = t6 = t7 = NULL;    
    
    macro_ab = macro_c = NULL;
/*
    init = 0L;  
    if(getdes(name2,&s2,&init,&t2) == false)
       goto CHECK_LABEL;
    ///////////////////////////////////////////////////////
    // Algorithm for checking localization
    //  ALLSUPER = Allevents(SUPER)
    //EAGENTi = Sync(AGENTi,ALLSUPER)  [in general may contain globally prohibited events]
    //EAGENTiLOC = Sync(AGENTiLOC,ALLSUPER) [should not contain globally prohibited events]
    //ZAGENTi = Meet(EAGENTi,EAGENTiLOC) [will eliminate globally prohibited events]
    //ZSUPER = Meet(ZAGENT1,ZAGENT2,...) [should be isomorphic to SUPER]
    
    
    //  ALLSUPER = Allevents(SUPER)
    allevent_des(&t2,&s2,&t1,&s1);
    if(mem_result == 1){
       goto CHECK_LABEL;
    }
    
    for(i = 0; i < sfile; i ++){
       init = 0L;
       getdes(names1[i],&s4,&init,&t4);
       getdes(names2[i],&s5,&init,&t5);       
       
       //EAGENTi = Sync(AGENTi,ALLSUPER)
       free(macro_ab); free(macro_c);
       macro_ab = macro_c = NULL;
       loc_copy_des(&s7,&t7,s1,t1);
       //sync2(s4,t4,s7,t7,&s6,&t6,&macro_ab,&macro_c);
       freedes(s4,&t4); s4 = 0; t4 = NULL;
       freedes(s7,&t7); s7 = 0; t7 = NULL;
       free(macro_ab); free(macro_c); macro_ab = macro_c = NULL;
       
       //EAGENTiLOC = Sync(AGENTiLOC,ALLSUPER)
       loc_copy_des(&s7,&t7,s1,t1);
       //sync2(s5,t5,s7,t7,&s4,&t4,&macro_ab,&macro_c);
       freedes(s5,&t5); s5 = 0; t5 = NULL;
       freedes(s7,&t7); s7 = 0; t7 = NULL;
       free(macro_ab); free(macro_c); macro_ab = macro_c = NULL;
       
       //ZAGENTi = Meet(EAGENTi,EAGENTiLOC)
       meet2(s6,t6,s4,t4,&s5,&t5,&macro_ab,&macro_c);
       if(i == 0){
          loc_copy_des(&s3,&t3,s5,t5);
       } else{
          free(macro_ab); free(macro_c);
          macro_ab = macro_c = NULL;
          freedes(s4,&t4); s4 = 0; t4 = NULL;
          //ZSUPER = Meet(ZAGENT1,ZAGENT2,...)
          meet2(s3,t3,s5,t5,&s4,&t4,&macro_ab,&macro_c);
          freedes(s3,&t3); s3 = 0; t3 = NULL;
          loc_copy_des(&s3,&t3,s4,t4);
       }
       freedes(s4,&t4);
       freedes(s5,&t5);
       freedes(s6,&t6);
       s4 = s5 = s6 = 0;
       t4 = t5 = t6 = NULL;
    }
    INT_S * mapstate;
    
    *flag = false;
    mapstate = NULL;
       
    mapstate = (INT_S*)CALLOC(s3,sizeof(INT_S));
    if(mapstate == NULL){
       mem_result = 1;
       goto CHECK_LABEL;
    }
    memset(mapstate,-1,s3 * sizeof(INT_S));
    mapstate[0] = 0;
    iso1(s3,s2,t3,t2,flag,mapstate);
      
    if(!(*flag)){  
        minimize(&s3,&t3);
        minimize(&s2,&t2);
        memset(mapstate,-1,s3 * sizeof(INT_S));
        mapstate[0] = 0;
        iso1(s3,s2,t3,t2,flag,mapstate);        
    }
    free(mapstate);*/
//CHECK_LABEL:
    freedes(s1,&t1);      
    freedes(s2,&t2);  
    freedes(s3,&t3); 
    freedes(s4,&t4);  
    freedes(s5,&t5);
    freedes(s6,&t6);
    freedes(s7,&t7);
 
    free(macro_ab);
    free(macro_c);
}

int localize_proc1(char* name1, char *name2, char *name3, char *name4, INT_T s_tlist, INT_T *tlist)
{
    INT_S s1, s2, s3, s4;
    state_node *t1, *t2, *t3, *t4;
    INT_S init;//,i;
    INT_S *macro_ab, *macro_c;
    int result;
    INT_B ok;
//    FILE * file;  
    char long_temp_DAT[MAX_PATH];
    char long_tick_DAT[MAX_PATH];
    char long_name1[MAX_PATH];
    char long_name2[MAX_PATH];
    char long_name3[MAX_PATH];
    char long_name4[MAX_PATH];
    INT_S num;
    INT_T slist, *list;
    
    INT_T *ft1, *ft2, *ft3;
    INT_S fs1, fs2, fs3;
	    INT_S lb; double long cr; 
    
    
    s1 = s2 = s3 = s4 = 0;
    t1 = t2 = t3 = t4 =  NULL;  
    
    fs1 = fs2 = fs3 = 0;
    ft1 = ft2 = ft3 = NULL;  
    
    macro_ab = macro_c = NULL;     
    slist = 0; list = NULL;
    num = 0; 
    
    result = 0;
        
    init = 0L;
    if(gettds(name1,&s1,&init,&t1, &fs1, &ft1) == false)
       goto LOC1_LABEL; 

    init = 0L;  
    if(gettds(name2,&s2,&init,&t2, &fs2, &ft2) == false)
       goto LOC1_LABEL;

    loc_gentranlist(s2,t2,&slist, &list);
    
    if (chk_diff_forcible(s1, t1, (INT_T)fs1, ft1, s2, t2, (INT_T)fs2, ft2)) {
      //move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      result = -1;
      goto LOC1_LABEL;
    }
    
    meet2(s1,t1,s2,t2,&s3,&t3,&macro_ab,&macro_c);
    

    ok = false;
    lb = 0; cr = 0.0;
    
    fs3 = fs1;
    ft3 = (INT_T*) calloc(fs1,sizeof(INT_T));
    memcpy(ft3, ft1, sizeof(INT_T) * fs1);
     
    remove_forcible(&fs3, &ft3, slist, list);  
       
    remove_forcible(&fs3, &ft3, s_tlist, tlist);
    //printf("What's wrong1");system("pause");       
    loc_condat2(t1,s1,s2,s3,t3,fs3, ft3, s_tlist, tlist, &s4,&t4,macro_c);  
    if (mem_result != 1)
       filetds(name2, s4, -1L, t4, 0, NULL);
       //filedes(names2[i],s4,-1,t4);  
    freedes(s4, &t4);
    s4 = 0; t4 = NULL;
    
    loc_condat3(t1,s1,s2,s3,t3,fs3, ft3, &s4,&t4,macro_c);  
    if (mem_result != 1)
       filetds(name4, s4, -1L, t4, 0, NULL);
       
    freedes(s4, &t4);
    s4 = 0; t4 = NULL;
    
    free(ft3);
    ft3 = NULL; fs3 = 0;
    
    strcpy(long_temp_DAT,"");
    strcpy(long_tick_DAT,"");
    make_filename_ext(long_temp_DAT,name2,EXT_DAT);
    make_filename_ext(long_tick_DAT,name4,EXT_DAT);              
    if((!exist(long_temp_DAT)) || (!exist(long_tick_DAT))){
          result = -1;
          goto LOC1_LABEL;
    }
    
       // Use Condat to generate DAT file at first
    
    println();   
    printw("Generating %s%s...", name3, EXT_DES);   println();
    println(); 
        
    //loc_condat1(t1,s1,s2,s3,t3,&s4,&t4,s_list,list,macro_c);
    
       
    // Use Supreduce to implement Localize algorithm   
    //strcpy(long_temp_DES,"");
    strcpy(long_name1,"");
    strcpy(long_name2,"");
    strcpy(long_name3,"");
    strcpy(long_name4,"");
     
    make_filename_ext(long_name1,name1,EXT_DES);
    make_filename_ext(long_name2,name2,EXT_DES);
    make_filename_ext(long_name3,name3,EXT_DES);
    make_filename_ext(long_name4,name4,EXT_DES);
       
    supreduce3(long_name1,long_name2,long_temp_DAT,long_name3,&lb,&cr,&num);  
    supreduce3(long_name1,long_name2,long_tick_DAT,long_name4,&lb,&cr,&num);  
    
    println();
    if(exist(long_name3) && exist(long_name4)){    
       printw("%s%s is generated.\n",name3, EXT_DES); 
       println();
       printw("%s%s is generated.\n",name4, EXT_DES); 
       
       init = 0L;
       gettds(name3, &s4, &init, &t4, &fs3, &ft3);
       filetds(name3, s4, 0L, t4, fs2, ft2);
       freedes(s4, &t4);
       s4 = 0; t4 = NULL;
       free(ft3); fs3 = 0; ft3 = NULL;
       
       init = 0L;
       gettds(name4, &s4, &init, &t4, &fs3, &ft3);
       filetds(name4, s4, 0L, t4, fs2, ft2);
    }
    else {
       printw("\n%s%s and %s%scannot be generated: possible error in data entry.\n",name3, EXT_DES, name4, EXT_DES);
       result = -1;
       goto LOC1_LABEL;
    }
    println(); 
  
    remove(long_temp_DAT);
    //remove(long_tick_DAT);
      
LOC1_LABEL:
    
    freedes(s1,&t1);      
    freedes(s2,&t2);  
    freedes(s3,&t3); 
    freedes(s4,&t4);     
 
    free(macro_ab);
    free(macro_c); 
    
    free(ft1);
    free(ft2);
    free(ft3);
    
    return result;
}
