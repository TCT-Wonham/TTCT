#include "des_data.h"
#include "des_proc.h"
#include "des_supp.h"
#include "minm.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "setup.h"
#include "tct_curs.h"
#include "tct_proc.h"

/* DES procedures */

void gentranlist(INT_S s1,
                 state_node *t1,
                 INT_T *s_t1,
                 INT_T **list1)
{
   /* Generate a list of all transition labels used in DES */
   INT_S i;
   INT_T j;
   INT_B ok;

   *s_t1 = 0;
   *list1 = NULL;
   if (s1 == 0L) return;

   for (i=0L; i < s1; i++) {
     for (j=0; j < t1[i].numelts; j++) {
       addordlist(t1[i].next[j].data1, list1, *s_t1, &ok);
       if (ok) (*s_t1)++;
     }
   }
}

void gentranlist1(INT_S s1,
	state_node *t1,
	INT_S *s_t1,
	INT_T **list1)
{
	/* Generate a list of all transition labels used in DES */
	INT_S i;
	INT_T j;
	INT_B ok;

	*s_t1 = 0;
	*list1 = NULL;
	if (s1 == 0L) return;

	for (i=0L; i < s1; i++) {
		for (j=0; j < t1[i].numelts; j++) {
			addordlist(t1[i].next[j].data1, list1, (INT_T)*s_t1, &ok);
			if (ok) (*s_t1)++;
		}
	}
}

void gensublist(INT_T s_t1,
                INT_T *tranlist1,
                INT_T s_t2,
                INT_T *tranlist2,
                INT_T *s_s1,
                INT_T **sublist1,
                INT_T *s_s2,
                INT_T **sublist2)
{
   /* This generates sublist1 (list1-list2) and sublist2 (list2-list1) */
   INT_T i,j;
   INT_B ok;

   *s_s1 = *s_s2 = 0;
   *sublist1 = *sublist2 = NULL;
   i = j = 0;
   while ( (i < s_t1) && (j < s_t2) ) {
      if (tranlist1[i] == tranlist2[j]) {
         i++;
         j++;
         continue;
      }
      if (tranlist1[i] > tranlist2[j]) {
         addordlist(tranlist2[j], sublist2, *s_s2, &ok);
         if (ok) (*s_s2)++;
         j++;
      } else {
         addordlist(tranlist1[i], sublist1, *s_s1, &ok);
         if (ok) (*s_s1)++;
         i++;
      }
   }

   if (i >= s_t1) {
     if (*sublist2 == NULL) {
       while (j < s_t2) {
         addordlist(tranlist2[j], sublist2, *s_s2, &ok);
         if (ok) (*s_s2)++;
         j++;
       }
       return;
     }

     while(j < s_t2) {
       addordlist(tranlist2[j], sublist2, *s_s2, &ok);
       if (ok) (*s_s2)++;
       j++;
     }
     return;
   }

   if (*sublist1 == NULL) {
     while (i < s_t1) {
       addordlist(tranlist1[i], sublist1, *s_s1, &ok);
       if (ok) (*s_s1)++;
       i++;
     }
     return;
   }
   while (i < s_t1) {
      addordlist(tranlist1[i], sublist1, *s_s1, &ok);
      if (ok) (*s_s1)++;
      i++;
   }
}

void gentran(INT_T s_list,
             INT_T *list,
             INT_S s,
             state_node *t)
{
   /* Generate transitions by self-looping with labels in list */
   INT_S i;
   INT_T j;
   INT_B ok;

   for (i=0L; i < s; i++) {
      for (j=0; j < s_list; j++) {
         addordlist1(list[j], i, &t[i].next, t[i].numelts, &ok);
         if (ok) t[i].numelts++;
      }
   }
}

void meet2(INT_S s1,
           state_node *t1,
           INT_S s2,
           state_node *t2,
           INT_S *s3,
           state_node **t3,
           INT_S **macro_ab,
           INT_S **macro_c)
{
   INT_S t1i, t2j;
   INT_T colptr1, colptr2;
   INT_T tran1, tran2;
   INT_S srcstate, newstate, macrostate;
   INT_S a,b,i;

   if (s1 == 0L || s2 == 0L) {
      *s3 = 0;
      *t3 = NULL;
      return;
   }
   *s3  = 0;
   *t3  = NULL;
  // *macro_ab = (INT_S*) calloc(s1*s2,sizeof(INT_S));
   *macro_ab = (INT_S*) malloc(sizeof(INT_S)*s1*s2);
  *macro_c  = (INT_S*) malloc(sizeof(INT_S)*s1*s2);

   if ( (*macro_ab == NULL) || (*macro_c == NULL) ) {
      mem_result = 1;
      return;
   }

   for (i=0; i < s1*s2; i++) {
      (*macro_ab)[i] = -1L;
      (*macro_c)[i]  = -1L;
   }

   (*macro_ab)[0] = (*macro_c)[0] = 0L;
   srcstate = newstate = macrostate = 0L;
   t1i = t2j = 0L;
   do {
      colptr1 = 0;
      colptr2 = 0;
      while (colptr1 < t1[t1i].numelts && colptr2 < t2[t2j].numelts) {
         tran1 = t1[t1i].next[colptr1].data1;
         tran2 = t2[t2j].next[colptr2].data1;
         if (tran1 != tran2) {
            if (tran1 < tran2)
               colptr1++;
            else
               colptr2++;
            continue;
         }

         a = t1[t1i].next[colptr1].data2;
         b = t2[t2j].next[colptr2].data2;
         macrostate = (*macro_ab)[b*s1+a];

         if (macrostate == -1L) {
            newstate++;
            (*macro_ab)[b*s1+a] = newstate;
            (*macro_c)[newstate] = b*s1+a;

            insertlist4(srcstate, tran1, newstate, s3, t3);
         } else {
            insertlist4(srcstate, tran1, macrostate, s3, t3);
         }
         colptr1++;
         colptr2++;
      }

      srcstate++;
      a = (*macro_c)[srcstate];
      if (a != -1L) {
        t1i = a % s1;
        t2j = a / s1;
      }

   } while (srcstate <= newstate);

   resize_des(t3,*s3,newstate+1);
   *s3 = newstate+1;

   (*t3)[0].reached = true;
   for (i=0; i < *s3; i++) {
     a = (*macro_c)[i];
     (*t3)[i].marked = t1[a % s1].marked && t2[a / s1].marked;
   }

   /* Should be safe because the size is smaller than before */
   *macro_c = (INT_S*) realloc(*macro_c, sizeof(INT_S)*(*s3));
}

/* For nonconflict use only */
void nc_meet2(INT_S s1,
           state_node *t1,
           INT_S s2,
           state_node *t2,
           INT_S *s3,
           state_node **t3,
           INT_S **macro_ab,
           INT_S **macro_c)
{
   INT_S t1i, t2j;
   INT_T colptr1, colptr2;
   INT_T tran1, tran2;
   INT_S srcstate, newstate, macrostate;
   INT_S a,b,i;

   if (s1 == 0L || s2 == 0L) {
      *s3 = 0;
      *t3 = NULL;
      return;
   }
   *s3  = 0;
   *t3  = NULL;

   *macro_ab = (INT_S*) malloc(sizeof(INT_S)*s1*s2);
   *macro_c  = (INT_S*) malloc(sizeof(INT_S)*s1*s2);

   if ( (*macro_ab == NULL) || (*macro_c == NULL) ) {
      mem_result = 1;
      return;
   }

   for (i=0; i < s1*s2; i++) {
      (*macro_ab)[i] = -1L;
      (*macro_c)[i]  = -1L;
   }

   (*macro_ab)[0] = (*macro_c)[0] = 0L;
   srcstate = newstate = macrostate = 0L;
   t1i = t2j = 0L;
   do {
      colptr1 = 0;
      colptr2 = 0;
      while (colptr1 < t1[t1i].numelts && colptr2 < t2[t2j].numelts) {
         tran1 = t1[t1i].next[colptr1].data1;
         tran2 = t2[t2j].next[colptr2].data1;
         if (tran1 != tran2) {
            if (tran1 < tran2)
               colptr1++;
            else
               colptr2++;
            continue;
         }

         a = t1[t1i].next[colptr1].data2;
         b = t2[t2j].next[colptr2].data2;
         macrostate = (*macro_ab)[b*s1+a];

         if (macrostate == -1L) {
            newstate++;
            (*macro_ab)[b*s1+a] = newstate;
            (*macro_c)[newstate] = b*s1+a;

            /* The line below differs from meet2 function */
            insertlist4(newstate, tran1, srcstate, s3, t3);
         } else {
	    /* The line below differs from meet2 function */
            insertlist4(macrostate, tran1, srcstate, s3, t3);
         }
         colptr1++;
         colptr2++;
      }

      srcstate++;
      a = (*macro_c)[srcstate];
      if (a != -1L) {
        t1i = a % s1;
        t2j = a / s1;
      }

   } while (srcstate <= newstate);

   resize_des(t3,*s3,newstate+1);
   *s3 = newstate+1;

   (*t3)[0].reached = true;
   for (i=0; i < *s3; i++) {
     a = (*macro_c)[i];
     (*t3)[i].marked = t1[a % s1].marked && t2[a / s1].marked;
   }

   /* Should be safe because the size is smaller than before */
   *macro_c = (INT_S*) realloc(*macro_c, sizeof(INT_S)*(*s3));
}

/* merge two forcible lists together */
void merge_forcible(INT_T s1, INT_T *t1, INT_S *s2, INT_T **t2)
{
   int i; 
   
   for (i = 0; i < s1; i++) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (*s2 > 1) {
	 lower = 1;
	 upper = (INT_T)*s2;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ( t1[i] == (*t2)[pos-1]) {
	       found = true;
	       pos = pos-1;
	    } else if (t1[i] > (*t2)[pos-1]) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
	 
	 if (found == false) {
	    if (t1[i] < (*t2)[pos-1])
	       pos--;
	 }
      } else if (*s2 == 1) {
	 if (t1[i] == (*t2)[0]) {
	    found = true;
	    pos = 0;
	 } else if (t1[i] > (*t2)[0]) {
	    pos = 1;
	 }
      }
      if (found == false) {
	 *t2 = (INT_T*) realloc(*t2, ++(*s2) * sizeof(INT_T));
	 if (pos < *s2 - 1) {
	    memmove(&(*t2)[pos+1], &(*t2)[pos], 
		    (*s2 - 1 - pos) * sizeof(INT_T));
	 }
	 (*t2)[pos] = t1[i];
      }
   }
}

/* remove elements of first list from second list */
void remove_alt_forcible(INT_S s1, INT_T *t1, INT_S *s2, INT_T **t2)
{
   int i; 
   
   for (i = 0; i < s1; i++) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (*s2 > 1) {
	 lower = 1;
	 upper = (INT_T)*s2;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ( t1[i] == (*t2)[pos-1]) {
	       found = true;
	       pos = pos-1;
	    } else if (t1[i] > (*t2)[pos-1]) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
	 
      } else if (*s2 == 1) {
	 if (t1[i] == (*t2)[0]) {
	    found = true;
	    pos = 0;
	 } else if (t1[i] > (*t2)[0]) {
	    pos = 1;
	 }
      }
      if (found == true) {
	 if (pos < *s2 - 1) {
	    memmove(&(*t2)[pos], &(*t2)[pos+1], 
		    (*s2 - 1 - pos) * sizeof(INT_T));
	 }
	 *t2 = (INT_T*) realloc(*t2, --(*s2) * sizeof(INT_T));
      }
   }
}

/* remove elements of first list from second list */
void set_aforcible(INT_S s1, INT_T *t1, INT_T *s2, timed_event **t2, 
		   INT_B flag)
{
   int i; 
   
   for (i = 0; i < s1; i++) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (*s2 > 1) {
	 lower = 1;
	 upper = *s2;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ( t1[i] == (*t2)[pos-1].label) {
	       found = true;
	       pos = pos-1;
	    } else if (t1[i] > (*t2)[pos-1].label) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
	 
      } else if (s1 == 1) {
	 if (t1[i] == (*t2)[0].label) {
	    found = true;
	    pos = 0;
	 } else if (t1[i] > (*t2)[0].label) {
	    pos = 1;
	 }
      }
      if (found == true) {
	 (*t2)[pos].forcible = flag;
      }
   }
}

/* merge two forcible lists of ADS for the comp procedure together */
int merge_aforcible(INT_T s1, timed_event *t1, INT_T *s2, timed_event **t2)
{
   int i; 
   
   for (i = 0; i < s1; i++) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (*s2 > 1) {
	 lower = 1;
	 upper = *s2;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ( t1[i].label == (*t2)[pos-1].label) {
	       found = true;
	       pos = pos-1;
	    } else if (t1[i].label > (*t2)[pos-1].label) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
	 
	 if (found == false) {
	    if (t1[i].label < (*t2)[pos-1].label)
	       pos--;
	 }
      } else if (*s2 == 1) {
	 if (t1[i].label == (*t2)[0].label) {
	    found = true;
	    pos = 0;
	 } else if (t1[i].label > (*t2)[0].label) {
	    pos = 1;
	 }
      }
      if (found == false) {
	 *t2 = (timed_event*) realloc(*t2, ++(*s2) * sizeof(timed_event));
	 if (pos < *s2 - 1) {
	    memmove(&(*t2)[pos+1], &(*t2)[pos], 
		    (*s2 - 1 - pos) * sizeof(timed_event));
	 }
	 memcpy(&(*t2)[pos], &t1[i], sizeof(timed_event));
      } else {
	 (*t2)[pos].low = max((*t2)[pos].low, t1[i].low);
	 (*t2)[pos].upper = min((*t2)[pos].upper, t1[i].upper);
	 if ((*t2)[pos].low > (*t2)[pos].upper)
	    return 1;
      }
   }
   return 0;
}

/* merge elements of list 1 in list 2 with default timebounds */
void merge_adeftime(INT_T s_list, INT_T *list, INT_T *s2, timed_event **t2)
{
   int i; 
   
   for (i = 0; i < s_list; i++) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (*s2 > 1) {
	 lower = 1;
	 upper = *s2;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ( list[i] == (*t2)[pos-1].label) {
	       found = true;
	       pos = pos-1;
	    } else if (list[i] > (*t2)[pos-1].label) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
	 
	 if (found == false) {
	    if (list[i] < (*t2)[pos-1].label)
	       pos--;
	 }
      } else if (*s2 == 1) {
	 if (list[i] == (*t2)[0].label) {
	    found = true;
	    pos = 0;
	 } else if (list[i] > (*t2)[0].label) {
	    pos = 1;
	 }
      }
      if (found == false) {
	 *t2 = (timed_event*) realloc(*t2, ++(*s2) * sizeof(timed_event));
	 if (pos < *s2 - 1) {
	    memmove(&(*t2)[pos+1], &(*t2)[pos], 
		    (*s2 - 1 - pos) * sizeof(timed_event));
	 }
	 (*t2)[pos].label = list[i];
	 (*t2)[pos].forcible = false;
	 (*t2)[pos].low = 0;
	 (*t2)[pos].upper = MAX_TIME;
      }
   }
}

void sync2(INT_S s1,
           state_node *t1,
           INT_S s2,
           INT_T *t2,
           INT_S s3,
           state_node *t3,
	   INT_S s4,
	   INT_T *t4,
	   INT_S *s5,
	   state_node **t5,
	   INT_S *s6,
	   INT_T **t6,
           INT_S **macro_ab,
           INT_S **macro_c)
{
    INT_T* tranlist1, *tranlist2, *sublist1, *sublist2;
    INT_T  s_t1, s_t3, s_s1, s_s3;

    s_t1 = s_t3 = s_s1 = s_s3 = 0;
    tranlist1 = tranlist2 = sublist1 = sublist2 = NULL;
    if (s1 == 0 || s3 == 0) {
      *s5 = 0;
      *t5 = NULL;
      *s6 = 0;
      *t6 = NULL;
      return;
    }

    gentranlist(s1, t1, &s_t1, &tranlist1);
    gentranlist(s3, t3, &s_t3, &tranlist2);
    gensublist(s_t1, tranlist1,
               s_t3, tranlist2,
               &s_s1, &sublist1,
               &s_s3, &sublist2);

    gentran(s_s3, sublist2, s1, t1);
    gentran(s_s1, sublist1, s3, t3);
    meet2(s1, t1, s3, t3, s5, t5, macro_ab, macro_c);
   
    *s6 = s2;
    *t6 = (INT_T*) calloc(s2,sizeof(INT_T));
    memcpy(*t6, t2, sizeof(INT_T) * s2);
    merge_forcible((INT_T)s4, t4, s6, t6);

    free(tranlist1);
    free(tranlist2);
    free(sublist1);
    free(sublist2);
}

void comp2(INT_S s1, state_node *t1, INT_T s2, timed_event *t2,
           INT_S s3, state_node *t3, INT_T s4, timed_event *t4,
	   INT_S *s5, state_node **t5, INT_T *s6, timed_event **t6,
           INT_S **macro_ab, INT_S **macro_c)
{
    INT_T* tranlist1, *tranlist2, *sublist1, *sublist2;
    INT_T  s_t1, s_t3, s_s1, s_s3;
    int ok;

    s_t1 = s_t3 = s_s1 = s_s3 = 0;
    tranlist1 = tranlist2 = sublist1 = sublist2 = NULL;
    if (s1 == 0 || s3 == 0) {
      *s5 = 0;
      *t5 = NULL;
      *s6 = 0;
      *t6 = NULL;
      return;
    }

    gentranlist(s1, t1, &s_t1, &tranlist1);
    gentranlist(s3, t3, &s_t3, &tranlist2);
    gensublist(s_t1, tranlist1,
               s_t3, tranlist2,
               &s_s1, &sublist1,
               &s_s3, &sublist2);

    gentran(s_s3, sublist2, s1, t1);
    gentran(s_s1, sublist1, s3, t3);
    meet2(s1, t1, s3, t3, s5, t5, macro_ab, macro_c);
   
    *s6 = s2;
    *t6 = (timed_event*) calloc(s2,sizeof(timed_event));
    memcpy(*t6, t2, sizeof(timed_event) * s2);
    ok = merge_aforcible(s4, t4, s6, t6);
    if (ok == 1) {
       move(15,0);
       printw("Condition l < u violated ! Undefined ! Aborted !");
       user_pause();
       mem_result=1;
    }

    free(tranlist1);
    free(tranlist2);
    free(sublist1);
    free(sublist2);
}

/* Breadth first search */
void b_reach(tran_node *init,
             INT_S     s_init,
             state_node **t1,
             INT_S     s1)
{
   INT_T cur;
   INT_S s;
   INT_S es;
   t_queue tq;

   queue_init(&tq);

   enqueue(&tq, s_init);

   while (!queue_empty(&tq)) {
      s = dequeue(&tq);
      for (cur=0; cur < (*t1)[s].numelts; cur++) {
         es = (*t1)[s].next[cur].data2;
         if (!(*t1)[es].reached) {
            enqueue(&tq,es);
            (*t1)[es].reached = true;

         }
      }
   }

   queue_done(&tq);
}

void reversetran(INT_S src,
                 state_node *t1,
                 state_node **t2)
{
   INT_T cur;
   INT_B ok;
   INT_S target;

   cur = 0;
   while (cur < t1[src].numelts) {
      target = t1[src].next[cur].data2;
      addordlist1(t1[src].next[cur].data1, src,
                  &(*t2)[target].next, (*t2)[target].numelts, &ok);
      if (ok) (*t2)[target].numelts++;
      cur++;
   }
}


void coreach1(tran_node  *init,
              INT_S      s_init,
              INT_S      s1,
              state_node **t1,
              char*      un)
{
   INT_B ok, ok2, found;
   INT_T cur;
   INT_S s;
   INT_S es;
   INT_S i;
   char* visited;
   t_stack ts;

   visited = (char*) calloc(s1, sizeof(char));

   pstack_Init(&ts);

   cur = 0;
   s = s_init;

   /* To avoid selfloop, we mark the first state as being visited */
   visited[s] = 1;

   while (!( (cur >= (*t1)[s].numelts) && pstack_IsEmpty(&ts) )) {
      es = (*t1)[s].next[cur].data2;
      if ((*t1)[es].coreach || (*t1)[es].marked) {
         /* Unwind stack to marked all states as coreached */
         do {
             pstack_Pop(&ts, &cur, &s, &ok);
             if (ok)
                (*t1)[s].coreach = true;
         } while (!pstack_IsEmpty(&ts));
         (*t1)[s_init].coreach = true;
         break;
      } else {
         /* Have we visited this state already? */
         found = (visited[es] == 1) || (un[es] == 1);

         if (found == true) {
            cur++;
         } else {
            visited[es] = 1;
            ok2 = pstack_Push(&ts, cur, s);
            if (ok2 == false) {
               mem_result = 1;
               pstack_Done(&ts);
               return;
            }
            s = es;
            cur = 0L;
         }
      }

      if (cur >= (*t1)[s].numelts) {
         do {
            pstack_Pop(&ts, &cur, &s, &ok);
            if (cur < (*t1)[s].numelts && ok)
               cur++;
         } while (!((cur < (*t1)[s].numelts) || pstack_IsEmpty(&ts)));
      }
   }

   if ((*t1)[s_init].coreach == false) {
      /* Mark all others as uncoreachedable also */
      for (i=0; i < s1; i++) {
        if (visited[i] == 1)
           un[i] = 1;
      }
   }

   pstack_Done(&ts);
   free(visited);
}

void coreach2(INT_S s1,
              state_node **t1)
{
   INT_S state;
   char* un;
 
   if (!(*t1)[0].marked)
     (*t1)[0].coreach = false;

   for (state=1; state < s1; state++)
     (*t1)[state].coreach = false;  

   un = (char*) calloc(s1, sizeof(char));

   for (state=0; state < s1; state++) {
     if ((*t1)[state].marked || (*t1)[state].coreach) {
       (*t1)[state].coreach = true;
     } else if (un[state] == 1) {
       /* Already determined not a coreachable state */
     } else {
       /* Can we be coreached */
       coreach1((*t1)[state].next, state, s1, t1, un);
     }
   }

   free(un);
}

/* File base coreach */
void _coreach2(INT_S s1,
               state_node **t1)
{
   INT_B ok;
   INT_S i, j, s;
   INT_T jj, e, num;
   FILE *in;
   tran_node *next;

   /* Save DES to file */
/* has to be fixed   filedes("$$$", s1, 0L, *t1);*/

   /* Free transitions */
   for (i=0L; i < s1; i++) {
     if ((*t1)[i].next != NULL) {
       free((*t1)[i].next);
       (*t1)[i].next = NULL;
     }
     (*t1)[i].numelts = 0;
     (*t1)[i].coreach = (*t1)[i].reached;
     (*t1)[i].reached = false;
   }
   (*t1)[0].reached = true;

   /* Read it back */
   /* Skip over marking and other states */
   in = fopen("$$$.des", "rb");
   if (in == NULL) {
      printf("Error reading $$$.des\n");
      exit(1);
   }

   fread(&s, sizeof(INT_S), 1, in);
   fread(&s, sizeof(INT_S), 1, in);

   /* Read over the marked states */
   s = 0L;
   while (s != -1L) {
     fread(&s, sizeof(INT_S), 1, in);
   }

   /* Read the transitions */
   s = 0L;
   while (s != -1L) {
      fread(&s, sizeof(INT_S), 1, in);

      if (s == -1L) break;

      fread(&num, sizeof(INT_T), 1, in);
      next = (tran_node*) malloc(sizeof(tran_node)*num);
      if (num != 0) {
         if ( next == NULL ) {
            printf("Out of memory\n");
            exit(1);
         }
      }
      fread(next, sizeof(tran_node), num, in);

      for (jj=0; jj < num; jj++) {
        e = next[jj].data1;
        j = next[jj].data2;
        addordlist1(e, s, &(*t1)[j].next, (*t1)[j].numelts, &ok);
        if (ok) (*t1)[j].numelts++;
      }

      free(next);
   }
   fclose(in);

   printf("Read back and reverse transitions done\n");

   /* Now do reachable */
   for (i=0; i < s1; i++) {
     if ((*t1)[i].marked) {
       (*t1)[i].reached = true;
       b_reach((*t1)[i].next, i, t1, s1);
     }
   }

   printf("Reach done\n");

   /* Free again */
   /* Free transitions */
   for (i=0L; i < s1; i++) {
     if ((*t1)[i].next != NULL) {
       free((*t1)[i].next);
       (*t1)[i].next = NULL;
     }
     (*t1)[i].numelts = 0;
   }

   printf("Freeing memory done\n");

   /* Read it back */
   /* Skip over marking and other states */
   in = fopen("$$$.des", "rb");
   if (in == NULL) {
      printf("Error reading $$$.des\n");
      exit(1);
   }

   fread(&s, sizeof(INT_S), 1, in);
   fread(&s, sizeof(INT_S), 1, in);

   /* Read over the marked states */
   s = 0L;
   while (s != -1L) {
     fread(&s, sizeof(INT_S), 1, in);
   }

   s = 0L;
   while (s != -1L) {
      fread(&s, sizeof(INT_S), 1, in);

      if (s == -1L) break;

      fread(&num, sizeof(INT_T), 1, in);
      (*t1)[s].next = (tran_node*) malloc(sizeof(tran_node)*num);
      if ( (*t1)[s].next == NULL ) {
         printf("Out of memory\n");
         fclose(in);
         exit(1);
      }

      (*t1)[s].numelts = num;
      fread((*t1)[s].next, sizeof(tran_node), num, in);
   }

   fclose(in);
   _unlink("$$$.des");

   printf("Read back done\n");
}

void recode(INT_S s1,
            state_node **t1,
            recode_node *recode_states)
{
   INT_S state, es, new_state;
   INT_T numelts, j, diff;

   for (state=0; state < s1; state++) {
     if ( recode_states[state].reached ) {
        /* Purge transitions that point to dead states */
        j = 0;
        numelts = (*t1)[state].numelts;
        while (j < (*t1)[state].numelts) {
            es = (*t1)[state].next[j].data2;
            if ( !recode_states[es].reached ) {
               diff = (*t1)[state].numelts-(j+1);
               if (diff > 0)
                  memmove(&(*t1)[state].next[j], &(*t1)[state].next[j+1],
                          sizeof(tran_node)*diff);
               (*t1)[state].numelts--;
            } else {
               (*t1)[state].next[j].data2 = recode_states[es].recode;
               j++;
            }
        }

        if (numelts != (*t1)[state].numelts) {
           (*t1)[state].next = (tran_node*) realloc((*t1)[state].next,
                                 sizeof(tran_node)*(*t1)[state].numelts);
        }

        /* Move state over if necessary */
        new_state = recode_states[state].recode;
        if (new_state != state) {
            memmove(&(*t1)[new_state], &(*t1)[state], sizeof(state_node));
            /* Remove all traces of the moved state */
            (*t1)[state].next = NULL;
        }
     } else {
        /* Purge the transitions from this state */
        (*t1)[state].numelts = 0;
        if ( (*t1)[state].next != NULL) {
           free( (*t1)[state].next );
           (*t1)[state].next = NULL;
        }
     }
   }
}

/* remove non existing transitions from forcible list*/
void remove_aforcible(INT_T *s1, timed_event **t1, INT_T s_list, INT_T *list)
{
   int i;

   i = 0;
   while (i < *s1) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (s_list > 1) {
	 lower = 1;
	 upper = s_list;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ((*t1)[i].label == list[pos-1]) {
	       found = true;
	       pos = pos-1;
	    } else if ((*t1)[i].label > list[pos-1]) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
      } else if (s_list == 1) {
	 if ((*t1)[i].label == list[0]) {
	    found = true;
	 }
      }
      if (found == false) {
	 if (i < *s1 - 1) {
	    memmove(&(*t1)[i], &(*t1)[i+1], 
		    (*s1 - 1 - i) * sizeof(timed_event));
	 }
	 *t1 = (timed_event*) realloc(*t1, --(*s1) * sizeof(timed_event));
      } else {
	 i++;
      }	 
   }
}

/* remove non existing transitions from forcible list*/
void remove_forcible(INT_S *s1, INT_T **t1, INT_T s_list, INT_T *list)
{
   int i;

   i = 0;
   while (i < *s1) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (s_list > 1) {
	 lower = 1;
	 upper = s_list;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if ((*t1)[i] == list[pos-1]) {
	       found = true;
	       pos = pos-1;
	    } else if ((*t1)[i] > list[pos-1]) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
      } else if (s_list == 1) {
	        if ((*t1)[i] == list[0]) {
	          found = true;
	        }
        }
      if (found == false) {
	      if (i < *s1 - 1) {
	         memmove(&(*t1)[i], &(*t1)[i+1], 
		    (*s1 - 1 - i) * sizeof(INT_T));
	      }
	      *t1 = (INT_T*) realloc(*t1, --(*s1) * sizeof(INT_T));
     } else {
	 i++;
     }	 
   }
}

/* Faster Trim and less memory */
void trima1(INT_S *s1, state_node **t1, INT_T *s2, timed_event **t2)
{
   INT_S s3, state;
   recode_node *recode_states;
   INT_S num_reachable;
   INT_T s_list, *list;

   if (*s1 <= 0) return;

   for (state=0; state < *s1; state++) 
      (*t1)[state].reached = false; 

   (*t1)[0].reached = true;
   b_reach((*t1)[0].next, 0L, t1, *s1);
   coreach2(*s1, t1);

   s3 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached && (*t1)[state].coreach)
       s3++;
     else
       (*t1)[state].reached = false;
   }
   if (s3 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) calloc(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode(*s1, t1, recode_states);

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;

   gentranlist(*s1, *t1, &s_list, &list);
   remove_aforcible(s2, t2, s_list, list);
   
   free(recode_states);
}

/* Faster Trim and less memory */
void trim1(INT_S *s1, state_node **t1, INT_S *s2, INT_T **t2)
{
   INT_S s3, state;
   recode_node *recode_states;
   INT_S num_reachable;
   INT_T s_list, *list;

   if (*s1 <= 0) return;

   for (state=0; state < *s1; state++) 
      (*t1)[state].reached = false; 

   (*t1)[0].reached = true;
   b_reach((*t1)[0].next, 0L, t1, *s1);
   coreach2(*s1, t1);

   s3 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached && (*t1)[state].coreach)
       s3++;
     else
       (*t1)[state].reached = false;
   }
   if (s3 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) calloc(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode(*s1, t1, recode_states);

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;
   
   gentranlist(*s1, *t1, &s_list, &list);
   remove_forcible(s2, t2, s_list, list);

   free(recode_states);
}


void recode2(INT_S s1,
             state_node **t1,
             recode_node *recode_states,
             INT_S *macro_c)
{
   INT_S state, es, new_state;
   INT_T numelts, j, diff;

   for (state=0; state < s1; state++) {
     if ( recode_states[state].reached ) {
        /* Purge transitions that point to dead states */
        j = 0;
        numelts = (*t1)[state].numelts;
        while (j < (*t1)[state].numelts) {
            es = (*t1)[state].next[j].data2;
            if ( !recode_states[es].reached ) {
               diff = (*t1)[state].numelts-(j+1);
               if (diff > 0)
                  memmove(&(*t1)[state].next[j], &(*t1)[state].next[j+1],
                          sizeof(tran_node)*diff);
               (*t1)[state].numelts--;
            } else {
               (*t1)[state].next[j].data2 = recode_states[es].recode;
               j++;
            }
        }

        if (numelts != (*t1)[state].numelts) {
           (*t1)[state].next = (tran_node*) realloc((*t1)[state].next,
                                 sizeof(tran_node)*(*t1)[state].numelts);
        }

        /* Move state over if necessary */
        new_state = recode_states[state].recode;
        if (new_state != state) {
            memmove(&(*t1)[new_state], &(*t1)[state], sizeof(state_node));
            /* Remove all traces of the moved state */
            (*t1)[state].next = NULL;
            macro_c[new_state] = macro_c[state];
        }
     } else {
        /* Purge the transitions from this state */
        (*t1)[state].numelts = 0;
        if ( (*t1)[state].next != NULL) {
           free( (*t1)[state].next );
           (*t1)[state].next = NULL;
        }
     }
   }
}

/* Pre-condition.
   DES reach is set to false if you want to purge the bad state
 */
void purgebadstates(INT_S s1,
                    state_node **t1)
{
   INT_S state, es;
   INT_T numelts, j, diff;

   for (state=0; state < s1; state++) {
     if ( (*t1)[state].reached ) {
        /* Purge transitions that point to dead states */
        j = 0;
        numelts = (*t1)[state].numelts;
        while (j < (*t1)[state].numelts) {
            es = (*t1)[state].next[j].data2;
            if ( !(*t1)[es].reached ) {
               diff = (*t1)[state].numelts-(j+1);
               if (diff > 0)
                  memmove(&(*t1)[state].next[j], &(*t1)[state].next[j+1],
                          sizeof(tran_node)*diff);
               (*t1)[state].numelts--;
            } else {
               j++;
            }
        }

        if (numelts != (*t1)[state].numelts) {
           (*t1)[state].next = (tran_node*) realloc((*t1)[state].next,
                                 sizeof(tran_node)*(*t1)[state].numelts);
        }
     } else {
        /* Purge the transitions from this state */
        (*t1)[state].numelts = 0;
        if ( (*t1)[state].next != NULL) {
           free( (*t1)[state].next );
           (*t1)[state].next = NULL;
        }
     }
   }
}

void _trim2(INT_S *s1,
            state_node **t1,
            INT_S *macro_c)
{
   INT_S s2, state;
   recode_node *recode_states;
   INT_S num_reachable;

   if (*s1 <= 0) return;

   (*t1)[0].reached = true;
   b_reach((*t1)[0].next, 0L, t1, *s1);
   _coreach2(*s1, t1);

   s2 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached && (*t1)[state].coreach)
       s2++;
     else
       (*t1)[state].reached = false;
   }
   if (s2 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) calloc(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode2(*s1, t1, recode_states, macro_c);

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;

   free(recode_states);
}

void trim2(INT_S *s1, state_node **t1, INT_S *s2, INT_T **t2, 
           INT_S *macro_c)
{
   INT_S s3, state;
   INT_T s_list, *list;
   recode_node *recode_states;
   INT_S num_reachable;

   if (*s1 <= 0) return;

   (*t1)[0].reached = true;
   b_reach((*t1)[0].next, 0L, t1, *s1);
   coreach2(*s1, t1);

   s3 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached && (*t1)[state].coreach)
       s3++;
     else
       (*t1)[state].reached = false;
   }
   if (s3 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) calloc(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode2(*s1, t1, recode_states, macro_c);

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;

   gentranlist(*s1, *t1, &s_list, &list);
   remove_forcible(s2, t2, s_list, list);

   free(recode_states);
}

void trim_endstates(INT_S *s,
                    state_node **t)
{
   INT_S size, i;

   if (*s <= 0) return;

   /* Mark all the reachable states */
   /* Remove all end states that are not referenced */
   for (i=0; i < *s; i++) {
      (*t)[i].reached = false;
   }
   (*t)[0].reached = true;
   b_reach((*t)[0].next, 0L, t, *s);

   size = *s;
   for (i=*s-1; i >= 0; i--) {
     if ( ((*t)[i].reached == false) &&
          ((*t)[i].vocal == 0) &&
          ((*t)[i].numelts == 0) &&
          ((*t)[i].marked == 0) ) {
       size = i+1;
     } else {
       break;
     }
   }

   if (size != *s) {
     *t = (state_node*) realloc(*t, sizeof(state_node)*(size));
     *s = size;
   }
}

void uncontrolist(INT_S state,
                  state_node *t,
                  INT_T *numlist, INT_B *tickinlist)
{
   INT_T i;

   *tickinlist = false;
   *numlist = 0;

   /* this is only correct for a sorted event list, assuming TICK 0*/
   if ( t[state].numelts > 0 && t[state].next[0].data1 == 0 )
      *tickinlist = true;
   /* Count the number of uncontrollable events */
   for (i=0; i < t[state].numelts; i++) {
      if ( t[state].next[i].data1 % 2 == 0)
         (*numlist)++;
   }
}

void uncontrolist2(INT_S state,
                   state_node *t,
                   INT_T *numlist)
{
   INT_T i;
   INT_S es;

   *numlist = 0;
   /* Count the number of uncontrollable events */
   for (i=0; i < t[state].numelts; i++) {
      if (t[state].next[i].data1 % 2 == 0) {
         es = t[state].next[i].data2;
         if (t[es].reached)
            (*numlist)++;
      }
   }
}

void cp_tim_info(INT_S s1, state_node *t1, INT_S *s2, state_node **t2, 
		 INT_S *macro_c)
{
   INT_S i;
   state_node *ost, *nst;
   
   for (i=0; i < *s2; i++) {
      ost = &(t1[macro_c[i] % s1]);
      nst = &((*t2)[i]);
      /* Copy state_info */
      nst->nstinfo = (state_info*) calloc(1, sizeof(state_info));
      nst->nstinfo[0].state = ost->nstinfo[0].state;
      /* Copy timer_info */
      nst->ntimer = (timer_info*) calloc(ost->numtimer,sizeof(timer_info));
      nst->numtimer = ost->numtimer;
      memcpy(nst->ntimer, ost->ntimer, ost->numtimer * sizeof(timer_info));
   }
}

void shave1(INT_S s1, state_node *t1, INT_S s2, INT_T *t2,
	    INT_S *s3, state_node **t3, INT_S *s4, INT_T **t4,
            INT_S *macro_c)
{
   INT_S state, state1, tmp;
   INT_T numlist1, numlist2;
   INT_T s_difflist, *difflist; 
   INT_B tickinlist;

   if (*s3 == 0)
      return;

   tmp = *s3;
   do {
      tmp = *s3;
      for (state = 0; state < *s3; state++) {
         (*t3)[state].reached = true;
         state1 = macro_c[state] % s1;
         uncontrolist(state1,t1,&numlist1,&tickinlist);
         if (numlist1 != 0) {
             uncontrolist2(state,*t3,&numlist2);
             if (numlist1 != numlist2) {
                if (tickinlist) {
		   gendifflist1(t1[state1].numelts, t1[state1].next,
				(*t3)[state].numelts, (*t3)[state].next,
				&s_difflist, &difflist);
		   if (s_difflist == 1 && difflist[0] == 0 && 
		       exist_forcible((*t3)[state].numelts, 
					(*t3)[state].next,
					*s4, *t4));
		   else 
		      (*t3)[state].reached = false;
		} else {
		      (*t3)[state].reached = false;
		      /* Need to mark this state as to be deleted */
		}
             }
         }
      }
      
      /* Purge all references to the unreached states? */
      purgebadstates(*s3, t3);

      if (*s3 > 0) {
         if ( !(*t3)[0].reached) {
	    free(*t4);
	    *s4 = 0;
	    (*t4) = NULL;
            freedes(*s3, t3);
            *s3 = 0;
            (*t3) = NULL;
            return;
         }
      }

      for (state=1; state < *s3; state++) {
         (*t3)[state].reached = false;
      }
      trim2(s3, t3, s4, t4, macro_c);
//      filetds("TEST", *s3, 0, *t3, *s4, *t4);
   } while (tmp != *s3);
}

 
  


void genlist(INT_T slist1, tran_node *list1, INT_T slist2, tran_node *list2,
	     INT_S s1, INT_T *t1, INT_S s, state_node **t)
{
   INT_T j1, j2,jj, *tmplist;
   INT_S s_tmplist;
   INT_B ok,Add;
   INT_B forcible;
   
   forcible = false;
   s_tmplist = 0;
   tmplist = (INT_T*) calloc(max(slist1,slist2), sizeof(INT_T));
   j1 = j2 = 0;
   /* relying on ordered list and TICK = 0*/
   if (slist1 > 0 && slist2 > 0 && 
       (list1[0].data1 == TICK && list2[0].data1 != TICK))
      forcible = true;
   while ((j1 < slist1) && (j2 < slist2)) {
     if (list1[j1].data1 == list2[j2].data1) {
        tmplist[s_tmplist++] = list1[j1].data1;
        j1++; j2++;
     } else if (list1[j1].data1 > list2[j2].data1) {
        j2++;
     } else {        
        addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
        if (ok) (*t)[s].numelts++;

        j1++;
     }
   }

   while (j1 < slist1) {
     addordlist1(list1[j1].data1, 0, &(*t)[s].next, (*t)[s].numelts, &ok);
     if (ok) (*t)[s].numelts++;
     j1++;
   }
   
//if ((s==1) && ((*t)[s].vocal==0)) {
     //if (s==1) {
    //forcible=false;
    
   //(*t)[s].vocal=0;
   forcible=false;
   if (forcible) {
       //printw("amazing");
       /*      if (s_tmplist == 0) {
	   printw("There is something terribly wrong here !"); 
	   user_pause();
       } else {*/
      remove_forcible(&s_tmplist, &tmplist, (INT_T)s1, t1);
         /* if (s_tmplist == 0) {
	    printw("There is something terribly wrong here !"); 
	    user_pause();
	    } else {*/
      for (j1 = 0; j1 < s_tmplist; j1++) {
	       
     		 Add=true;
             for (jj=0; jj< (*t)[s].numelts; jj++)
	               if ( tmplist[j1]== (*t)[s].next[jj].data1 ) 
	                        Add=false;

		     if (Add) {
		      
				 addunordlist1(tmplist[j1], 0, &(*t)[s].next, (*t)[s].numelts, &ok);
	      
	             if (ok) {
	                (*t)[s].numelts++;
	                (*t)[s].vocal++;
				 }
             }
      }
      
   }
//}   
   free(tmplist);
   
}

void genstatetran(INT_S state,
                  state_node *t,
                  INT_T *s_state_tranlist,
                  INT_T **state_tranlist)
{
   INT_T i;
   INT_B ok;

   *state_tranlist = NULL;
   *s_state_tranlist = 0;

   for (i=0; i < t[state].numelts; i++) {
     addordlist(t[state].next[i].data1, state_tranlist, *s_state_tranlist, &ok);
     if (ok) (*s_state_tranlist)++;
   }
}

INT_B exist_forcible(INT_T s1, tran_node *t1, INT_S s2, INT_T *t2)
{
   int i;
   
   for (i = 0; i < s1; i++) {
      /* Do a binary search. */
      INT_B found;
      INT_T pos, lower, upper;
      found = false;
      pos = 0;
      if (s2 > 1) {
	 lower = 1;
	 upper = (INT_T)s2;
	 while ( (found == false) && (lower <= upper) ) {
	    pos = (lower + upper) / 2;
	    if (t1[i].data1 == t2[pos-1]) {
	       found = true;
	       pos = pos-1;
	    } else if (t1[i].data1 > t2[pos-1]) {
	       lower = pos+1;
	    } else {
	       upper = pos-1;
	    }
	 }
	 
	 /* if (found == false) {
	    if (t1[i].data1 < t2[pos-1])
	    pos--;
	    }*/
      } else if (s2 == 1) {
	 if (t1[i].data1 == t2[0]) {
	    found = true;
	    pos = 0;
	 } else if (t1[i].data1 > t2[0]) {
	    pos = 1;
	 }
      }
      if (found == true) 
	 return true;
      /* if (i < *s6 - 1) {
	 memmove(&(*t6)[i], &(*t6)[i+1], 
	    (*s6 - 1 - i) * sizeof(INT_T));
		    }
	 *t6 = (INT_T*) realloc(*t6, --(*s6) * sizeof(INT_T));
	 } else {
	 i++;
	 }	*/ 
   }
   return false;
}


void gendifflist(INT_T s_list1,
                 INT_T *list1,
                 INT_T s_list2,
                 INT_T *list2,
                 INT_T *s_sublist,
                 INT_T **sublist)
{
   INT_T i,j;
   INT_B ok;

   /* Generate sublist (list1-list2) */
   *sublist = NULL;
   *s_sublist = 0;
   i = j = 0;

   while ((i < s_list1) && (j < s_list2)) {
     if (list1[i] == list2[j]) {
       i++; j++;
     } else if (list1[i] > list2[j]) {
       j++;
     } else {
       addordlist(list1[i], sublist, *s_sublist, &ok);
       if (ok) (*s_sublist)++;
       i++;
     }
   }

   /* append the rest of "list1" to "sublist" */
   while (i < s_list1) {
     addordlist(list1[i], sublist, *s_sublist, &ok);
     if (ok) (*s_sublist)++;
     i++;
   }
}

void gendifflist1(INT_T s_list1,
		  tran_node *list1,
		  INT_T s_list2,
		  tran_node *list2,
		  INT_T *s_sublist,
		  INT_T **sublist)
{
   INT_T i,j;
   INT_B ok;
   
   /* Generate sublist (list1-list2) */
   *sublist = NULL;
   *s_sublist = 0;
   i = j = 0;

   while ((i < s_list1) && (j < s_list2)) {
      if (list1[i].data1 == list2[j].data1) {
	 i++; j++;
      } else if (list1[i].data1 > list2[j].data1) {
	 j++;
      } else {
	 if (list1[i].data1 % 2 == 0) {
	 addordlist(list1[i].data1, sublist, *s_sublist, &ok);
	 if (ok) (*s_sublist)++;
	 }
	 i++;
      }
   }
   
   /* append the rest of "list1" to "sublist" */
   while (i < s_list1) {
      if (list1[i].data1 % 2 == 0) {
	 addordlist(list1[i].data1, sublist, *s_sublist, &ok);
	 if (ok) (*s_sublist)++;
      }
      i++;
   }
}

void complement1(INT_S *s,
                 state_node **t,
                 INT_T slist,
                 INT_T *list)
{
   INT_S state;
   INT_B newsize, ok;
   INT_T *tranlist;
   INT_T s_tranlist;

   INT_T *state_tranlist;
   INT_T s_state_tranlist;

   INT_T *new_tranlist;
   INT_T s_new_tranlist;

   INT_T i;

   s_tranlist = 0; tranlist = NULL;
   s_new_tranlist = 0; new_tranlist = NULL;
   s_state_tranlist = 0; state_tranlist = NULL;

   gentranlist(*s, *t, &s_tranlist, &tranlist);

   for (i=0; i < slist; i++) {
      addordlist(list[i],&tranlist, s_tranlist, &ok);
      if (ok) s_tranlist++;
   }

   newsize = false;
   if (*s == 0) {
     newsize = true;
     *t = newdes(1);
   } else {
     for (state=0; state < *s; state++) {
       (*t)[state].marked = !(*t)[state].marked;

       if (state_tranlist != NULL) free(state_tranlist);
       s_state_tranlist = 0;

       genstatetran(state, *t, &s_state_tranlist, &state_tranlist);

       if (s_state_tranlist < s_tranlist) {
          if (newsize == false) {
             *t = (state_node*) realloc(*t, sizeof(state_node)*(*s+1));
      	     newsize = true;
          }

          if (new_tranlist != NULL) free(new_tranlist);
          s_new_tranlist = 0;

          gendifflist(s_tranlist, tranlist,
                      s_state_tranlist, state_tranlist,
                      &s_new_tranlist, &new_tranlist);

          for (i=0; i < s_new_tranlist; i++) {
             addordlist1(new_tranlist[i],*s,&(*t)[state].next,(*t)[state].numelts,&ok);
             if (ok) (*t)[state].numelts++;
          }
       }
     }
   }

   if (newsize) {
     (*t)[*s].numelts = 0;
     (*t)[*s].marked  = true;
     (*t)[*s].vocal   = 0;
     (*t)[*s].nstinfo = NULL;
     (*t)[*s].numtimer= 0;
     (*t)[*s].ntimer  = NULL;
     (*t)[*s].reached = false;
     (*t)[*s].next    = NULL;
     for (i=0; i < s_tranlist; i++) {
        addordlist1(tranlist[i],*s,&(*t)[*s].next,(*t)[*s].numelts,&ok);
        if (ok) (*t)[*s].numelts++;
     }
     (*s)++;
   }

   for(i = 0; i < *s; i ++){
	   if ((*t)[i].nstinfo != NULL) {

		   state_info *p, *q;

		   for (p = (*t)[i].nstinfo; p != NULL; p = q) {
			   q = p->next;
			   free(p);
		   }
		   (*t)[i].nstinfo = NULL;
	   };

	   if ((*t)[i].ntimer != NULL) {
		   free((*t)[i].ntimer);
		   (*t)[i].ntimer = NULL;
	   };
   }

   if (tranlist != NULL) free(tranlist);
   if (state_tranlist != NULL) free(state_tranlist);
   if (new_tranlist != NULL) free(new_tranlist);
}

/* Regular reach */
void reach(INT_S *s1, state_node **t1, INT_S *s2, INT_T **t2)
{
   INT_S s3, state;
   recode_node *recode_states;
   INT_S num_reachable;
   INT_T s_list, *list;

   if (*s1 <= 0) return;

   /* Zero all the reach variables */
   for (state=0; state < *s1; state++) {
      (*t1)[state].reached = false;
   }

   (*t1)[0].reached = true;
   b_reach((*t1)[0].next, 0L, t1, *s1);

   s3 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached)
       s3++;
   }
   if (s3 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) calloc(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode(*s1, t1, recode_states);

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;
   
   gentranlist(*s1, *t1, &s_list, &list);
   remove_forcible(s2, t2, s_list, list);

   free(recode_states);
}

/* Regular reach */
void areach(INT_S *s1, state_node **t1, INT_T *s2, timed_event **t2)
{
   INT_S s3, state;
   recode_node *recode_states;
   INT_S num_reachable;
   INT_T s_list, *list;

   if (*s1 <= 0) return;

   /* Zero all the reach variables */
   for (state=0; state < *s1; state++) {
      (*t1)[state].reached = false;
   }

   (*t1)[0].reached = true;
   b_reach((*t1)[0].next, 0L, t1, *s1);

   s3 = 0;
   for (state = *s1-1L; state >= 0; state--) {
     if ((*t1)[state].reached)
       s3++;
   }
   if (s3 == *s1) {
     return;
   }

   /* Remove all "unreachable states" */
   /* Allocate tempory data structure for new recorded names */
   recode_states = (recode_node*) calloc(*s1,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s1; state++) {
     if ( (*t1)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode(*s1, t1, recode_states);

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*num_reachable);
   *s1 = num_reachable;
   
   gentranlist(*s1, *t1, &s_list, &list);
   remove_aforcible(s2, t2, s_list, list);

   free(recode_states);
}


void compare_tran(INT_S i, INT_S j,
                  state_node *t1, state_node *t2,
                  INT_B *equal,
                  INT_S *mapState,
                  state_pair **iEj,
                  INT_S *s_iEj)
{
   INT_T a,b;
   INT_B ok;
   INT_S entr1, entr2;
   t_stack ts;

   pstack_Init(&ts);

   a = 0;
   b = 0;

   for(;;) {
LABEL1:
      if (a < t1[i].numelts) {
	 if (t1[i].next[a].data1 != t2[j].next[b].data1) {
	    *equal = false;
	 } else {
	    addstatepair(i,j,iEj,*s_iEj,&ok);
	    if (ok) (*s_iEj)++;
	    entr1 = t1[i].next[a].data2;
	    entr2 = t2[j].next[b].data2;
	/*    *equal = (entr1 == entr2) && (mapState[entr1] == mapState[entr2]);
	*/    
	    if ((mapState[entr1] != -1) && (mapState[entr2] == -1))
/*             *equal = (entr1 == entr2) && (mapState[entr1] == mapState[entr2]); */
               *equal = false;
         else
             *equal = mapState[entr1] == entr2; 
        
        if (!(*equal)) {
	       *equal = instatepair(entr1,entr2,iEj,*s_iEj);
	    }
	    
	    if (!(*equal)) {
	       if ((entr1 !=i) || ((entr1==j) && (entr2 > j)) ) {
		  addstatepair(i,j,iEj,*s_iEj,&ok);
		  if (ok) (*s_iEj)++;
		  *equal = (t1[entr1].marked == t2[entr2].marked) &&
		     (t1[entr1].vocal == t2[entr2].vocal) &&
		     (t1[entr1].numelts == t2[entr2].numelts);
		  if (*equal) {
		     ok = pstack_Push(&ts,a,i);
		     ok = pstack_Push(&ts,b,j);
		     i = entr1;
		     j = entr2;
		     a = 0;
		     b = 0;
		     goto LABEL1;
		  }
	       }
	    }
LABEL2:
	    if (*equal) {
	       a++;
	       b++;
	       goto LABEL1;
	    }
	 }
      } else {
	 if (b < t2[j].numelts) {
	    *equal = false;
	 } else {
	    *equal = true;
	    mapState[i] = j;
	    t1[i].reached = true;
	    t2[j].reached = true;
	 }
      }
      
      if (pstack_IsEmpty(&ts)) {
	 break;
      } else {
	 pstack_Pop(&ts,&b,&j,&ok);
	 pstack_Pop(&ts,&a,&i,&ok);
	 goto LABEL2;
      }
      
   } /*forever*/
   pstack_Done(&ts);
}

void compare_states(INT_S i, INT_S j,
                    INT_B *equal,
                    INT_S *mapState,
                    state_pair **iEj,
                    INT_S *s_iEj,
                    state_node *t1, state_node *t2)
{
   INT_B bothmarked, marktest;

   bothmarked = (t1[i].marked == t2[j].marked);
   marktest = bothmarked && (t1[i].numelts==0) && (t2[j].numelts==0)
              && (t1[i].vocal == t2[j].vocal);
   if (marktest) *equal = true;
   if (!marktest) {
      if (bothmarked && (t1[i].numelts == t2[j].numelts) &&
          t1[i].vocal == t2[j].vocal)
        compare_tran(i,j,t1,t2,equal,mapState,iEj,s_iEj);
      else {
	 *equal = false;
      }
   }
}

void compare_tran2(INT_S i, INT_S j,
                   state_node *t1, state_node *t2,
                   INT_B *equal,
                   INT_S *mapState,
                   state_pair **iEj,
                   INT_S *s_iEj)
{
   INT_T a,b;
   INT_B ok;
   INT_S entr1, entr2;
   t_stack ts;

   pstack_Init(&ts);

   a = 0;
   b = 0;

   for(;;) {
LABEL1:
     if (a < t1[i].numelts) {
       if (t1[i].next[a].data1 != t2[j].next[b].data1)
         *equal = false;
       else {
         addstatepair(i,j,iEj,*s_iEj,&ok);
         if (ok) (*s_iEj)++;
         entr1 = t1[i].next[a].data2;
         entr2 = t2[j].next[b].data2;
      //   *equal = (entr1 == entr2) && (mapState[entr1] == mapState[entr2]);
         if ((mapState[entr1] != -1) && (mapState[entr2] == -1))
/*             *equal = (entr1 == entr2) && (mapState[entr1] == mapState[entr2]); */
               *equal = false;
         else
             *equal = mapState[entr1] == entr2; 
         
         if (!(*equal)) {
            *equal = instatepair(entr1,entr2,iEj,*s_iEj);
         }
         if (!(*equal)) {
/*         if ((entr1 !=i) || ((entr1==j) && (entr2 > j)) ) { */
             addstatepair(i,j,iEj,*s_iEj,&ok);
             if (ok) (*s_iEj)++;
             *equal = (t1[entr1].marked == t2[entr2].marked) &&
                      (t1[entr1].vocal == t2[entr2].vocal) &&
                      (t1[entr1].numelts == t2[entr2].numelts);
             if (*equal) {
                ok = pstack_Push(&ts,a,i);
                ok = pstack_Push(&ts,b,j);
                i = entr1;
                j = entr2;
                a = 0;
                b = 0;
                goto LABEL1;
             }
/*         } */
         }
LABEL2:
         if (*equal) {
            a++;
            b++;
            goto LABEL1;
         }
       }
     } else {
        if (b < t2[j].numelts)
          *equal = false;
        else
          *equal = true;
     }

     if (pstack_IsEmpty(&ts)) {
        break;
     } else {
        pstack_Pop(&ts,&b,&j,&ok);
        pstack_Pop(&ts,&a,&i,&ok);
        goto LABEL2;
     }

  } /*forever*/
  pstack_Done(&ts);
}

void compare_states2(INT_S i, INT_S j,
                     INT_B *equal,
                     INT_S *mapState,
                     state_pair **iEj,
                     INT_S *s_iEj,
                     state_node *t1, state_node *t2)
{
   INT_B bothmarked, marktest;

   bothmarked = (t1[i].marked == t2[j].marked);
   marktest = bothmarked && (t1[i].numelts==0) && (t2[j].numelts==0)
              && (t1[i].vocal == t2[j].vocal);
   if (marktest) *equal = true;
   if (!marktest) {
      if (bothmarked && (t1[i].numelts == t2[j].numelts) &&
          t1[i].vocal == t2[j].vocal)
        compare_tran2(i,j,t1,t2,equal,mapState,iEj,s_iEj);
      else
        *equal = false;
   }
}

void addrow(INT_S i, part_node *pn)
{
   pn[i].next = (INT_S*) malloc(sizeof(INT_S));
   if ( pn[i].next == NULL ) {
      mem_result = 1;
      return;
   }
   pn[i].numelts = 1;
   pn[i].next[0] = i;
}

void addcolumn(INT_S i, INT_S j,
               part_node *pn)
{
   INT_S pos;

   if (pn[i].numelts == 0) return;    /* State does not exist */

   /* Append to the end */
   pos = pn[i].numelts;
   pn[i].numelts++;
   pn[i].next = (INT_S*) realloc(pn[i].next, sizeof(INT_S)*pn[i].numelts);
   pn[i].next[pos] = j;
}

void recode_min(INT_S s1,
                state_node *t1,
                INT_S s2,
                state_node *t2,
                INT_S *mapState)
{
   INT_S i,jj;
   INT_T ee,j;
   INT_S classlist;
   INT_B ok;

   for (i=0; i < s1; i++) {
      classlist = mapState[i];
      t2[classlist].marked = t1[i].marked;
      t2[classlist].vocal  = t1[i].vocal;
      for (j=0; j< t1[i].numelts; j++) {
         ee = t1[i].next[j].data1;
         jj = mapState[t1[i].next[j].data2];
         addordlist1(ee, jj, &t2[classlist].next, t2[classlist].numelts, &ok);
         if (ok) {
            t2[classlist].numelts++;
         }
      }
   }
}

void fix_partition(INT_S s1,
                   INT_S *mapState,
                   part_node *pn)
{
   INT_S kk,mm,nn;
   INT_S row_index, col_index;

   for (kk=0; kk < 2; kk++) {
     for (mm=0; mm < s1; mm++) {
       if (pn[mm].numelts > 0) {
          row_index = mm;
          for (nn=0; nn < pn[mm].numelts; nn++) {
             col_index = pn[mm].next[nn];
             if (mapState[col_index] > row_index)
                mapState[col_index] = row_index;
             if (mapState[row_index] > mapState[col_index])
                mapState[row_index] = mapState[col_index];
          }
       }
    }
  }
}

void free_part(INT_S s1,
               part_node **pn)
{
   INT_S i;

   for (i=0; i < s1; i++) {
     if ( (*pn)[i].next != NULL )
       free((*pn)[i].next);
   }
   free(*pn);
}

void build_partition(INT_S s1,
                     state_node *t1,
                     INT_S *mapState,
                     INT_S *s2)
{
   INT_S i, j, state;
   part_node *pn;
   INT_S *ord_states;
   INT_S classnum;
   INT_B equal_class;
   state_pair *iEj;
   INT_S s_iEj;

   *s2 = s1;
   pn = NULL;
   iEj = NULL;

   pn = (part_node*) calloc(s1, sizeof(part_node));
   if (pn == NULL) {
     mem_result = 1;
     return;
   }

   ord_states = (INT_S*) calloc(s1, sizeof(INT_S));
   if (ord_states == NULL) {
     free(pn);
     mem_result = 1;
     return;
   }

   s_iEj = 0;

   for (i=0; i < s1; i++) {
     mapState[i] = i;
     ord_states[i] = i;
   }

   classnum = -1;
   for (state=0; state < s1; state++) {
     i = ord_states[state];
     if (i != -1) {
        addrow(i,pn);
        ord_states[i] = -1;
        classnum++;
        mapState[i] = classnum;
        for (j=i+1; j < s1; j++) {
          if (t1[i].numelts != t1[j].numelts) continue;
          if (iEj != NULL) {
            free(iEj);
            iEj = NULL;
            s_iEj = 0;
          }
          equal_class = false;
          compare_states2(i,j,&equal_class,mapState,&iEj,&s_iEj,t1,t1);
          if (equal_class) {
             mapState[j] = mapState[i];
             addcolumn(i,j,pn);
             ord_states[j] = -1;
             (*s2)--;
          }
        }
     }
   }
   fix_partition(s1,mapState,pn);

   free(iEj);
   free(ord_states);
   free_part(s1, &pn);
}

void minimize1(INT_S *s1, state_node **t1)
{
   INT_S s2;
   state_node *t2;
   INT_S *mapState;

   if (*s1 == 0) return;

   mapState = (INT_S*) calloc(*s1, sizeof(INT_S));
   if (mapState == NULL) {
     mem_result = 1;
     return;
   }

   build_partition(*s1,*t1,mapState,&s2);

   if (*s1 == s2) {
      free(mapState);
      return;  /* No change */
   }
/* printf("Build partition: %ld\n", s2); */

   t2 = newdes(s2);
   if ((s2 != 0) && (t2 == NULL)) {
      mem_result = 1;
      free(mapState);
      return;
   }

   recode_min(*s1,*t1,s2,t2,mapState);

   free(mapState);
   freedes(*s1,t1);
   *s1 = s2;
   *t1 = t2;
}

void minimize(INT_S *s1, state_node **t1)
{
  minimize1(s1, t1);
}

void recodelist(INT_S state,
                state_node *t1,
                INT_T *nullist,
                INT_T s_nullist,
                INT_B *nullstate_bool)
{
   /* Convert the transition labels to be projected to 1000.
      Cannot use -1 because it is an unsigned integer.
      Need better method to mark transitions to be converted. */

   INT_T cur, elem;

   *nullstate_bool = false;
   for (cur=0; cur < t1[state].numelts; cur++) {
      elem = t1[state].next[cur].data1;
      if (inlist(elem, nullist, s_nullist)) {
          t1[state].next[cur].data1 = 1023;       /* hard code for now */
          *nullstate_bool = true;
      }
   }
}

void reorderlist(tran_node* next,
                 INT_T numelts,
                 tran_node **orderlist,
                 INT_T *s_orderlist)
{
   INT_B ok;
   INT_T i;

   *s_orderlist = 0;
   for (i=0; i < numelts; i++) {
      addordlist1(next[i].data1, next[i].data2, orderlist, *s_orderlist, &ok);
      if (ok) (*s_orderlist)++;
   }
}

void addpart(INT_S e,
             INT_S **L,
             INT_S size,
             INT_B *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1]) {
          found = true;
       } else if (e > (*L)[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1])
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0]) {
       found = true;
     } else if (e > (*L)[0]) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (INT_S*) realloc(*L, sizeof(INT_S)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      *ok = false;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(INT_S)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos]= e;

   *ok = true;
}

void build_nullsets(INT_S state,
                    state_node *t1,
                    part_node *nullsets)
{
   INT_B ok;
   INT_S entr2;
   INT_S s;
   INT_T cur;
   t_stack ts;

   pstack_Init(&ts);

   t1[state].reached = true;
   s = state;
   cur = 0;

   do {
LABEL1:
      while ( (cur < t1[s].numelts) && (t1[s].next[cur].data1 != 1023) ) {
         cur++;
      }

      while ( (cur < t1[s].numelts) && (t1[s].next[cur].data1 == 1023) ) {
         entr2 = t1[s].next[cur].data2;
         addpart(entr2, &nullsets[state].next, nullsets[state].numelts, &ok);
         if (ok) nullsets[state].numelts++;
         if (!t1[entr2].reached) {
             t1[entr2].reached = true;
             pstack_Push(&ts, cur, s);
             cur = 0;
             s = entr2;
             goto LABEL1;
         }
LABEL2:
         cur++;
      }

      pstack_Pop(&ts, &cur, &s, &ok);
      if (cur < t1[s].numelts && ok) goto LABEL2;
   } while (!pstack_IsEmpty(&ts));

   pstack_Done(&ts);
}

void mark_newstate(INT_S* next,
                   INT_S numelts,
                   state_node *t1,
                   INT_B *marked)
{
   INT_T cur;
   INT_S cur_state;

   *marked = false;
   cur = 0;
   while (cur < numelts && !(*marked)) {
      cur_state = next[cur];
      if (t1[cur_state].marked)
         *marked = true;
      else
         cur++;
   }
}

void generate(INT_S *next,
              INT_S numelts,
              state_node **t1,
              state_map **templist,
              INT_S *s_templist)
{
   INT_T i,j;
   INT_T event;
   INT_S entr;
   INT_B ok;

   for (i=0; i < numelts; i++) {
      for (j=0; j < (*t1)[next[i]].numelts; j++) {
         event = (*t1)[next[i]].next[j].data1;
         entr  = (*t1)[next[i]].next[j].data2;
         if (event != 1023) {
            addstatemap(event,entr,templist,*s_templist,&ok);
            if (ok) (*s_templist)++;
         }
      }
   }
}

void unionsets(INT_S *list1,
               INT_S size1,
               INT_S **list2,
               INT_S *size2)
{
   /* Form the union: list2 <- list1 + list2 */
   INT_S cur;
   INT_B ok;

   for (cur=0; cur < size1; cur++) {
      addstatelist(list1[cur],list2,*size2,&ok);
      if (ok) (*size2)++;
   }
}

INT_B equal_list(INT_S *list1,
                   INT_S *list2,
                   INT_S numelts)
{
   INT_S i;

   for (i=0; i < numelts; i++) {
      if (list1[i] != list2[i])
         return false;
   }
   return true;
}

void memberset(INT_S *tempset,
               INT_S numelts,
               state_map *macrosets,
               INT_S size,
               INT_S *macrostate)
{
    INT_B found;
    INT_S firstelt, i;

    /* Check that the list of states exists in the set of existing states */
    if (numelts <= 0) {
       *macrostate = -2;
       return;
    }

    i = 0;
    found = false;
    firstelt = tempset[0];
    while ((i < size) && !found) {
        /* Try to find the first element */
        if (firstelt > macrosets[i].next[0]) {
        } else if (firstelt == macrosets[i].next[0]) {
           if (numelts == macrosets[i].numelts) {
              if (equal_list(tempset,macrosets[i].next,numelts)) {
                  *macrostate = macrosets[i].state;
                  found = true;
              }
           }
        } /* else {
           found = true;
           *macrostate = -1;
        } */
        i++;
    }

    if (found == false) {
       *macrostate = -1;
    }
}

void addordlist3(INT_S newstate,
                 INT_S setsize,
                 INT_B marked,
                 INT_S *tempset,
                 state_map **macrosets,
                 INT_S *s_macrosets)
{
   INT_B ok;
   INT_S i;

   for (i=0; i < setsize; i++) {
     addstatemap(newstate, tempset[i], macrosets, *s_macrosets, &ok);
     if (ok) (*s_macrosets)++;
   }

   for (i=0; i < *s_macrosets; i++) {
     if ( (*macrosets)[i].state == newstate ) {
       (*macrosets)[i].marked = marked;
       break;
     }
   }
}

void project1(INT_S *s1,
              state_node **t1,
              INT_T s_nullist,
              INT_T *nullist)
{
   INT_S state, i;
   INT_B nullstate_bool;
   INT_S *nullstates_list, s_nullstates_list;
   tran_node *orderlist; INT_T s_orderlist;
   part_node *nullsets;
   INT_B ok, marked;
   state_map* macrosets; INT_S s_macrosets;
   INT_S s2; state_node *t2;
   state_map* templist; INT_S s_templist;
   INT_S *tempset; INT_S setsize;
   INT_S macrostate;
   INT_S j, k;
   INT_S srcstate, newstate, curr_row;
   INT_B found;
   INT_S macroptr;

   nullstates_list = NULL;   s_nullstates_list = 0;
   orderlist = NULL; s_orderlist = 0;
   nullsets = NULL;
   macrosets = NULL;  s_macrosets = 0;
   t2 = NULL; s2 = 0;
   templist = NULL; s_templist = 0;
   tempset = NULL; setsize = 0;

   /* record all states with nulled transitions in nullstates_list*/
   for (state=0; state < *s1; state++) {
      nullstate_bool = false;
      recodelist(state,*t1,nullist,s_nullist,&nullstate_bool);
      if (nullstate_bool) {
         addstatelist(state,&nullstates_list,s_nullstates_list,&ok);
         if (ok) s_nullstates_list++;
	 /* reorder transitions because of nulled transitions*/
         reorderlist((*t1)[state].next, (*t1)[state].numelts, &orderlist, &s_orderlist);
         free((*t1)[state].next);
         (*t1)[state].next = orderlist;
         (*t1)[state].numelts = s_orderlist;
         s_orderlist = 0;
         orderlist = NULL;
      }
      (*t1)[state].reached = false;
   }

   if (s_nullstates_list == 0)
      return;

   nullsets = (part_node*) calloc(*s1, sizeof(part_node));
   if (nullsets == NULL) {
     mem_result = 1;
     goto FREE_ALL;
   }

   /* initialize all nullsets to contain a singleton (itself)*/
   for (state=0; state < *s1; state++) {
     nullsets[state].numelts = 1;
     nullsets[state].next = (INT_S*) malloc(sizeof(INT_S));
     if (nullsets[state].next == NULL) {
        mem_result = 1;
        goto FREE_ALL;
     }
     nullsets[state].next[0] = state;
   }

   /* build nullsets of states which have to be merged together*/
   for (i=0; i < s_nullstates_list; i++) {
     state = nullstates_list[i];
     build_nullsets(state,*t1,nullsets);
     for (state=0; state < *s1; state++)
        (*t1)[state].reached = false;
   }

   s_macrosets = 1;
   macrosets = (state_map*) malloc(sizeof(state_map));
   if (macrosets == NULL) {
     mem_result = 1;
     goto FREE_ALL;
   }
 
   macrosets[0].state   = 0;
   macrosets[0].numelts = 0;
   mark_newstate(nullsets[0].next, nullsets[0].numelts,*t1,&marked);
   macrosets[0].marked = marked;
   macrosets[0].next = NULL;

   /* Copy all states nullsets[0].next -> macrosets[0].next */
   for (i=0; i < nullsets[0].numelts; i++) {
      addstatelist(nullsets[0].next[i], &macrosets[0].next, macrosets[0].numelts,&ok);
      if (ok) macrosets[0].numelts++;
   }

   templist = NULL; s_templist = 0;

   /* generate for first set a templist with all remaining transitions*/
   generate(nullsets[0].next,nullsets[0].numelts,t1,&templist,&s_templist);
   if (templist == NULL) {
      /* Free all pointer -> do a "goto" free part */
      s2 = 1;
      t2 = newdes(s2);
      t2[0].marked = macrosets[0].marked;
      freedes(*s1,t1);
      *s1 = s2;
      *t1 = t2;
      s2 = 0; t2 = NULL;  /* Goto free part of the procedure */
      goto FREE_ALL;
   }

   srcstate = 0;
   newstate = 0;
   s2 = 0; t2 = NULL;

   do {
      for (i=0; i < s_templist; i++) {
        curr_row = templist[i].state;
        /* build the union of the nullsets of all entrance states of 
	   one transition*/ 
	for (j=0; j < templist[i].numelts; j++) {
           k = templist[i].next[j];
           unionsets(nullsets[k].next, nullsets[k].numelts,
                     &tempset,&setsize);
        }
	/* See if tempset is equal to one of the macrosets*/ 
        memberset(tempset,setsize,macrosets,s_macrosets,&macrostate);
	/* if not create new macroset*/
        if (macrostate == -1) {
           newstate++;
           mark_newstate(tempset,setsize,*t1,&marked);
           addordlist3(newstate,setsize,marked,tempset,&macrosets,&s_macrosets);
           insertlist4(srcstate,(INT_T)curr_row,newstate,&s2,&t2);
        } else {
           if (macrostate != -2) {
             insertlist4(srcstate,(INT_T)curr_row,macrostate,&s2,&t2);
           }
        }

        if (tempset != NULL) {
           free(tempset); tempset = NULL;
        }
        setsize = 0;
      }
      srcstate++;

      /* Some stuff here */
      found = false;
      for (i=0; i < s_macrosets; i++) {
        if (macrosets[i].state == srcstate) {
           found = true;
           macroptr = i;
           break;
        }
      }

      if (found) {
         if (s_templist > 0) {
            free(templist); templist = NULL;
            s_templist = 0;
         }
         generate(macrosets[macroptr].next, macrosets[macroptr].numelts,t1,
                  &templist,&s_templist);
      }
   } while (srcstate <= newstate);

   resize_des(&t2,s2,newstate+1);
   s2 = newstate+1;

   for (i=0; i < s_macrosets; i++) {
      t2[macrosets[i].state].marked = macrosets[i].marked;
   }

   freedes(*s1, t1);
   *s1 = s2;
   *t1 = t2;

   /* Free all tempory variables here */
FREE_ALL:
   free(nullstates_list);
   free(orderlist);
   free(nullsets);
   free(macrosets);
   free(templist);
   free(tempset);
}

void project0(INT_S *s1, state_node **t1, INT_S *s2, INT_T **t2,
	      INT_T s_nullist, INT_T *nullist)
{
   INT_T *list, s_list , i;
   INT_B ok;

   list = NULL; s_list = 0;
   if (s_nullist == 0) {
      reach(s1, t1, s2, t2);
      minimize(s1, t1);
   } else {

      /* Ad-hoc method to improve runtime of project */
     if (*s1 < 100) {
        /* Do what I did before */
        project1(s1,t1,s_nullist,nullist);
        if (*s1 > 1) {
	   reach(s1, t1, s2, t2);
           minimize(s1, t1);
        }
     } else if (*s1 < 1000) {
        for (i=0; i < s_nullist; i+=2) {
           addordlist(nullist[i], &list, s_list, &ok);
           if (ok) s_list++;

           if (i+1 < s_nullist) {
              addordlist(nullist[i+1], &list, s_list, &ok);
              if (ok) s_list++;
           }

           project1(s1, t1, s_list, list);
           if (*s1 > 1) {
	      reach(s1, t1, s2, t2); 
              minimize(s1, t1); 
           }
           free(list); list=NULL; s_list = 0;
        }
     } else {
        for (i=0; i < s_nullist; i++) {
           addordlist(nullist[i], &list, s_list, &ok);
           if (ok) s_list++;

           project1(s1, t1, s_list, list);
           if (*s1 > 1) {
	      reach(s1, t1, s2, t2);
              minimize(s1, t1);
           }
           free(list); list=NULL; s_list = 0;
        }
     }
   }
}

// This function finds just the disabled events not the forced ones
void condat1(state_node *t1, INT_S s1, INT_S s2, INT_S s3, state_node *t3,
             INT_S s4, INT_T *t4, INT_S *s5, state_node **t5,
             INT_S *macro_c)
{
   INT_S state, state1, state2;

   *s5 = s2;
   *t5 = newdes(*s5);

   for (state=0; state < s3; state++) {
     state1 = macro_c[state] % s1;
     state2 = macro_c[state] / s1;

     genlist(t1[state1].numelts, t1[state1].next,
             t3[state].numelts, t3[state].next, s4, t4, state2, t5);
   }

}

//This function finds both the disabled and forced events

void condat2(state_node *t1, INT_S s1, INT_S s2,state_node *t2, INT_S s3, state_node *t3,
             INT_S s4, INT_T *t4, INT_S *s5, state_node **t5,
             INT_S *macro_c)
{
   
   // (s4,t4) are the set of forcible events
   INT_S state, state1, state2;
   INT_T *tmplist1,*tmplist2,ii,jj;
   INT_S s_tmplist1,s_tmplist2;
   INT_B ok,Add;

   *s5 = s2;
   *t5 = newdes(*s5);
   
   // This section finds the disabled evetns is each state of TDES2 as 
   // a TDES (t5) whose states are TDES2 states and "next" states of each state are disabled events.

   for (state=0; state < s3; state++) {
     state1 = macro_c[state] % s1;
     state2 = macro_c[state] / s1;

     genlist(t1[state1].numelts, t1[state1].next,
             t3[state].numelts, t3[state].next, s4, t4, state2, t5);
   }
   
   
   // This section finds the forced events at each state of TDES2
   // and stores them in t5 as the "next" states of each state after the disabled events of each state 
    // the number of forced events at each state of t5 is stored in the "vocal" propert of each state.
    

    
    for (ii=0;ii<s2;ii++)
      (*t5)[ii].vocal=0;// vocal property of each state of t5 is used to store the number of forced events on that state
   
  
    for (state=0; state < s3; state++) {
        state1 = macro_c[state] % s1; //state of TDES1
        state2 = macro_c[state] / s1; //state of TDES2
    
        if  ( (*t5)[state2].numelts > 0 ) { //if 1
              // for the states TICK=0 has been disabled check to find the forcible events        
             if ( (*t5)[state2].next[0].data1 == 0){ //if 2
           
                // finding the existing events at state "state2" of TDES2
                s_tmplist2=t2[state2].numelts;
                tmplist2 = (INT_T*) calloc(s_tmplist2, sizeof(INT_T));
                for (ii=0; ii < s_tmplist2 ; ii++)
                    tmplist2[ii]=t2[state2].next[ii].data1;
        
                // removing the events that are not forcible from tmplist2 (s4,t4) are forcible events
                remove_forcible(&s_tmplist2, &tmplist2, (INT_T)s4, t4);
        
                // finding the existing events at state "state1" of TDES1
                s_tmplist1=t1[state1].numelts;
                tmplist1 = (INT_T*) calloc(s_tmplist1, sizeof(INT_T));
                for (ii=0; ii < s_tmplist1 ; ii++)
                tmplist1[ii]=t1[state1].next[ii].data1;
        
                // removing the events that are not forcible from tmplist1 (s4,t4) are forcible events
                remove_forcible(&s_tmplist1, &tmplist1, (INT_T)s4, t4);  
           
                // finding the forcibel events of TDES2 at "state2" which are also defined at "state1" of TDES1           
                remove_forcible(&s_tmplist2,&tmplist2,(INT_T)s_tmplist1,tmplist1);
           
                for (ii = 0; ii < s_tmplist2; ii++) {
	         
	                  // if the forcible event "tmplist2[ii]" has already been added to t5, the "Add" flag will go "false"
                      Add=true;
                      for (jj=0; jj< (*t5)[state2].numelts; jj++)
	                       if ( tmplist2[ii]== (*t5)[state2].next[jj].data1 ) 
	                           Add=false;
            
                      // adding new forced events to t5 ,
                      // increasing the value of "vocal" as number of forced events and "numelts" as the number of next states at each state of t5
                      if (Add) {
                 
                          addunordlist1(tmplist2[ii], 0, &(*t5)[state2].next, (*t5)[state2].numelts, &ok);
	      
                          if (ok) {
	                          (*t5)[state2].numelts++;
	                          (*t5)[state2].vocal++;
     	                  }
          
                      }   
          
               }
           
               free(tmplist1);
               free(tmplist2); 
        
             }   // end if  2 
        } //end if 1   
      
    } //end for   state   
     
     

 
          


}



void b_recode(INT_S s1,
              state_node **t1,
              INT_S *s2,
              INT_S **recode_array)
{
   INT_T cur, diff, numelts;
   INT_S s;
   INT_S es;
   t_queue tq;
/*   long num_hits = 0; */
   state_node *t2;

   if (s1 <= 0) return;

   *s2 = 0;

   *recode_array = (INT_S*) malloc(s1*sizeof(INT_S));
   if (*recode_array == NULL) {
      mem_result = 1;
      return;
   }

   for (s=0; s < s1; s++)
     (*t1)[s].reached = false;
   (*t1)[0].reached = true;

   queue_init(&tq);

   s = 0; enqueue(&tq,s); (*recode_array)[*s2] = s; (*s2)++;

   while (!queue_empty(&tq)) {
      s = dequeue(&tq);
      for (cur=0; cur < (*t1)[s].numelts; cur++) {
         es = (*t1)[s].next[cur].data2;
         if (!(*t1)[es].reached) {
            enqueue(&tq,es); (*recode_array)[es] = *s2; (*s2)++;
            (*t1)[es].reached = true;
         }
      }
   }

   queue_done(&tq);

   /* Recode the transitions - based on the recode array */
   for(s=0; s < s1; s++) {
      if ((*t1)[s].reached) {
        /* Purge transitions that point to dead states */
        cur = 0;
        numelts = (*t1)[s].numelts;
        while (cur < (*t1)[s].numelts) {
           es = (*t1)[s].next[cur].data2;
           if (!(*t1)[es].reached) {
              diff = (*t1)[s].numelts-(cur+1);
              if (diff > 0)
                 memmove(&(*t1)[s].next[cur], &(*t1)[s].next[cur+1],
                         sizeof(tran_node)*diff);
              (*t1)[s].numelts--;
           } else {
              (*t1)[s].next[cur].data2 = (*recode_array)[es];
              cur++;
           }

           if (numelts != (*t1)[s].numelts) {
              (*t1)[s].next = (tran_node*) realloc((*t1)[s].next,
                              sizeof(tran_node)*(*t1)[s].numelts);
           }
        }
      } else {
        if ((*t1)[s].next != NULL) free((*t1)[s].next);
        (*t1)[s].next = NULL;
        (*t1)[s].numelts = 0;
      }
   }

   t2 = newdes(*s2);
   if ((*s2 != 0) && (t2 == NULL)) {
      mem_result = 1;
      return;
   }

   for (s=0; s < *s2; s++) {
      es = (*recode_array)[s];
      t2[es].marked  = (*t1)[s].marked;
      t2[es].vocal   = (*t1)[s].vocal;
      t2[es].next    = (*t1)[s].next;
      t2[es].numelts = (*t1)[s].numelts;
   }

   free(*t1);
   *t1 = t2;
}

void reversetran1(INT_S state,
                  state_node *t3,
                  state_node *t)
{
   INT_T j, event;
   INT_S target;
   INT_B ok;

   for(j=0; j < t3[state].numelts; j++) {
      event  = t3[state].next[j].data1;
      target = t3[state].next[j].data2;
      addordlist1(event, state, &t[target].next, t[target].numelts, &ok);
      if (ok) t[target].numelts++;
   }
}

void ya_coreach2(INT_S state,
                 state_node *t1,
                 state_node *t2, INT_T s3, INT_T *t3)
{
   INT_B ok;
   INT_T cur, event;
   INT_S s;
   INT_S es;
   t_stack ts;

   pstack_Init(&ts);

   cur = 0;
   s = state;

   while (!( (cur >= t2[s].numelts) && pstack_IsEmpty(&ts) )) {
      es = t2[s].next[cur].data2;
      if (!t2[es].reached) {
          event = t2[s].next[cur].data1;
          delete_ordlist1(event, state, &t1[es].next, t1[es].numelts, &ok);
          if (ok) t1[es].numelts--;

          if ((event % 2) == 0) {
	     if (event == TICK) {
		if (exist_forcible(t1[es].numelts, t1[es].next, s3, t3));
		else {
		   t2[es].reached = true;
		   t1[es].reached = true;
		   ok = pstack_Push(&ts, cur, s);
		   s = es;
		   cur = 0;
		   goto LABEL1;
		}
	     } else {
		t2[es].reached = true;
		t1[es].reached = true;
		ok = pstack_Push(&ts, cur, s);
		s = es;
		cur = 0;
		goto LABEL1;
	     }
          }
      }
      cur++;
LABEL1:
      if (cur >= t2[s].numelts) {
         do {
            pstack_Pop(&ts, &cur, &s, &ok);
            if (cur < t2[s].numelts && ok)
                cur++;
         } while (!((cur < t2[s].numelts) || pstack_IsEmpty(&ts)));
      }
   }

   pstack_Done(&ts);
}

void mutex1(INT_S *s5, state_node **t5, INT_T s6, INT_T *t6,
            INT_S s1, INT_S s3, INT_S *macro_ab, 
	    state_pair *badlist, INT_S s_badlist)
{
   INT_S i, macrostate;
   INT_S *mutexlist, s_mutexlist;
   INT_S badstate;
   INT_B ok;
   INT_S substate1, substate2;
   state_node *ttemp;
   INT_S state, s4;
   recode_node *recode_states;
   INT_S num_reachable, stemp;

   mutexlist = NULL; s_mutexlist = 0;

   if (*s5 == 0) {
     return;
   }

   for (i=0; i < s_badlist; i++) {
      substate1 = badlist[i].data1;
      substate2 = badlist[i].data2;
      if ( (0 <= substate1 && substate1 < s1) &&
           (0 <= substate2 && substate2 < s3) ) {
         macrostate = macro_ab[substate2*s1+substate1];
         if (macrostate != -1L) {
            addstatelist(macrostate,&mutexlist,s_mutexlist,&ok);
            if (ok) s_mutexlist++;
         }
      }
   }

   if (mutexlist == NULL) {
      return;
   }

   (*t5)[0].reached = false;
   for (i=0; i < s_mutexlist; i++) {
      badstate = mutexlist[i];
      (*t5)[badstate].reached = true;
      if ((*t5)[badstate].next != NULL) {
         free((*t5)[badstate].next);
         (*t5)[badstate].next = NULL;
      }
      (*t5)[badstate].numelts = 0;
   }

   if ((*t5)[0].reached) {
     free(mutexlist);
     freedes(*s5, t5);
     *s5 = 0;
     *t5 = NULL;
     return;
   }

   /* do some kind of reachability on t5 so that
      certain states are not marked as reach */
   /* Do some recoding on the states left */
   /* Operations very similar to TRIM1 but instead of taking
      the reachable, take the NOT reachable */

   stemp = *s5;
   ttemp = newdes(stemp);
   if (ttemp == NULL) {
      free(mutexlist);
      mem_result = 1;
      return;
   }

   for (i=0; i < *s5; i++)
      reversetran1(i,*t5,ttemp);

   for (i=0; i < s_mutexlist; i++) {
      for (state=0; state < *s5; state++)
         ttemp[state].reached = false;
      badstate = mutexlist[i];
      ttemp[state].reached = true;
      ya_coreach2(badstate,*t5,ttemp, s6, t6);
   }

   freedes(stemp, &ttemp);
   free(mutexlist);

   if ((*t5)[0].reached) {
      freedes(*s5, t5);
      *s5 = 0;
      *t5 = NULL;
      return;
   }

   s4 = 0;
   for (state=0; state < *s5; state++) {
      /* Switch all the reach variable to its complement */
      (*t5)[state].reached = !((*t5)[state].reached);
      if ((*t5)[state].reached)
         s4++;
   }

   if (s4 == *s5)
      return;

   /* Recode all "unreachable states" */
   recode_states = (recode_node*) calloc(*s5,sizeof(recode_node));

   /* Re-name all reached states to the new state names */
   num_reachable = 0;
   for (state=0; state < *s5; state++) {
     if ( (*t5)[state].reached ) {
        recode_states[state].recode  = num_reachable;
        recode_states[state].reached = true;
        num_reachable++;
     }
   }

   /* Purge dead transitions followed by purging states */
   recode(*s5, t5, recode_states);

   *t5 = (state_node*) realloc(*t5, sizeof(state_node)*num_reachable);
   *s5 = num_reachable;

   free(recode_states);
}

INT_B checkdet(INT_S s1,
                 state_node *t1)
{
   INT_S i, s;
   INT_T j, cur;

   for (i=0; i< s1; i++) {
      cur = (INT_T) (-1);
      for (j=0; j < t1[i].numelts; j++) {
         if (cur == t1[i].next[j].data1) {
            return false;
         } else {
            cur = t1[i].next[j].data1;
         }

         /* Make sure data2 is valid */
         s = t1[i].next[j].data2;
         if ((s < 0) || (s >= s1)) {
           printf("Corrupted DES file: %ld out of range\n", s);
           exit(1);
         }
      }
   }
   return true;
}

void expand_des_vocal(state_node** t1, INT_S *s1,
                      quad__t **list, INT_S *slist)
{
    /* Increase the number of states by the number of unique
       [entry,vocal_output] pairs */

   state_pair *pl; INT_S s_pl;
   INT_S cur;
   INT_B ok;
   INT_S old_max, new_max;

   pl = NULL;  s_pl =0;

   cur = 0;
   for (cur = 0; cur < *slist; cur++) {
      addstatepair( (*list)[cur].c, (*list)[cur].d,
                    &pl, s_pl, &ok);
      if (ok) {
         s_pl++;
      }
   }

   free(pl);

   /* s_pl = # of new states to add */
   old_max = *s1;
   new_max = *s1 + s_pl;

   *t1 = (state_node*) realloc(*t1, sizeof(state_node)*new_max);
   if ((new_max !=0) && (*t1 == NULL)) {
      mem_result = 1;
      return;
   }

   for (cur=old_max; cur < new_max; cur++) {
      (*t1)[cur].numelts = 0;
      (*t1)[cur].nstinfo = NULL;
      (*t1)[cur].numtimer= 0;
      (*t1)[cur].ntimer  = NULL;
      (*t1)[cur].marked  = true;
      (*t1)[cur].vocal   = 0;
      (*t1)[cur].reached = false;
      (*t1)[cur].next    = NULL;
   }

   *s1 = new_max;
}

INT_B inlist_quad(quad__t *list, INT_S slist,
                    INT_S i, INT_T e, INT_S j, INT_V *v)
{
   INT_S cur;

   for (cur=0; cur < slist; cur++) {
      if ( (list[cur].a == i) && (list[cur].b == e) && (list[cur].c == j) ) {
         *v = list[cur].d;
         return true;
      }
   }

   return false;
}

void vocalize_des(state_node** t1, INT_S *s1,
                  quad__t **list,   INT_S *slist)
{
   INT_S size, cur, j;
   quad__t *state_list;     INT_S s_state_list;
   quad__t *one_state_list; INT_S s_one_state_list;
   INT_S  *vocal_list;     INT_S s_vocal_list;
   INT_S i, dummy;
   INT_B ok;
   INT_S start_state, new_state;
   INT_T k, ee, *dummy1;
   INT_S ii, jj, entry;
   INT_V vocal_output;

   state_list = NULL;      s_state_list = 0;
   one_state_list = NULL;  s_one_state_list = 0;
   vocal_list = NULL;      s_vocal_list = 0;

   size = *s1;
   start_state = *s1;
   expand_des_vocal(t1, s1, list, slist);

   for (i=0; i < size; i++) {
     free(state_list); state_list = NULL; s_state_list = 0;
     free(vocal_list); vocal_list = NULL; s_vocal_list = 0;

     /* Get a list of significant events entering state "i" */
     for (cur = 0; cur < *slist; cur++) {
         if ( (*list)[cur].c == i) {
            add_quad( (*list)[cur].a,  (*list)[cur].b,
                      (*list)[cur].c,  (*list)[cur].d,
                      &state_list,  s_state_list, &ok);
            if (ok) s_state_list++;
         }
      }

      if (s_state_list > 0) {
         /* Count # of unique vocal output.
            Stored in "s_vocal_list */
         for (cur=0; cur < s_state_list; cur++) {
            addstatelist(state_list[cur].d, &vocal_list, s_vocal_list, &ok);
            if (ok) s_vocal_list++;
         }

         for (j=0; j < s_vocal_list; j++) {
           new_state = start_state+j;
           (*t1)[new_state].marked  = (*t1)[i].marked;
           (*t1)[new_state].vocal   = (INT_V)vocal_list[j];

           /* Do we need to update the user_list and state_list? */
           for (k=0; k < (*t1)[i].numelts; k++) {
             /* Self-loop? */
             ee = (*t1)[i].next[k].data1;
             jj = (*t1)[i].next[k].data2;

             if ( jj == i ) {
                entry = i;
             } else {
                entry = jj;
             }

             if ( inlist_quad(*list, *slist, i, ee, jj, &vocal_output) ) {
                add_quad(new_state, ee, jj, vocal_output,
                         list, *slist, &ok);
                if (ok) (*slist)++;

                if (jj == i) {
                   add_quad(new_state, ee, jj, vocal_output,
                            &state_list, s_state_list, &ok);
                   if (ok) (s_state_list)++;
                }
             }

             addordlist1(ee, entry, &(*t1)[new_state].next,
                         (*t1)[new_state].numelts, &ok);
             if (ok) (*t1)[new_state].numelts++;
           }
         }

         for (j=0; j < s_vocal_list; j++) {
            /* Construct a list so that they have the same vocal output */
            free(one_state_list); one_state_list = NULL;  s_one_state_list = 0;
            for (cur = 0; cur < s_state_list; cur++) {
               if (state_list[cur].d == vocal_list[j]) {
                   add_quad(state_list[cur].a, state_list[cur].b,
                            state_list[cur].c, state_list[cur].d,
                            &one_state_list, s_one_state_list, &ok);
                   if (ok) s_one_state_list++;
               }
            }

            for (cur=0; cur < s_one_state_list; cur++) {
               ii = one_state_list[cur].a;
               delete_ordlist1(one_state_list[cur].b,
                               one_state_list[cur].c,
                               &(*t1)[ii].next,
                                (*t1)[ii].numelts, &ok);
               if (ok) (*t1)[ii].numelts--;

               addordlist1(one_state_list[cur].b,
                           start_state+j,
                           &(*t1)[ii].next,
                           (*t1)[ii].numelts, &ok);
               if (ok) (*t1)[ii].numelts++;
            }
         }
      }

      start_state += s_vocal_list;
   }

   free(state_list);
   free(one_state_list);
   free(vocal_list);

   reach(s1, t1, &dummy, &dummy1); 
}

INT_S num_marked(state_node *t,
                 INT_S s)
{
   INT_S i, count;

   count = 0;
   for (i=0; i < s; i++) {
      if (t[i].marked) count++;
   }
   return count;
}

int is_deterministic(state_node *des, int states, triple **non_det)
{
  int i, j;
  int curEntrance, cur;
  INT_B first, ok;
  int s_nonDetList=0;

  assert(des);
  assert(non_det && *non_det);

  *non_det = NULL;
  for (i=0; i<states; i++) {
    first = true;
    if (des[i].numelts > 0) {
      cur = des[i].next[0].data1;
      curEntrance = des[i].next[0].data2;
    }
    for (j=1; j<des[i].numelts; j++) {
      if (cur == des[i].next[j].data1) {
	if (first) {
	  addtriple(i,cur,curEntrance, non_det, s_nonDetList, &ok);
	  if (ok) s_nonDetList++;
	}
	first = false;
	addtriple(i,cur,des[i].next[j].data2, non_det, s_nonDetList, &ok);
	if (ok) s_nonDetList++;
      } else {
	first = true;
	cur = des[i].next[j].data1;
	curEntrance = des[i].next[j].data2;
      }
    }
  }
  return s_nonDetList;
}

void iso1(INT_S s1, INT_S s2, INT_S s3, INT_S s4,
          state_node *t1, INT_T *t2, state_node *t3, INT_T *t4, 
          INT_B *inflag, INT_S *mapState)
{
   state_pair *iEj;
   INT_S s_iEj;
   /* Pre-conditions:
      Same number of states.
      Same list of forcible events
      Same number of transitions.
      Same number of marker states.
      Same number of vocal states
    */
   INT_B flag, equal;
   INT_S count1, count2;
   INT_S t1i, t2j;
   int dummy;

   iEj = NULL;
   s_iEj = 0;

   flag = (s1 == s3);
   if (flag) {
      count1 = num_marked(t1, s1);
      count2 = num_marked(t3, s3);
      flag = (count1 == count2);
   }
   if (flag) {
      count1 = count_tran(t1, s1, &dummy, &dummy, &dummy);
      count2 = count_tran(t3, s3, &dummy, &dummy, &dummy);
      flag = (count1 == count2);
   }
   
   /* relying on ordered list of forcible events */
   if (flag) {
      if (s2 == s4) {
	 flag = memcmp(t2, t4, sizeof(INT_T) * s2);
	 flag = (flag == 0);
      } else {
	 flag = false;
      }
   }

   if (flag) {
      if ((s1 == 0) && (s3 == 0)) {
         flag = true;
      } else {
         equal = false;
         if (iEj != NULL) {
            free(iEj); iEj = NULL; s_iEj = 0;
         }
         compare_states(0L,0L,&equal,mapState,&iEj,&s_iEj,t1,t3);
         if (equal) {
            mapState[0] = 0;
            t1i = 1;
            while ((t1i < s1) && equal) {
              if (!t1[t1i].reached) {
                 equal = false;
                 t2j = 1;
                 while ((t2j < s3) && (!equal)) {
                    if (!t3[t2j].reached) {
                        if (iEj != NULL) {
                           free(iEj); iEj = NULL; s_iEj = 0;
                        }
                        compare_states(t1i,t2j,&equal,mapState,&iEj,&s_iEj,t1,t3);

                        if (equal) {
                           mapState[t1i] = t2j;
                           t1[t1i].reached = true;
                           t3[t2j].reached = true;
                           t1i++;
                           t2j = 1;
                        } else {
                           t2j++;
                        }
                    } else {
                        t2j++;
                    }
                 }
              } else {
                 t1i++;
              }
            }
         }
         flag = equal;
      }
   }

   *inflag = flag;

   if (iEj != NULL) {
      free(iEj); iEj = NULL; s_iEj = 0;
   }
}

void isoa1(INT_S s1, INT_S s2, INT_S s3, INT_S s4,
	   state_node *t1, timed_event *t2, state_node *t3, timed_event *t4, 
	   INT_B *inflag, INT_S *mapState)
{
   state_pair *iEj;
   INT_S s_iEj;
   /* Pre-conditions:
      Same number of states.
      Same list of timed events
      Same number of transitions.
      Same number of marker states.
      Same number of vocal states
    */
   INT_B flag, equal;
   INT_S count1, count2;
   INT_S t1i, t2j;
   int dummy;

   iEj = NULL;
   s_iEj = 0;

   flag = (s1 == s3);
   if (flag) {
      count1 = num_marked(t1, s1);
      count2 = num_marked(t3, s3);
      flag = (count1 == count2);
   }
   if (flag) {
      count1 = count_tran(t1, s1, &dummy, &dummy, &dummy);
      count2 = count_tran(t3, s3, &dummy, &dummy, &dummy);
      flag = (count1 == count2);
   }
   
   /* relying on ordered list of timed events */
   if (flag) {
      if (s2 == s4) {
	 flag = memcmp(t2, t4, sizeof(INT_T) * s2);
	 flag = (flag == 0);
      } else {
	 flag = false;
      }
   }

   if (flag) {
      if ((s1 == 0) && (s3 == 0)) {
         flag = true;
      } else {
         equal = false;
         if (iEj != NULL) {
            free(iEj); iEj = NULL; s_iEj = 0;
         }
         compare_states(0L,0L,&equal,mapState,&iEj,&s_iEj,t1,t3);
         if (equal) {
            mapState[0] = 0;
            t1i = 1;
            while ((t1i < s1) && equal) {
              if (!t1[t1i].reached) {
                 equal = false;
                 t2j = 1;
                 while ((t2j < s3) && (!equal)) {
                    if (!t3[t2j].reached) {
                        if (iEj != NULL) {
                           free(iEj); iEj = NULL; s_iEj = 0;
                        }
                        compare_states(t1i,t2j,&equal,mapState,&iEj,&s_iEj,t1,t3);

                        if (equal) {
                           mapState[t1i] = t2j;
                           t1[t1i].reached = true;
                           t3[t2j].reached = true;
                           t1i++;
                           t2j = 1;
                        } else {
                           t2j++;
                        }
                    } else {
                        t2j++;
                    }
                 }
              } else {
                 t1i++;
              }
            }
         }
         flag = equal;
      }
   }

   *inflag = flag;

   if (iEj != NULL) {
      free(iEj); iEj = NULL; s_iEj = 0;
   }
}

INT_S count_tran(state_node* t1,
                 INT_S s1, int *marker, int *vocal, int *silent)
{
   INT_S count, i;
   count = 0;

   *marker = *vocal = *silent = 0;
   for (i=0; i < s1; i++) {
     count += t1[i].numelts;
     if (t1[i].marked)
       (*marker)++;
     if (t1[i].vocal) {
       (*vocal)++;
     } else {
       (*silent)++;
     }
   }
   return count;
}

INT_B compute_controllable(state_node *t1, INT_S s1)
{
   INT_S ii;
   INT_T jj;
   INT_T realtrans1;

   for (ii=0; ii < s1; ii++) {
      realtrans1 = t1[ii].numelts - t1[ii].vocal;
      //for (jj=0; jj < t1[ii].numelts; jj++) {
        for (jj=0; jj < realtrans1 ; jj++) {    
         if (    ( (t1[ii].next[jj].data1 % 2) == 0 ) &&  (t1[ii].next[jj].data1 != 0)   )/* Even & != 0*/
            return false;
         if (   (t1[ii].next[jj].data1 == 0) && ( t1[ii].vocal < 1 )  )
            return false;
     }
   }

   return true;
 /*  
   INT_S k;
   INT_T t;
   INT_T realtrans;
   
   state_pair *tran_stack;
   INT_S s_tran_stack;
   INT_S prevNumTran;
   INT_T j;
   INT_T i;
   
   tran_stack = NULL; s_tran_stack = 0;

   INT_S total_tran = 0;
   leftSide = false;
   prevNumTran = 0;
   i = 0; j = 0;

   do {
          while (i < s1) {
	        realtrans = t1[i].numelts - t1[i].vocal;
            if (t1[i].numelts > 0) {
	             if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
	                  println();
	                  if (_wherey() >= 22)
	            	  dat_page_control(false);
	                  if (quit) {
	                	  free(tran_stack);
	                 	  return true;
	                  }
	       
	                  printw("%4s", " ");
	                  leftSide = true;
                 } else {
	                  for (k=prevNumTran; k < 6; k++)
		                  printw("%5s", " ");
	                  leftSide = false;
	             }
	             printw("%4d:", i);
	             prevNumTran = t1[i].numelts;
           }

           while (j < t1[i].numelts) {
               if (_wherey() >= 22)
                  dat_page_control(false);
               if (quit) {
                   free(tran_stack);
                   return true;
               }

               t = t1[i].next[j].data1;
	           if (j < realtrans) { 
	               printw("%4d ", t);
	           } else {
	               printw("%4df", t);
	           }

               if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
                    println();
                    printw("%9s", " ");
               }
               j++;
           }
         j = 0;
         i++;
      }
      dat_page_control(true);
      if (quit) {
         free(tran_stack);
         return true;
      }
   } while ( (ch != CEnter) && (ch != CPgDn) );
   println();
   free(tran_stack);
   
 */  
}

void print_des_stat_header(FILE *out,
                           char *name,
                           INT_S s,
                           INT_S init)
{
   fprintf(out, "%s    # states: %d", name, s);
   if (s > 0) {
      fprintf(out, "    state set: 0 ... %d", s-1);
      fprintf(out, "    initial state: %d\n", init);
   } else {
      fprintf(out, "    state set: empty ");
      fprintf(out, "    initial state: none\n");
   }
}

INT_B print_marker_states(FILE *out,
                            state_node *t1,
                            INT_S s1)
{
   INT_S i, total_marker;

   total_marker = 0;

   fprintf(out, "\n");
   fprintf(out, "marker states:       ");
   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         fprintf(out, "%5d   ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            fprintf(out, "\n\n");
            fprintf(out, "%-20s", " ");
         }
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B print_timebounds(FILE *out, timed_event *t1, INT_T s1)
{
   INT_S i, total;

   total = 0;

   fprintf(out, "\n");
   fprintf(out, "event timebounds:       \n");
   for (i=0; i < s1; i++) {
      if (t1[i].upper == MAX_TIME) {
	 fprintf(out, "event: %3ld    [%5ld, Inf]    ",t1[i].label, t1[i].low);
      } else {
	 fprintf(out, "event: %3ld    [%5ld,%4ld]    ",t1[i].label, t1[i].low, 
		 t1[i].upper);
      }
      total++;
      if ((total % 2) == 0) {
	 fprintf(out, "\n\n");
	 /*fprintf(out, "%-20s", " ");*/
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B print_aforcible_states(FILE *out, timed_event *t1, INT_T s1)
{
   INT_S i, total;

   total = 0;

   fprintf(out, "\n");
   fprintf(out, "forcible events:       ");
   for (i=0; i < s1; i++) {
      if (t1[i].forcible) {
	 fprintf(out, "%5d   ", t1[i].label);
	 total++;
      }
      if ((total % 7) == 0) {
	 fprintf(out, "\n\n");
	 fprintf(out, "%-20s", " ");
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B print_forcible_states(FILE *out, INT_T *t1, INT_S s1)
{
   INT_S i, total;

   total = 0;

   fprintf(out, "\n");
   fprintf(out, "forcible events:       ");
   for (i=0; i < s1; i++) {
      fprintf(out, "%5d   ", t1[i]);
      total++;
      if ((total % 7) == 0) {
	 fprintf(out, "\n\n");
	 fprintf(out, "%-20s", " ");
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B print_timer_info(FILE *out, state_node *t1, INT_S s1)
{
   INT_S i, j, total;


   fprintf(out, "\n");
   fprintf(out, "state and timer information:       \n");
   for (i=0; i < s1; i++) {
      total = 0;
      fprintf(out, "%5d  :  %5d  ", i, t1[i].nstinfo[0].state);
      total++;
      j = 0;
      while (j < t1[i].numtimer) {
	 fprintf(out, "[%5d, %5d]  ", t1[i].ntimer[j].num, 
		 t1[i].ntimer[j].value);
	 total++;
	 if ((total % 5) == 0 && j+1 < t1[i].numtimer) {
	    fprintf(out, "\n\n");
/*	    fprintf(out, "%-2s", " ");*/
	 }
	 j++;
      }
      fprintf(out, "\n\n");
   }
   fprintf(out, "\n");
   return false;
}

INT_B print_vocal_output(FILE *out,
                           state_node *t1,
                           INT_S s1)
{
   INT_S i, total_vocal;

   total_vocal = 0;

   fprintf(out, "\n");
   fprintf(out, "vocal states:       \n");
   for (i=0; i < s1; i++) {
      if (t1[i].vocal > 0) {
         fprintf(out, "[%5ld,%4d]   ", i, t1[i].vocal);
         total_vocal++;
         if ((total_vocal % 5) == 0) {
            fprintf(out, "\n");
         }
      }
   }
   fprintf(out, "\n");
   return false;
}

INT_B print_transitions(FILE *out,
                          state_node *t1,
                          INT_S s1)
{
   INT_S i, total_tran;
   INT_T j;
   int d;

   total_tran = 0;

   fprintf(out, "\n");
   fprintf(out, "# transitions: %d\n", count_tran(t1, s1, &d, &d, &d));
   fprintf(out, "\n");
   fprintf(out, "transitions: \n");
   fprintf(out, "\n");
   for (i=0; i < s1; i++) {
     for (j=0; j< t1[i].numelts; j++) {
       fprintf(out, "[%5ld,%3d,%5ld]  ", i, t1[i].next[j].data1, t1[i].next[j].data2);
       total_tran++;
       if ((total_tran % 4) == 0) {
          fprintf(out, "\n");
       }
     }
   }
   return false;
}

INT_B nonconflict(INT_S s,
                    state_node *t)
{
   INT_S state;

   if (s==0) return true;

   for (state=0; state < s; state++) 
     t[state].reached = false;
   
   for (state=0; state < s; state++) {
     if (t[state].marked) {
        t[state].reached = true;
        b_reach(t[state].next, state, &t, s);
     }
   }

   for (state=0; state < s; state++) {
      if (!t[state].reached) {
        return false;
      }
   }
   return true;
}

/*** Cedric Delayre's job ***/


/*++++++++++++++++++++++++++++++++++++++
  This function makes a given state unreachable. It deletes all the
transitions from and to this state.

void isolate_state    This function returns nothing

state_node *des       The DES data structure

int states            The number of states

int state             The state to isolate
  ++++++++++++++++++++++++++++++++++++++*/

void isolate_state(state_node *des, int states, int state)
{
  int i, j;

  assert(des);
  assert(state < states && state >= 0);

  /*
   * make this state unreachable
   */
  des[state].reached = false;
  des[state].coreach = false;

  /*
   * delete all the transitions from this state
   */
  free(des[state].next);
  des[state].next = NULL;
  des[state].numelts = 0;

  /*
   * delete all the transitions going to this state
   */
  for (i=0; i<states; i++) {
    for (j=0; j<des[i].numelts; j++) {
      if (des[i].next[j].data2 == state) {
	remove_transition(des, states, i, des[i].next[j].data1, state);
      }
    }
  }
}

