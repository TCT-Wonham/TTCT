#ifndef _OUTCON_H
#define _OUTCON_H

#include "des_data.h"

extern void outcon_des(state_node**, INT_S*, INT_T**, INT_S*);

#endif
