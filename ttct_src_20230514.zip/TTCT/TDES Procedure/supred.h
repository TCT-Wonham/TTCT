#ifndef _SUPRED_H
#define _SUPRED_H

#include "des_data.h"

extern int supreduce(char *,
                     char *,
                     char *,
                     char *,
                     INT_S*,
                     double long*);
extern int supreduce1(char *,
                     char *,
                     char *,
                     char *,
                     INT_S*,
                     double long*,
                     INT_S*);
extern int supreduce2(char *,
                     char *,
                     char *,
                     char *,
                     INT_S*,
                     double long*,
                     INT_S*);
extern int supreduce3(char *,
                     char *,
                     char *,
                     char *,
                     INT_S*,
                     double long*,
                     INT_S*);

#endif

