#ifndef _CONVERT_H
#define _CONVERT_H




#ifdef __cplusplus
extern "C" {
#endif

extern int convert_program(char *, char * , int, int);


#ifdef __cplusplus
}
#endif
                   
#endif 
