#include <stdio.h>
#include <stdlib.h>
#include "des_proc.h"
#include "cnorm.h"

/* This procedures is the same as "gentranlist" in DES_PROC.C */
void get_event_list(INT_S s1, state_node *t1, INT_T **list1, INT_T *s_t1)
{
   /* Generate a list of all transition labels used in DES */
   INT_S i;
   INT_T j;
   INT_B ok;

   *s_t1 = 0;
   *list1 = NULL;
   if (s1 == 0L) return;

   for (i=0L; i < s1; i++) {
     for (j=0; j < t1[i].numelts; j++) {
       addordlist(t1[i].next[j].data1, list1, *s_t1, &ok);
       if (ok) (*s_t1)++;
     }
   }
}

/* Is this the same as "gendifflist" in DES_PROC.C */
void get_event_diff(INT_T **aux, INT_T *s_aux,
                    INT_T *list2, INT_T s_list2,
                    INT_T *list0, INT_T s_list0)
{
    INT_T ii;
    INT_B ok;

    for (ii=0; ii < s_list2; ii++) {
       if (inlist(list2[ii], list0, s_list0)) {
          addordlist(list2[ii], aux, *s_aux, &ok);
          if (ok) (*s_aux)++;
       }
    }
}

void copy_des(state_node **t_dest, INT_S *s_dest,
              state_node *t_src,   INT_S s_src)
{
    INT_S i, jj;
    INT_T j, ee;
    INT_B ok;

    *s_dest = s_src;
    *t_dest = newdes(s_src);

    if ((s_src !=0) && (*t_dest == NULL)) {
      mem_result = 1;
      return;
    }

    for (i=0; i < s_src; i++) {
      (*t_dest)[i].marked  = t_src[i].marked;
      (*t_dest)[i].reached = t_src[i].reached;
      (*t_dest)[i].coreach = t_src[i].coreach;
      (*t_dest)[i].vocal   = t_src[i].vocal;
      for (j=0; j < t_src[i].numelts; j++) {
         ee = t_src[i].next[j].data1;
         jj = t_src[i].next[j].data2;
         addordlist1(ee, jj, &(*t_dest)[i].next, (*t_dest)[i].numelts, &ok);
         if (ok) (*t_dest)[i].numelts++;
      }
    }
}

void suprema_normal(state_node*  t1, INT_S s1, INT_T *t4, INT_S s4,
                    state_node*  t2, INT_S s2, INT_T *t5, INT_S s5,
                    state_node** t3, INT_S *s3, INT_T **t6, INT_S *s6,
                    INT_T *nullist, INT_T s_nullist)
{
   state_node *_t0, *_t1, *_t2, *_t3, *_t4, *_t5, *_t6, *_t7;
   INT_S _s0, _s1, _s2, _s3, _s4, _s5, _s6, _s7;

   INT_T *list0, *list2, *list4, *aux1, *aux3, *list;
   INT_T s_list0, s_list2, s_list4, s_aux1, s_aux3, s_list;
   INT_S i;
   INT_S dummy;
   INT_T *dummy1;

   INT_S *macro_ab; INT_S *macro_c;

   dummy = 0;
   dummy1 = NULL;
   /* 1.  Initialize tempory data structures */
   _t0 = NULL;   _t1 = NULL;   _t2 = NULL;   _t3 = NULL;
   _t4 = NULL;   _t5 = NULL;   _t6 = NULL;   _t7 = NULL;

   _s0 = 0; _s1 = 0; _s2 = 0; _s3 = 0;
   _s4 = 0; _s5 = 0; _s6 = 0; _s7 = 0;

   list0 = NULL; list2 = NULL; list4 = NULL; aux1 = NULL; aux3 = NULL;
   s_list0 = 0; s_list2 = 0; s_list4 = 0; s_aux1 = 0; s_aux3 = 0;

   macro_ab = NULL; macro_c = NULL;

   /* 2. LIST2 = [all event labels that appear in t2] */
   get_event_list(s2, t2, &list2, &s_list2);

   /* 3. t3 = meet(t1, t2) */
   meet2(s1, t1, s2, t2, &_s0, &_t0, &macro_ab, &macro_c);
   free(macro_ab); free(macro_c);
   macro_ab = NULL; macro_c = NULL;

   /* 4. LIST0 = [all event labels that appear in _t0] */
   get_event_list(_s0, _t0, &list0, &s_list0);

   /* 5. aux1 = [all event labels which appear in LIST2, but which
                 do not appear in LIST0] */
   get_event_diff(&aux1, &s_aux1, list2, s_list2, list0, s_list0);
   free(list0); list0 = NULL; s_list0 = 0;

   /* 6. _t1 = COMPLEMENT(_t0, aux1) */
   /* Copy _t1 <- _t0 */
   copy_des(&_t1,&_s1,_t0,_s0);
   complement1(&_s1, &_t1, s_aux1, aux1);
   reach(&_s1, &_t1, &dummy, &dummy1); 
   free(aux1); aux1 = NULL; s_aux1 = 0;

   /* 7. _t2 = meet(t2, _t1) */
   meet2(s2, t2, _s1, _t1, &_s2, &_t2, &macro_ab, &macro_c);
   free(macro_ab); free(macro_c);
   macro_ab = NULL; macro_c = NULL;
   freedes(_s1, &_t1);
   _s1 = 0; _t1 = NULL;

   /* 8. _t3 = project(_t2, null_event_list) */
   _t3 = _t2;
   _s3 = _s2;
   _t2 = NULL;
   _s2 = 0;

/*   if (s_nullist == 0) {
      reach(&_s3, &_t3);
      minimize(&_s3, &_t3);
   } else {
      project1(&_s3, &_t3, s_nullist, nullist);
      if (_s3 > 0) {
        reach(&_s3, &_t3);
        minimize(&_s3, &_t3);
      }
   }
*/
   project0(&_s3, &_t3, &dummy, &dummy1, s_nullist, nullist);

   /* 9. _t4 = selfloop(_t3, null_event_list) */
   _t4 = _t3;
   _s4 = _s3;
   _t3 = NULL;
   _s3 = 0;
   gentran(s_nullist, nullist, _s4, _t4);

   /* 10. list4 = [all event labels which appear in _t4 */
   get_event_list(_s4, _t4, &list4, &s_list4);

   /* 11. aux3 = [all event labels which appear in LIST2, but which do
                  not appear in LIST4 */
   get_event_diff(&aux3, &s_aux3, list2, s_list2, list4, s_list4);
   free(list2); list2 = NULL; s_list2 = 0;
   free(list4); list4 = NULL; s_list4 = 0;

   /* 12. _t5 = complement(_t4, aux3) */
   _t5 = _t4;
   _s5 = _s4;
   _t4 = NULL;
   _s4 = 0;
   complement1(&_s5, &_t5, s_aux3, aux3);
   free(aux3); aux3 = NULL; s_aux3 = 0;

   /* 13. _t6 = meet(_t0, _t5) */
   meet2(_s0, _t0, _s5, _t5, &_s6, &_t6, &macro_ab, &macro_c);
   free(macro_ab); free(macro_c);
   macro_ab = NULL; macro_c = NULL;

   /* 14. _t7 = trim(_t6) */
   _t7 = _t6;
   _s7 = _s6;
   _t6 = NULL;
   _s6 = 0;

   /* Clear all reach */
   for (i=0; i < _s7; i++)
      _t7[i].reached = false;
   trim1(&_s7, &_t7, &dummy, &dummy1);

   /* Clear reach field of _t7 */
   for (i=1; i < _s7; i++)
     _t7[i].reached = false;
   if (_s7 > 0)
     _t7[0].reached = true;

   /* 15. t3 = minstate(_t7) */
   *t3 = _t7;
   *s3 = _s7;
   _t7 = NULL;
   _s7 = 0;
   reach(s3, t3, &dummy, &dummy1); 
   minimize(s3, t3);

   gentranlist(*s3, *t3, &s_list, &list);
   *s6 = s4;
   *t6 = (INT_T*) calloc(s4,sizeof(INT_T));
   memcpy(*t6, t4, sizeof(INT_T) * s4);
   remove_forcible(s6, t6, s_list, list);


   /* Cleanup the procedure of the intermediate data structures */
   free(_t0);   free(_t1);   free(_t2);   free(_t3);
   free(_t4);   free(_t5);   free(_t6);   free(_t7);
   free(list0); free(list2);  free(list4);
   free(aux1);  free(aux3);
}

