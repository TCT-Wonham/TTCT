
#include <stdio.h>
//#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <windows.h>
#include <direct.h>
#include "tct_curs.h"
#include "ttct_io.h"
#include <io.h>
#include"des_data.h"
#include"setup.h"
#include "convert.h"
#include "display.h"


#include"tct_proc.h"

#if defined(__DOS32__) || defined(__BORLANDC__) || defined(__WIN32__)
#include <dos.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
static time_t curTime;

int GenerateTxtFile(INT_S s1,state_node *t1, char * txtFilename,char *desName, int flag)
{
    char txtFile_fullname[MAX_PATH];
    char txttime[30]; char strtime[30];
    FILE *txt;
    INT_S i,j;
//    int ti;    
    struct tm *ts;
    INT_S entr;
    INT_T event;
	INT_B mark_flag;

    strcpy(txtFile_fullname,txtFilename);
    
    txt = fopen(txtFile_fullname,"w");
    if(txt == NULL)
           return 0;
    curTime = time(NULL);     
     ts = localtime(&curTime);  
   strcpy(txttime,"");
   strcpy(strtime,"");
   fprintf(txt,"digraph finite_state_machine {\n");
   fprintf(txt,"graph [label = \"");
   if(flag == 0){
	   fprintf(txt,"\\n\\nATG of TDES ");
   }else if(flag == 1){
	   fprintf(txt,"\\n\\nTTG of TDES ");
   }
   
   fprintf(txt,"%s \\n",desName);
   sprintf(txttime,"%4d.",ts->tm_year+1900);
   strcat(strtime,txttime);
   if(ts->tm_mon + 1 > 9 )
     sprintf(txttime,"%2d.",ts->tm_mon + 1);
   else
     sprintf(txttime,"0%d.",ts->tm_mon + 1);
   strcat(strtime,txttime);
   if(ts->tm_mday > 9 )
     sprintf(txttime,"%2d/",ts->tm_mday);
   else
     sprintf(txttime,"0%d/",ts->tm_mday);
   strcat(strtime,txttime);
   if(ts->tm_hour > 9 )
     sprintf(txttime,"%2d:",ts->tm_hour);
   else
     sprintf(txttime,"0%d:",ts->tm_hour);
   strcat(strtime,txttime);
   if(ts->tm_min > 9 )
     sprintf(txttime,"%2d ",ts->tm_min);
   else
     sprintf(txttime,"0%d ",ts->tm_min);
   strcat(strtime,txttime);

   fprintf(txt,"%s \"",strtime);
   fseek(txt,ftell(txt)-2,SEEK_SET);
   fprintf(txt,"\"];\n");
   fprintf(txt,"rankdir=LR;\n");
   fprintf(txt,"node [shape = doublecircle]; ");
   
   mark_flag = false;
   for(i=0;i<s1;i++){
       if(t1[i].marked == true){
          fprintf(txt,"%d ",i);
		  mark_flag = true;
	   }
   }
   if(mark_flag)
	 fprintf(txt,";\n");

   if(s1 != 0){
   fprintf(txt,"node [shape = circle];\n");
   //Add the entering arrow to state 0 to indicate initial
   fprintf(txt, "a [color = white, fontsize = 0.1, fontcolor = white, length = 0.3, width = 0.3, fixedsize = true];\n");
   fprintf(txt, "a -> 0;\n");     

   if(s1 == 1 && t1[0].numelts == 0){
	   fprintf(txt, "%d", 0);
   }
   
   for(i=0;i<s1;i++){
        for(j=0;j<t1[i].numelts;j++){
             fprintf(txt,"%d -> ",i);
             entr = t1[i].next[j].data2;
             event = t1[i].next[j].data1;
             fprintf(txt,"%d  [ label = \"",entr);
             if(event != EEE){
                 if(event == 0 && flag == 1){
                    if(t1[entr].vocal >= 1 && t1[entr].vocal <= 999){
                       fprintf(txt,"tick/%d\" ];\n",t1[entr].vocal);
                    } else{
                       fprintf(txt,"tick\" ];\n"); 
                    } 
                 } else{
                    if(t1[entr].vocal >= 1 && t1[entr].vocal <= 999){
                       fprintf(txt,"%d/%d\" ];\n",event,t1[entr].vocal);
                    } else{
                       fprintf(txt,"%d\" ];\n",event); 
                    }    
                 }
             } else{
                 if(t1[entr].vocal >= 1 && t1[entr].vocal <= 999){
                     fprintf(txt,"/%d\" ];\n",t1[entr].vocal);
                 } else{
                     fprintf(txt," \" ];\n"); 
                 } 
             }         
                        
        }  
   }
   }
   fprintf(txt,"}");
   fclose(txt);
   return 1;
}

int convert_program(char * name1, char * name2, int flag, int format_change)
{  
     int errorno;
     state_node *t1;
     INT_S s1,init;
     timed_event *t2;
     INT_T s2;
     INT_T *t3;
     INT_S s3;
     int txtFlag = 0;    
     int result;
//     FILE *f1;
     
//     char *pos;
     char currentpath[MAX_PATH];
     char exefullpath[MAX_PATH];
     char cmdLine[1024];
//     char path1[MAX_PATH];
//     char cprefix[MAX_PATH];
     char exname2[MAX_PATH];
//     char long_name2[MAX_PATH];
//     char long_txtname[MAX_PATH];
     char txtname[MAX_PATH];
     char binname[MAX_PATH]="\\GRAPHVIZ\\dot.exe";
     char long_binname[MAX_PATH];
     
     char ini[99];
//     char  str[99];
     char *ptr;
     char currentDir[256];
     
     s1 = 0; t1 = NULL;
     s2 = 0; t2 = NULL;
	 s3 = 0; t3 = NULL;
     
     strcpy(ini, "");
     _getcwd(currentDir, 255);   
     ptr = strchr(currentDir, '\\');
     if (ptr != NULL)
     {
        ptr[0] = 0;
        strcpy(ini, currentDir);
        strcpy(ini, "\\");
     } 
     else
     {
        strcat(ini, "C:\\");
     }
     strcat(ini,INIFILE); 
     
     errorno = -1;
     result = 0;
     
     init = 0L;
     if(flag == 0){
        if(getads(name1,&s1,&init,&t1, &s2, &t2)==false){      
          return -1;
        } 
     }else if(flag == 1){
        if(gettds(name1,&s1,&init,&t1, &s3, &t3)==false){      
          return -1;
        } 
     }
     if(format_change){
        init = 0L;
        filedes(name1, s1, init, t1);
     }
     /*Get current path and set new work path */
    /* f1 = fopen(ini,"rt");
     fgets(path1,255,f1);
     if (path1[strlen(path1)-1] == '\n')
        path1[strlen(path1)-1] = '\0';
     fclose(f1);*/
     //pos = strrchr(path1,'\\');
     //if(pos)
     //   pos ++;
     //else
     //   pos = path1;
     
    // strcpy(currentpath,"");
     _getcwd(currentpath,MAX_PATH);
//     strcpy(cprefix,currentpath);
//     if (cprefix[strlen(cprefix)-1] == '\\')
//        cprefix[strlen(cprefix)-1] = '\0';
//     strcat(cprefix,"\\");
     //strcat(cprefix,pos);
     //strcat(cprefix,"\\");
     //printf(cprefix);
     _chdir(prefix);
     
     /*Make full name of GIF file*/     
     strcpy(exname2,"");
     strcat(exname2,name2);
     if(flag == 0)
        strcat(exname2,".GIF"); 
     else if(flag == 1)
        strcat(exname2, ".JPG");
    // strcpy(long_name2,"\"");
    // strcat(long_name2,path1);
    // strcat(long_name2,exname2);
    // strcat(long_name2,"\"");
//     printf(long_name2);
     /*Make full name of dot.exe and check wether it exists or doesn't*/
     strcpy(long_binname,"");
     strcat(long_binname,currentpath);
     strcat(long_binname,binname);
     if(!exist(long_binname)){
         printw("Conversion failure: Graphviz folder must be placed in workspace!");
         result = -1;
         goto CONVERT_LABEL;
     }
     strcpy(exefullpath,"\"");
     strcat(exefullpath,long_binname); 
     strcat(exefullpath,"\"");   

     strcpy(cmdLine,exefullpath);
     strcat(cmdLine," -T");
     if(flag == 0)
        strcat(cmdLine,"gif");
     else if(flag == 1)
        strcat(cmdLine, "jpg");        
     strcat(cmdLine," -o ");
     strcat(cmdLine,exname2);      
     
     /*Make full name of TXT file which is used to generate GIF file*/
     strcpy(txtname,"");
     strcat(txtname,name2);     
     strcat(txtname,".txt");     
     //strcpy(long_txtname,"");     
     //strcat(long_txtname,cprefix);
     //strcat(long_txtname,txtname);
     //printf(long_txtname);
     /*Generate TXT file*/
     txtFlag = GenerateTxtFile(s1,t1,txtname,name1, flag);
     if(txtFlag == 0){
         result = -1;
         goto CONVERT_LABEL;
     }
     
     /*Make command line*/
     strcat(cmdLine," ");
     strcat(cmdLine,txtname);
     //printw(cmdLine);
     /*Execute the command line */
     errorno = system(cmdLine); 
     
     if(errorno ==127 || errorno == -1)
        result = -1;
        
     /*Check whether the object file be generated or not*/
     if(!exist(exname2))  
        result = -2;                         

CONVERT_LABEL:
     /*Remove the TXT file and change work directory to the original*/
     remove(txtname);     
     _chdir(currentpath);
     
     freedes(s1, &t1);
     free(t2);
     free(t3);
     return result;
}

#ifdef __cplusplus
}
#endif
