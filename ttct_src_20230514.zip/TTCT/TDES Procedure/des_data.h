#ifndef _DES_DATA_H
#define _DES_DATA_H

/* Common definitions */
#define false 0
#define true  1

/* Some constants */
/*#if defined(__BORLANDC__)
#define MAX_STATES        16000
#else*/
#define MAX_STATES        2000000
/*#endif*/

#define MAX_DESS    20
#define MAX_FILENAME   256
#define MAX_LONG_FILENAME  1024

#define TICK              0
#define MAX_TIME          1000
#define MAX_TRANSITIONS   999
#define MAX_VOCAL_OUTPUT  999

#define EEE               1000

/* Some macros */
//#define max(a,b)   (((a) > (b)) ? (a) : (b))
//#define min(a,b)   (((a) < (b)) ? (a) : (b))

extern int mem_result;

//typedef unsigned int   boolean;
typedef long           INT_S;     /* State type        */
typedef unsigned short INT_T;     /* Event label type  */
typedef short          INT_V;     /* Vocal output type */
typedef unsigned short INT_B;

/*#if defined(__BORLANDC__)
#include "des_dos.h"
#else*/
#include "des_unix.h"
/*#endif*/

/* state information struct */
typedef struct state_info {
   INT_S state;                    /* state number of composite state */
   struct state_info *next;
} state_info;

/* timer information struct */
typedef struct timer_info {
   INT_T num;                      /* number of timer */
   INT_T value;                    /* value of timer  */
/*   struct timer_info *next;*/
} timer_info;

/* The fields are aligned on those important fields */
typedef struct state_node {
   INT_B marked  : 1;           /* 1-bit  */
   INT_B reached : 1;           /* 1-bit  */
   INT_B coreach : 1;           /* 1-bit  */
   INT_V vocal : 13;              /* 13-bit */           /* 0..999 */
   state_info *nstinfo;           /* 32-bit */
   INT_T numtimer;                /* 16-bit */ 
   timer_info *ntimer;            /* 32-bit */
   INT_T numelts;                 /* 16-bit */
   tran_node *next;               /* 32-bit */
} state_node;                     /* 18 bytes total */

/* The new timed event structure */ 
typedef struct timed_event { 
   INT_T label;                    /* event label (number) */
   INT_T low;                      /* lower boundary of event */ 
   INT_T upper;                    /* upper boundary of event */ 
   INT_B forcible;               /* flag for forcible */
} timed_event;

/* forcible event structure 
typedef struct forcible_event {
   INT_T label;
   INT_B forcible;
} forcible_event;
*/

/* A structure to hold a list of states */
typedef struct part_node {
   INT_S numelts;
   INT_S *next;
} part_node;

/* State pair */
typedef struct state_pair {
   INT_S data1, data2;
} state_pair;

/* Triple */
typedef struct triple {
   INT_S i;
   INT_T e;
   INT_S j;
} triple;

/* Quad set */
typedef struct quad__t {
   INT_S a;
   INT_T b;
   INT_S c;
   INT_V d;
} quad__t;

typedef short color_t;

#define green_color 0
#define red_color   1
#define amber_color 2

extern state_node* newdes(INT_S);
extern void resize_des(state_node**, INT_S, INT_S);
extern void freedes(INT_S, state_node**);
extern void free_map(INT_S, state_map**);
extern int filedes(char*, INT_S, INT_S, state_node*);
extern INT_B getdes(char*, INT_S*, INT_S*, state_node**);

extern int filetds(char*, INT_S, INT_S, state_node*, INT_S, INT_T*);
extern INT_B gettds(char*, INT_S*, INT_S*, state_node**, INT_S*, INT_T**);

extern int fileads(char*, INT_S, INT_S, state_node*, INT_T, timed_event*);
extern INT_B getads(char*, INT_S*, INT_S*, state_node**, INT_T*, 
		      timed_event**);

extern void addordlist1(INT_T, INT_S, tran_node**, INT_T, INT_B*);
extern void addordlist(INT_T, INT_T**, INT_T, INT_B*);
extern void addunordlist1(INT_T e,
	INT_S j,
	tran_node **L,
	INT_T size,
	INT_B *ok);

extern void addstatelist(INT_S, INT_S**, INT_S, INT_B*);
extern INT_B instatelist(INT_S, INT_S*, INT_S);
extern void addstatemap(INT_S, INT_S, state_map**, INT_S, INT_B*);
extern void addstatepair(INT_S, INT_S, state_pair**, INT_S, INT_B*);
extern INT_B instatepair(INT_S, INT_S, state_pair**, INT_S);

extern void insertlist4(INT_S, INT_T, INT_S, INT_S*, state_node **);
extern void addtriple(INT_S, INT_T, INT_S, triple**, INT_S, INT_B*);
extern void delete_ordlist1(INT_T, INT_S, tran_node**, INT_T, INT_B*);
extern INT_B inlist(INT_T, INT_T*, INT_T);
extern void add_quad(INT_S, INT_T, INT_S, INT_V, quad__t**, INT_S, INT_B*);
extern INT_B check_des_sanity(state_node*, INT_S);
extern INT_S num_mark_states(state_node*, INT_S);
extern INT_S num_vocal_output(state_node*, INT_S);
extern INT_S num_forcible_events(timed_event*, INT_T);

extern INT_B is_valid_transition(INT_S i, INT_T e, INT_S *j,
                            state_node *t1, INT_S s1);

extern INT_B
add_transition( state_node *data, int elemts, int s, int e, int t );
extern INT_B
add_marker(state_node *des, int states, int marker);
extern INT_B
is_marked(state_node *des, int states, int i);
extern INT_B
remove_marker(state_node *des, int states, int marker);
extern INT_B
add_states(state_node **des, int *states, int count);
extern INT_B
remove_transition( state_node *data, int elemts, int s, int e, int t );

extern void 
addordlist_time(INT_T, INT_T, INT_T, timed_event**, INT_T, INT_B*);

#endif

