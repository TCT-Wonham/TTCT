#ifndef _TCT_PROC_H
#define _TCT_PROC_H
//#include <dirent.h>
#include "des_data.h"

#if !defined(__GO32__)

#define EXT_ADS       ".ads"
#define EXT_DES       ".tds"   
#define EXT_DAT       ".dat"
#define EXT_TXT       ".txt"
#define EXT_PDS       ".pds"
#define EXT_PDT       ".pdt"
#define EXT_DAV       ".dav"
#define EXT_PSS       ".pss"
#define EXT_PST       ".pst"
#define EXT_ATS       ".ats"    /* .TDS TDS ASCII format */
#define EXT_AAS       ".aas"    /* .ADS ADS ASCII format */
#define EXT_GIF       ".gif"
#define EXT_JPG       ".jpg"

#else
#include <dos.h>
#include <direct.h>

#define EXT_ADS       ".ADS"
#define EXT_DES       ".TDS"
#define EXT_DAT       ".DAT"
#define EXT_TXT       ".TXT"
#define EXT_PDS       ".PDS"
#define EXT_PDT       ".PDT"
#define EXT_DAV       ".DAV"
#define EXT_PSS       ".PSS"
#define EXT_PST       ".PST"
#define EXT_ATS       ".ATS"    /* .TDS TDS ASCII format */
#define EXT_AAS       ".AAS"    /* .ADS ADS ASCII format */

#define EXT_GIF       ".GIF"
#define EXT_JPG       ".JPG"

#endif

#define des_filesize  80
typedef char filename[MAX_FILENAME];
typedef char long_filename[MAX_LONG_FILENAME];

extern void setuserpath(char *ini_file);
extern char *dos_uppercase(char *string);


extern void not_yet();
extern void create_p(); 
extern void trim_p(); 
extern void trim_ap(); 
extern void selfloop_p(); 
extern void selfloop_ap(); 
extern void sync_p();
extern void comp_ap();
extern void convert_ap();  
extern void meet_p(); 
extern void supcon_p();  
extern void mutex_p();  
extern void mutex_ap();  
extern void condat_p();  
extern void supreduce_p();
extern void minstate_p();  
extern void minstate_ap();  
extern void complement_ap(); 
extern void complement_p(); 
extern void isomorph_p();  
extern void isomorph_ap();  
extern void nonconflict_p();
extern void bfs_recode_p();
extern void bfs_recode_ap();
extern void directory_p();

extern void create_ap();

extern void vocalize_p();
extern void outconsis_p();
extern void hiconsis_p();
extern void higen_p();

extern void supnorm_p();

extern void project_p();
extern void eventmap_p();
extern void allevents_p();
extern void export_gml_des_p();
extern void export_place_des_p();

extern void print_des_p();
extern void print_ads_p();
extern void print_dat_p();
extern void print_ascii_p();

extern void file_des_p();
extern void file_dat_p();
extern void file_ats_p();

extern void file_ads_p();
extern void file_aas_p(); 

extern void export_ads_ap();
extern void export_altads_ap();
extern void export_des_p();
extern void export_altdes_p();

extern void introduction_p();
extern void reset_directory_p();
extern void bell_control_p();
extern void display_control_p();
extern void timing_control_p();

extern void user_pause();

extern void find_timebounds(INT_T s1, timed_event *t1, INT_T label, 
			    INT_T *index);
extern INT_B chk_for_tick(INT_S *s1, state_node **t1);
extern void mergeChop(int);
extern INT_B any_mark_states(state_node*, INT_S);
extern INT_B any_vocal_output(state_node*, INT_S);
extern void check_determinism(state_node*, INT_S, char*, INT_B*, INT_B);
extern void check_des_p();
extern INT_B chk_diff_forcible(INT_S s1, state_node *t1, INT_T s2, INT_T *t2,
	INT_S s3, state_node *t3, INT_T s4, INT_T *t4);

extern void convert_p(int);
extern void display_p(int);
extern void localize_p();
#endif



