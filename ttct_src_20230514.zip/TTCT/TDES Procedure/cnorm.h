#ifndef _CNORM_H
#define _CNORM_H

#include "des_data.h"

extern void suprema_normal(state_node*, INT_S, INT_T*, INT_S,
                           state_node*, INT_S, INT_T*, INT_S,
                           state_node**,INT_S*, INT_T**, INT_S*,
                           INT_T*, INT_T);

#endif
