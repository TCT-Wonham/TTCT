#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "des_data.h"
#include "supred.h"

static char signature[8] = {"Z8^0L;1"};
static int  signature_length = 7;
static long endian = 0xFF00AA55;
unsigned short *forcible_event;
long elemts1;
int *controller,*controller_tree, *simpler_controller, **merging_table, *plant,*c_marked_states,*p_marked_states;

int *record;

int data_length = 32;


int *tmpu_stack;

long tran_number, num_states;
struct equivalent_state_set{
       int state_number;
       struct equivalent_state_set *next_node;
};
struct forbidden_event_set{
       int event;
       struct forbidden_event_set *next_event;
};
struct transitions{
       int event;
       int target_state_number;
       struct transitions *next_transition;
};
struct node{
       struct equivalent_state_set *equal_set;
       INT_B marked_in_plant;
       INT_B marked_in_controller;
       struct forbidden_event_set *forb_set;
       struct transitions *tran_set;
} *root_node;
struct virtual_stack{
       int state_1;
       int state_2;
       int node_1,node_2,c_flag, flag, r_flag_1,r_flag_2;
       int tmpu_point_1,tmpu_point_2;
       int record_point_1, record_point_2;
       struct equivalent_state_set *temp6, *temp7;
       struct transitions *temp3, *temp4;
       int tmp_state_3, tmp_state_4;
       int tmp_state_1, tmp_state_2;
       struct virtual_stack *last_state_pair;
       struct virtual_stack *next_state_pair;
} *stack;


FILE *out;

int Txt_DES(int);
void Controller_Tree();
int Combined_Tree();
int Set_State_No_of_Plant(int);
int Forbidden_Event(char*);
void Tree_Structure_Conversion(char*);
void Reduction();
void Reduction2();
int Selfloop_Node(int, int, int, int);
int Selfloop_Node2(int, int, int, int);
int Selfloop_Node3(int, int, int, int);
void Final_Result();
int Refinement();
int Refinement2();
int Get_DES(long *, long *, int, char*);

void father_node_in_controller_tree(int);

/*I use this module to read the data directly from DES files.*/
int Get_DES(long *tran_number,long *num_states,int index, char *name)
{
   FILE *in;
   int base_point;
   long mark, s, z, yy,init;
   short num;
   char ch;
   char header[8];
   long read_endian;
   long block_type, block_size;
   long address,tmp,index_1;
   int counter,mark_states_number;

   in = NULL;
   while(in == NULL)
   {
     if(index==0)
     {
        /* Input the DES data file for spec */
        in = fopen(name, "rb");
     }
     if(index==1)
     {
        /* Input the DES data file of the plant */
        in = fopen(name, "rb");
     }
     if (in == NULL)
     {
        return 1;
     }
   }

   /* Setup a buffer for faster IO */
   setvbuf(in, NULL, _IOFBF, 32000);

   /* Read the ASCII header and junk */
   ch = 0;
   while ((ch != 26) && !feof(in)) {
      fread(&ch, sizeof(char), 1, in);
   }

   memset(header, 0, 8); /* Zero out the string */
   /* Read the unique string to authenic CTCT DES file */
   fread(header, sizeof(char), 7, in);
   if (strcmp(header, signature) != 0) {
      fclose(in);
      return 9;
   }

   /* Big-endian and Little-endian information */
   fread(&read_endian, sizeof(long), 1, in);
   if (read_endian != endian) {
      fclose(in);
      return 2;
   }

   /* Block type */
   fread(&block_type, sizeof(long), 1, in);
   if (block_type != 0) {
      fclose(in);
      return 3;
   }

   /* Read the number of bytes of this block type */
   fread(&block_size, sizeof(long), 1, in);

   fread(num_states, sizeof(long), 1, in);
   fread(&init, sizeof(long), 1, in);

   if (ferror(in)) {
      fclose(in);
      return 4;
   }

   /* Read the marked states */
   address=ftell(in);
   mark_states_number=0;
   mark = 0L;
   while (mark != -1L) {
      fread(&mark, sizeof(long), 1, in);
      mark_states_number +=1;
   }
   if(index==0)
   {
     c_marked_states= (int *) malloc((mark_states_number+1)*sizeof(int));
     if (c_marked_states == NULL)
     {
        mem_result = 1;
        fclose(in);
        return 5;
     }
   }
   if(index==1)
   {
     p_marked_states= (int *) malloc((mark_states_number+1)*sizeof(int));
     if (p_marked_states == NULL)
     {
        free(c_marked_states); c_marked_states = NULL;
        mem_result = 1;
        fclose(in);
        return 6;
     }
   }

   fseek(in,address,SEEK_SET);
   base_point=0;
   mark=0L;
   while(mark!=-1L)
   {
      fread(&mark,sizeof(long),1,in);
      if(index==0)
      {
         c_marked_states[base_point]=(int)mark;
      }
      if(index==1)
      {
         p_marked_states[base_point]=(int)mark;
      }
      base_point +=1;
   }
   if(index==0)
   {
     c_marked_states[base_point]=-1;
   }
   if(index==1)
   {
     p_marked_states[base_point]=-1;
   }

   /* Read the transitions */
   address=ftell(in);
   s = 0L;
   *tran_number=0;
   index_1 = 0;
   while (s != -1L) {
      fread(&s, sizeof(long), 1, in);
      if (s == -1L) break;
      fread(&num, sizeof(short), 1, in);
      *tran_number += num;
      index_1 += 1;
      for (z=0; z < num; z++) {
         fread(&yy, sizeof(long), 1, in);
      }
   }
   counter = *num_states - index_1;
   *tran_number = *tran_number+counter;
   if(index==0)
   {
      controller =(int *) malloc((3*(*tran_number)+1)*sizeof(int)); /*.....*/
      if (controller == NULL)
      {
         free(c_marked_states); c_marked_states = NULL;
         free(p_marked_states); p_marked_states = NULL;
         mem_result = 1;
         fclose(in);
         return 7;
      }
   }
   if(index==1)
   {
      plant =(int *) malloc((3*(*tran_number)+1)*sizeof(int)); /*.....*/
      if (plant == NULL)
      {
         free(c_marked_states); c_marked_states = NULL;
         free(p_marked_states); p_marked_states = NULL;
         free(controller);      controller = NULL;
         mem_result = 1;
         fclose(in);
         return 8;
      }
   }
   fseek(in,address,SEEK_SET);

   /* Modification start here ......................... */

   fread(&s,sizeof(long),1,in);
   if(s==-1L)
   {
       base_point = 0;
       for(index_1=0;index_1<*num_states;index_1++)
       {
          if(index==0)
          {
            controller[3*base_point]=(int)index_1;
            controller[3*base_point+1]=1000+(int)index_1;
            controller[3*base_point+2]=(int)index_1;
            base_point += 1;
	  }
 	  if(index==1)
	  {
            plant[3*base_point]=(int)index_1;
            plant[3*base_point+1]=5000+(int)index_1;
            plant[3*base_point+2]=(int)index_1;
            base_point +=1;
	  }
       }
   }
   else
   {
     fseek(in,address,SEEK_SET);
     s=0L;
     base_point=0;
     index_1=-1;
     while(s!=-1L)
     {
       index_1 +=1;
       fread(&s,sizeof(long),1,in);
       if(s==-1L) break;
       fread(&num,sizeof(short),1,in);
       for(z=0;z<num;z++)
       {
          fread(&yy,sizeof(long),1,in);
          if(index==0)
	  {
            if(index_1!=s)
            {
              while(index_1<s)
   	      {
                controller[3*base_point]=(int)index_1;
                controller[3*base_point+1]=1000+(int)index_1;
                controller[3*base_point+2]=(int)index_1;
                base_point +=1;
                index_1 +=1;
   	      }
 	    }
            controller[3*base_point]=(int)s;
            tmp=yy;
            controller[3*base_point+2]=(int) (yy & 0x003FFFFF);
            controller[3*base_point+1]=(int) ((unsigned long) tmp >> 22);
          }
          if(index==1)
	  {
            if(index_1!=s)
            {
              while(index_1<s)
   	      {
                plant[3*base_point]=(int)index_1;
                plant[3*base_point+1]=5000+(int)index_1;
                plant[3*base_point+2]=(int)index_1;
                base_point +=1;
                index_1 +=1;
              }
            }
            plant[3*base_point]=(int)s;
            tmp=yy;
            plant[3*base_point+2]=(int) (yy & 0x003FFFFF);
            plant[3*base_point+1]=(int) ((unsigned long) tmp >> 22);
            }
          base_point +=1;
          }
       }
   }  

   /* Modification ends here ............................ */

   if(index==0)
   {
     if(*num_states-1>controller[3*(base_point-1)])
     {
        for(z=controller[3*(base_point-1)]+1;z<*num_states;z++)
        {
          controller[3*base_point]=z;
          controller[3*base_point+1]=1000+z;
          controller[3*base_point+2]=z;
          base_point +=1;
        }
     }
     controller[3*base_point]=-1;
   }
   if(index==1)
   {
     if(*num_states-1>plant[3*(base_point-1)])
     {
        for(z=plant[3*(base_point-1)]+1;z<*num_states;z++)
        {
          plant[3*base_point]=z;
          plant[3*base_point+1]=5000+z;
          plant[3*base_point+2]=z;
          base_point +=1;
        }
     }
     plant[3*base_point]=-1;
   }

   /* Read the vocal states */

   /* We don't read the last block type because we don't know how to
      process anything else after this point */

   fclose(in);
   return 0;
}


/*This module is part of the main module Reduction.*/
int Selfloop_Node(int base_state,int tmp_state,int nodel, int indexx)
{
  int node_1,node_2,c_flag, flag, r_flag_1,r_flag_2;
  int tmpu_point,tmpu_point_1,tmpu_point_2,k;
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  struct equivalent_state_set *temp6, *temp7;
  int tmp_state_1, tmp_state_2;

  node_1=base_state;
  node_2=tmp_state;

  temp6=root_node[root_node[node_1].equal_set->state_number].equal_set;
  r_flag_1=0;
  tmpu_point_1=0;

  while(r_flag_1==0)
  {
   if(indexx == 0)
   {
    if(temp6 != NULL)
    {
        tmp_state_1 = temp6->state_number;
        temp6 = temp6->next_node;
    }
    else
    {
        tmp_state_1=-1;
        while(*(tmpu_stack+2*tmpu_point_1)!=-1)
        {
            if(*(tmpu_stack+2*tmpu_point_1)==node_1)
            {
                tmp_state_1=*(tmpu_stack+2*tmpu_point_1+1);
                tmpu_point_1 +=1;
                break;
            }
            if(*(tmpu_stack+2*tmpu_point_1+1)==node_1)
            {
                tmp_state_1=*(tmpu_stack+2*tmpu_point_1);
                tmpu_point_1 +=1;
                break;
            }
            tmpu_point_1 +=1;
        }
        if(tmp_state_1==-1) r_flag_1=1;;
    }
   }
   else
   {
        r_flag_1 = 1;
        tmp_state_1 = node_1;
   }

    if(tmp_state_1!= -1)
    {
        temp7=root_node[root_node[node_2].equal_set->state_number].equal_set;
        r_flag_2=0;
        tmpu_point_2=0;
        while(r_flag_2==0)
        {
          if(indexx == 0)
          {
           if(temp7 != NULL)
           {
                 tmp_state_2 = temp7->state_number;
                 temp7 = temp7->next_node;
           }
           else
           {
                 tmp_state_2=-1;
                 while(*(tmpu_stack+2*tmpu_point_2)!=-1)
                 {
                     if(*(tmpu_stack+2*tmpu_point_2)==node_2)
                     {
                         tmp_state_2=*(tmpu_stack+2*tmpu_point_2+1);
                         tmpu_point_2 +=1;
                         break;
                     }
                     if(*(tmpu_stack+2*tmpu_point_2+1)==node_2)
                     {
                         tmp_state_2=*(tmpu_stack+2*tmpu_point_2);
                         tmpu_point_2 +=1;
                         break;
                     }
                     tmpu_point_2 +=1;
                 }
                 if(tmp_state_2==-1) r_flag_2=1;;
           }
          }
          else
          {
             r_flag_2 = 1;
             tmp_state_2 = node_2;
          }
           if(tmp_state_2!= -1)
           {
               c_flag=0;
               if((tmp_state_1!=node_1 || tmp_state_2!=node_2) && (tmp_state_1!=node_2 || tmp_state_2!=node_1))
               {
                   if(indexx == 1)
                   {
                      if(merging_table[tmp_state_1][tmp_state_2] == 0) continue;
                      if(merging_table[tmp_state_1][tmp_state_2] == 1 && tmp_state_1 != tmp_state_2) return 10;
                   }
                   if(root_node[tmp_state_1].equal_set->state_number == root_node[tmp_state_2].equal_set->state_number) continue;


                 tmpu_point=0;
                 while(*(tmpu_stack+2*tmpu_point)!=-1)
                 {
                    if(*(tmpu_stack+2*tmpu_point)==tmp_state_1 && *(tmpu_stack+2*tmpu_point+1)==tmp_state_2)
                    {
                        c_flag=8;
                        break;
                    }
                    if(*(tmpu_stack+2*tmpu_point+1)==tmp_state_1 && *(tmpu_stack+2*tmpu_point)==tmp_state_2)
                    {
                        c_flag=8;
                        break;
                    }
                    tmpu_point +=1;
                 }
                 if(c_flag ==8) continue;


                 if(root_node[tmp_state_1].marked_in_plant==root_node[tmp_state_2].marked_in_plant && root_node[tmp_state_1].marked_in_controller!=root_node[tmp_state_2].marked_in_controller)
                         return 10;

                 for(k=1;k<3;k++)
                 {
                   if(k==1)
                   {
                      temp1 = root_node[tmp_state_1].forb_set;
                      temp2 = root_node[tmp_state_2].tran_set;
                   }
                   if(k==2)
                   {
                      temp1 = root_node[tmp_state_2].forb_set;
                      temp2 = root_node[tmp_state_1].tran_set;
                   }
                   temp22 = temp2;
                   while(temp1 != NULL)
                   {
                     temp2 = temp22;
                     while(temp2 != NULL)
                     {
                         if(temp1->event == temp2->event)
                              return 10;
                         temp2 = temp2->next_transition;
                     }
                     temp1 = temp1->next_event;
                   }
                 }
                 if(c_flag!=8)
                 {
                    *(tmpu_stack+2*tmpu_point)=tmp_state_1;
                    *(tmpu_stack+2*tmpu_point+1)=tmp_state_2;
                    *(tmpu_stack+2*tmpu_point+2)=-1;
                 }
               }
               if(c_flag==0)
               {
                  struct transitions *temp3, *temp4;
                  int tmp_state_3, tmp_state_4;
                  temp3 = root_node[tmp_state_1].tran_set;
                  while(temp3 != NULL)
                  {
                     temp4 = root_node[tmp_state_2].tran_set;
                     while(temp4 != NULL)
                     {
                        if(temp3->event == temp4->event)
                        {
                           flag = 0;
                           tmp_state_3 = temp3->target_state_number;
                           tmp_state_4 = temp4->target_state_number;
                           if(indexx == 1)
                           {
                              if(merging_table[tmp_state_3][tmp_state_4] == 0)
                              {
                                  temp4 = temp4->next_transition;
                                  continue;
                              }
                              if(merging_table[tmp_state_3][tmp_state_4] == 1 && tmp_state_3 != tmp_state_4) return 10;
                           }
                           if((root_node[tmp_state_3].equal_set)->state_number != (root_node[tmp_state_4].equal_set)->state_number)
                           {

			     /*****************************************************************/

                               if((root_node[tmp_state_3].equal_set)->state_number<nodel || (root_node[tmp_state_4].equal_set)->state_number<nodel) return 10;
			     /*****************************************************************/


                               tmpu_point=0;
                               while(*(tmpu_stack+2*tmpu_point)!=-1)
                               {
                                  if(*(tmpu_stack+2*tmpu_point)==tmp_state_3 && *(tmpu_stack+2*tmpu_point+1)==tmp_state_4)
                                  {
                                      flag=8;
                                      break;
                                  }
                                  if(*(tmpu_stack+2*tmpu_point+1)==tmp_state_3 && *(tmpu_stack+2*tmpu_point)==tmp_state_4)
                                  {
                                      flag=8;
                                      break;
                                  }
                                  tmpu_point +=1;
                               }
                               if(flag==8)
                               {
                                   temp4=temp4->next_transition;
                                   continue;
                               }


                               if(root_node[tmp_state_3].marked_in_plant==root_node[tmp_state_4].marked_in_plant && root_node[tmp_state_3].marked_in_controller!=root_node[tmp_state_4].marked_in_controller)
                                   return 10;

                               for(k=1;k<3;k++)
                               {
                                  if(k==1)
                                  {
                                      temp1 = root_node[tmp_state_3].forb_set;
                                      temp2 = root_node[tmp_state_4].tran_set;
                                  }
                                  if(k==2)
                                  {
                                      temp1 = root_node[tmp_state_4].forb_set;
                                      temp2 = root_node[tmp_state_3].tran_set;
                                  }
                                  temp22 = temp2;
                                  while(temp1 != NULL)
                                  {
                                      temp2 = temp22;
                                      while(temp2 != NULL)
                                      {
                                          if(temp1->event == temp2->event)
                                               return 10;
                                          temp2 = temp2->next_transition;
                                      }
                                      temp1 = temp1->next_event;
                                  }
                               }
                               if(flag==0)
                               {
                                  *(tmpu_stack+2*tmpu_point)=tmp_state_3;
                                  *(tmpu_stack+2*tmpu_point+1)=tmp_state_4;
                                  *(tmpu_stack+2*tmpu_point+2)=-1;
                                  flag=Selfloop_Node(tmp_state_3,tmp_state_4,nodel,indexx);
                                  if(flag==10)
                                  {
                                     if(indexx == 1)
                                     {
                                       merging_table[tmp_state_3][tmp_state_4] = 1;
                                       merging_table[tmp_state_4][tmp_state_3] = 1;
                                     }
                                     return 10;
                                  }
                              }
                           }
                        }
                        temp4 = temp4->next_transition;
                     }
                     temp3 = temp3->next_transition;
                  }
               }
           }
        }
    }
  }
return 9;
}
//modified by ZRY exclude mark infomation
/*This module is part of the main module Reduction.*/
int Selfloop_Node2(int base_state,int tmp_state,int nodel, int indexx)
{
  int node_1,node_2,c_flag, flag, r_flag_1,r_flag_2;
  int tmpu_point,tmpu_point_1,tmpu_point_2,k;
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  struct equivalent_state_set *temp6, *temp7;
  int tmp_state_1, tmp_state_2;

  node_1=base_state;
  node_2=tmp_state;

  temp6=root_node[root_node[node_1].equal_set->state_number].equal_set;
  r_flag_1=0;
  tmpu_point_1=0;

  while(r_flag_1==0)
  {
   if(indexx == 0)
   {
    if(temp6 != NULL)
    {
        tmp_state_1 = temp6->state_number;
        temp6 = temp6->next_node;
    }
    else
    {
        tmp_state_1=-1;
        while(*(tmpu_stack+2*tmpu_point_1)!=-1)
        {
            if(*(tmpu_stack+2*tmpu_point_1)==node_1)
            {
                tmp_state_1=*(tmpu_stack+2*tmpu_point_1+1);
                tmpu_point_1 +=1;
                break;
            }
            if(*(tmpu_stack+2*tmpu_point_1+1)==node_1)
            {
                tmp_state_1=*(tmpu_stack+2*tmpu_point_1);
                tmpu_point_1 +=1;
                break;
            }
            tmpu_point_1 +=1;
        }
        if(tmp_state_1==-1) r_flag_1=1;;
    }
   }
   else
   {
        r_flag_1 = 1;
        tmp_state_1 = node_1;
   }

    if(tmp_state_1!= -1)
    {
        temp7=root_node[root_node[node_2].equal_set->state_number].equal_set;
        r_flag_2=0;
        tmpu_point_2=0;
        while(r_flag_2==0)
        {
          if(indexx == 0)
          {
           if(temp7 != NULL)
           {
                 tmp_state_2 = temp7->state_number;
                 temp7 = temp7->next_node;
           }
           else
           {
                 tmp_state_2=-1;
                 while(*(tmpu_stack+2*tmpu_point_2)!=-1)
                 {
                     if(*(tmpu_stack+2*tmpu_point_2)==node_2)
                     {
                         tmp_state_2=*(tmpu_stack+2*tmpu_point_2+1);
                         tmpu_point_2 +=1;
                         break;
                     }
                     if(*(tmpu_stack+2*tmpu_point_2+1)==node_2)
                     {
                         tmp_state_2=*(tmpu_stack+2*tmpu_point_2);
                         tmpu_point_2 +=1;
                         break;
                     }
                     tmpu_point_2 +=1;
                 }
                 if(tmp_state_2==-1) r_flag_2=1;;
           }
          }
          else
          {
             r_flag_2 = 1;
             tmp_state_2 = node_2;
          }
           if(tmp_state_2!= -1)
           {
               c_flag=0;
               if((tmp_state_1!=node_1 || tmp_state_2!=node_2) && (tmp_state_1!=node_2 || tmp_state_2!=node_1))
               {
                   if(indexx == 1)
                   {
                      if(merging_table[tmp_state_1][tmp_state_2] == 0) continue;
                      if(merging_table[tmp_state_1][tmp_state_2] == 1 && tmp_state_1 != tmp_state_2) return 10;
                   }
                   if(root_node[tmp_state_1].equal_set->state_number == root_node[tmp_state_2].equal_set->state_number) continue;


                 tmpu_point=0;
                 while(*(tmpu_stack+2*tmpu_point)!=-1)
                 {
                    if(*(tmpu_stack+2*tmpu_point)==tmp_state_1 && *(tmpu_stack+2*tmpu_point+1)==tmp_state_2)
                    {
                        c_flag=8;
                        break;
                    }
                    if(*(tmpu_stack+2*tmpu_point+1)==tmp_state_1 && *(tmpu_stack+2*tmpu_point)==tmp_state_2)
                    {
                        c_flag=8;
                        break;
                    }
                    tmpu_point +=1;
                 }
                 if(c_flag ==8) continue;


                 if(root_node[tmp_state_1].marked_in_plant==root_node[tmp_state_2].marked_in_plant && root_node[tmp_state_1].marked_in_controller!=root_node[tmp_state_2].marked_in_controller)
                         return 10;

                 for(k=1;k<3;k++)
                 {
                   if(k==1)
                   {
                      temp1 = root_node[tmp_state_1].forb_set;
                      temp2 = root_node[tmp_state_2].tran_set;
                   }
                   if(k==2)
                   {
                      temp1 = root_node[tmp_state_2].forb_set;
                      temp2 = root_node[tmp_state_1].tran_set;
                   }
                   temp22 = temp2;
                   while(temp1 != NULL)
                   {
                     temp2 = temp22;
                     while(temp2 != NULL)
                     {
                         if(temp1->event == temp2->event)
                              return 10;
                         temp2 = temp2->next_transition;
                     }
                     temp1 = temp1->next_event;
                   }
                 }
                 if(c_flag!=8)
                 {
                    *(tmpu_stack+2*tmpu_point)=tmp_state_1;
                    *(tmpu_stack+2*tmpu_point+1)=tmp_state_2;
                    *(tmpu_stack+2*tmpu_point+2)=-1;
                 }
               }
               if(c_flag==0)
               {
                  struct transitions *temp3, *temp4;
                  int tmp_state_3, tmp_state_4;
                  temp3 = root_node[tmp_state_1].tran_set;
                  while(temp3 != NULL)
                  {
                     temp4 = root_node[tmp_state_2].tran_set;
                     while(temp4 != NULL)
                     {
                        if(temp3->event == temp4->event)
                        {
                           flag = 0;
                           tmp_state_3 = temp3->target_state_number;
                           tmp_state_4 = temp4->target_state_number;
                           if(indexx == 1)
                           {
                              if(merging_table[tmp_state_3][tmp_state_4] == 0)
                              {
                                  temp4 = temp4->next_transition;
                                  continue;
                              }
                              if(merging_table[tmp_state_3][tmp_state_4] == 1 && tmp_state_3 != tmp_state_4) return 10;
                           }
                           if((root_node[tmp_state_3].equal_set)->state_number != (root_node[tmp_state_4].equal_set)->state_number)
                           {

			     /*****************************************************************/

                               if((root_node[tmp_state_3].equal_set)->state_number<nodel || (root_node[tmp_state_4].equal_set)->state_number<nodel) return 10;
			     /*****************************************************************/


                               tmpu_point=0;
                               while(*(tmpu_stack+2*tmpu_point)!=-1)
                               {
                                  if(*(tmpu_stack+2*tmpu_point)==tmp_state_3 && *(tmpu_stack+2*tmpu_point+1)==tmp_state_4)
                                  {
                                      flag=8;
                                      break;
                                  }
                                  if(*(tmpu_stack+2*tmpu_point+1)==tmp_state_3 && *(tmpu_stack+2*tmpu_point)==tmp_state_4)
                                  {
                                      flag=8;
                                      break;
                                  }
                                  tmpu_point +=1;
                               }
                               if(flag==8)
                               {
                                   temp4=temp4->next_transition;
                                   continue;
                               }


                               if(root_node[tmp_state_3].marked_in_plant==root_node[tmp_state_4].marked_in_plant && root_node[tmp_state_3].marked_in_controller!=root_node[tmp_state_4].marked_in_controller)
                                   return 10;

                               for(k=1;k<3;k++)
                               {
                                  if(k==1)
                                  {
                                      temp1 = root_node[tmp_state_3].forb_set;
                                      temp2 = root_node[tmp_state_4].tran_set;
                                  }
                                  if(k==2)
                                  {
                                      temp1 = root_node[tmp_state_4].forb_set;
                                      temp2 = root_node[tmp_state_3].tran_set;
                                  }
                                  temp22 = temp2;
                                  while(temp1 != NULL)
                                  {
                                      temp2 = temp22;
                                      while(temp2 != NULL)
                                      {
                                          if(temp1->event == temp2->event)
                                               return 10;
                                          temp2 = temp2->next_transition;
                                      }
                                      temp1 = temp1->next_event;
                                  }
                               }
                               if(flag==0)
                               {
                                  *(tmpu_stack+2*tmpu_point)=tmp_state_3;
                                  *(tmpu_stack+2*tmpu_point+1)=tmp_state_4;
                                  *(tmpu_stack+2*tmpu_point+2)=-1;
                                  flag=Selfloop_Node2(tmp_state_3,tmp_state_4,nodel,indexx);
                                  if(flag==10)
                                  {
                                     if(indexx == 1)
                                     {
                                       merging_table[tmp_state_3][tmp_state_4] = 1;
                                       merging_table[tmp_state_4][tmp_state_3] = 1;
                                     }
                                     return 10;
                                  }
                              }
                           }
                        }
                        temp4 = temp4->next_transition;
                     }
                     temp3 = temp3->next_transition;
                  }
               }
           }
        }
    }
  }
return 9;
}
int Selfloop_Node3(int base_state,int tmp_state,int nodel, int indexx)
{
  int node_1,node_2,c_flag, flag, r_flag_1,r_flag_2;
  int tmpu_point,tmpu_point_1,tmpu_point_2,k;
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  struct equivalent_state_set *temp6, *temp7;
  int tmp_state_1, tmp_state_2;

  node_1=base_state;
  node_2=tmp_state;

  temp6=root_node[root_node[node_1].equal_set->state_number].equal_set;
  r_flag_1=0;
  tmpu_point_1=0;

  while(r_flag_1==0)
  {
   if(indexx == 0)
   {
    if(temp6 != NULL)
    {
        tmp_state_1 = temp6->state_number;
        temp6 = temp6->next_node;
    }
    else
    {
        tmp_state_1=-1;
        while(*(tmpu_stack+2*tmpu_point_1)!=-1)
        {
            if(*(tmpu_stack+2*tmpu_point_1)==node_1)
            {
                tmp_state_1=*(tmpu_stack+2*tmpu_point_1+1);
                tmpu_point_1 +=1;
                break;
            }
            if(*(tmpu_stack+2*tmpu_point_1+1)==node_1)
            {
                tmp_state_1=*(tmpu_stack+2*tmpu_point_1);
                tmpu_point_1 +=1;
                break;
            }
            tmpu_point_1 +=1;
        }
        if(tmp_state_1==-1) r_flag_1=1;;
    }
   }
   else
   {
        r_flag_1 = 1;
        tmp_state_1 = node_1;
   }

    if(tmp_state_1!= -1)
    {
        temp7=root_node[root_node[node_2].equal_set->state_number].equal_set;
        r_flag_2=0;
        tmpu_point_2=0;
        while(r_flag_2==0)
        {
          if(indexx == 0)
          {
           if(temp7 != NULL)
           {
                 tmp_state_2 = temp7->state_number;
                 temp7 = temp7->next_node;
           }
           else
           {
                 tmp_state_2=-1;
                 while(*(tmpu_stack+2*tmpu_point_2)!=-1)
                 {
                     if(*(tmpu_stack+2*tmpu_point_2)==node_2)
                     {
                         tmp_state_2=*(tmpu_stack+2*tmpu_point_2+1);
                         tmpu_point_2 +=1;
                         break;
                     }
                     if(*(tmpu_stack+2*tmpu_point_2+1)==node_2)
                     {
                         tmp_state_2=*(tmpu_stack+2*tmpu_point_2);
                         tmpu_point_2 +=1;
                         break;
                     }
                     tmpu_point_2 +=1;
                 }
                 if(tmp_state_2==-1) r_flag_2=1;;
           }
          }
          else
          {
             r_flag_2 = 1;
             tmp_state_2 = node_2;
          }
           if(tmp_state_2!= -1)
           {
               c_flag=0;
               if((tmp_state_1!=node_1 || tmp_state_2!=node_2) && (tmp_state_1!=node_2 || tmp_state_2!=node_1))
               {
                   if(indexx == 1)
                   {
                      if(merging_table[tmp_state_1][tmp_state_2] == 0) continue;
                      if(merging_table[tmp_state_1][tmp_state_2] == 1 && tmp_state_1 != tmp_state_2) return 10;
                   }
                   if(root_node[tmp_state_1].equal_set->state_number == root_node[tmp_state_2].equal_set->state_number) continue;


                 tmpu_point=0;
                 while(*(tmpu_stack+2*tmpu_point)!=-1)
                 {
                    if(*(tmpu_stack+2*tmpu_point)==tmp_state_1 && *(tmpu_stack+2*tmpu_point+1)==tmp_state_2)
                    {
                        c_flag=8;
                        break;
                    }
                    if(*(tmpu_stack+2*tmpu_point+1)==tmp_state_1 && *(tmpu_stack+2*tmpu_point)==tmp_state_2)
                    {
                        c_flag=8;
                        break;
                    }
                    tmpu_point +=1;
                 }
                 if(c_flag ==8) continue;


                 //if(root_node[tmp_state_1].marked_in_plant==root_node[tmp_state_2].marked_in_plant && root_node[tmp_state_1].marked_in_controller!=root_node[tmp_state_2].marked_in_controller)
                  //       return 10;

                 for(k=1;k<3;k++)
                 {
                   if(k==1)
                   {
                      temp1 = root_node[tmp_state_1].forb_set;
                      temp2 = root_node[tmp_state_2].tran_set;
                   }
                   if(k==2)
                   {
                      temp1 = root_node[tmp_state_2].forb_set;
                      temp2 = root_node[tmp_state_1].tran_set;
                   }
                   temp22 = temp2;
                   while(temp1 != NULL)
                   {
                     temp2 = temp22;
                     while(temp2 != NULL)
                     {
                         if(temp1->event == temp2->event)
                              return 10;
                         temp2 = temp2->next_transition;
                     }
                     temp1 = temp1->next_event;
                   }
                 }
                 if(c_flag!=8)
                 {
                    *(tmpu_stack+2*tmpu_point)=tmp_state_1;
                    *(tmpu_stack+2*tmpu_point+1)=tmp_state_2;
                    *(tmpu_stack+2*tmpu_point+2)=-1;
                 }
               }
               if(c_flag==0)
               {
                  struct transitions *temp3, *temp4;
                  int tmp_state_3, tmp_state_4;
                  temp3 = root_node[tmp_state_1].tran_set;
                  while(temp3 != NULL)
                  {
                     temp4 = root_node[tmp_state_2].tran_set;
                     while(temp4 != NULL)
                     {
                        if(temp3->event == temp4->event)
                        {
                           flag = 0;
                           tmp_state_3 = temp3->target_state_number;
                           tmp_state_4 = temp4->target_state_number;
                           if(indexx == 1)
                           {
                              if(merging_table[tmp_state_3][tmp_state_4] == 0)
                              {
                                  temp4 = temp4->next_transition;
                                  continue;
                              }
                              if(merging_table[tmp_state_3][tmp_state_4] == 1 && tmp_state_3 != tmp_state_4) return 10;
                           }
                           if((root_node[tmp_state_3].equal_set)->state_number != (root_node[tmp_state_4].equal_set)->state_number)
                           {

			     /*****************************************************************/

                               if((root_node[tmp_state_3].equal_set)->state_number<nodel || (root_node[tmp_state_4].equal_set)->state_number<nodel) return 10;
			     /*****************************************************************/


                               tmpu_point=0;
                               while(*(tmpu_stack+2*tmpu_point)!=-1)
                               {
                                  if(*(tmpu_stack+2*tmpu_point)==tmp_state_3 && *(tmpu_stack+2*tmpu_point+1)==tmp_state_4)
                                  {
                                      flag=8;
                                      break;
                                  }
                                  if(*(tmpu_stack+2*tmpu_point+1)==tmp_state_3 && *(tmpu_stack+2*tmpu_point)==tmp_state_4)
                                  {
                                      flag=8;
                                      break;
                                  }
                                  tmpu_point +=1;
                               }
                               if(flag==8)
                               {
                                   temp4=temp4->next_transition;
                                   continue;
                               }


                             //  if(root_node[tmp_state_3].marked_in_plant==root_node[tmp_state_4].marked_in_plant && root_node[tmp_state_3].marked_in_controller!=root_node[tmp_state_4].marked_in_controller)
                             //      return 10;

                               for(k=1;k<3;k++)
                               {
                                  if(k==1)
                                  {
                                      temp1 = root_node[tmp_state_3].forb_set;
                                      temp2 = root_node[tmp_state_4].tran_set;
                                  }
                                  if(k==2)
                                  {
                                      temp1 = root_node[tmp_state_4].forb_set;
                                      temp2 = root_node[tmp_state_3].tran_set;
                                  }
                                  temp22 = temp2;
                                  while(temp1 != NULL)
                                  {
                                      temp2 = temp22;
                                      while(temp2 != NULL)
                                      {
                                          if(temp1->event == temp2->event)
                                               return 10;
                                          temp2 = temp2->next_transition;
                                      }
                                      temp1 = temp1->next_event;
                                  }
                               }
                               if(flag==0)
                               {
                                  *(tmpu_stack+2*tmpu_point)=tmp_state_3;
                                  *(tmpu_stack+2*tmpu_point+1)=tmp_state_4;
                                  *(tmpu_stack+2*tmpu_point+2)=-1;
                                  flag=Selfloop_Node3(tmp_state_3,tmp_state_4,nodel,indexx);
                                  if(flag==10)
                                  {
                                     if(indexx == 1)
                                     {
                                       merging_table[tmp_state_3][tmp_state_4] = 1;
                                       merging_table[tmp_state_4][tmp_state_3] = 1;
                                     }
                                     return 10;
                                  }
                              }
                           }
                        }
                        temp4 = temp4->next_transition;
                     }
                     temp3 = temp3->next_transition;
                  }
               }
           }
        }
    }
  }
return 9;
}


/*This module is used to change data from tree form into transition table list.*/
void Final_Result()
{
  int s_base_point=0;
  int exit_node,transition,target_node,trace_node,tmp_node,tmp_value;
  int i;
  for(i=0;i<num_states;i++)
  {
    struct transitions *temp1;
    temp1 = root_node[i].tran_set;
    while(temp1 != NULL)
    {
       exit_node=(root_node[i].equal_set)->state_number;
       transition=temp1->event;
       target_node=(root_node[temp1->target_state_number].equal_set)->state_number;
       *(simpler_controller+3*s_base_point)=exit_node;
       *(simpler_controller+3*s_base_point+1)=transition;
       *(simpler_controller+3*s_base_point+2)=target_node;
       s_base_point +=1;
       temp1 = temp1->next_transition;

    }
  }
  *(simpler_controller+3*s_base_point)=-1;
  *c_marked_states = -1;
  for(i=0;i<num_states;i++)
  {
    if(root_node[i].marked_in_controller==true)
    {
       trace_node=0;
       while(*(c_marked_states+trace_node)!=-1)
       {
          if(*(c_marked_states+trace_node)==(root_node[i].equal_set)->state_number)
             break;
          trace_node += 1;
       }
       if(*(c_marked_states+trace_node)==-1)
       {
           *(c_marked_states+trace_node)=(root_node[i].equal_set)->state_number;
           *(c_marked_states+trace_node+1)=-1;
       }
    }
  }
  trace_node=0;
  while(*(c_marked_states+trace_node)!=-1)
  {
    tmp_node=trace_node+1;
    tmp_value=trace_node;
    while(*(c_marked_states+tmp_node)!=-1)
    {
       if(*(c_marked_states+tmp_node)<*(c_marked_states+tmp_value))
            tmp_value=tmp_node;
       tmp_node +=1;
    }
    tmp_node=*(c_marked_states+trace_node);
    *(c_marked_states+trace_node)=*(c_marked_states+tmp_value);
    *(c_marked_states+tmp_value)=tmp_node;
    trace_node +=1;
  }
}


/*This module is used to reduce the transition structure of optimal controller.*/
void Reduction()
{
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  int temp3, temp4, temp_state;
  struct equivalent_state_set **temp5, *temp6;
  int tmpu_point;
  int flag;
  int i,j;
  int state_1, state_2;
  *tmpu_stack=-1;


  for(i=0;i<num_states;i++)
  {
    if((root_node[i].equal_set)->state_number == i)
    {
      for(j=i+1;j<num_states;j++)
      {
        if((root_node[j].equal_set)->state_number==j)
        {
           flag=0;
           if(flag!=10)
           {
              if(root_node[i].marked_in_plant==root_node[j].marked_in_plant && root_node[i].marked_in_controller!=root_node[j].marked_in_controller)
                  flag = 10;
           }
           temp1 = root_node[i].forb_set;
           temp2 = root_node[j].tran_set;
           if(flag != 10)
           {
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
             temp1 = root_node[j].forb_set;
             temp2 = root_node[i].tran_set;
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
           }
           if(flag != 10)
           {
             *tmpu_stack=i;
             *(tmpu_stack+1)=j;
             *(tmpu_stack+2)=-1;
             flag=Selfloop_Node(i,j,i,0);
           }
           if(flag == 10)
           {
             *tmpu_stack = -1;
           }
           if(flag != 10)
           {
             tmpu_point=0;
             while(*(tmpu_stack+2*tmpu_point)!=-1)
             {
               state_1 = *(tmpu_stack+2*tmpu_point);
               state_2 = *(tmpu_stack+2*tmpu_point+1);
               temp3 = root_node[state_1].equal_set->state_number;
               temp4 = root_node[state_2].equal_set->state_number;
               if(temp3 < temp4)
               {
                  temp5=&(root_node[temp3].equal_set); /*acceptor*/
                  temp6=root_node[temp4].equal_set; /*merger*/
               }
               else if(temp3 > temp4)
               {
                  temp5=&(root_node[temp4].equal_set); /*acceptor*/
                  temp6=root_node[temp3].equal_set; /*merger*/
               }
               temp_state = (*temp5)->state_number;
               if(temp3==temp4)
               {
                  tmpu_point +=1;
                  continue;
               }
               while(*temp5!=NULL)
                  temp5 = &((*temp5)->next_node);
               while(temp6!=NULL)
               {
                  *temp5 = (struct equivalent_state_set *) malloc(sizeof(struct equivalent_state_set));
                  (*temp5)->state_number = temp6->state_number;
                  root_node[temp6->state_number].equal_set->state_number=temp_state;
                  temp6=temp6->next_node;
                  if(temp6!=NULL)
                     temp5 = &((*temp5)->next_node);
                  else
                     (*temp5)->next_node=NULL;
               }
               tmpu_point += 1;
             }
             *tmpu_stack=-1;
           }
        }
      }
    }
  }
  simpler_controller=(int *) malloc((3*tran_number+1)*sizeof(int));
  Final_Result();
}
void Reduction1()
{
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  int temp3, temp4, temp_state;
  struct equivalent_state_set **temp5, *temp6;
  int tmpu_point;
  int flag;
  int i,j;
  int state_1, state_2;
  *tmpu_stack=-1;


  for(i=0;i<num_states;i++)
  {
    if((root_node[i].equal_set)->state_number == i)
    {
      for(j=i+1;j<num_states;j++)
      {
        if((root_node[j].equal_set)->state_number==j)
        {
           flag=0;
          // if(flag!=10)
          // {
          //    if(root_node[i].marked_in_plant==root_node[j].marked_in_plant && root_node[i].marked_in_controller!=root_node[j].marked_in_controller)
           //       flag = 10;
           //}
           temp1 = root_node[i].forb_set;
           temp2 = root_node[j].tran_set;
           if(flag != 10)
           {
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
             temp1 = root_node[j].forb_set;
             temp2 = root_node[i].tran_set;
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
           }
           if(flag != 10)
           {
             *tmpu_stack=i;
             *(tmpu_stack+1)=j;
             *(tmpu_stack+2)=-1;
             flag=Selfloop_Node2(i,j,i,0);
           }
           if(flag == 10)
           {
             *tmpu_stack = -1;
           }
           if(flag != 10)
           {
             tmpu_point=0;
             while(*(tmpu_stack+2*tmpu_point)!=-1)
             {
               state_1 = *(tmpu_stack+2*tmpu_point);
               state_2 = *(tmpu_stack+2*tmpu_point+1);
               temp3 = root_node[state_1].equal_set->state_number;
               temp4 = root_node[state_2].equal_set->state_number;
               if(temp3 < temp4)
               {
                  temp5=&(root_node[temp3].equal_set); /*acceptor*/
                  temp6=root_node[temp4].equal_set; /*merger*/
               }
               else if(temp3 > temp4)
               {
                  temp5=&(root_node[temp4].equal_set); /*acceptor*/
                  temp6=root_node[temp3].equal_set; /*merger*/
               }
               temp_state = (*temp5)->state_number;
               if(temp3==temp4)
               {
                  tmpu_point +=1;
                  continue;
               }
               while(*temp5!=NULL)
                  temp5 = &((*temp5)->next_node);
               while(temp6!=NULL)
               {
                  *temp5 = (struct equivalent_state_set *) malloc(sizeof(struct equivalent_state_set));
                  (*temp5)->state_number = temp6->state_number;
                  root_node[temp6->state_number].equal_set->state_number=temp_state;
                  temp6=temp6->next_node;
                  if(temp6!=NULL)
                     temp5 = &((*temp5)->next_node);
                  else
                     (*temp5)->next_node=NULL;
               }
               tmpu_point += 1;
             }
             *tmpu_stack=-1;
           }
        }
      }
    }
  }
  simpler_controller=(int *) malloc((3*tran_number+1)*sizeof(int));
  Final_Result();
}

void Reduction2()
{
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  int temp3, temp4, temp_state;
  struct equivalent_state_set **temp5, *temp6;
  int tmpu_point;
  int flag;
  int i,j;
  int state_1, state_2;
  *tmpu_stack=-1;


  for(i=0;i<num_states;i++)
  {
    if((root_node[i].equal_set)->state_number == i)
    {
      for(j=i+1;j<num_states;j++)
      {
        if((root_node[j].equal_set)->state_number==j)
        {
           flag=0;
           if(flag!=10)
           {
              if(root_node[i].marked_in_plant==root_node[j].marked_in_plant && root_node[i].marked_in_controller!=root_node[j].marked_in_controller)
                  flag = 10;
           }
           temp1 = root_node[i].forb_set;
           temp2 = root_node[j].tran_set;
           if(flag != 10)
           {
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
             temp1 = root_node[j].forb_set;
             temp2 = root_node[i].tran_set;
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
           }
           if(flag != 10)
           {
             *tmpu_stack=i;
             *(tmpu_stack+1)=j;
             *(tmpu_stack+2)=-1;
             flag=Selfloop_Node2(i,j,i,0);
           }
           if(flag == 10)
           {
             *tmpu_stack = -1;
           }
           if(flag != 10)
           {
             tmpu_point=0;
             while(*(tmpu_stack+2*tmpu_point)!=-1)
             {
               state_1 = *(tmpu_stack+2*tmpu_point);
               state_2 = *(tmpu_stack+2*tmpu_point+1);
               temp3 = root_node[state_1].equal_set->state_number;
               temp4 = root_node[state_2].equal_set->state_number;
               if(temp3 < temp4)
               {
                  temp5=&(root_node[temp3].equal_set); /*acceptor*/
                  temp6=root_node[temp4].equal_set; /*merger*/
               }
               else if(temp3 > temp4)
               {
                  temp5=&(root_node[temp4].equal_set); /*acceptor*/
                  temp6=root_node[temp3].equal_set; /*merger*/
               }
               temp_state = (*temp5)->state_number;
               if(temp3==temp4)
               {
                  tmpu_point +=1;
                  continue;
               }
               while(*temp5!=NULL)
                  temp5 = &((*temp5)->next_node);
               while(temp6!=NULL)
               {
                  *temp5 = (struct equivalent_state_set *) malloc(sizeof(struct equivalent_state_set));
                  (*temp5)->state_number = temp6->state_number;
                  root_node[temp6->state_number].equal_set->state_number=temp_state;
                  temp6=temp6->next_node;
                  if(temp6!=NULL)
                     temp5 = &((*temp5)->next_node);
                  else
                     (*temp5)->next_node=NULL;
               }
               tmpu_point += 1;
             }
             *tmpu_stack=-1;
           }
        }
      }
    }
  }
  simpler_controller=(int *) malloc((3*tran_number+1)*sizeof(int));
  Final_Result();
}

void Reduction3()
{
  struct forbidden_event_set *temp1;
  struct transitions *temp2, *temp22;
  int temp3, temp4, temp_state;
  struct equivalent_state_set **temp5, *temp6;
  int tmpu_point;
  int flag;
  int i,j;
  int state_1, state_2;
  *tmpu_stack=-1;


  for(i=0;i<num_states;i++)
  {
    if((root_node[i].equal_set)->state_number == i)
    {
      for(j=i+1;j<num_states;j++)
      {
        if((root_node[j].equal_set)->state_number==j)
        {
           flag=0;
          // if(flag!=10)
          // {
          //    if(root_node[i].marked_in_plant==root_node[j].marked_in_plant && root_node[i].marked_in_controller!=root_node[j].marked_in_controller)
           //       flag = 10;
           //}
           temp1 = root_node[i].forb_set;
           temp2 = root_node[j].tran_set;
           if(flag != 10)
           {
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
             temp1 = root_node[j].forb_set;
             temp2 = root_node[i].tran_set;
             temp22 = temp2;
             while(temp1 != NULL)
             {
               temp2 = temp22;
               while(temp2 != NULL)
               {
                 if(temp1->event == temp2->event)
                 {
                    flag = 10;
                    break;
                 }
                 temp2 = temp2->next_transition;
               }
               if(flag == 10) break;
               temp1 = temp1->next_event;
             }
           }
           if(flag != 10)
           {
             *tmpu_stack=i;
             *(tmpu_stack+1)=j;
             *(tmpu_stack+2)=-1;
             flag=Selfloop_Node3(i,j,i,0);
           }
           if(flag == 10)
           {
             *tmpu_stack = -1;
           }
           if(flag != 10)
           {
             tmpu_point=0;
             while(*(tmpu_stack+2*tmpu_point)!=-1)
             {
               state_1 = *(tmpu_stack+2*tmpu_point);
               state_2 = *(tmpu_stack+2*tmpu_point+1);
               temp3 = root_node[state_1].equal_set->state_number;
               temp4 = root_node[state_2].equal_set->state_number;
               if(temp3 < temp4)
               {
                  temp5=&(root_node[temp3].equal_set); /*acceptor*/
                  temp6=root_node[temp4].equal_set; /*merger*/
               }
               else if(temp3 > temp4)
               {
                  temp5=&(root_node[temp4].equal_set); /*acceptor*/
                  temp6=root_node[temp3].equal_set; /*merger*/
               }
               temp_state = (*temp5)->state_number;
               if(temp3==temp4)
               {
                  tmpu_point +=1;
                  continue;
               }
               while(*temp5!=NULL)
                  temp5 = &((*temp5)->next_node);
               while(temp6!=NULL)
               {
                  *temp5 = (struct equivalent_state_set *) malloc(sizeof(struct equivalent_state_set));
                  (*temp5)->state_number = temp6->state_number;
                  root_node[temp6->state_number].equal_set->state_number=temp_state;
                  temp6=temp6->next_node;
                  if(temp6!=NULL)
                     temp5 = &((*temp5)->next_node);
                  else
                     (*temp5)->next_node=NULL;
               }
               tmpu_point += 1;
             }
             *tmpu_stack=-1;
           }
        }
      }
    }
  }
  simpler_controller=(int *) malloc((3*tran_number+1)*sizeof(int));
  Final_Result();
}

/*This module is used to add any possible forbidden event at each node of controller_tree.*/
int Forbidden_Event(char *name)
{
   FILE *in;
   long mark, s, z, yy,init;
   short num;
   char ch;
   char header[8];
   long read_endian;
   long block_type, block_size;
   long address;
   int exit_state;

   in = NULL;
   while(in == NULL)
   {
      /* Input .dat data file of supervisor: */
      in = fopen(name, "rb");
      if(in == NULL)
      {
         return 1;
      }
   }

   /* Setup a buffer for faster IO */
   setvbuf(in, NULL, _IOFBF, 32000);

   /* Read the ASCII header and junk */
   ch = 0;
   while ((ch != 26) && !feof(in)) {
      fread(&ch, sizeof(char), 1, in);
   }

   memset(header, 0, 8); /* Zero out the string */
   /* Read the unique string to authenic CTCT DES file */
   fread(header, sizeof(char), 7, in);
   if (strcmp(header, signature) != 0) {
      fclose(in);
      return 1;
   }

   /* Big-endian and Little-endian information */
   fread(&read_endian, sizeof(long), 1, in);
   if (read_endian != endian) {
      fclose(in);
      return 1;
   }

   /* Block type */
   fread(&block_type, sizeof(long), 1, in);
   if (block_type != 0) {
      fclose(in);
      return 1;
   }

   /* Read the number of bytes of this block type */
   fread(&block_size, sizeof(long), 1, in);

   fread(&num_states, sizeof(long), 1, in);
   fread(&init, sizeof(long), 1, in);

   if (ferror(in)) {
      fclose(in);
      return 1;
   }

   /* Read the marked states */
   address=ftell(in);
   mark = 0L;
   while (mark != -1L) {
      fread(&mark, sizeof(long), 1, in);
   }
   fseek(in,address,SEEK_SET);
   mark=0L;
   while(mark!=-1L)
   {
      fread(&mark,sizeof(long),1,in);
   }

   /* Read the transitions */
   s=0L;
   {
   struct forbidden_event_set **temp1;
   while(s!=-1L)
   {
     fread(&s,sizeof(long),1,in);
     if(s==-1L) break;
     exit_state = (int) s;
     fread(&num,sizeof(short),1,in);
     temp1=&(root_node[exit_state].forb_set);
     for(z=0;z<num;z++)
     {
        fread(&yy,sizeof(long),1,in);
        *temp1=(struct forbidden_event_set *) malloc(sizeof(struct forbidden_event_set));
        if (*temp1 == NULL)
        {
           mem_result = 1;
        }
        (*temp1)->event=((unsigned long) yy>>22);
        if(z<num-1)
           temp1=&((*temp1)->next_event);     
        else
           (*temp1)->next_event=NULL;
     }
   }
   }
   fclose(in);
   return 0;
}

/*I use this module to reindex the controller_tree by the index set of plant.*/
/*So that each node of the controller_tree will have two index, one from the */
/*index set of optimal controller, and the other from the index set of plant.*/
int Set_State_No_of_Plant(int c_st_no_of_con)
{
  int base_point=0,father_base_point=0,father_relative_point=0,trace_in_plant=0;
  while(*(controller_tree+base_point)!=c_st_no_of_con)
  {
    base_point +=15+2*(*(controller_tree+base_point+14));
    if(*(controller_tree+base_point)==-1)
    {
      return 1;
    }
  }
  while(*(controller_tree+father_base_point)!=*(controller_tree+base_point+13))
  {
    father_base_point +=15+2*(*(controller_tree+father_base_point+14));
    if(*(controller_tree+father_base_point)==-1)
    {
      return 1;
    }
  }
  if(*(controller_tree+father_base_point+2)==-1)
    Set_State_No_of_Plant(*(controller_tree+father_base_point));
  while(*(controller_tree+father_base_point+16+2*father_relative_point)!=*(controller_tree+base_point))
  {
    father_relative_point +=1;
    if(father_relative_point > *(controller_tree+father_base_point+14))
    {
      return 1;
    }
  }
  while((*(plant+3*trace_in_plant)!=*(controller_tree+father_base_point+2))||(*(plant+3*trace_in_plant+1)!=*(controller_tree+father_base_point+15+2*father_relative_point)))
  {
    trace_in_plant +=1;
    if(*(plant+3*trace_in_plant)==-1)
    {
      return 1;
    }
  }
  *(controller_tree+base_point+2)=*(plant+3*trace_in_plant+2);
  return 0;
}


/*I use this module to add any possible forbidden event at each node of controller_tree.*/
/*This kind of information is very important.*/
int Combined_Tree()
{
  int flag,c_st_no_of_con,base_point=0;
  *(controller_tree+2)=0;
  while(*(controller_tree+base_point)!=-1)
  {
    c_st_no_of_con=*(controller_tree+base_point);
    if(c_st_no_of_con!=0)
    {
       flag=Set_State_No_of_Plant(c_st_no_of_con);
       if(flag==1) return 1;
    }
    base_point +=15+2*(*(controller_tree+base_point+14));
  }
  return 0;
}


/*I use this module to create a controller_tree just using the transition table*/
/*obtained by CTCT software. In this tree, each branch has a father node, a son */
/*node and a transition index corresponding to the source state, transition and*/
/*the target state in the transition tables.*/
void Controller_Tree()
{
 int index,tran_number=0,trace_father_node=0,base_point=0,relative_point=0;
 int stno_in_controller,stno_in_plant=-1,forbidden_event=-1;
 int father_node=-1,no_of_son_nodes=0,forbidden_index;
 index=*controller;
 while(index!=-1)
 {
   stno_in_controller=*(controller+3*tran_number);
   /*the following is to find the father_node.*/
   if(stno_in_controller!=0)
   {
     while(*(controller+3*trace_father_node+2)!=stno_in_controller)
     {
       trace_father_node +=1;
     }
     trace_father_node=0;
   }
 /*the following is to find the number of the son_nodes and the corresponding*/
 /*branches which are connected between the current node and its son_nodes.*/
   while(*(controller+3*tran_number)==stno_in_controller)
   {
     *(controller_tree+base_point+relative_point+15)=*(controller+3*tran_number+1);
     *(controller_tree+base_point+relative_point+16)=*(controller+3*tran_number+2);
     relative_point +=2;
     no_of_son_nodes +=1;
     tran_number +=1;
   }
   *(controller_tree+base_point)=stno_in_controller;
   *(controller_tree+base_point+2)=stno_in_plant;
   for(forbidden_index=0;forbidden_index<10;forbidden_index++) *(controller_tree+base_point+3+forbidden_index)=forbidden_event;
   *(controller_tree+base_point+13)=father_node;
   *(controller_tree+base_point+14)=no_of_son_nodes;
   base_point +=15+2*no_of_son_nodes;
   relative_point=0;
   no_of_son_nodes=0;
   index=*(controller+3*tran_number);
 }
 *(controller_tree+base_point)=-1;
 father_node_in_controller_tree(0);
}

void father_node_in_controller_tree(int base_point)
{
 int relative_point,son_base_point,son_node,no_of_son_nodes;
/* modification starts here */
/* assign father-node-number to each node in controller_tree */
	 relative_point = 0;
	 for(relative_point=0;relative_point<*(controller_tree+base_point+14);relative_point++)
	 {
		 son_node = *(controller_tree+base_point+2*relative_point+16);
                 son_base_point = 0;
		 while(*(controller_tree+son_base_point)!=son_node && *(controller_tree+son_base_point)!=-1)
		 {
			 no_of_son_nodes = *(controller_tree+son_base_point+14);
			 son_base_point +=15+2*no_of_son_nodes;
		 }
		 if(*(controller_tree+son_base_point)==-1)
                 {
		   /*cout << "something wrong 20, program halt"; */
                   /*return 1; */
		 }
		 if(*(controller_tree+son_base_point+13)==-1 && *(controller_tree+son_base_point)!=0)
		 {
			 *(controller_tree+son_base_point+13) = *(controller_tree+base_point);
			 father_node_in_controller_tree(son_base_point);
		 }
	 }
/* end of modification */
}

void Tree_Structure_Conversion(char *name)
{
   int base_point=0;
   int p_mark, c_mark;
   int plant_number;
   int i;
   int relative_point;
   struct transitions **temp_1;
   for(i=0;i<num_states;i++)
   {
       p_mark=0;
       c_mark=0;
       root_node[i].equal_set = (struct equivalent_state_set *) malloc(sizeof(struct equivalent_state_set));
       if (root_node[i].equal_set == NULL)
       {
          mem_result = 1;
       }
       (root_node[i].equal_set)->state_number = *(controller_tree+base_point);
       (root_node[i].equal_set)->next_node = NULL;
       plant_number = *(controller_tree+base_point+2);
       root_node[i].marked_in_plant = false;
       root_node[i].marked_in_controller = false;
       while(*(p_marked_states+p_mark)!=-1)
       {
         if(*(p_marked_states+p_mark)==plant_number)
         {
            root_node[i].marked_in_plant = true;
            break;
         }
         p_mark += 1;
       }
       while(*(c_marked_states+c_mark)!=-1)
       {
         if(*(c_marked_states+c_mark)==*(controller_tree+base_point))
         {
            root_node[i].marked_in_controller = true;
            break;
         }
         c_mark += 1;
       }
       root_node[i].forb_set = NULL;
       root_node[i].tran_set = NULL;
       temp_1 = &(root_node[i].tran_set);
       for(relative_point=0;relative_point<*(controller_tree+base_point+14);relative_point++)
       {
         *temp_1 = (struct transitions *) malloc(sizeof(struct transitions));
         if (*temp_1 == NULL)
         {
            mem_result = 1;
         }
         (**temp_1).event = *(controller_tree+base_point+15+2*relative_point);
         (**temp_1).target_state_number = *(controller_tree+base_point+15+2*relative_point+1);
         if(relative_point<*(controller_tree+base_point+14)-1)
             temp_1 = &((**temp_1).next_transition);
         else
             (**temp_1).next_transition = NULL;
       }
       base_point += 15+2*(*(controller_tree+base_point+14));
   }
   Forbidden_Event(name);
}


/*I use this module to convert the .txt file into .des file so that CTCT software*/
/*can use this simplified controller directly.*/
int Txt_DES(int number_of_states)
{
    long i,yy,header_len,block_type,block_size,cur_pos,temp,init=0;
    char header[100];
    int tran_number,base_point,trace_point,j,k,mark_state,counter;
    typedef struct tran_node {
         long data2;        /*target state*/
         unsigned short data1; /*transition*/
         unsigned short data3; /*no meaning*/
    } tran_node;
    sprintf(header,"CTCT DES file. Version 1.0");
    header_len=(long)strlen(header);
    header[header_len]=26;
    fwrite(header,sizeof(char),header_len+1,out);
    fwrite(&signature,sizeof(char),signature_length,out);
    fwrite(&endian,sizeof(long),1,out);
    block_type=0;
    fwrite(&block_type,sizeof(long),1,out);
    fwrite(&block_size,sizeof(long),1,out);
    block_size=ftell(out);
    fwrite(&number_of_states,sizeof(long),1,out);
    fwrite(&init,sizeof(long),1,out);
    mark_state=0;
    while(*(c_marked_states+mark_state)!=-1)
    {
      i=(long) *(c_marked_states+mark_state);
      fwrite(&i,sizeof(long),1,out);
      mark_state +=1;
    }
    i=-1L;
    fwrite(&i,sizeof(long),1,out);
    base_point=0;
    i=0L;
    for(k=0;k<number_of_states;k++)
    {
      trace_point=base_point;
      counter=0;
      while(*(simpler_controller+3*base_point)==k)
      {
         if(*(simpler_controller+3*base_point+1)>=1000) counter +=1;
         base_point +=1;
      }
      tran_number=base_point-trace_point-counter;
      fwrite(&i,sizeof(long),1,out);
      fwrite(&tran_number,sizeof(unsigned short),1,out);
      for(j=0;j<tran_number;j++)
      {
         if(simpler_controller[3*trace_point+1]<1000)
         {
           yy=(unsigned long)simpler_controller[3*trace_point+1];
           yy=yy << 22;
           yy=yy | (unsigned long)simpler_controller[3*trace_point+2];
           fwrite(&yy,sizeof(long),1,out);
         }
         trace_point +=1;
      }
      i +=1L;
    }
    i=-1L;
    fwrite(&i,sizeof(long),1,out);
    fwrite(&i,sizeof(long),1,out);
    cur_pos=ftell(out);
    fseek(out,block_size,SEEK_CUR);
    block_size=cur_pos-block_size;
    fwrite(&block_size,sizeof(long),1,out);
    fseek(out,0,SEEK_END);
    block_type=-1;
    fwrite(&block_type,sizeof(long),1,out);
    block_size=8;
    fwrite(&block_size,sizeof(long),1,out);
    temp=0;
    fwrite(&temp,sizeof(long),1,out);
    fwrite(&temp,sizeof(long),1,out);
    return 1;
}



int Refinement()
{
   int i,j,k,flag, flag_1, ref_char_control_pattern;
   int l;
   int **filtering, counter, max_num, max_state;
   struct forbidden_event_set *temp1;
   struct transitions *temp2, *temp22;
   struct virtual_stack *current_stack, *next_stack;

   stack = NULL;
   *tmpu_stack = -1;
   ref_char_control_pattern = 0;
   for(i=0;i<num_states;i++)
   {
      root_node[i].equal_set->state_number = i;
      root_node[i].equal_set->next_node = NULL;
   }
   merging_table = (int **) malloc(num_states*sizeof(int *));
   if (merging_table == NULL)
   {
      mem_result = 1;
   }
      
   for(j=0;j<num_states;j++)
   {
      merging_table[j] = (int *) malloc(num_states*sizeof(int));
      if (merging_table[j] == NULL)
      {
         mem_result = 1;
      }
      for(k=0;k<num_states;k++)
         merging_table[j][k] = -1; /*initialize merging_table*/
   }
   
      for(j=0;j<num_states-1;j++)
      {
         for(k=j+1;k<num_states;k++)
         {
            flag = 0;
            if(merging_table[j][k] != -1) continue;
            if((root_node[j].marked_in_plant==root_node[k].marked_in_plant) && (root_node[j].marked_in_controller!=root_node[k].marked_in_controller))
               flag = 10;

            for(l=1;l<3;l++)
            {
              if(l==1)
              {
                 temp1 = root_node[j].forb_set;
                 temp2 = root_node[k].tran_set;
              }
              if(l==2)
              {
                 temp1 = root_node[k].forb_set;
                 temp2 = root_node[j].tran_set;
              }
              temp22 = temp2;
              while(temp1 != NULL)
              {
                 temp2 = temp22;
                 while(temp2 != NULL)
                 {
                     if(temp1->event == temp2->event)
                     {
                          flag = 10;
                          break;
                     }
                     temp2 = temp2->next_transition;
                 }
                 if(flag == 10) break;
                 temp1 = temp1->next_event;
              }
            }


            if(flag == 0)
            {
               tmpu_stack[0] = j;
               tmpu_stack[1] = k;
               tmpu_stack[2] = -1;

               /* modification is here ........*/ 
               stack = (struct virtual_stack *) malloc(sizeof(struct virtual_stack));
               stack->state_1 = j;
	   		   stack->state_2 = k;
               stack->last_state_pair = NULL; 
               stack->next_state_pair = NULL;
               /* end of modification .........*/
               
			   
 	       flag=Selfloop_Node(j,k,-1,1);
               if(flag != 10)
               {
                  l = 0;
                  while(tmpu_stack[2*l] != -1)
                  {
                     merging_table[tmpu_stack[2*l]][tmpu_stack[2*l+1]] = 0;
                     merging_table[tmpu_stack[2*l+1]][tmpu_stack[2*l]] = 0;
                     l += 1;
                  }
                  tmpu_stack[0] = -1;

				  /*clear memory */
       			 current_stack = stack;
	    		 while(current_stack != NULL)
				 {
     			    next_stack = current_stack->next_state_pair;
                    free(current_stack);
	    			current_stack = next_stack;
				 }

			     stack = NULL;
                 /*end of clearing memory */

               }
               else
               {
				  /*clear memory */
       			 current_stack = stack;
	    		 while(current_stack != NULL)
				 {
     			    next_stack = current_stack->next_state_pair;
					merging_table[current_stack->state_1][current_stack->state_2] = 1;
					merging_table[current_stack->state_2][current_stack->state_1] = 1;
                    free(current_stack);
	    			current_stack = next_stack;
				 }

			     stack = NULL;
                 /*end of clearing memory */
	   
               }
            }
         }
      }
      /*Begin the refinement........................................................*/
      filtering = (int **) malloc(num_states*sizeof(int *));
      for(j=0;j<num_states;j++)
         filtering[j] = (int *) malloc(2*sizeof(int));
      for(j=0;j<num_states;j++)
      {
         counter = 0;
         for(k=0;k<num_states;k++)
            if(merging_table[j][k] == 0) counter += 1;
         filtering[j][0] = j;
         filtering[j][1] = counter;
      }
      flag_1 = 0;
      while(flag_1 == 0)
      {
         for(j=0;j<num_states;j++)
         {
            if(filtering[j][0] != -1) break;
         }
         max_num = filtering[j][1];
         max_state = j;
         for(k=j+1;k<num_states;k++)
         {
            if(filtering[k][0] != -1 && filtering[k][1] > max_num)
            {
               max_num = filtering[k][1];
               max_state = k;
            }
         }
         if(max_num == 0) break;
         for(k=0;k<num_states;k++)
         {
            if(merging_table[max_state][k] == 0)
            {
               if(filtering[k][0] != -1)
                  filtering[k][1] -= 1;
            }
         }
         filtering[max_state][0] = -1;
      }

      counter = 0;
      for(k=0;k<num_states;k++)
         if(filtering[k][0] != -1) counter += 1;
      ref_char_control_pattern += counter;

/*      for(j=0;j<num_states;j++)
         free(filtering[j]); */
      free(filtering); filtering = NULL;
      free(tmpu_stack); tmpu_stack = NULL;

      /* free the memory of merging_table */
/*      for(k=0;k<num_states;k++)
         free(merging_table[k]);
      free(merging_table);  
*/
      return ref_char_control_pattern;
}

//modified by zry
int Refinement2()
{
   int i,j,k,flag, flag_1, ref_char_control_pattern;
   int l;
   int **filtering, counter, max_num, max_state;
   struct forbidden_event_set *temp1;
   struct transitions *temp2, *temp22;
   struct virtual_stack *current_stack, *next_stack;

   stack = NULL;
   *tmpu_stack = -1;
   ref_char_control_pattern = 0;
   for(i=0;i<num_states;i++)
   {
      root_node[i].equal_set->state_number = i;
      root_node[i].equal_set->next_node = NULL;
   }
   merging_table = (int **) malloc(num_states*sizeof(int *));
   if (merging_table == NULL)
   {
      mem_result = 1;
   }
      
   for(j=0;j<num_states;j++)
   {
      merging_table[j] = (int *) malloc(num_states*sizeof(int));
      if (merging_table[j] == NULL)
      {
         mem_result = 1;
      }
      for(k=0;k<num_states;k++)
         merging_table[j][k] = -1; /*initialize merging_table*/
   }
   
      for(j=0;j<num_states-1;j++)
      {
         for(k=j+1;k<num_states;k++)
         {
            flag = 0;
            if(merging_table[j][k] != -1) continue;
            //if((root_node[j].marked_in_plant==root_node[k].marked_in_plant) && (root_node[j].marked_in_controller!=root_node[k].marked_in_controller))
            //   flag = 10;

            for(l=1;l<3;l++)
            {
              if(l==1)
              {
                 temp1 = root_node[j].forb_set;
                 temp2 = root_node[k].tran_set;
              }
              if(l==2)
              {
                 temp1 = root_node[k].forb_set;
                 temp2 = root_node[j].tran_set;
              }
              temp22 = temp2;
              while(temp1 != NULL)
              {
                 temp2 = temp22;
                 while(temp2 != NULL)
                 {
                     if(temp1->event == temp2->event)
                     {
                          flag = 10;
                          break;
                     }
                     temp2 = temp2->next_transition;
                 }
                 if(flag == 10) break;
                 temp1 = temp1->next_event;
              }
            }


            if(flag == 0)
            {
               tmpu_stack[0] = j;
               tmpu_stack[1] = k;
               tmpu_stack[2] = -1;

               /* modification is here ........*/ 
               stack = (struct virtual_stack *) malloc(sizeof(struct virtual_stack));
               stack->state_1 = j;
	   		   stack->state_2 = k;
               stack->last_state_pair = NULL; 
               stack->next_state_pair = NULL;
               /* end of modification .........*/
               
			   
 	       flag=Selfloop_Node2(j,k,-1,1);
               if(flag != 10)
               {
                  l = 0;
                  while(tmpu_stack[2*l] != -1)
                  {
                     merging_table[tmpu_stack[2*l]][tmpu_stack[2*l+1]] = 0;
                     merging_table[tmpu_stack[2*l+1]][tmpu_stack[2*l]] = 0;
                     l += 1;
                  }
                  tmpu_stack[0] = -1;

				  /*clear memory */
       			 current_stack = stack;
	    		 while(current_stack != NULL)
				 {
     			    next_stack = current_stack->next_state_pair;
                    free(current_stack);
	    			current_stack = next_stack;
				 }

			     stack = NULL;
                 /*end of clearing memory */

               }
               else
               {
				  /*clear memory */
       			 current_stack = stack;
	    		 while(current_stack != NULL)
				 {
     			    next_stack = current_stack->next_state_pair;
					merging_table[current_stack->state_1][current_stack->state_2] = 1;
					merging_table[current_stack->state_2][current_stack->state_1] = 1;
                    free(current_stack);
	    			current_stack = next_stack;
				 }

			     stack = NULL;
                 /*end of clearing memory */
	   
               }
            }
         }
      }
      /*Begin the refinement........................................................*/
      filtering = (int **) malloc(num_states*sizeof(int *));
      for(j=0;j<num_states;j++)
         filtering[j] = (int *) malloc(2*sizeof(int));
      for(j=0;j<num_states;j++)
      {
         counter = 0;
         for(k=0;k<num_states;k++)
            if(merging_table[j][k] == 0) counter += 1;
         filtering[j][0] = j;
         filtering[j][1] = counter;
      }
      flag_1 = 0;
      while(flag_1 == 0)
      {
         for(j=0;j<num_states;j++)
         {
            if(filtering[j][0] != -1) break;
         }
         max_num = filtering[j][1];
         max_state = j;
         for(k=j+1;k<num_states;k++)
         {
            if(filtering[k][0] != -1 && filtering[k][1] > max_num)
            {
               max_num = filtering[k][1];
               max_state = k;
            }
         }
         if(max_num == 0) break;
         for(k=0;k<num_states;k++)
         {
            if(merging_table[max_state][k] == 0)
            {
               if(filtering[k][0] != -1)
                  filtering[k][1] -= 1;
            }
         }
         filtering[max_state][0] = -1;
      }

      counter = 0;
      for(k=0;k<num_states;k++)
         if(filtering[k][0] != -1) counter += 1;
      ref_char_control_pattern += counter;

/*      for(j=0;j<num_states;j++)
         free(filtering[j]); */
      free(filtering); filtering = NULL;
      free(tmpu_stack); tmpu_stack = NULL;

      /* free the memory of merging_table */
/*      for(k=0;k<num_states;k++)
         free(merging_table[k]);
      free(merging_table);  
*/
      return ref_char_control_pattern;
}

//Origial supreduce procedure
int supreduce(char *name1,
              char *name2,
              char *name3,
              char *name4,
              INT_S* lb,
              double long *cr)
{
   int min_exit,tmp_data,tmp_trace_node,trace_node,index,min_tran_point;
   int base_point,number_of_transitions,flag,tmp_data_1;
   double long compress_ratio;
   int trace_mark,choice=0;
   int return_code = 0;
   int i;

   /* Initial all arrays to NULL */
   c_marked_states    = NULL;
   p_marked_states    = NULL;
   controller         = NULL;
   plant              = NULL;
   root_node          = NULL;
   controller_tree    = NULL;
   simpler_controller = NULL;
   tmpu_stack         = NULL;
   record             = NULL;

   flag = Get_DES(&tran_number,&num_states, 1, name1);
   if (flag != 0) return flag;
   if (num_states == 0) return -1;

   flag = Get_DES(&tran_number,&num_states, 0, name2);
   if (flag != 0) return flag+10;
   if (num_states == 0) return -1;
   if (tran_number == 1)
   {
      return_code = -2;
      goto FREEMEM;
   }

   root_node = (struct node *) calloc(num_states,sizeof(struct node));
   controller_tree=(int *) calloc((2*tran_number+15*num_states+1),sizeof(int));
   tmpu_stack=(int *) malloc((2*num_states*num_states+1)*sizeof(int));
   record = (int *) malloc((num_states+1)*sizeof(int)); 

   if ( (root_node == NULL) ||
        (controller_tree == NULL) ||
        (tmpu_stack == NULL) ||
        (record == NULL))
   {
      mem_result = 1;
      return_code = 30;
      goto FREEMEM;
   }

   /* generate controller_tree */
   Controller_Tree();
   free(controller); controller = NULL;

   /* generate combined_tree */
   flag=Combined_Tree();
   free(plant); plant = NULL;
   if(flag==1) {
      return_code = 40;
      goto FREEMEM;
   }

   /* generate root_node[] */
   Tree_Structure_Conversion(name3);
   free(controller_tree);  controller_tree = NULL;

   Reduction();

   if (mem_result == 1)
     goto FREEMEM;

   /* refine simpler_controller to generate the final text version transition structure of the reduced supervisor */
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     min_exit=base_point;
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)<*(simpler_controller+3*min_exit))
           min_exit=trace_node;
       trace_node +=1;
     }
     tmp_data=*(simpler_controller+3*base_point);
     *(simpler_controller+3*base_point)=*(simpler_controller+3*min_exit);
     *(simpler_controller+3*min_exit)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+1);
     *(simpler_controller+3*base_point+1)=*(simpler_controller+3*min_exit+1);
     *(simpler_controller+3*min_exit+1)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+2);
     *(simpler_controller+3*base_point+2)=*(simpler_controller+3*min_exit+2);
     *(simpler_controller+3*min_exit+2)=tmp_data;
     base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)>*(simpler_controller+3*base_point))
          break;
       else
       {
          if((*(simpler_controller+3*trace_node+1)==*(simpler_controller+3*base_point+1))&&(*(simpler_controller+3*trace_node+2)==*(simpler_controller+3*base_point+2)))
          {
              tmp_trace_node=trace_node+1;
              while(*(simpler_controller+3*tmp_trace_node)!=-1)
              {
                 *(simpler_controller+3*tmp_trace_node-3)=*(simpler_controller+3*tmp_trace_node);
                 *(simpler_controller+3*tmp_trace_node-2)=*(simpler_controller+3*tmp_trace_node+1);
                 *(simpler_controller+3*tmp_trace_node-1)=*(simpler_controller+3*tmp_trace_node+2);
                 tmp_trace_node +=1;
              }
              *(simpler_controller+3*tmp_trace_node-3)=-1;
              trace_node -=1;
          }
       }
       trace_node +=1;
     }
     base_point +=1;
   }
   base_point=0;
   index=1;
   tmp_data=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
      while(*(simpler_controller+3*base_point)>tmp_data)
      {
          if(*(simpler_controller+3*base_point)==-1) break;
          tmp_data=*(simpler_controller+3*base_point);
          trace_mark=0;
          while(*(c_marked_states+trace_mark)!=-1)
          {
             if(*(c_marked_states+trace_mark)==tmp_data) *(c_marked_states+trace_mark)=index;
             trace_mark +=1;
          }
          while((*(simpler_controller+3*base_point)==tmp_data)&&(*(simpler_controller+3*base_point)!=-1))
          {
            *(simpler_controller+3*base_point)=index;
            base_point +=1;
          }
          tmp_trace_node=0;
          while(*(simpler_controller+3*tmp_trace_node)!=-1)
          {
            if(*(simpler_controller+3*tmp_trace_node+2)==tmp_data) *(simpler_controller+3*tmp_trace_node+2)=index;
            tmp_trace_node +=1;
          }
          index +=1;
     }
     if(*(simpler_controller+3*base_point)!=-1) base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     tmp_data=*(simpler_controller+3*base_point);
     trace_node=base_point;
     while(*(simpler_controller+3*base_point)==tmp_data) base_point +=1;
     while(trace_node<base_point)
     {
       min_tran_point=trace_node;
       for(tmp_trace_node=trace_node;tmp_trace_node<base_point;tmp_trace_node++)
       {
          if(*(simpler_controller+3*tmp_trace_node+1)<*(simpler_controller+3*min_tran_point+1))
          {
              min_tran_point=tmp_trace_node;
          }
       }
       tmp_data_1=*(simpler_controller+3*trace_node+1);
       *(simpler_controller+3*trace_node+1)=*(simpler_controller+3*min_tran_point+1);
       *(simpler_controller+3*min_tran_point+1)=tmp_data_1;
       tmp_data_1=*(simpler_controller+3*trace_node+2);
       *(simpler_controller+3*trace_node+2)=*(simpler_controller+3*min_tran_point+2);
       *(simpler_controller+3*min_tran_point+2)=tmp_data_1;
       trace_node +=1;
     }
   }

   base_point=0;
   number_of_transitions=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     number_of_transitions +=1;
     if(*(simpler_controller+3*base_point+1)>=1000) 
        number_of_transitions -=1;
     base_point +=1;
   }

   /* output simsup.des */
   tmp_data=*(simpler_controller+3*base_point-3)+1;
   compress_ratio = ((double long) num_states)/((double long) tmp_data);
   *cr = compress_ratio;

   out=fopen(name4, "wb");
   if (out == NULL) return 1;
   flag=Txt_DES(tmp_data);
   fclose(out);

   free(simpler_controller); simpler_controller = NULL;
   free(c_marked_states); c_marked_states = NULL;
   free(p_marked_states); p_marked_states = NULL;
   
   if(flag!=1)
   {
      return_code = 50;
      goto FREEMEM;
   }

   /* lower bound estimate */
   *lb = Refinement();  

FREEMEM:
   if (root_node != NULL)
   {
       for (i=0; i < num_states; i++) {
          struct equivalent_state_set *temp1, *temp11;
          struct forbidden_event_set *temp2, *temp22;
          struct transitions *temp3, *temp33;

          temp1 = root_node[i].equal_set;
          while (temp1 != NULL)
          {
             temp11 = temp1->next_node;
             free(temp1);
             temp1 = temp11;
          }

          temp2 = root_node[i].forb_set;
          while (temp2 != NULL)
          {
             temp22 = temp2->next_event;
             free(temp2);
             temp2 = temp22;
          }

          temp3 = root_node[i].tran_set;
          while (temp3 != NULL)
          {
             temp33 = temp3->next_transition;
             free(temp3);
             temp3 = temp33;
          }
      }
   }
   free(root_node);
   free(controller_tree);
   free(tmpu_stack);
   free(controller);
   free(plant);
   free(record);
   
   return return_code;
}
// used in component-wise localize
int supreduce1(char *name1,
              char *name2,
              char *name3,
              char *name4,
              INT_S* lb,
              double long *cr, INT_S *num)
{
   int min_exit,tmp_data,tmp_trace_node,trace_node,index,min_tran_point;
   int base_point,number_of_transitions,flag,tmp_data_1;
   double long compress_ratio;
   int trace_mark,choice=0;
   int return_code = 0;
   int i;

   /* Initial all arrays to NULL */
   c_marked_states    = NULL;
   p_marked_states    = NULL;
   controller         = NULL;
   plant              = NULL;
   root_node          = NULL;
   controller_tree    = NULL;
   simpler_controller = NULL;
   tmpu_stack         = NULL;
   record             = NULL;

   flag = Get_DES(&tran_number,&num_states, 1, name1);
   if (flag != 0) return flag;
   if (num_states == 0) return -1;

   flag = Get_DES(&tran_number,&num_states, 0, name2);
   if (flag != 0) return flag+10;
   if (num_states == 0) return -1;
   if (tran_number == 1)
   {
      return_code = -2;
      goto FREEMEM;
   }

   root_node = (struct node *) calloc(num_states,sizeof(struct node));
   controller_tree=(int *) calloc((2*tran_number+15*num_states+1),sizeof(int));
   tmpu_stack=(int *) malloc((2*num_states*num_states+1)*sizeof(int));
   record = (int *) malloc((num_states+1)*sizeof(int)); 

   if ( (root_node == NULL) ||
        (controller_tree == NULL) ||
        (tmpu_stack == NULL) ||
        (record == NULL))
   {
      mem_result = 1;
      return_code = 30;
      goto FREEMEM;
   }

   /* generate controller_tree */
   Controller_Tree();
   free(controller); controller = NULL;

   /* generate combined_tree */
   flag=Combined_Tree();
   free(plant); plant = NULL;
   if(flag==1) {
      return_code = 40;
      goto FREEMEM;
   }

   /* generate root_node[] */
   Tree_Structure_Conversion(name3);
   free(controller_tree);  controller_tree = NULL;

   Reduction();

   if (mem_result == 1)
     goto FREEMEM;

   /* refine simpler_controller to generate the final text version transition structure of the reduced supervisor */
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     min_exit=base_point;
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)<*(simpler_controller+3*min_exit))
           min_exit=trace_node;
       trace_node +=1;
     }
     tmp_data=*(simpler_controller+3*base_point);
     *(simpler_controller+3*base_point)=*(simpler_controller+3*min_exit);
     *(simpler_controller+3*min_exit)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+1);
     *(simpler_controller+3*base_point+1)=*(simpler_controller+3*min_exit+1);
     *(simpler_controller+3*min_exit+1)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+2);
     *(simpler_controller+3*base_point+2)=*(simpler_controller+3*min_exit+2);
     *(simpler_controller+3*min_exit+2)=tmp_data;
     base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)>*(simpler_controller+3*base_point))
          break;
       else
       {
          if((*(simpler_controller+3*trace_node+1)==*(simpler_controller+3*base_point+1))&&(*(simpler_controller+3*trace_node+2)==*(simpler_controller+3*base_point+2)))
          {
              tmp_trace_node=trace_node+1;
              while(*(simpler_controller+3*tmp_trace_node)!=-1)
              {
                 *(simpler_controller+3*tmp_trace_node-3)=*(simpler_controller+3*tmp_trace_node);
                 *(simpler_controller+3*tmp_trace_node-2)=*(simpler_controller+3*tmp_trace_node+1);
                 *(simpler_controller+3*tmp_trace_node-1)=*(simpler_controller+3*tmp_trace_node+2);
                 tmp_trace_node +=1;
              }
              *(simpler_controller+3*tmp_trace_node-3)=-1;
              trace_node -=1;
          }
       }
       trace_node +=1;
     }
     base_point +=1;
   }
   base_point=0;
   index=1;
   tmp_data=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
      while(*(simpler_controller+3*base_point)>tmp_data)
      {
          if(*(simpler_controller+3*base_point)==-1) break;
          tmp_data=*(simpler_controller+3*base_point);
          trace_mark=0;
          while(*(c_marked_states+trace_mark)!=-1)
          {
             if(*(c_marked_states+trace_mark)==tmp_data) *(c_marked_states+trace_mark)=index;
             trace_mark +=1;
          }
          while((*(simpler_controller+3*base_point)==tmp_data)&&(*(simpler_controller+3*base_point)!=-1))
          {
            *(simpler_controller+3*base_point)=index;
            base_point +=1;
          }
          tmp_trace_node=0;
          while(*(simpler_controller+3*tmp_trace_node)!=-1)
          {
            if(*(simpler_controller+3*tmp_trace_node+2)==tmp_data) *(simpler_controller+3*tmp_trace_node+2)=index;
            tmp_trace_node +=1;
          }
          index +=1;
     }
     if(*(simpler_controller+3*base_point)!=-1) base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     tmp_data=*(simpler_controller+3*base_point);
     trace_node=base_point;
     while(*(simpler_controller+3*base_point)==tmp_data) base_point +=1;
     while(trace_node<base_point)
     {
       min_tran_point=trace_node;
       for(tmp_trace_node=trace_node;tmp_trace_node<base_point;tmp_trace_node++)
       {
          if(*(simpler_controller+3*tmp_trace_node+1)<*(simpler_controller+3*min_tran_point+1))
          {
              min_tran_point=tmp_trace_node;
          }
       }
       tmp_data_1=*(simpler_controller+3*trace_node+1);
       *(simpler_controller+3*trace_node+1)=*(simpler_controller+3*min_tran_point+1);
       *(simpler_controller+3*min_tran_point+1)=tmp_data_1;
       tmp_data_1=*(simpler_controller+3*trace_node+2);
       *(simpler_controller+3*trace_node+2)=*(simpler_controller+3*min_tran_point+2);
       *(simpler_controller+3*min_tran_point+2)=tmp_data_1;
       trace_node +=1;
     }
   }

   base_point=0;
   number_of_transitions=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     number_of_transitions +=1;
     if(*(simpler_controller+3*base_point+1)>=1000) 
        number_of_transitions -=1;
     base_point +=1;
   }

   /* output simsup.des */
   tmp_data=*(simpler_controller+3*base_point-3)+1;
   compress_ratio = ((double long) num_states)/((double long) tmp_data);
   *cr = compress_ratio;

   out=fopen(name4, "wb");
   if (out == NULL) return 1;
   flag=Txt_DES(tmp_data);
   *num = tmp_data;
   fclose(out);

   free(simpler_controller); simpler_controller = NULL;
   free(c_marked_states); c_marked_states = NULL;
   free(p_marked_states); p_marked_states = NULL;
   
   if(flag!=1)
   {
      return_code = 50;
      goto FREEMEM;
   }

   /* lower bound estimate */
   *lb = Refinement();  

FREEMEM:
   if (root_node != NULL)
   {
       for (i=0; i < num_states; i++) {
          struct equivalent_state_set *temp1, *temp11;
          struct forbidden_event_set *temp2, *temp22;
          struct transitions *temp3, *temp33;

          temp1 = root_node[i].equal_set;
          while (temp1 != NULL)
          {
             temp11 = temp1->next_node;
             free(temp1);
             temp1 = temp11;
          }

          temp2 = root_node[i].forb_set;
          while (temp2 != NULL)
          {
             temp22 = temp2->next_event;
             free(temp2);
             temp2 = temp22;
          }

          temp3 = root_node[i].tran_set;
          while (temp3 != NULL)
          {
             temp33 = temp3->next_transition;
             free(temp3);
             temp3 = temp33;
          }
      }
   }
   free(root_node);
   free(controller_tree);
   free(tmpu_stack);
   free(controller);
   free(plant);
   free(record);
   
   return return_code;
}
// used in event-wise localization: marker information is incorporated
int supreduce2(char *name1,
              char *name2,
              char *name3,
              char *name4,
              INT_S* lb,
              double long *cr, 
              INT_S *num)
{
   int min_exit,tmp_data,tmp_trace_node,trace_node,index,min_tran_point;
   int base_point,number_of_transitions,flag,tmp_data_1;
   double long compress_ratio;
   int trace_mark,choice=0;
   int return_code = 0;
   int i;

   /* Initial all arrays to NULL */
   c_marked_states    = NULL;
   p_marked_states    = NULL;
   controller         = NULL;
   plant              = NULL;
   root_node          = NULL;
   controller_tree    = NULL;
   simpler_controller = NULL;
   tmpu_stack         = NULL;
   record             = NULL;

   flag = Get_DES(&tran_number,&num_states, 1, name1);
   if (flag != 0) return flag;
   if (num_states == 0) return -1;

   flag = Get_DES(&tran_number,&num_states, 0, name2);
   if (flag != 0) return flag+10;
   if (num_states == 0) return -1;
   if (tran_number == 1)
   {
      return_code = -2;
      goto FREEMEM;
   }

   root_node = (struct node *) calloc(num_states,sizeof(struct node));
   controller_tree=(int *) calloc((2*tran_number+15*num_states+1),sizeof(int));
   tmpu_stack=(int *) malloc((2*num_states*num_states+1)*sizeof(int));
   record = (int *) malloc((num_states+1)*sizeof(int)); 

   if ( (root_node == NULL) ||
        (controller_tree == NULL) ||
        (tmpu_stack == NULL) ||
        (record == NULL))
   {
      mem_result = 1;
      return_code = 30;
      goto FREEMEM;
   }

   /* generate controller_tree */
   Controller_Tree();
   free(controller); controller = NULL;

   /* generate combined_tree */
   flag=Combined_Tree();
   free(plant); plant = NULL;
   if(flag==1) {
      return_code = 40;
      goto FREEMEM;
   }

   /* generate root_node[] */
   Tree_Structure_Conversion(name3);
   free(controller_tree);  controller_tree = NULL;

   Reduction2();

   if (mem_result == 1)
     goto FREEMEM;

   /* refine simpler_controller to generate the final text version transition structure of the reduced supervisor */
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     min_exit=base_point;
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)<*(simpler_controller+3*min_exit))
           min_exit=trace_node;
       trace_node +=1;
     }
     tmp_data=*(simpler_controller+3*base_point);
     *(simpler_controller+3*base_point)=*(simpler_controller+3*min_exit);
     *(simpler_controller+3*min_exit)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+1);
     *(simpler_controller+3*base_point+1)=*(simpler_controller+3*min_exit+1);
     *(simpler_controller+3*min_exit+1)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+2);
     *(simpler_controller+3*base_point+2)=*(simpler_controller+3*min_exit+2);
     *(simpler_controller+3*min_exit+2)=tmp_data;
     base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)>*(simpler_controller+3*base_point))
          break;
       else
       {
          if((*(simpler_controller+3*trace_node+1)==*(simpler_controller+3*base_point+1))&&(*(simpler_controller+3*trace_node+2)==*(simpler_controller+3*base_point+2)))
          {
              tmp_trace_node=trace_node+1;
              while(*(simpler_controller+3*tmp_trace_node)!=-1)
              {
                 *(simpler_controller+3*tmp_trace_node-3)=*(simpler_controller+3*tmp_trace_node);
                 *(simpler_controller+3*tmp_trace_node-2)=*(simpler_controller+3*tmp_trace_node+1);
                 *(simpler_controller+3*tmp_trace_node-1)=*(simpler_controller+3*tmp_trace_node+2);
                 tmp_trace_node +=1;
              }
              *(simpler_controller+3*tmp_trace_node-3)=-1;
              trace_node -=1;
          }
       }
       trace_node +=1;
     }
     base_point +=1;
   }
   base_point=0;
   index=1;
   tmp_data=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
      while(*(simpler_controller+3*base_point)>tmp_data)
      {
          if(*(simpler_controller+3*base_point)==-1) break;
          tmp_data=*(simpler_controller+3*base_point);
          trace_mark=0;
          while(*(c_marked_states+trace_mark)!=-1)
          {
             if(*(c_marked_states+trace_mark)==tmp_data) *(c_marked_states+trace_mark)=index;
             trace_mark +=1;
          }
          while((*(simpler_controller+3*base_point)==tmp_data)&&(*(simpler_controller+3*base_point)!=-1))
          {
            *(simpler_controller+3*base_point)=index;
            base_point +=1;
          }
          tmp_trace_node=0;
          while(*(simpler_controller+3*tmp_trace_node)!=-1)
          {
            if(*(simpler_controller+3*tmp_trace_node+2)==tmp_data) *(simpler_controller+3*tmp_trace_node+2)=index;
            tmp_trace_node +=1;
          }
          index +=1;
     }
     if(*(simpler_controller+3*base_point)!=-1) base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     tmp_data=*(simpler_controller+3*base_point);
     trace_node=base_point;
     while(*(simpler_controller+3*base_point)==tmp_data) base_point +=1;
     while(trace_node<base_point)
     {
       min_tran_point=trace_node;
       for(tmp_trace_node=trace_node;tmp_trace_node<base_point;tmp_trace_node++)
       {
          if(*(simpler_controller+3*tmp_trace_node+1)<*(simpler_controller+3*min_tran_point+1))
          {
              min_tran_point=tmp_trace_node;
          }
       }
       tmp_data_1=*(simpler_controller+3*trace_node+1);
       *(simpler_controller+3*trace_node+1)=*(simpler_controller+3*min_tran_point+1);
       *(simpler_controller+3*min_tran_point+1)=tmp_data_1;
       tmp_data_1=*(simpler_controller+3*trace_node+2);
       *(simpler_controller+3*trace_node+2)=*(simpler_controller+3*min_tran_point+2);
       *(simpler_controller+3*min_tran_point+2)=tmp_data_1;
       trace_node +=1;
     }
   }

   base_point=0;
   number_of_transitions=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     number_of_transitions +=1;
     if(*(simpler_controller+3*base_point+1)>=1000) 
        number_of_transitions -=1;
     base_point +=1;
   }

   /* output simsup.des */
   tmp_data=*(simpler_controller+3*base_point-3)+1;
   compress_ratio = ((double long) num_states)/((double long) tmp_data);
   *cr = compress_ratio;

   out=fopen(name4, "wb");
   if (out == NULL) return 1;
   flag=Txt_DES(tmp_data);
   *num = tmp_data;
   fclose(out);

   free(simpler_controller); simpler_controller = NULL;
   free(c_marked_states); c_marked_states = NULL;
   free(p_marked_states); p_marked_states = NULL;
   
   if(flag!=1)
   {
      return_code = 50;
      goto FREEMEM;
   }

   /* lower bound estimate */
   *lb = 0;  

FREEMEM:
   if (root_node != NULL)
   {
       for (i=0; i < num_states; i++) {
          struct equivalent_state_set *temp1, *temp11;
          struct forbidden_event_set *temp2, *temp22;
          struct transitions *temp3, *temp33;

          temp1 = root_node[i].equal_set;
          while (temp1 != NULL)
          {
             temp11 = temp1->next_node;
             free(temp1);
             temp1 = temp11;
          }

          temp2 = root_node[i].forb_set;
          while (temp2 != NULL)
          {
             temp22 = temp2->next_event;
             free(temp2);
             temp2 = temp22;
          }

          temp3 = root_node[i].tran_set;
          while (temp3 != NULL)
          {
             temp33 = temp3->next_transition;
             free(temp3);
             temp3 = temp33;
          }
      }
   }
   free(root_node);
   free(controller_tree);
   free(tmpu_stack);
   free(controller);
   free(plant);
   free(record);
   
   return return_code;
}
//used in event-wise localization: marker information is not considered
int supreduce3(char *name1,
              char *name2,
              char *name3,
              char *name4,
              INT_S* lb,
              double long *cr, 
              INT_S *num)
{
   int min_exit,tmp_data,tmp_trace_node,trace_node,index,min_tran_point;
   int base_point,number_of_transitions,flag,tmp_data_1;
   double long compress_ratio;
   int trace_mark,choice=0;
   int return_code = 0;
   int i;

   /* Initial all arrays to NULL */
   c_marked_states    = NULL;
   p_marked_states    = NULL;
   controller         = NULL;
   plant              = NULL;
   root_node          = NULL;
   controller_tree    = NULL;
   simpler_controller = NULL;
   tmpu_stack         = NULL;
   record             = NULL;

   flag = Get_DES(&tran_number,&num_states, 1, name1);
   if (flag != 0) return flag;
   if (num_states == 0) return -1;

   flag = Get_DES(&tran_number,&num_states, 0, name2);
   if (flag != 0) return flag+10;
   if (num_states == 0) return -1;
   if (tran_number == 1)
   {
      return_code = -2;
      goto FREEMEM;
   }

   root_node = (struct node *) calloc(num_states,sizeof(struct node));
   controller_tree=(int *) calloc((2*tran_number+15*num_states+1),sizeof(int));
   tmpu_stack=(int *) malloc((2*num_states*num_states+1)*sizeof(int));
   record = (int *) malloc((num_states+1)*sizeof(int)); 

   if ( (root_node == NULL) ||
        (controller_tree == NULL) ||
        (tmpu_stack == NULL) ||
        (record == NULL))
   {
      mem_result = 1;
      return_code = 30;
      goto FREEMEM;
   }

   /* generate controller_tree */
   Controller_Tree();
   free(controller); controller = NULL;

   /* generate combined_tree */
   flag=Combined_Tree();
   free(plant); plant = NULL;
   if(flag==1) {
      return_code = 40;
      goto FREEMEM;
   }

   /* generate root_node[] */
   Tree_Structure_Conversion(name3);
   free(controller_tree);  controller_tree = NULL;

   Reduction3();

   if (mem_result == 1)
     goto FREEMEM;

   /* refine simpler_controller to generate the final text version transition structure of the reduced supervisor */
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     min_exit=base_point;
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)<*(simpler_controller+3*min_exit))
           min_exit=trace_node;
       trace_node +=1;
     }
     tmp_data=*(simpler_controller+3*base_point);
     *(simpler_controller+3*base_point)=*(simpler_controller+3*min_exit);
     *(simpler_controller+3*min_exit)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+1);
     *(simpler_controller+3*base_point+1)=*(simpler_controller+3*min_exit+1);
     *(simpler_controller+3*min_exit+1)=tmp_data;
     tmp_data=*(simpler_controller+3*base_point+2);
     *(simpler_controller+3*base_point+2)=*(simpler_controller+3*min_exit+2);
     *(simpler_controller+3*min_exit+2)=tmp_data;
     base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     trace_node=base_point+1;
     while(*(simpler_controller+3*trace_node)!=-1)
     {
       if(*(simpler_controller+3*trace_node)>*(simpler_controller+3*base_point))
          break;
       else
       {
          if((*(simpler_controller+3*trace_node+1)==*(simpler_controller+3*base_point+1))&&(*(simpler_controller+3*trace_node+2)==*(simpler_controller+3*base_point+2)))
          {
              tmp_trace_node=trace_node+1;
              while(*(simpler_controller+3*tmp_trace_node)!=-1)
              {
                 *(simpler_controller+3*tmp_trace_node-3)=*(simpler_controller+3*tmp_trace_node);
                 *(simpler_controller+3*tmp_trace_node-2)=*(simpler_controller+3*tmp_trace_node+1);
                 *(simpler_controller+3*tmp_trace_node-1)=*(simpler_controller+3*tmp_trace_node+2);
                 tmp_trace_node +=1;
              }
              *(simpler_controller+3*tmp_trace_node-3)=-1;
              trace_node -=1;
          }
       }
       trace_node +=1;
     }
     base_point +=1;
   }
   base_point=0;
   index=1;
   tmp_data=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
      while(*(simpler_controller+3*base_point)>tmp_data)
      {
          if(*(simpler_controller+3*base_point)==-1) break;
          tmp_data=*(simpler_controller+3*base_point);
          trace_mark=0;
          while(*(c_marked_states+trace_mark)!=-1)
          {
             if(*(c_marked_states+trace_mark)==tmp_data) *(c_marked_states+trace_mark)=index;
             trace_mark +=1;
          }
          while((*(simpler_controller+3*base_point)==tmp_data)&&(*(simpler_controller+3*base_point)!=-1))
          {
            *(simpler_controller+3*base_point)=index;
            base_point +=1;
          }
          tmp_trace_node=0;
          while(*(simpler_controller+3*tmp_trace_node)!=-1)
          {
            if(*(simpler_controller+3*tmp_trace_node+2)==tmp_data) *(simpler_controller+3*tmp_trace_node+2)=index;
            tmp_trace_node +=1;
          }
          index +=1;
     }
     if(*(simpler_controller+3*base_point)!=-1) base_point +=1;
   }
   base_point=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     tmp_data=*(simpler_controller+3*base_point);
     trace_node=base_point;
     while(*(simpler_controller+3*base_point)==tmp_data) base_point +=1;
     while(trace_node<base_point)
     {
       min_tran_point=trace_node;
       for(tmp_trace_node=trace_node;tmp_trace_node<base_point;tmp_trace_node++)
       {
          if(*(simpler_controller+3*tmp_trace_node+1)<*(simpler_controller+3*min_tran_point+1))
          {
              min_tran_point=tmp_trace_node;
          }
       }
       tmp_data_1=*(simpler_controller+3*trace_node+1);
       *(simpler_controller+3*trace_node+1)=*(simpler_controller+3*min_tran_point+1);
       *(simpler_controller+3*min_tran_point+1)=tmp_data_1;
       tmp_data_1=*(simpler_controller+3*trace_node+2);
       *(simpler_controller+3*trace_node+2)=*(simpler_controller+3*min_tran_point+2);
       *(simpler_controller+3*min_tran_point+2)=tmp_data_1;
       trace_node +=1;
     }
   }

   base_point=0;
   number_of_transitions=0;
   while(*(simpler_controller+3*base_point)!=-1)
   {
     number_of_transitions +=1;
     if(*(simpler_controller+3*base_point+1)>=1000) 
        number_of_transitions -=1;
     base_point +=1;
   }

   /* output simsup.des */
   tmp_data=*(simpler_controller+3*base_point-3)+1;
   compress_ratio = ((double long) num_states)/((double long) tmp_data);
   *cr = compress_ratio;

   out=fopen(name4, "wb");
   if (out == NULL) return 1;
   flag=Txt_DES(tmp_data);
   *num = tmp_data;
   fclose(out);

   free(simpler_controller); simpler_controller = NULL;
   free(c_marked_states); c_marked_states = NULL;
   free(p_marked_states); p_marked_states = NULL;
   
   if(flag!=1)
   {
      return_code = 50;
      goto FREEMEM;
   }

   /* lower bound estimate */
   *lb = 0;  

FREEMEM:
   if (root_node != NULL)
   {
       for (i=0; i < num_states; i++) {
          struct equivalent_state_set *temp1, *temp11;
          struct forbidden_event_set *temp2, *temp22;
          struct transitions *temp3, *temp33;

          temp1 = root_node[i].equal_set;
          while (temp1 != NULL)
          {
             temp11 = temp1->next_node;
             free(temp1);
             temp1 = temp11;
          }

          temp2 = root_node[i].forb_set;
          while (temp2 != NULL)
          {
             temp22 = temp2->next_event;
             free(temp2);
             temp2 = temp22;
          }

          temp3 = root_node[i].tran_set;
          while (temp3 != NULL)
          {
             temp33 = temp3->next_transition;
             free(temp3);
             temp3 = temp33;
          }
      }
   }
   free(root_node);
   free(controller_tree);
   free(tmpu_stack);
   free(controller);
   free(plant);
   free(record);
   
   return return_code;
}
