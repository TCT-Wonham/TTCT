/* DES data structure */

#include <assert.h>
#include "des_data.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "setup.h"
#include "tct_proc.h"
#include "io_desff.h"

int mem_result = 0;

/* Func: newdes(size)
   Description:
      Allocate a new DES data structure with a given number of states.
      No transitions, silent states.

   Parameters:
      size    - number of states.  Must be greater than zero.
   Returns:
      Pointer to start of "state_node" array.
*/
state_node* newdes(INT_S size)
{
   return (state_node*) calloc(size, sizeof(state_node));
}

void resize_des(state_node **t, INT_S oldsize, INT_S newsize)
{
   INT_S i;

   *t = (state_node*) realloc(*t, sizeof(state_node)*(newsize));
   if (*t == NULL) {
      mem_result = 1;
      return;
   }

   if (oldsize < newsize) {
      for (i=oldsize; i < newsize; i++) {
         (*t)[i].marked       = false;
         (*t)[i].reached      = false;
         (*t)[i].coreach      = false;
         (*t)[i].vocal        = 0;
	 (*t)[i].nstinfo      = NULL;
	 (*t)[i].numtimer     = 0;
	 (*t)[i].ntimer       = NULL;
         (*t)[i].numelts      = 0;
         (*t)[i].next         = NULL;
      }
   }
}


/* Func: freedes(size, data)
   Description:
      Deallocate all memory held by the DES data structure.

   Parameters:
      size   - number of states.  Must be a number zero or greater.
      data   - pointer to DES data structure.
   Returns:
      nothing.
      Sets the pointer of "data" to NIL.
*/
void freedes(INT_S size, state_node** data)
{
   INT_S i;

   if (*data == NULL) return;
   if (size <= 0) return;

   for (i=0L; i < size; i++) {
      if ((*data)[i].nstinfo != NULL) {
	 
	 state_info *p, *q;
	 
	 for (p = (*data)[i].nstinfo; p != NULL; p = q) {
	    q = p->next;
	    free(p);
	 }
	 (*data)[i].nstinfo = NULL;
      };

      if ((*data)[i].ntimer != NULL) {
	 free((*data)[i].ntimer);
	 (*data)[i].ntimer = NULL;
      };
      if ((*data)[i].next != NULL) {
	 free((*data)[i].next);
	 (*data)[i].next = NULL;
      };
   }

   if (*data != NULL) free(*data);
   *data = NULL;
}

void free_map(INT_S size, state_map** data)
{
   INT_S i;

   if (*data == NULL) return;

   for (i=0L; i < size; i++)
     if ((*data)[i].next != NULL) {
        free((*data)[i].next);
        (*data)[i].next = NULL;
     }

   if (*data != NULL) free(*data);
   *data = NULL;
}

/* Add transition,extrance state pair */
void addordlist1(INT_T e,
                 INT_S j,
                 tran_node **L,
                 INT_T size,
                 INT_B *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2)) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j < (*L)[pos-1].data2))
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       found = true;
     } else if (e > (*L)[0].data1 || (e == (*L)[0].data1 && j > (*L)[0].data2)) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (tran_node*) realloc(*L, sizeof(tran_node)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(tran_node)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].data1 = e;
   (*L)[pos].data2 = j;

   *ok = true;
}

void addunordlist1(INT_T e,
                 INT_S j,
                 tran_node **L,
                 INT_T size,
                 INT_B *ok)
{
   *ok = false;

   /* Make space for new element */
   *L = (tran_node*) realloc(*L, sizeof(tran_node)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Insert the element into the list */
   (*L)[size].data1 = e;
   (*L)[size].data2 = j;

   *ok = true;
}

/* Add transition */
void addordlist(INT_T e,
                INT_T **L,
                INT_T size,
                INT_B *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1]) {
          found = true;
       } else if (e > (*L)[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1])
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0]) {
       found = true;
     } else if (e > (*L)[0]) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (INT_T*) realloc(*L, sizeof(INT_T)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(INT_T)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos]= e;

   *ok = true;
}

/* Add state */
void addstatelist(INT_S e,
                  INT_S **L,
                  INT_S size,
                  INT_B *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1]) {
          found = true;
       } else if (e > (*L)[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1])
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0]) {
       found = true;
     } else if (e > (*L)[0]) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (INT_S*) realloc(*L, sizeof(INT_S)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(INT_S)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos]= e;

   *ok = true;
}

/* Find a state in a list */
INT_B instatelist(INT_S e,         /* element to find */
                    INT_S *L,        /* list to search */
                    INT_S size)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == L[pos-1]) {
          found = true;
       } else if (e > L[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

   } else if (size == 1) {
     if (e == L[0]) {
       found = true;
     }
   }

   return found;
}

/* Add state map */
void addstatemap(INT_S e1, INT_S e2,
                 state_map **L,
                 INT_S size,
                 INT_B *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found, ok2;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e1 == (*L)[pos-1].state) {
          found = true;
       } else if (e1 > (*L)[pos-1].state) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e1 < (*L)[pos-1].state)
           pos--;
     }
   } else if (size == 1) {
     if (e1 == (*L)[0].state) {
       pos = 1;
       found = true;
     } else if (e1 > (*L)[0].state) {
       pos = 1;
     }
   }

   if (found == true) {
     addstatelist(e2, &(*L)[pos-1].next, (*L)[pos-1].numelts, &ok2);
     if (ok2) (*L)[pos-1].numelts++;
     return;
   }

   /* Make space for new element */
   *L = (state_map*) realloc(*L, sizeof(state_map)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(state_map)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].state = e1;
   (*L)[pos].numelts = 0;
   (*L)[pos].next = NULL;

   addstatelist(e2, &(*L)[pos].next, (*L)[pos].numelts, &ok2);
   if (ok2) (*L)[pos].numelts++;

   *ok = true;
}

/* Add State Pair */
void addstatepair(INT_S e,
                  INT_S j,
                  state_pair **L,
                  INT_S size,
                  INT_B *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2)) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j < (*L)[pos-1].data2))
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       found = true;
     } else if (e > (*L)[0].data1 || (e == (*L)[0].data1 && j > (*L)[0].data2)) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (state_pair*) realloc(*L, sizeof(state_pair)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(state_pair)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].data1 = e;
   (*L)[pos].data2 = j;

   *ok = true;
}

/* Find state pair */
INT_B instatepair(INT_S e, INT_S j,
                    state_pair **L,
                    INT_S size)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2)) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       found = true;
     }
   }

   return found;
}

void insertlist4(INT_S src,
                 INT_T tran,
                 INT_S dest,
                 INT_S *s,
                 state_node **t)
{
   INT_B ok;
   INT_S i;
   state_node *temp;

   if (src < *s) {
     addordlist1(tran, dest, &(*t)[src].next, (*t)[src].numelts, &ok);
     if (ok) (*t)[src].numelts++;
   } else {
     /* Need to increase the size of the array */
     temp = (state_node*) realloc(*t, sizeof(state_node)*(src+1));

     if (temp == NULL) {
       mem_result = 1;
       return;
     }
     *t = temp;

     for (i=*s; i <= src; i++) {
       (*t)[i].marked       = false;
       (*t)[i].reached      = false;
       (*t)[i].coreach      = false;
       (*t)[i].vocal        = 0;
       (*t)[i].nstinfo      = NULL;
       (*t)[i].numtimer     = 0;
       (*t)[i].ntimer       = NULL;
       (*t)[i].numelts      = 0;
       (*t)[i].next         = NULL;
    }

     *s = src+1;
     addordlist1(tran, dest, &(*t)[src].next, (*t)[src].numelts, &ok);
     if (ok) (*t)[src].numelts++;
   }
}


/* For triple, list of [i,e,j] */
void addtriple(INT_S i,
               INT_T e,
               INT_S j,
               triple **L,
               INT_S size,
               INT_B *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (i == (*L)[pos-1].i && e == (*L)[pos-1].e && j == (*L)[pos-1].j) {
          found = true;
       } else if (i > (*L)[pos-1].i || (i == (*L)[pos-1].i && e > (*L)[pos-1].e ) ||
                  (i == (*L)[pos-1].i && e == (*L)[pos-1].e && j > (*L)[pos-1].j ) ) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (i < (*L)[pos-1].i || (i == (*L)[pos-1].i && e < (*L)[pos-1].e) ||
            (i == (*L)[pos-1].i && e == (*L)[pos-1].e && j < (*L)[pos-1].j ) )
           pos--;
     }
   } else if (size == 1) {
     if (i == (*L)[0].i && e == (*L)[0].e && j == (*L)[0].j) {
       found = true;
     } else if (i > (*L)[0].i || (i == (*L)[0].i && e > (*L)[0].e) ||
                (i == (*L)[0].i && e == (*L)[0].e && j > (*L)[0].j ) ) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (triple*) realloc(*L, sizeof(triple)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(triple)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].i = i;
   (*L)[pos].e = e;
   (*L)[pos].j = j;

   *ok = true;
}

/* Delete transition,extrance state pair */
void delete_ordlist1(INT_T e,
                     INT_S j,
                     tran_node **L,
                     INT_T size,
                     INT_B *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].data1 && j == (*L)[pos-1].data2) {
          found = true;
       } else if (e > (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j > (*L)[pos-1].data2)) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1].data1 || (e == (*L)[pos-1].data1 && j < (*L)[pos-1].data2))
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].data1 && j == (*L)[0].data2) {
       pos = 1;
       found = true;
     } else if (e > (*L)[0].data1 || (e == (*L)[0].data1 && j > (*L)[0].data2)) {
       pos = 1;
     }
   }

   if (found == false) {
     return;
   }

   /* Move over any elements up the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos-1], &(*L)[pos], sizeof(tran_node)*(size-pos));

   /* Remove space for element */
   *L = (tran_node*) realloc(*L, sizeof(tran_node)*(size-1));
   if (size > 1) {
     if (*L == NULL) {
        mem_result = 1;
        return;
     }
   } else {
     *L = NULL;
   }

   *ok = true;
}

/* Find an event in a list */
INT_B inlist(INT_T e,         /* element to find */
               INT_T *L,        /* list to search */
               INT_T size)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B found;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == L[pos-1]) {
          found = true;
       } else if (e > L[pos-1]) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }
   } else if (size == 1) {
     if (e == L[0]) {
       found = true;
     }
   }

   return found;
}

void add_quad(INT_S i, INT_T e, INT_S j, INT_V v,
              quad__t **L, INT_S slist, INT_B *ok)
{
   INT_S pos;
   INT_S lower, upper;
   INT_B found;

   *ok = false;

   pos = 0;
   found = false;
   if (slist > 1) {
      lower = 1;
      upper = slist;
      while ( (found == false) && (lower <= upper) ) {
         pos = (lower + upper) / 2;
         if (i == (*L)[pos-1].a &&
             e == (*L)[pos-1].b &&
             j == (*L)[pos-1].c &&
             v == (*L)[pos-1].d) {
             found = true;
         } else if (i > (*L)[pos].a ||
                    (i == (*L)[pos-1].a && e > (*L)[pos-1].b ) ||
                    (i == (*L)[pos-1].a && e == (*L)[pos-1].b && j > (*L)[pos-1].c) ||
                    (i == (*L)[pos-1].a && e == (*L)[pos-1].b && j == (*L)[pos-1].c && v > (*L)[pos-1].d ) ) {
             lower = pos+1;
         } else {
             upper = pos-1;
         }
      }

      if (found == false) {
         if (i < (*L)[pos-1].a ||
             (i == (*L)[pos-1].a && e < (*L)[pos-1].b) ||
             (i == (*L)[pos-1].a && e == (*L)[pos-1].b && j < (*L)[pos-1].c) ||
             (i == (*L)[pos-1].a && e == (*L)[pos-1].b && j == (*L)[pos-1].c && v < (*L)[pos-1].d) )
            pos--;
      }
   } else if (slist == 1) {
      if (i == (*L)[0].a && e == (*L)[0].b && j == (*L)[0].c && v == (*L)[0].d) {
         found = true;
      } else if (i > (*L)[0].a || (i == (*L)[0].a && e > (*L)[0].b) ||
                 (i == (*L)[0].a && e == (*L)[0].b && j > (*L)[0].c ) ||
                 (i == (*L)[0].a && e == (*L)[0].b && j == (*L)[0].c && v > (*L)[0].d) ) {
         pos = 1;
      }
   }

   if (found == true) {
      return;
   }

   /* Make spae for new element */
   *L = (quad__t*) realloc(*L, sizeof(quad__t)*(slist+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((slist-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(quad__t)*(slist-pos));

   /* Insert the element into the list */
   (*L)[pos].a = i;
   (*L)[pos].b = e;
   (*L)[pos].c = j;
   (*L)[pos].d = v;

   *ok = true;
}

/* Determine if the DES files contains correct values */
INT_B check_des_sanity(state_node *t, INT_S s)
{
   INT_S i, jj;
   INT_T j, ee;

   if ((t == NULL) || (s <= 0)) return true;

   for (i=0; i < s; i++) {
      for (j=0; j < t[i].numelts; j++) {
         ee = t[i].next[j].data1;
         jj = t[i].next[j].data2;
         if (ee > 999) return false;
         if (!((0 <= jj) && (jj < s))) return false;
      }
   }
   return true;
}

/* Return the number of mark states */
INT_S num_mark_states(state_node* t1, INT_S s1)
{
   INT_S i;
   INT_S num_mark;

   num_mark = 0L;

   for (i=0; i < s1; i++) {
     if (t1[i].marked)
        num_mark++;
   }
   return num_mark;
}

/* Return the number of forcible states */
INT_S num_forcible_events(timed_event* t1, INT_T s1)
{
   INT_S i;
   INT_S num_forcible;

   num_forcible = 0L;

   for (i=0; i < s1; i++) {
     if (t1[i].forcible)
        num_forcible++;
   }
   return num_forcible;
}

/* Return the number of vocal states */
INT_S num_vocal_output(state_node *t1, INT_S s1)
{
   INT_S i;
   INT_S num_vocal;

   num_vocal = 0;
   for (i=0; i < s1; i++) {
     if (t1[i].vocal > 0)
        num_vocal++;
   }
   return num_vocal;
}

INT_B is_valid_transition(INT_S i,
                            INT_T e,
                            INT_S *j,
                            state_node *t1,
                            INT_S s1)
{
   INT_T ii;
   INT_B found;
   /* Have to do a linear search because, the DES maybe non-deterministic
      and also, we don't have the entrance state */
   found = false;
   ii = 0;
   while ((ii < t1[i].numelts) && (!found)) {
     if (t1[i].next[ii].data1 == e) {
       found = true;
       *j = t1[i].next[ii].data2;
     }
     ii++;
   }
   return found;
}

/*
***************************************************************************
* Cedric Delayre's job
***************************************************************************
*/

/* dummy function 
int filedes(char *name, INT_S size, INT_S init, state_node *data) {}*/
#define TCTNAME "XPTCT"
static char  signature[8] = {"Z8^0L;1"};
static int   signature_length = 7;
static INT_S endian = 0xFF00AA55;
int filedes(char*       name,
             INT_S       size,
             INT_S       init,
             state_node *data)
{
   char  fullname[_MAX_PATH];
   FILE  *out;
   INT_S i, z, yy;
   INT_V v;
   char  header[100];
   INT_S header_len;
   long block_type, block_size;
   long cur_pos;
   INT_S temp;
   
//   if (z) {}  /* Remove warning in some version of TCT */
 //  if (yy) {} /* Remove warning in some version of TCT */

#if defined(__UNIX__)
   if (init == -1L)     /* CONDAT file */
      sprintf(fullname, "%s%s.dat", prefix, name);
   else
      sprintf(fullname, "%s%s.des", prefix, name);
#else
   if (init == -1L)     /* CONDAT file */
      sprintf(fullname, "%s%s.DAT", prefix, name);
   else
      sprintf(fullname, "%s%s.DES", prefix, name);
#endif

   out = fopen(fullname, "wb");
   if (out == NULL) {
      printf("Could not create file: %s\n", fullname);
      return 1;
   }

   /* Setup a buffer for faster IO */
   setvbuf(out, NULL, _IOFBF, 32000);

   /* Enter some useful ASCII text */
#if defined(__BORLANDC__)
   sprintf(header, "CTCT DES file. Borland C/C++ version.  For testing only");
#else
   sprintf(header, "%s DES file. Version 1.0", TCTNAME);
#endif
   header_len = (INT_S)strlen(header);
   header[header_len] = 26;  /* Mark end of ASCII file */
   fwrite(&header, sizeof(char), header_len+1, out);

   /* Unique string to uniquely identify it is a CTCT DES file.
      Some other program put a header string. */
   fwrite(&signature, sizeof(char), signature_length, out);

   /* Big-endian and Little-endian information */
   fwrite(&endian, sizeof(INT_S), 1, out);

   /* Block type zero (0) - required */
   block_type = 0;
   fwrite(&block_type, sizeof(long), 1, out);

   /* Save the current position because we have to fill in the size */
   fwrite(&block_size, sizeof(INT_S), 1, out);
   block_size = ftell(out);

   fwrite(&size, sizeof(INT_S), 1, out);
   fwrite(&init, sizeof(INT_S), 1, out);

   /* Write the marker states */
   for (i=0L; i < size; i++)
     if (data[i].marked)
       fwrite(&i, sizeof(INT_S), 1, out);
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);

   /* Write the transitions */
   for (i=0L; i < size; i++) {
     if ((data[i].next != NULL) && (data[i].numelts > 0)){
       fwrite(&i, sizeof(INT_S), 1, out);
       fwrite(&data[i].numelts, sizeof(INT_T), 1, out);
//#if defined(__BORLANDC__)
       for (z=0; z < data[i].numelts; z++) {
          yy = (unsigned long) data[i].next[z].data1;
          yy = yy << 22;
          yy = yy | data[i].next[z].data2;
          fwrite(&yy, sizeof(INT_S), 1, out);
       }
//#else
//       fwrite(data[i].next, sizeof(tran_node), data[i].numelts, out);
//#endif
     }
   }
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);

   /* Write the vocal states */
   for (i=0L; i < size; i++) {
     if (data[i].vocal != 0) {
       fwrite(&i, sizeof(INT_S), 1, out);
       v = data[i].vocal;
       fwrite(&v, sizeof(INT_V), 1, out);
     }
   }
   i = -1L; fwrite(&i, sizeof(INT_S), 1, out);

   if (ferror(out)) {
      fclose(out);
      return 1;
   }

   /* Update the block size */
   cur_pos = ftell(out);
   fseek(out, block_size, SEEK_CUR);
   block_size = cur_pos - block_size;
   fwrite(&block_size, sizeof(INT_S), 1, out);
   fseek(out, 0, SEEK_END);

   /* Block type zero (-1) - required */
   block_type = -1;
   fwrite(&block_type, sizeof(long), 1, out);
   block_size = 8;
   fwrite(&block_size, sizeof(long), 1, out);
   temp = 0;
   fwrite(&temp, sizeof(INT_S), 1, out);
   fwrite(&temp, sizeof(INT_S), 1, out);

   if (ferror(out)) {
      fclose(out);
      return 1;
   }

   fclose(out);
   return 0;      /* Success in writing file to disk */
}

/* "filetds" function */
int filetds(char *name, INT_S size, INT_S init, state_node *data, 
	    INT_S size1, INT_T *data1)
/*char*       name;
INT_S       size;
INT_S       init;
state_node *data;*/
{
  FILE *out;
  int t=0;
  char fullname[1024];

   if (init == -1L)     /* CONDAT file */
#if defined(__GO32__)
      sprintf(fullname, "%s%s.DAT", prefix, name);
#else
      sprintf(fullname, "%s%s.dat", prefix, name);
#endif
   else
      sprintf(fullname, "%s%s%s", prefix, name,EXT_DES);

   out = fopen(fullname, "wb");
   if (out == NULL) {
      fprintf(stderr,"Could not create file: %s\n", fullname);
      return 0;
   }
   t = write_tds_to_file(data,size,init,data1,size1,out);
   fclose(out);
   return t;
}

/* "fileads" function */
int fileads(char *name, INT_S size, INT_S init, state_node *data, 
	    INT_T size1, timed_event *data1)
/*char*       name;
INT_S       size;
INT_T       size1;
INT_S       init;
state_node *data;
timed_event *data1;*/
{
  FILE *out;
  int t=0;
  char fullname[1024];

   if (init == -1L)     /* CONDAT file */
#if defined(__GO32__)
      sprintf(fullname, "%s%s.DAT", prefix, name);
#else
      sprintf(fullname, "%s%s.dat", prefix, name);
#endif
   else
      sprintf(fullname, "%s%s%s", prefix, name,EXT_ADS);

   out = fopen(fullname, "wb");
   if (out == NULL) {
      fprintf(stderr,"Could not create file: %s\n", fullname);
      return 0;
   }
   t = write_ades_to_file(data,size,data1,size1,init,out);
   fclose(out);
   return t;
}
/* Dummy function until all is changed 
INT_B getdes(char *name, INT_S *size, INT_S *init, state_node **data) {}*/
INT_B getdes(char*        name,
               INT_S       *size,
               INT_S       *init,
               state_node **data)
{
   FILE *in;
   char fullname[_MAX_PATH];
   INT_S mark, s, z, yy;
   INT_T num;
   INT_V vocal;
   char ch;
   char header[8];
   INT_S read_endian;
   long block_type, block_size;

//   if (z) {}  /* Remove warning in some versions of TCT */
 //  if (yy) {} /* Remove warning in some versions of TCT */

   if (*init == -1L) {
      sprintf(fullname, "%s%s.dat", prefix, name);
   } else {
      sprintf(fullname, "%s%s.des", prefix, name);
   }
   in = fopen(fullname, "rb");
   if (in == NULL) return false;

   /* Setup a buffer for faster IO */
   setvbuf(in, NULL, _IOFBF, 32000);

   /* Read the ASCII header and junk */
   ch = 0;
   while ((ch != 26) && !feof(in)) {
      fread(&ch, sizeof(char), 1, in);
   }

   memset(header, 0, 8); /* Zero out the string */
   /* Read the unique string to authenic CTCT DES file */
   fread(header, sizeof(char), 7, in);
   if (strcmp(header, signature) != 0) {
      fclose(in);
      return false;
   }

   /* Big-endian and Little-endian information */
   fread(&read_endian, sizeof(INT_S), 1, in);
   if (read_endian != endian) {
      fclose(in);
      return false;
   }

   /* Block type */
   fread(&block_type, sizeof(long), 1, in);
   if (block_type != 0) {
      fclose(in);
      return false;
   }

   /* Read the number of bytes of this block type */
   fread(&block_size, sizeof(long), 1, in);

   fread(size, sizeof(INT_S), 1, in);
   fread(init, sizeof(INT_S), 1, in);

   if (ferror(in)) {
      fclose(in);
      return false;
   }

   *data = newdes(*size);
   if ((*size != 0) && (*data == NULL)) {
      mem_result = 1;
      fclose(in);
      return false;
   }

   if (*size > 0L) (*data)[0L].reached = true;

   /* Read the marked states */
   mark = 0L;
   while (mark != -1L) {
      fread(&mark, sizeof(INT_S), 1, in);
      if (mark != -1L)
         (*data)[mark].marked = true;
   }

   /* Read the transitions */
   s = 0L;
   while (s != -1L) {
      fread(&s, sizeof(INT_S), 1, in);

      if (s == -1L) break;

      fread(&num, sizeof(INT_T), 1, in);
      (*data)[s].next = (tran_node*) malloc(sizeof(tran_node)*num);
      if ( (*data)[s].next == NULL ) {
         mem_result = 1;
         fclose(in);
         return false;
      }

      (*data)[s].numelts = num;
//#if defined(__BORLANDC__)
      for (z=0; z < num; z++) {
         fread(&yy, sizeof(INT_S), 1, in);
         (*data)[s].next[z].data1 = (INT_T) ((unsigned long) yy >> 22);
         (*data)[s].next[z].data2 = (yy & 0x003FFFFF);
      }
//#else
//      fread((*data)[s].next, sizeof(tran_node), num, in);
//#endif
   }

   /* Read the vocal states */
   s = 0L;
   while (s != -1L) {
      fread(&s, sizeof(INT_S), 1, in);
      if (s == -1L) break;
      fread(&vocal, sizeof(INT_V), 1, in);
      (*data)[s].vocal = vocal;
   }

   /* We don't read the last block type because we don't know how to
      process anything else after this point */

   fclose(in);
   return true;
}

/* GetDes function */
INT_B gettds(char *name, INT_S *size, INT_S *init, state_node **data, 
	       INT_S *size1, INT_T **data1)
/*char*        name;
INT_S       *size;
INT_S       *init;
state_node **data;*/
{
   FILE *in;
   char fullname[1024];

   if (*init == -1L)
      sprintf(fullname, "%s%s.dat", prefix, name);
   else
      sprintf(fullname, "%s%s%s", prefix, name, EXT_DES);
   in = fopen(fullname, "rb");
   if (in == NULL) {
      fprintf(stderr,"Could not open file: %s\n", fullname);
      return false;
   }
   *data = read_new_tds_file((FILE*)in, (int*)size, (int*)init, size1, data1);
   fclose(in);
   return (*data != NULL || size == 0);
}

/* Getads function */
INT_B getads(char *name, INT_S *size, INT_S *init, state_node **data,
	       INT_T *size1, timed_event **data1)
/*char*        name;
INT_S       *size;
INT_T       *size1;
INT_S       *init;
state_node **data;
timed_event **data1;*/
{
   FILE *in;
   char fullname[1024];

   if (*init == -1L)
      sprintf(fullname, "%s%s.dat", prefix, name);
   else
      sprintf(fullname, "%s%s%s", prefix, name, EXT_ADS);
   in = fopen(fullname, "rb");
   if (in == NULL) {
      fprintf(stderr,"Could not open file: %s\n", fullname);
      return false;
   }

   *data = read_ades_file((FILE*)in, (int*)size, (int*)init, size1,
			  data1);
   fclose(in);
   return (*data != NULL);
}

/*
** This function adds a transition [s,e,t] into the DES data structure
**    data represents the DES data structure
**    elemts is the number of DES states
**    [s,e,t] is the transition to add (source,event,target)
**    returns true if added, false if already exists
 */
INT_B
add_transition( state_node *data, int elemts, int s, int e, int t )
{
  tran_node trans, *new;
  state_node *vertex;
  int i;

  //assert( data && s>=0 && s<elemts );
  trans.data2 = t;
  trans.data1 = e;
  vertex = &(data[s]);

  /*  addordlist1((INT_T) e, (INT_S) t, &data[s].next, data[s].numelts, &ok);
  if (ok) data[s].numelts++;
  return ok;
  */
  for (i=0; i<vertex->numelts; i++)
    {
      /* check if the transition doesn't exist */
      if (memcmp(&(vertex->next[i]),&trans,sizeof(tran_node)) == 0)
	return false;
    }

  /* allocates a new place, not with realloc because of some bugs on different
     operating systems */
  new = (tran_node*)malloc( (vertex->numelts+1)*sizeof(tran_node) );
  assert(new);
  memcpy( new, vertex->next, vertex->numelts*sizeof(tran_node) );
  free(vertex->next);
  memcpy( &(new[vertex->numelts++]), &trans, sizeof(tran_node) );
  vertex->next = new;
  return true;
}

/*
** This function removes a transition [s,e,t] in the DES data structure
**    data represents the DES data structure
**    elemts is the number of DES states
**    [s,e,t] is the transition to add (source,event,target)
**    returns true if removed, false if it doesn't exist
 */
INT_B
remove_transition( state_node *data, int elemts, int s, int e, int t )
{
  tran_node trans, *new;
  state_node *vertex;
  int i;

  //assert( data && s>=0 && s<elemts );
  trans.data2 = t;
  trans.data1 = e;
  vertex = &(data[s]);

  for (i=0; i<vertex->numelts; i++)
    {
      /* check if the transition exists */
      if (memcmp(&(vertex->next[i]),&trans,sizeof(tran_node)) == 0)
	break;
    }
  if (i >= vertex->numelts) {
    return false;
  }

  /* allocates a new place, not with realloc because of some bugs on different
     operating systems */
  new = (tran_node*)malloc( (vertex->numelts-1)*sizeof(tran_node) );
  assert(new);
  memcpy( new, vertex->next, i*sizeof(tran_node) );
  memcpy( &(new[i]), &(vertex->next[i+1]),
	  (vertex->numelts-i-1)*sizeof(tran_node) );
  free(vertex->next);
  vertex->next = new;
  vertex->numelts--;
  return true;
}

/*
 * this function adds a marker state
 * return true if the marker is added, false if it already exists
 */
INT_B
add_marker(state_node *des, int states, int marker)
{
  assert(marker < states);
  assert(des);
  if (!des[marker].marked) {
    des[marker].marked = true;
    return true;
  }
  return false;
}

/*
 * this function returns true if the given state is marked
 */
INT_B
is_marked(state_node *des, int states, int i)
{
  assert(i < states);
  return des[i].marked;
}

/*
 * this function removes a given marker state
 */
INT_B
remove_marker(state_node *des, int states, int marker)
{
  assert(marker < states);
  if (des[marker].marked) {
    des[marker].marked = false;
    return true;
  }
  return false;
}

/*
 * this function adds a couple of states
 */
INT_B
add_states(state_node **des, int *states, int count)
{
  state_node *new;
  int oldstates;

  /*
   * verification of the arguments
   */
  assert(des && *des);
  assert(states);
  if (count <= 0) {
    return false;
  }
  oldstates = *states;

  /*
   * memory allocation
   */
  new = realloc(*des, (oldstates+count)*sizeof(struct state_node));
  if (!new) {
    return false;
  }
  *des = new;
  *states += count;
  memset(&((*des)[oldstates]), 0, count*sizeof(struct state_node));
  return true;
}

void addordlist_time(INT_T e, INT_T low, INT_T high, 
                     timed_event **L, INT_T size, INT_B *ok)
{
   INT_T pos;
   INT_T lower, upper;
   INT_B found;

   *ok = false;

   /* Do a binary search. */
   found = false;
   pos = 0;
   if (size > 1) {
     lower = 1;
     upper = size;
     while ( (found == false) && (lower <= upper) ) {
       pos = (lower + upper) / 2;
       if (e == (*L)[pos-1].label) {
          found = true;
       } else if (e > (*L)[pos-1].label) {
          lower = pos+1;
       } else {
          upper = pos-1;
       }
     }

     if (found == false) {
        if (e < (*L)[pos-1].label)
           pos--;
     }
   } else if (size == 1) {
     if (e == (*L)[0].label) {
       found = true;
     } else if (e > (*L)[0].label) {
       pos = 1;
     }
   }

   if (found == true) {
     return;
   }

   /* Make space for new element */
   *L = (timed_event*) realloc(*L, sizeof(timed_event)*(size+1));
   if (*L == NULL) {
      mem_result = 1;
      return;
   }

   /* Move over any elements down the list */
   if ((size-pos) > 0)
      memmove(&(*L)[pos+1], &(*L)[pos], sizeof(timed_event)*(size-pos));

   /* Insert the element into the list */
   (*L)[pos].label    = e;
   (*L)[pos].low      = low;
   (*L)[pos].upper    = high;
   (*L)[pos].forcible = false;

   *ok = true;
}
