#include <stdio.h>
#include <stdlib.h>
#include "hicons.h"
#include "outcon.h"
#include "des_supp.h"
#include "des_data.h"

static INT_V max_vocal;
static INT_B overflow_error;

/* Determine whether "blocking_set" is a subset of "dedicated_set" */
INT_B subset(INT_S* blocking_set, INT_S* dedicated_set) {
   INT_S i,j;
   INT_B is_subset;
   INT_B blockPresent;

   is_subset = true;

   if (blocking_set[0] == -1)
     return false;

   i = 0;
   while ( (blocking_set[i] != -1) && (is_subset == true) ) {
      j = 0;
      blockPresent = false;
      while ( (dedicated_set[j] != -1) && (blockPresent == false) ) {
         if ( blocking_set[i] == dedicated_set[j] ) {
             blockPresent = true;
         } else {
             j++;
         }
      }

      if (blockPresent == false) {
         is_subset = false;
      }
      i++;
   }

   return is_subset;
}

/* Vocalize silent state with next vocal state output */
void vocalize(state_node **t, INT_S i, INT_T **unused, INT_T *s_unused) {
   INT_B ok;

   do {
      if (inlist(max_vocal, *unused, *s_unused)) {
         max_vocal++;
         if (max_vocal > 99) {
	    overflow_error=true;
	    return;
         }
      } else {
         break;
      }
   } while (true); 
   (*t)[i].vocal = max_vocal;
   addordlist(max_vocal, unused, *s_unused, &ok);
   if (ok) (*s_unused)++;
}

static INT_B uncont(INT_T e)
{
   return ((e % 2) == 0);  /* Even */
}

/* Determine if the state is a vocal state */
INT_B is_vocal_state(state_node *t, INT_S i)
{
    return (t[i].vocal > 0);
}

INT_B agent(state_node** t, INT_S *s, INT_S i, tran_node *tr)
{
   INT_S ii, jj;
   INT_T ee, j;
   INT_B agentFlag;
   INT_B ok;
   t_stack ts;

   if (uncont(tr->data1)) {
      return false;
   } else if (is_vocal_state(*t, tr->data2)) {
      return true;
   } else {
      pstack_Init(&ts);

      /* Set "reach" field of state to false */
      for (i=0; i < *s; i++)
         (*t)[i].reached = false;

      jj = tr->data2;
      (*t)[jj].reached = true;
      agentFlag = false;
      j = 0;
      do {
          if (j < (*t)[jj].numelts) {
             ee = (*t)[jj].next[j].data1;
             ii = (*t)[jj].next[j].data2;
             if (uncont(ee) && !(*t)[ii].reached) {
                 if (is_vocal_state(*t,ii)) {
                     agentFlag = true;
                 } else {
                     pstack_Push(&ts, j, jj);
                     (*t)[ii].reached = true;
                     jj = ii;
                     j = 0;
                 }
             } else {
                 j++;
             }
          } else {
             if (! pstack_IsEmpty(&ts)) {
                pstack_Pop(&ts, &j, &jj, &ok);
                j++;
             }
          }
      } while ( ((j < (*t)[jj].numelts) || !pstack_IsEmpty(&ts))
                && (agentFlag != true) );
      pstack_Done(&ts);
   }

   return agentFlag;
}

/* Get the blocking set for the state and event.  See notes
   for details of the definitions of a blocking set. */
void getblocking_set(state_node** t, INT_S *s,
                     INT_S i, tran_node *tr, INT_S *blocking_set)
{
   INT_S nBlockingSet;  /* Number of elements in blocking set */
   INT_B *ra;
   INT_S ii, jj;
   INT_T j;
   INT_B ok;
   t_stack ts;

   nBlockingSet = 0;
   if ( uncont(tr->data1) ) {
   } else if (is_vocal_state(*t, tr->data2)) {
      blocking_set[nBlockingSet] = tr->data2;
      nBlockingSet++;
   } else {
      pstack_Init(&ts);

      /* Allocate memory for reachability array */
      ra = (INT_B*) calloc(*s, sizeof(INT_B)); /* Set values to false */
      if (ra == NULL) {
        pstack_Done(&ts);
        mem_result = 1;
        return;
      }

      ii = tr->data2;
      (*t)[ii].reached = true;
      j = 0;
      do {
        if (j < (*t)[ii].numelts) {
           jj = (*t)[ii].next[j].data2;
           if (!ra[jj]) {
              if (is_vocal_state(*t, jj)) {
                  blocking_set[nBlockingSet] = jj;
                  nBlockingSet++;
                  ra[jj] = true;
                  j++;
              } else {
                  pstack_Push(&ts,j,ii);
                  ra[jj] = true;
                  j = 0;
                  ii = jj;
              }
           } else {
              j++;
           }
        } else {
           if (!pstack_IsEmpty(&ts)) {
              pstack_Pop(&ts,&j,&ii,&ok);
              j++;
           }
        }
      } while ( (j < (*t)[ii].numelts) || !pstack_IsEmpty(&ts));

      free(ra);
      pstack_Done(&ts);
   }

   blocking_set[nBlockingSet] = -1;
}

/* Get the dedicated set for the "state".  See notes for more details */
void getdedicated_set(state_node **t, INT_S *s,
                      INT_S i, INT_S *dedicated_set)
{
   INT_S nDedicatedSet;
   INT_S *bs;
   INT_B *ra, isAgent, ok, isUnary, dedicatedFlag;
   INT_S size;
   t_stack ts;
   INT_T j, ee, eee;
   INT_S ii, jj, iii;
   INT_S s_index;

   nDedicatedSet = 0;
   size = *s;

   pstack_Init(&ts);

   /* Allocate local memory */
   bs = (INT_S*)   calloc(size+1, sizeof(INT_S));
   ra = (INT_B*) calloc(size, sizeof(INT_B));  /* Set all values to false */

   if ( (bs == NULL) || (ra == NULL) ) {
       mem_result = 1;
       return;
   }

   j = 0;
   jj = i;
   do {
      if (j < (*t)[jj].numelts) {
         ee = (*t)[jj].next[j].data1;
         ii = (*t)[jj].next[j].data2;
         if (! ra[ii]) {
            if (is_vocal_state(*t,ii)) {
                pstack_Push(&ts, j, jj);

                /* Start examining transitions */
                s_index = ts.head_size;
                do {
                   eee = ts.head[s_index-1].data1;
                   iii = ts.head[s_index-1].data2;

                   isAgent = agent(t,s,0,&(*t)[iii].next[eee]);
                   getblocking_set(t,s,0,&(*t)[iii].next[eee],bs);

                   if ((bs[1] == -1) && (bs[0] == ii)) {
                      isUnary = true;
                   } else {
                      isUnary = false;
                   }

                   if ( (! isAgent) || isUnary ) {
                      dedicatedFlag = true;
                   } else {
                      dedicatedFlag = false;
                   }
                   s_index--;
                } while ((s_index > 0) && (dedicatedFlag == true));

                /* Include the state if it is a dedicated s.p.s */
                if (dedicatedFlag) {
                    dedicated_set[nDedicatedSet] = ii;
                    nDedicatedSet++;
                    ra[ii] = true;
                }

                pstack_Pop(&ts, &j, &jj, &ok);
                j++;
            } else {
                pstack_Push(&ts, j, jj);
                ra[ii] = true;
                j = 0;
                jj = ii;
            }
         } else {
            j++;
         }
      } else {
         if (!pstack_IsEmpty(&ts)) {
            pstack_Pop(&ts, &j, &jj, &ok);
            j++;
         }
      }
   } while ( (j < (*t)[jj].numelts) || !pstack_IsEmpty(&ts) );

   pstack_Done(&ts);

   /* Free local memory */
   free(bs);
   free(ra);

   dedicated_set[nDedicatedSet] = -1;
}

void hcc(state_node **t1, INT_S *s1)
{
   INT_S *dedicated_set;
   INT_S *blocking_set;
   INT_V temp_vocal;
   INT_S i, size;
   INT_B flag, ok;
   INT_T j;
   INT_T *unused, s_unused;

   overflow_error = false;
   size = *s1;

   /* Allocate memory for 'dedicated_set' and 'blocking_set' */
   dedicated_set = (INT_S*) calloc(*s1+1, sizeof(INT_S));
   blocking_set  = (INT_S*) calloc(*s1+1, sizeof(INT_S));

   if ( (dedicated_set == NULL) || (blocking_set == NULL) ) {
      mem_result = 1;
      return;
   }

   /* Get the maximum vocal state 
   max_vocal = 0;
   for (i=0; i < *s1; i++) {
      if ( (*t1)[i].vocal > 0) {
         if ( (*t1)[i].vocal <= 99) {
            max_vocal = max(max_vocal, (*t1)[i].vocal);
         } else {
            temp_vocal = (*t1)[i].vocal / 10;
            max_vocal = max(max_vocal, temp_vocal);
         }
      }
   } */

   /* Make a list of used vocal outputs */
   s_unused=0; unused=NULL;
   max_vocal=10;
   for (i=0; i < *s1; i++) {
      if (( (*t1)[i].vocal > 0) && ( (*t1)[i].vocal <= 99 )) {
         addordlist((*t1)[i].vocal, &unused, s_unused, &ok);
	 if (ok) s_unused++;
      } else {
         temp_vocal = (*t1)[i].vocal / 10;
         addordlist(temp_vocal, &unused, s_unused, &ok);
         if (ok) s_unused++;
      }
   }

   do {
      flag = true;
      for (i=0; i < size; i++) {
         for (j=0; j < (*t1)[i].numelts; j++) {
            if (agent(t1, s1, i, &(*t1)[i].next[j])) {
                getdedicated_set(t1, s1, i, dedicated_set);
                getblocking_set(t1, s1, i, &(*t1)[i].next[j], blocking_set);
                if (! subset(blocking_set, dedicated_set)) {
                   flag = false;  /* agent is inadmissible */
                   vocalize(t1, (*t1)[i].next[j].data2, &unused, &s_unused);
		}
		if (overflow_error) {
		   free(dedicated_set);
		   free(blocking_set);
		   return;
                }
            }
         }
      }
   } while (flag == false);   /* All agents are admissible */

   free(dedicated_set);
   free(blocking_set);
}

INT_B hiconsis_des(state_node** t1, INT_S* s1, INT_T **t2, INT_S *s2)
{
   outcon_des(t1, s1, t2, s2);
   hcc(t1,s1);
   if (overflow_error == false) 
      outcon_des(t1, s1, t2, s2);
   return overflow_error;
}
