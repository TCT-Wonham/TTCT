#ifndef _MINM_H
#define _MINM_H

#include "des_data.h"

extern void minimize2(INT_S*, state_node**);

#endif
