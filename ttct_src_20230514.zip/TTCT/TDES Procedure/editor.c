/* TTCT Editor */

#include "ttct_io.h"
#include "editor.h"
#include "tct_curs.h"
#include "des_data.h"
#include "des_proc.h"
#include "tct_proc.h"
#include "display.h"
#include "setup.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static state_node *t1;
static INT_T *t2;
static INT_S s1, s2;
static INT_B quit;

/* Need to keep track of the following information for MAKEIT.TXT file:

   new name
   new states added
   old states deleted
   new marker states added
   old marker states deleted
   new vocal states added
   old vocal states deleted
   new transitions added
   old transitions deleted
   reachability operation performed.
 */

static INT_S *old_state_list; static INT_S s_old_state_list;
static INT_S *new_mark_list; static INT_S s_new_mark_list;
static INT_S *old_mark_list; static INT_S s_old_mark_list;
static INT_T *new_forcible_list; static INT_T s_new_forcible_list;
static INT_T *old_forcible_list; static INT_T s_old_forcible_list;
static INT_T *ch_timebounds; static INT_T s_ch_timebounds;
static state_pair *vocal_list; static INT_S s_vocal_list;
static state_pair *map_list; static INT_S s_map_list;
static triple *new_tran_list; static INT_S s_new_tran_list;
static triple *old_tran_list; static INT_S s_old_tran_list;
static INT_B reach_operation;

static filename name1, name2;
static filename fname1, fname2;

void add_des(state_node **t1,
             INT_S *s1,
             INT_S new_size)         /* New size */
{
   INT_S j;

   new_size++;
   if (new_size > *s1) {
      *t1 = (state_node*) realloc(*t1, sizeof(state_node)*(new_size));

      if (*t1 == NULL) {
         mem_result = 1;
         printf("Out of memory\n");
         exit(1);
      }

      /* Remember to initial the states */
      for (j=*s1; j < new_size; j++) {
         (*t1)[j].marked       = false;
         (*t1)[j].reached      = false;
         (*t1)[j].coreach      = false;
	 (*t1)[j].nstinfo      = NULL;
	 (*t1)[j].numtimer     = 0;
	 (*t1)[j].ntimer       = NULL;
         (*t1)[j].vocal        = 0;
         (*t1)[j].numelts      = 0;
         (*t1)[j].next         = NULL;
      }

      *s1 = new_size;
   }
}

void edit_header()
{
   printw("EDIT"); println();
   println();
   printw("TDS2 = EDIT (TDS1)"); println();
   println();
}

void edit_aheader()
{
   printw("EDIT"); println();
   println();
   printw("ADS2 = EDIT (ADS1)"); println();
   println();
}

void printmark1(INT_S s,
                state_node *t,
                INT_B *empty)
{
   INT_S i;
   int col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
     if (t[i].marked) {
        col = _wherex();
        row = _wherey();
        if (_wherey() > 22) {
           move(23,0);
           printw("Press <Enter> to page marker state table  ");
           refresh();
           do {
             ch = read_key();
           } while (ch != CEnter);
           clear();
           esc_footer();
           move(1,5);
           row = 1;
        }
        printw("%d", i);
        *empty = false;
        if (col < 65) {
          move(row, col+7);
        } else {
          println();
          printw("     ");
        }
     }
   }
}

void printmark(INT_S s,
               state_node *t)
{
   INT_B empty;

   printw("     ");
   printmark1(s,t,&empty);
   if (empty)
      printw(" empty");
}

void printforc1(INT_S s,
                INT_T *t,
                INT_B *empty)
{
   INT_S i;
   int col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
      col = _wherex();
      row = _wherey();
      if (_wherey() > 22) {
	 move(23,0);
	 printw("Press <Enter> to page forcible events table  ");
	 refresh();
	 do {
	    ch = read_key();
	 } while (ch != CEnter);
	 clear();
	 esc_footer();
	 move(1,5);
	 row = 1;
      }
      printw("%d", t[i]);
      *empty = false;
      if (col < 65) {
	 move(row, col+7);
      } else {
	 println();
	 printw("     ");
      }
   }
}

void printaforc1(INT_S s,
                timed_event *t,
                INT_B *empty)
{
   INT_S i;
   int col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
      if (t[i].forcible) {
	 col = _wherex();
	 row = _wherey();
	 if (_wherey() > 22) {
	    move(23,0);
	    printw("Press <Enter> to page forcible events table  ");
	    refresh();
	    do {
	       ch = read_key();
	    } while (ch != CEnter);
	    clear();
	    esc_footer();
	    move(1,5);
	    row = 1;
	 }
	 printw("%d", t[i].label);
	 *empty = false;
	 if (col < 65) {
	    move(row, col+7);
	 } else {
	    println();
	    printw("     ");
	 }
      }
   }
}

void printforc(INT_S s,
               INT_T *t)
{
   INT_B empty;

   printw("     ");
   printforc1(s,t,&empty);
   if (empty)
      printw(" empty");
}

void printaforc(INT_S s,
               timed_event *t)
{
   INT_B empty;

   printw("     ");
   printaforc1(s,t,&empty);
   if (empty)
      printw(" empty");
}

void printvocal1(INT_S s,
                 state_node *t,
                 INT_B *empty)
{
   INT_S i;
   int col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
     if ( t[i].vocal > 0) {
        col = _wherex();
        row = _wherey();
        if (_wherey() > 21) {
           move(23,0);
           printw("  Press <Enter> to page state output table  ");
           refresh();
           do {
              ch = read_key();
           } while (ch != CEnter);
           clear();
           move(1,3);
           row = 1;
        }
        printw("[%5d,%3d] ", i, t[i].vocal);
        *empty = false;
        if (col < 62) {
           move(row, col+15);
        } else {
           println();
           printw("   ");
        }
      }
   }
}

void printtimebounds1(INT_T s,
		      timed_event *t,
		      INT_B *empty)
{
   INT_S i;
   int col, row;
   char ch;

   *empty = true;
   for (i=0; i < s; i++) {
      col = _wherex();
      row = _wherey();
      if (_wherey() > 21) {
	 move(23,0);
	 printw("  Press <Enter> to page state output table  ");
	 refresh();
	 do {
	    ch = read_key();
	 } while (ch != CEnter);
	 clear();
	 move(1,3);
	 row = 1;
      }
      if (t[i].upper == MAX_TIME) {
	 printw(" %3d [%4d, Inf] ",t[i].label, t[i].low);
      } else {
	 printw(" %3d [%4d,%4d] ",t[i].label, t[i].low, 
		t[i].upper);
      }
      *empty = false;
      if (col < 62) {
	 move(row, col+25);
      } else {
	 println();
	 printw("   ");
      }
   }
}

void printvocal(INT_S s,
                state_node *t)
{
   INT_B empty;

   printw("   ");
   printvocal1(s,t,&empty);
   if (empty)
      printw(" none");
}

void printtimebounds(INT_T s,
		     timed_event *t)
{
   INT_B empty;

   printw("   ");
   printtimebounds1(s,t,&empty);
   if (empty)
      printw(" none");
}

void vocalmap_des(state_node *t1, INT_S s1,
                  state_pair *mlist, INT_S s_mlist)
{
    INT_S i, j;
    INT_V v;

    for (i=0; i < s1; i++) {
      v = t1[i].vocal;

      /* Do a linear search - assume the list is short */
      for (j = 0; j < s_mlist; j++)
      {
         if ( ((INT_V) mlist[j].data1) == v )
         {
            t1[i].vocal = (INT_V) mlist[j].data2;
            break;
         }
      }
    }
}

void edit_r()
{
   INT_S init, i, k, oldsize;
   int col, row, a;
   char ch;
   INT_B ok;
   INT_S nTransitions;
   short sign_j;
   INT_T j;
   INT_V v;
   INT_B allstate;
   INT_T s_list, *list;
   int d;

   clear();
   edit_header();

   quit = getname("Enter TDS1 to be edited ....  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, &s1, &init, &t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   if (init == -1) {
      printw("%s IS A CONTROL DATA FILE, AND CANNOT BE EDITED!", name1); println();
      user_pause();
      quit = true;
      return;
   }

   init = 0;   /* Assume the initial state is zero */
   oldsize = s1;

   strcpy(name2, name1);
/*   printw("Name of TDS2 is currently %s.  OK? (*y/n)  ", name2);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( ( ch == 'N') || (ch == 'n') ) {
      addch(ch);  println();
      println();
      quit = getname("Enter new name of TDS2 ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   } else {
      println();
   }
*/

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( ( ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();
   } else {
      if (ch != CEnter)
         addch(ch); 
      println();
      println();
      quit = getname("Enter new name of TDS2 ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   }

   println();
   printw("# states assigned to %s is %d.", name2, s1); println();
   println();

   /* If empty, we ask for an initial state but
      it might be better to assume state zero is for now */
/*   if (s1 == 0) {
      printw("Please enter the new initial state ....  ");
      init = readint(&ch, 0, MAX_STATES);
      if (ch == CEsc) {
         quit = true;
         return;
      }
      println();
      println();
      printw("Is the new initial state a marker state?  (y/n)  ");
      refresh();
      ch = read_key();
      if (ch == CEsc) {
         quit = true;
         return;
      }

      if ( (ch == 'Y') || (ch == 'y') ) {
         addch(ch); println();

         /- Should do something here -/
      }
      println();
   }
*/
   /* PROCEDURE TO MODIFY MARKED STATES */
   if (_wherey() > 17)
      clear();

   printw("List of marker states of %s is currently: ", name2); println();
   println();
   printmark(s1,t1);
   println();
   println();
   printw("OK?  (*y/n)  ");
   esc_footer();

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch); println();
      println();
      if (_wherey() > 16) {
         clear();
         esc_footer();
      }
      printw("Enter states of %s to be newly marked.  New states not in", name2); println();
      printw("current structure may be listed if required (type -1 to quit)."); println();
      printw("To mark all states, enter '*':"); println();
      println(); printw("     ");
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
             clear();
             printw("     ");
             esc_footer();
         }

         col = _wherex();
         row = _wherey();
         if (col >= 75) {
            move(row+1,5);
            col = 5;
            row++;
         }

         i = (INT_S) readintall(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
             quit = true; return;
         }

         if (ch == '*') {
	    for (k=0; k < s1; k++) {
               t1[k].marked = true;
               addstatelist(k, &new_mark_list, s_new_mark_list, &ok);
               if (ok) s_new_mark_list++;
            }
         }
         else
         {
            if (i != -1) {
               add_des(&t1, &s1, i);
               t1[i].marked = true;
               addstatelist(i, &new_mark_list, s_new_mark_list, &ok);
               if (ok) s_new_mark_list++;
            }
         }
         move(row, col+8);
      } /* while */

      println(); println();
      if (_wherey() > 17)
         clear();
      printw("Enter old marker states to be unmarked (type -1 to quit)."); println();
      printw("To unmark all states, enter '*':"); println();
      println(); tab(5);
      col = _wherex();
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
            clear();
            tab(5);
         }

         i = (INT_S) readintall(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
             quit = true; return;
         }

         if (ch == '*') {
            for (k=0; k < s1; k++) {
                t1[k].marked = false;
                addstatelist(k, &old_mark_list, s_old_mark_list, &ok);
                if (ok) s_old_mark_list++;
            }
            i = -1; /* All states now unmarked. */
         }

         if (i != -1) {
            if (i >= s1) {
               println();
               ring_bell();
               if (_wherey() > 20) clear();
               printw("Marker state %d is illegal, please reenter!", i); println();
               println(); tab(5);
               col = -3;
            } else {
               t1[i].marked = false;
               addstatelist(i, &old_mark_list, s_old_mark_list, &ok);
               if (ok) s_old_mark_list++;
            }
         }
         row = _wherey();
         if (col < 65) {
            move(row, col+8);
         } else {
            println(); tab(5);
         }
         col = _wherex(); row = _wherey();
      } /* while */
      println();
      println();
   }

   /* PROCEDURE TO MODIFY TRANSITIONS */
   clear();
   esc_footer();
   println();

   nTransitions = count_tran(t1, s1, &d, &d, &d);
   printw("# transitions in %s is currently %d", name2, nTransitions); println();
   println();
   printw("Current transition list OK?  (*y/n)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if ( (ch == 'n') || (ch == 'N') ) {
/*     addch(ch); println();
      if (_wherey() > 17) clear();
      println();
      printw("Enter new transitions to adjoin."); println();
      printw("New source or target states may be introduced as needed;"); println();
      printw("type -1 to quit:"); println();
      i = 0;
      while (i != -1) {
         println();
         if (_wherey() > 19) clear();
         row = _wherey();
         printw(" Source state:  ");
         i = (INT_S) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (i == -1) break;

         move(row, 25);
         printw("Event label:  ");
         sign_j = (short) readint(&ch, -1, MAX_TRANSITIONS);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         move(row, 50);
         printw("Target state:  ");
         k = (short) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;

         add_des(&t1, &s1, i);
         add_des(&t1, &s1, k);
         addordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
         if (ok) t1[i].numelts++;

         // record new state added 
         addtriple(i,j,k,&new_tran_list, s_new_tran_list, &ok);
         if (ok) s_new_tran_list++;
      }
*/
//      scrollok(stdscr, 1);
      clear();
      esc_footer();
      println();
      printw("Enter new transitions to adjoin."); println();
      printw("To add multiple transitions, enter * for Source state."); println();
      printw("New source or target states may be introduced as needed;"); println();
      printw("type -1 to quit:"); println(); println();
      esc_footer();
      do {
         if (_wherey() > 21) {
            col = _wherex(); row = _wherey()-1;
            move(23,0); clrtoeol();
            move(24,0);
            //println();//Justin0622
			scroll_line();//Justin0622

            for (a=0; a < 6; a++) {
               move(a,0); clrtoeol();
            }

            move(0,0);
            println();
            printw("Enter new transitions to adjoin."); println();
            printw("To add multiple transitions, enter * for Source state."); println();
            printw("New source or target states may be introduced as needed;"); println();
            printw("type -1 to quit:"); println(); println();
            esc_footer();
            move(row,col);
         }

         allstate = false;
         printw(" Source state:  ");
         i = (INT_S) readintall(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (ch == '*') allstate = true;
         if (i == -1) break;

         tab(25);
         printw("Event label:  ");
         sign_j = (short) readint(&ch, -1, MAX_TRANSITIONS);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         tab(50);
         printw("Target state:  ");
         k = (short) readint(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;
         println();

         add_des(&t1, &s1, i);
         add_des(&t1, &s1, k);

         if (allstate) {
            INT_S ii;

            for (ii=0; ii < oldsize; ii++)
            {
               addordlist1(j,k,&(t1[ii].next), t1[ii].numelts, &ok);
               if (ok) t1[ii].numelts++;

               /* record new state added for MAKEIT.TXT */
               addtriple(ii,j,k,&new_tran_list, s_new_tran_list, &ok);
               if (ok) s_new_tran_list++;
            }
         } else {
            addordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
            if (ok) t1[i].numelts++;

            /* record new state added for MAKEIT.TXT */
            addtriple(i,j,k,&new_tran_list, s_new_tran_list, &ok);
            if (ok) s_new_tran_list++;
         }
      } while (i != -1);

      /* Delete transitions */ 
      clear();
/*      println(); println();
      if (_wherey() > 19) clear();
*/
      printw("Enter old transitions to delete."); println();
      printw("To delete multiple transitions, enter * for Source state (type -1 to quit):");
      println(); println();
      esc_footer();
      i = 0;
      while (i != -1) {
         println();
         if (_wherey() > 21) {
            row = _wherey()-1; col = _wherex();
            move(23,0); clrtoeol();
            move(24,0);
            //println();//Justin0622
			scroll_line();//Justin0622

            for (a=0; a < 4; a++) {
               move(a,0);  clrtoeol();
            }

            move(0,0);
            println();
            printw("Enter old transitions to delete."); println();
            printw("To delete multiple transitions, enter * for Source state (type -1 to quit):");
            println(); println();
            esc_footer();
            move(row,col);
         }

         allstate = false;
         printw(" Source state:  ");
         i = (INT_S) readintall(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (ch == '*') allstate = true;
         if (i == -1) break;

         tab(25);
         printw("Event label:  ");
         sign_j = (short) readint(&ch, -1, MAX_TRANSITIONS);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         tab(50);
         printw("Target state:  ");
         k = (short) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;

         if (i >= s1) {
            println();
            ring_bell();
            printw("Source state %d is illegal, please reenter!", i); println();
            println();
            if (_wherey() > 19) {
               println(); 
               println();
               move(22,0);
            }
            continue;
         }

         if (k >= s1) {
            println();
            ring_bell();
            printw("Source state %d is illegal, please reenter!", k); println();
            println();
            if (_wherey() > 19) {
               println();
               println();
               move(22,0);
            } 
            continue;
         }

         if (allstate) {
            INT_S ii;

            for (ii=0; ii < s1; ii++) {
               delete_ordlist1(j, k, &(t1[ii].next), t1[ii].numelts, &ok);
               if (ok) t1[ii].numelts--;

               /* record old triple deleted into MAKEIT.TXT */
               addtriple(ii,j,k,&old_tran_list, s_old_tran_list, &ok);
               if (ok) s_old_tran_list++;
            }
         } else {
            delete_ordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
            if (ok) t1[i].numelts--;

            /* record new state added */
            addtriple(i,j,k,&old_tran_list, s_old_tran_list, &ok);
            if (ok) s_old_tran_list++;
	}
      }
   }
   
   /* PROCEDURE TO MODIFY FORCIBLE EVENTS */
   clear();
   esc_footer();
   gentranlist(s1, t1, &s_list, &list);
   remove_forcible(&s2, &t2, s_list, list);

   println();
   printw("List of forcible events of %s is currently: ", name2); println();
   println();
   printforc(s2,t2);
   println();
   println();
   printw("OK?  (*y/n)  ");
   esc_footer();

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {

      addch(ch); println();
      println();
      if (_wherey() > 17) {
         clear();
         esc_footer();
      }
      printw("Enter new forcible events of %s (type -1 to quit):", name2); println();
      println(); printw("     ");
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
             clear();
             printw("     ");
             esc_footer();
         }

         col = _wherex();
         row = _wherey();
         if (col >= 75) {
            move(row+1,5);
            col = 5;
            row++;
         }

         i = readcheckint(&ch, -1, MAX_STATES, s_list, list);

         if (ch == CEsc) {
             quit = true; return;
         }
         if (i != -1) {
	    new_forcible_list = (INT_T*) realloc(new_forcible_list, 
				 ++s_new_forcible_list * sizeof(INT_T));
	    new_forcible_list[s_new_forcible_list-1] = (INT_T)i;
         }
         move(row, col+8);
      } /* while */

      println(); println();
      if (_wherey() > 17)
         clear();
      printw("Enter old forcible events to delete (type -1 to quit):"); println();
      println(); tab(5);
      col = _wherex();
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
            clear();
            tab(5);
         }

         i =  readcheckint(&ch, -1, MAX_STATES, s2, t2);
         if (ch == CEsc) {
             quit = true; return;
         }
         if (i != -1) {
	    old_forcible_list = (INT_T*) realloc(old_forcible_list, 
				 ++s_old_forcible_list * sizeof(INT_T));
	    old_forcible_list[s_old_forcible_list-1] = (INT_T)i;
         }
         row = _wherey();
         if (col < 65) {
            move(row, col+8);
         } else {
            println(); tab(5);
         }
         col = _wherex(); row = _wherey();
      } /* while */
      merge_forcible(s_new_forcible_list, new_forcible_list, &s2, &t2);
      remove_alt_forcible(s_old_forcible_list, old_forcible_list, &s2, &t2);
      println();
      println();
   }

   if (!chk_for_tick(&s1, &t1)) {
      /* PROCEDURE FOR EDITING VOCAL STATES IN DES */
      clear();
      esc_footer();
      println();
      printw("List of vocal states of %s is currently:", name2); println();
      println();
      printvocal(s1, t1);
      println();
      println();
      printw("OK?  (*y/n)  ");
      
      refresh();
      ch = read_key();
      if (ch == CEsc) {
	 quit = true;
	 return;
      }
      
      if ( (ch == 'N') || (ch == 'n') ) {
         addch(ch); println();
         println();

         /* Uniform vocal output relabelling. */
         println();
         printw("Make uniform alteration in a vocal state output?  (y/*n)  ");

         refresh();
         ch = read_key();
         if (ch == CEsc) {
           quit = true;
           return;
         }

         addch(ch); println();
         println();

         if ( (ch == 'Y') || (ch == 'y') ) {

            printw("Enter list of vocal state output pairs."); println();
            printw("To make all states with Old output silent, enter 0 for New output."); println();
            printw("Type -1 to quit:"); println();
            println();
            i = 0;
            while (i != -1) {
               if (_wherey() > 19) clear();
               println();
               printw("Old output:  ");
               row = _wherey();
               i = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
               if (ch == CEsc) {
                  quit = true;
                  return;
               }
               if (i == -1) break;

               move(row, 40);
               printw("New output:  ");
               v = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
               if (ch == CEsc) {
                  quit = true;
                  return;
               }
               if (v == -1) break;

               if ( ( (i < 0) || ((i >= 1) && (i <= 9)) || (i > MAX_VOCAL_OUTPUT) ) ||
                    ( (v < 0) || ((v >= 1) && (v <= 9)) || (v > MAX_VOCAL_OUTPUT) ) ) {
                  println();
                  if (_wherey() > 17) clear();
                  printw("This vocalization is illegal; please reenter"); println();
               } else {
                  addstatepair((INT_S) i, (INT_S) v, &map_list, s_map_list, &ok);
                  if (ok) s_map_list++;
              }
            } /* while */

            vocalmap_des(t1,s1,map_list,s_map_list);

            clear();
         }

	 printw("For each state output to be altered, enter state and new output."); println();
	 printw("To make State silent, enter Output 0."); println();
	 printw("Type -1 to quit:"); println();
	 println();
	 i = 0;
	 while (i != -1) {
	    if (_wherey() > 19)
	       clear();
	    println();
	    printw(" State:  ");
	    row = _wherey();
	    i = (INT_S) readint(&ch, -1, MAX_STATES);
	    if (ch == CEsc) {
	       quit = true;
	       return;
	    }
	    if (i == -1) break;
	    
	    move(row, 30);
	    printw("Vocal Output:  ");
	    v = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
	    if (ch == CEsc) {
	       quit = true;
	       return;
	    }
	    if (v == -1) break;
	    
	    if ( (v < 0) || ((v >= 1) && (v <= 9)) || (v > MAX_VOCAL_OUTPUT) ) {
	       println();
	       if (_wherey() > 17) clear();
	       printw("This vocalization is illegal; please reenter"); println();
	    } else {
	       add_des(&t1, &s1, i);
	       t1[i].vocal = v;
	       addstatepair(i, (INT_S) v, &vocal_list, s_vocal_list, &ok);
	       if (ok) s_vocal_list++;
	    }
	 }
      }
   }

   /* PROCEDURE TO DELETE STATES */
   clear();
   esc_footer();
   println();
   printw("Delete any states from %s?  (y/*n)  ", name2);

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      addch(ch); println();
      println();
      printw("Enter states of %s to delete", name2); println();
      printw("To quit, enter -1"); println();
      println(); tab(5);
      i = 0;
      while (i != -1) {
         col = _wherex(); row = _wherey();
         if ( (row < 20) && (col >= 75) ) {
            move(row+1, 5);
            col = 5;
            row = row+1;
         }

         if (_wherey() > 19) {
            clear();
            move(1,0);
            printw("Continue to enter states of %s to delete (type -1 to quit):", name2); println();
            move(3,4);
            col = 4;
            row = 3;
         }

         i = (INT_S) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (i == -1) break;

         if ( (i >= 0) && (i < s1) ) {
            addstatelist(i, &old_state_list, s_old_state_list, &ok);
            if (ok) s_old_state_list++;
            move(row, col+7);
         }

         if (i == 0) {
            println();
            printw("Former initial state 0 will be deleted."); println();
            println();
            printw("Please enter the new initial state ....  ");
            init = (INT_S) readint(&ch, -1, MAX_STATES);
            if (ch == CEsc) {
               quit = true; return;
            }
         }

         if (i >= s1) {
            println(); println();
            if (_wherey() > 17) clear();
            printw("State %d is not in %s!", i, name2); println();
            println(); tab(5);
         }
      }
   } else {
      println();
   }

   /* Remove all reference to the deleted states.
      Make the states values to initial created states.
      No states are deleted but these state will be isolated.
      It is up to the user to purge the isolated states by
      doing a reach.

      Remember to fix initial state to zero.
   */

   /* Mark states to remove reference to as unreached */
   for (i=0; i < s1; i++)
      t1[i].reached = true;
   for (i=0; i < s_old_state_list; i++)
      t1[ old_state_list[i] ].reached = false;
   purgebadstates(s1, &t1);
   trim_endstates(&s1, &t1);

   gentranlist(s1, t1, &s_list, &list);
   remove_forcible(&s2, &t2, s_list, list);

   /* CHECK FOR DETERMINISTISM */
   check_determinism(t1,s1,name2,&quit,true);
   if (quit == true) return;

   clear();
   esc_footer();
   if (init != 0) {
       /* Just warn user that the initial state has been recoded to zero */
      move(1,0);
      printw("%s will be recoded with initial state relabelled to 0.", name2);
      move(3,0);
   } else {
      move(1,0);
   }
   printw("Do you want the edited TDS reachable?  (y/*n)  ");
   init = 0;
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      /* Clear "reach" before a call to reach procedure */
      for (i=0; i < s1; i++)
         t1[i].reached = false;
      reach_operation = true;
      reach(&s1, &t1, &s2, &t2);
   }

   if (ch == CEnter) {
      println();
   } else {
      addch(ch);
   }
   println(); println();
   refresh();
   
   /* if states were added delete state info*/
   if (s1 > oldsize) {
      free(t1[0].nstinfo);
      t1[0].nstinfo = NULL;
      t1[0].numtimer = 0;
      free(t1[0].ntimer);
      t1[0].ntimer = NULL;
   }

   if (mem_result != 1)
      filetds(name2, s1, init, t1, s2, t2);
}

void edit_ar(INT_T *s2, timed_event **t2)
{
   INT_S init, i, k, l, u, oldsize;
   int col, row, a;
   char ch;
   INT_B ok;
   INT_S nTransitions;
   short sign_j;
   INT_T j, index;
   INT_T s_list, *list;
   int d;
   INT_B allstate;

   clear();
   edit_aheader();

   quit = getname("Enter ADS1 to be edited ....  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   if (getads(name1, &s1, &init, &t1, s2, t2) == false) {
      quit = true;
      return;
   }

   if (init == -1) {
      printw("%s IS A CONTROL DATA FILE, AND CANNOT BE EDITED!", name1); println();
      user_pause();
      quit = true;
      return;
   }

   init = 0;   /* Assume the initial state is zero */
   oldsize = s1;

   strcpy(name2, name1);
/*   printw("Name of ADS2 is currently %s.  OK? (*y/n)  ", name2);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( ( ch == 'N') || (ch == 'n') ) {
      addch(ch);  println();
      println();
      quit = getname("Enter new name of ADS2 ....  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   } else {
      println();
   }
*/

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( ( ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();
   } else {
      if (ch != CEnter)
         addch(ch); 
      println();
      println();
      quit = getname("Enter new name of ADS2 ....  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   }

   println();
   printw("# states assigned to %s is %d.", name2, s1); println();
   println();

   /* If empty, we ask for an initial state but
      it might be better to assume state zero is for now */
/*   if (s1 == 0) {
      printw("Please enter the new initial state ....  ");
      init = readint(&ch, 0, MAX_STATES);
      if (ch == CEsc) {
         quit = true;
         return;
      }
      println();
      println();
      printw("Is the new initial state a marker state?  (y/n)  ");
      refresh();
      ch = read_key();
      if (ch == CEsc) {
         quit = true;
         return;
      }

      if ( (ch == 'Y') || (ch == 'y') ) {
         addch(ch); println();

         /- Should do something here -/
      }
      println();
   }
*/
   /* PROCEDURE TO MODIFY MARKED STATES */
   if (_wherey() > 17)
      clear();

   printw("List of marker states of %s is currently: ", name2); println();
   println();
   printmark(s1,t1);
   println();
   println();
   printw("OK?  (*y/n)  ");
   esc_footer();

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch); println();
      println();
      if (_wherey() > 16) {
         clear();
         esc_footer();
      }
      printw("Enter states of %s to be newly marked.  New states not in", name2); println();
      printw("current structure may be listed if required (type -1 to quit)."); println();
      printw("To mark all states, enter '*':"); println();
      println(); printw("     ");
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
             clear();
             printw("     ");
             esc_footer();
         }

         col = _wherex();
         row = _wherey();
         if (col >= 75) {
            move(row+1,5);
            col = 5;
            row++;
         }

         i = (INT_S) readintall(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
             quit = true; return;
         }


         if (ch == '*') {
	    for (k=0; k < s1; k++) {
               t1[k].marked = true;
               addstatelist(k, &new_mark_list, s_new_mark_list, &ok);
               if (ok) s_new_mark_list++;
            }
         }
         else
         {
            if (i != -1) {
               add_des(&t1, &s1, i);
               t1[i].marked = true;
               addstatelist(i, &new_mark_list, s_new_mark_list, &ok);
               if (ok) s_new_mark_list++;
            }
         }
         move(row, col+8);
      } /* while */

      println(); println();
      if (_wherey() > 17)
         clear();
      printw("Enter old marker states to be unmarked (type -1 to quit)."); println();
      printw("To unmark all states, enter '*':"); println();
      println(); tab(5);
      col = _wherex();
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
            clear();
            tab(5);
         }

         i = (INT_S) readintall(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
             quit = true; return;
         }

         if (ch == '*') {
            for (k=0; k < s1; k++) {
                t1[k].marked = false;
                addstatelist(k, &old_mark_list, s_old_mark_list, &ok);
                if (ok) s_old_mark_list++;
            }
            i = -1; /* All states now unmarked. */
         }

         if (i != -1) {
            if (i >= s1) {
               println();
               ring_bell();
               if (_wherey() > 20) clear();
               printw("Marker state %d is illegal, please reenter!", i); println();
               println(); tab(5);
               col = -3;
            } else {
               t1[i].marked = false;
               addstatelist(i, &old_mark_list, s_old_mark_list, &ok);
               if (ok) s_old_mark_list++;
            }
         }
         row = _wherey();
         if (col < 65) {
            move(row, col+8);
         } else {
            println(); tab(5);
         }
         col = _wherex(); row = _wherey();
      } /* while */
      println();
      println();
   }

   /* PROCEDURE TO MODIFY TRANSITIONS */
   clear();
   esc_footer();
   println();

   nTransitions = count_tran(t1, s1, &d, &d, &d);
   printw("# transitions in %s is currently %d", name2, nTransitions); println();
   println();
   printw("Current transition list OK?  (*y/n)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   if ( (ch == 'n') || (ch == 'N') ) {
/*      addch(ch); println();
      if (_wherey() > 17) clear();
      println();
      printw("Enter new transitions to adjoin."); println();
      printw("New source or target states may be introduced as needed;"); println();
      printw("type -1 to quit:"); println();
      i = 0;
      while (i != -1) {
         println();
         if (_wherey() > 19) clear();
         row = _wherey();
         printw(" Source state:  ");
         i = (INT_S) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (i == -1) break;

         move(row, 25);
         printw("Event label:  ");
         sign_j = (short) readtickint(&ch, -1, MAX_TRANSITIONS);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         move(row, 50);
         printw("Target state:  ");
         k = (short) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;

         add_des(&t1, &s1, i);
         add_des(&t1, &s1, k);
         addordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
         if (ok) t1[i].numelts++;

         // record new state added 
         addtriple(i,j,k,&new_tran_list, s_new_tran_list, &ok);
         if (ok) s_new_tran_list++;
      }
*/

      clear();
      esc_footer();
      println();
      printw("Enter new transitions to adjoin."); println();
      printw("To add multiple transitions, enter * for Source state."); println();
      printw("New source or target states may be introduced as needed;"); println();
      printw("type -1 to quit:"); println(); println();
      esc_footer();
      do {
         if (_wherey() > 21) {
            col = _wherex(); row = _wherey()-1;
            move(23,0); clrtoeol();
            move(24,0);
            println();

            for (a=0; a < 6; a++) {
               move(a,0); clrtoeol();
            }

            move(0,0);
            println();
            printw("Enter new transitions to adjoin."); println();
            printw("To add multiple transitions, enter * for Source state."); println();
            printw("New source or target states may be introduced as needed;"); println();
            printw("type -1 to quit:"); println(); println();
            esc_footer();
            move(row,col);
         }

         allstate = false;
         printw(" Source state:  ");
         i = (INT_S) readintall(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (ch == '*') allstate = true;
         if (i == -1) break;

         tab(25);
         printw("Event label:  ");
         sign_j = (short) readint(&ch, -1, MAX_TRANSITIONS);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         tab(50);
         printw("Target state:  ");
         k = (short) readint(&ch, -1, MAX_STATES-1);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;
         println();

         add_des(&t1, &s1, i);
         add_des(&t1, &s1, k);

         if (allstate) {
            INT_S ii;

            for (ii=0; ii < oldsize; ii++)
            {
               addordlist1(j,k,&(t1[ii].next), t1[ii].numelts, &ok);
               if (ok) t1[ii].numelts++;

               /* record new state added for MAKEIT.TXT */
               addtriple(ii,j,k,&new_tran_list, s_new_tran_list, &ok);
               if (ok) s_new_tran_list++;
            }
         } else {
            addordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
            if (ok) t1[i].numelts++;

            /* record new state added for MAKEIT.TXT */
            addtriple(i,j,k,&new_tran_list, s_new_tran_list, &ok);
            if (ok) s_new_tran_list++;
         }
      } while (i != -1);

     /* Delete transitions */      
      clear();
/*    println(); println();
      if (_wherey() > 19) clear();
*/

      printw("Enter old transitions to delete.");
      printw("To delete multiple transitions, enter * for Source state (type -1 to quit):");
      esc_footer();
      i = 0;
      while (i != -1) {
         println();
         if (_wherey() > 21) {
            row = _wherey()-1; col = _wherex();
            move(23,0); clrtoeol();
            move(24,0);
            println();

            for (a=0; a < 4; a++) {
               move(a,0);  clrtoeol();
            }

            move(0,0);
            println();
            printw("Enter old transitions to delete."); println();
            printw("To delete multiple transitions, enter * for Source state (type -1 to quit):");
            println(); println();
            esc_footer();
            move(row,col);
         }

         allstate = false;
         printw(" Source state:  ");
         i = (INT_S) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (ch == '*') allstate = true;
         if (i == -1) break;

         tab(25);
         printw("Event label:  ");
         sign_j = (short) readint(&ch, -1, MAX_TRANSITIONS);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (sign_j == -1) break;
         j = (INT_T) sign_j;

         tab(50);
         printw("Target state:  ");
         k = (short) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (k == -1) break;

         if (i >= s1) {
            println();
            ring_bell();
            printw("Source state %d is illegal, please reenter!", i); println();
            println();
            if (_wherey() > 19) {
               println(); 
               println();
               move(22,0);
            }
            continue;
         }

         if (k >= s1) {
            println();
            ring_bell();
            printw("Source state %d is illegal, please reenter!", k); println();
            println();
            if (_wherey() > 19) {
               println();
               println();
               move(22,0);
            } 
            continue;
         }

         if (allstate) {
            INT_S ii;

            for (ii=0; ii < s1; ii++) {
               delete_ordlist1(j, k, &(t1[ii].next), t1[ii].numelts, &ok);
               if (ok) t1[ii].numelts--;

               /* record old triple deleted into MAKEIT.TXT */
               addtriple(ii,j,k,&old_tran_list, s_old_tran_list, &ok);
               if (ok) s_old_tran_list++;
            }
         } else {
            delete_ordlist1(j, k, &(t1[i].next), t1[i].numelts, &ok);
            if (ok) t1[i].numelts--;

            /* record new state added */
            addtriple(i,j,k,&old_tran_list, s_old_tran_list, &ok);
            if (ok) s_old_tran_list++;
         }
      }
      gentranlist(s1, t1, &s_list, &list);
      merge_adeftime(s_list, list, s2, t2);
   }

   /* PROCEDURE TO MODIFY FORCIBLE EVENTS */
   clear();
   esc_footer();
   gentranlist(s1, t1, &s_list, &list);
   remove_aforcible(s2, t2, s_list, list);

   println();
   printw("List of forcible events of %s is currently: ", name2); println();
   println();
   printaforc(*s2,*t2);
   println();
   println();
   printw("OK?  (*y/n)  ");
   esc_footer();

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {

      addch(ch); println();
      println();
      if (_wherey() > 17) {
         clear();
         esc_footer();
      }
      printw("Enter new forcible events of %s (type -1 to quit):", name2); println();
      println(); printw("     ");
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
             clear();
             printw("     ");
             esc_footer();
         }

         col = _wherex();
         row = _wherey();
         if (col >= 75) {
            move(row+1,5);
            col = 5;
            row++;
         }

         i = readcheckint(&ch, -1, MAX_STATES, s_list, list);

         if (ch == CEsc) {
             quit = true; return;
         }
         if (i != -1) {
	    new_forcible_list = (INT_T*) realloc(new_forcible_list, 
				 ++s_new_forcible_list * sizeof(INT_T));
	    new_forcible_list[s_new_forcible_list-1] = (INT_T)i;
         }
         move(row, col+8);
      } /* while */

      println(); println();
      if (_wherey() > 17)
         clear();
      printw("Enter old forcible events to delete (type -1 to quit):"); println();
      println(); tab(5);
      col = _wherex();
      i = 0;
      while (i != -1) {
         if (_wherey() > 20) {
            clear();
            tab(5);
         }

         i =  readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
             quit = true; return;
         }
         if (i != -1) {
	    old_forcible_list = (INT_T*) realloc(old_forcible_list, 
				 ++s_old_forcible_list * sizeof(INT_T));
	    old_forcible_list[s_old_forcible_list-1] = (INT_T)i;
         }
         row = _wherey();
         if (col < 65) {
            move(row, col+8);
         } else {
            println(); tab(5);
         }
         col = _wherex(); row = _wherey();
      } /* while */
      set_aforcible(s_new_forcible_list, new_forcible_list, s2, t2, true);
      set_aforcible(s_old_forcible_list, old_forcible_list, s2, t2, false);
      println();
      println();
   }

   /* PROCEDURE FOR EDITING TIMEBOUNDS IN ADS */
   clear();
   esc_footer();
   println();
   printw("List of time bounds of events of %s is currently:", name2); println();
   println();
   printtimebounds(*s2, *t2);
   println();
   println();
   printw("OK?  (*y/n)  ");
     
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch); println();
      println();
      printw("For events time bounds to be altered, enter event and new time bounds."); println();
      printw("   Lower Time Bound      : RETURN signifies 0"); println();
      printw("   Upper Time Bound      : RETURN signifies Infinity"); println();
      printw("Type -1 to quit:"); println();
      println();
      i = 0;
      while (i != -1) {
         if (_wherey() > 19)
            clear();
         println();
         printw(" Event:  ");
         row = _wherey();
         i = readcheckint(&ch, -1, MAX_TRANSITIONS, s_list, list);
         if (ch == CEsc) {
            quit = true;
            return;
         }
         if (i == -1) break;

         move(row, 25);
         printw("Low:  ");
         l =  readdefint(&ch, 0, MAX_TIME);
         if (ch == CEsc) {
            quit = true;
            return;
	 } else if (ch == CEnter) {
	    l = 0;
	    printw("%d",l);
         }
	 /*         if (l == -1) break;*/

         move(row, 50);
         printw("Upper:  ");
	 if (i % 2 == 0) {
	    u =  readdefint(&ch, l, MAX_TIME);
	    if (ch == CEsc) {
	       quit = true;
	       return;
	    } else if (ch == CEnter) {
	       u = MAX_TIME;
	       printw("%d",u);
	    }
	 } else {
	    printw("Inf");
	    u = MAX_TIME;
	 }
	 /*         if (u == -1) break;*/
	 
	 find_timebounds(*s2, *t2, (INT_T)i, &index);
	 (*t2)[index].low   = (INT_T)l;
	 (*t2)[index].upper = (INT_T)u;
	 ch_timebounds = (INT_T*) realloc(ch_timebounds, 
				 ++s_ch_timebounds * sizeof(INT_T));
	 ch_timebounds[s_ch_timebounds-1] = (INT_T)i;
      }
   }

   /* PROCEDURE FOR EDITING VOCAL STATES IN DES 
   clear();
   esc_footer();
   println();
   printw("List of vocal states of %s is currently:", name2); println();
   println();
   printvocal(s1, t1);
   println();
   println();
   printw("OK?  (*y/n)  ");
     
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch); println();
      println();
      printw("For each state output to be altered, enter state and new output."); println();
      printw("To make State silent, enter Output 0."); println();
      printw("Type -1 to quit:"); println();
      println();
      i = 0;
      while (i != -1) {
         if (_wherey() > 19)
            clear();
         println();
         printw(" State:  ");
         row = _wherey();
         i = (INT_S) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true;
            return;
         }
         if (i == -1) break;

         move(row, 30);
         printw("Vocal Output:  ");
         v = (INT_V) readint(&ch, -1, MAX_VOCAL_OUTPUT);
         if (ch == CEsc) {
            quit = true;
            return;
         }
         if (v == -1) break;

         if ( (v < 0) || ((v >= 1) && (v <= 9)) || (v > MAX_VOCAL_OUTPUT) ) {
            println();
            if (_wherey() > 17) clear();
            printw("This vocalization is illegal; please reenter"); println();
         } else {
            add_des(&t1, &s1, i);
            t1[i].vocal = v;
            addstatepair(i, (INT_S) v, &vocal_list, s_vocal_list, &ok);
            if (ok) s_vocal_list++;
         }
      }
   }*/

   /* PROCEDURE TO DELETE STATES */
   clear();
   esc_footer();
   println();
   printw("Delete any states from %s?  (y/*n)  ", name2);

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      addch(ch); println();
      println();
      printw("Enter states of %s to delete", name2); println();
      printw("To quit, enter -1"); println();
      println(); tab(5);
      i = 0;
      while (i != -1) {
         col = _wherex(); row = _wherey();
         if ( (row < 20) && (col >= 75) ) {
            move(row+1, 5);
            col = 5;
            row = row+1;
         }

         if (_wherey() > 19) {
            clear();
            move(1,0);
            printw("Continue to enter states of %s to delete (type -1 to quit):", name2); println();
            move(3,4);
            col = 4;
            row = 3;
         }

         i = (INT_S) readint(&ch, -1, MAX_STATES);
         if (ch == CEsc) {
            quit = true; return;
         }
         if (i == -1) break;

         if ( (i >= 0) && (i < s1) ) {
            addstatelist(i, &old_state_list, s_old_state_list, &ok);
            if (ok) s_old_state_list++;
            move(row, col+7);
         }

         if (i == 0) {
            println();
            printw("Former initial state 0 will be deleted."); println();
            println();
            printw("Please enter the new initial state ....  ");
            init = (INT_S) readint(&ch, -1, MAX_STATES);
            if (ch == CEsc) {
               quit = true; return;
            }
         }

         if (i >= s1) {
            println(); println();
            if (_wherey() > 17) clear();
            printw("State %d is not in %s!", i, name2); println();
            println(); tab(5);
         }
      }
   } else {
      println();
   }

   /* Remove all reference to the deleted states.
      Make the states values to initial created states.
      No states are deleted but these state will be isolated.
      It is up to the user to purge the isolated states by
      doing a reach.

      Remember to fix initial state to zero.
   */

   /* Mark states to remove reference to as unreached */
   for (i=0; i < s1; i++)
      t1[i].reached = true;
   for (i=0; i < s_old_state_list; i++)
      t1[ old_state_list[i] ].reached = false;
   purgebadstates(s1, &t1);
   trim_endstates(&s1, &t1);
   
   gentranlist(s1, t1, &s_list, &list);
   remove_aforcible(s2, t2, s_list, list);


   /* CHECK FOR DETERMINISTISM */
/*   check_determinism(t1,s1,name2,&quit,true);
   if (quit == true) return;

   clear();
   esc_footer();
   if (init != 0) {*/
       /* Just warn user that the initial state has been recoded to zero */
/*      move(1,0);
      printw("%s will be recoded with initial state relabelled to 0.", name2);
      move(3,0);
   } else {
      move(1,0);
   } */
   
   
   clear();
   esc_footer();
   println();  
   
   
   printw("Do you want the edited ADS reachable?  (y/*n)  ");
   init = 0;
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      /* Clear "reach" before a call to reach procedure */
      for (i=0; i < s1; i++)
         t1[i].reached = false;
      reach_operation = true;
      areach(&s1, &t1, s2, t2);
   }

   if (ch == CEnter) {
      println();
   } else {
      addch(ch);
   }
   println(); println();
   refresh();

   if (mem_result != 1)
      fileads(name2, s1, init, t1, *s2, *t2);
}

void edit_amakeit(INT_T s2, timed_event *t2)
{
   FILE *out;
   INT_S i;
   INT_B openingComma;
   int d;
   INT_T index;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = AEdit(%s", name2, name1);

   openingComma = false;

   /* Mark and unmark list */
   if (s_new_mark_list > 0) {
      fprintf(out, ","); openingComma = true;
      fprintf(out, "[mark ");
      for (i=0; i < s_new_mark_list; i++) {
         fprintf(out, "+[%ld]", new_mark_list[i]);
         if (i < (s_new_mark_list-1) )
            fprintf(out, ",");
      }
   }

   if (s_old_mark_list > 0) {
      if (s_new_mark_list == 0) {
         fprintf(out, ","); openingComma = true;
         fprintf(out, "[mark ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_mark_list; i++) {
         fprintf(out, "-[%d]", old_mark_list[i]);
         if (i < (s_old_mark_list-1) )
            fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_mark_list > 0) fprintf(out, "]");
   }

   /* States that are deleted */
   if (s_old_state_list > 0) {
      if (openingComma == false) openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[states ");
      for (i=0; i < s_old_state_list; i++) {
         fprintf(out, "-[%d]", old_state_list[i]);
         if (i < (s_old_state_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Forcible list */
   if (s_new_forcible_list > 0) {
      fprintf(out, ","); openingComma = true;
      fprintf(out, "[forcible ");
      for (i=0; i < s_new_forcible_list; i++) {
         fprintf(out, "+[%ld]", new_forcible_list[i]);
         if (i < (s_new_forcible_list-1) )
            fprintf(out, ",");
      }
   }

   if (s_old_forcible_list > 0) {
      if (s_new_forcible_list == 0) {
         fprintf(out, ","); openingComma = true;
         fprintf(out, "[forcible ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_forcible_list; i++) {
         fprintf(out, "-[%d]", old_forcible_list[i]);
         if (i < (s_old_forcible_list-1) )
            fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_forcible_list > 0) fprintf(out, "]");
   }

   /* Timed Events */
   if (s_ch_timebounds > 0) {
      fprintf(out, ","); openingComma = true;
      fprintf(out, "[changed time bounds ");
      for (i=0; i < s_ch_timebounds; i++) {
	 find_timebounds(s2, t2, ch_timebounds[i], &index);
         fprintf(out, "[%3d [%4d,%4d]]", t2[index].label, t2[index].low,
		 t2[index].upper);
         if (i < (s_ch_timebounds-1) )
            fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Transitions */
   if (s_new_tran_list > 0) {
      if (openingComma == false) openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[trans ");
      for (i=0; i < s_new_tran_list; i++) {
         fprintf(out, "+[%d,%d,%d]", new_tran_list[i].i,
                                     new_tran_list[i].e,
                                     new_tran_list[i].j);
         if (i < (s_new_tran_list-1) ) fprintf(out, ",");
      }
   }

   if (s_old_tran_list > 0) {
      if (s_new_tran_list <= 0) {
         if (openingComma == false) openingComma = true;
         fprintf(out, ",");
         fprintf(out, "[trans ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_tran_list; i++) {
         fprintf(out, "-[%d,%d,%d]", old_tran_list[i].i,
                                     old_tran_list[i].e,
                                     old_tran_list[i].j);
         if (i < (s_old_tran_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_tran_list > 0) fprintf(out, "]");
   }

   /* Vocal */
   if (s_vocal_list > 0) {
      openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[voc ");
      for (i=0; i < s_vocal_list; i++) {
         fprintf(out, "[%ld,%ld]", vocal_list[i].data1,
                                   vocal_list[i].data2);
         if (i < (s_vocal_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   if (reach_operation)
      fprintf(out, ",rch");

   fprintf(out, ")");
   fprintf(out, "  (%d,%d)\n\n", s1, count_tran(t1,s1, &d, &d, &d));
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void edit_makeit()
{
   FILE *out;
   INT_S i;
   INT_B openingComma;
   int d;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = Edit(%s", name2, name1);

   openingComma = false;

   /* Mark and unmark list */
   if (s_new_mark_list > 0) {
      fprintf(out, ","); openingComma = true;
      fprintf(out, "[mark ");
      for (i=0; i < s_new_mark_list; i++) {
         fprintf(out, "+[%ld]", new_mark_list[i]);
         if (i < (s_new_mark_list-1) )
            fprintf(out, ",");
      }
   }

   if (s_old_mark_list > 0) {
      if (s_new_mark_list == 0) {
         fprintf(out, ","); openingComma = true;
         fprintf(out, "[mark ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_mark_list; i++) {
         fprintf(out, "-[%d]", old_mark_list[i]);
         if (i < (s_old_mark_list-1) )
            fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_mark_list > 0) fprintf(out, "]");
   }

   /* States that are deleted */
   if (s_old_state_list > 0) {
      if (openingComma == false) openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[states ");
      for (i=0; i < s_old_state_list; i++) {
         fprintf(out, "-[%d]", old_state_list[i]);
         if (i < (s_old_state_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Forcible list */
   if (s_new_forcible_list > 0) {
      fprintf(out, ","); openingComma = true;
      fprintf(out, "[forcible ");
      for (i=0; i < s_new_forcible_list; i++) {
         fprintf(out, "+[%ld]", new_forcible_list[i]);
         if (i < (s_new_forcible_list-1) )
            fprintf(out, ",");
      }
   }

   if (s_old_forcible_list > 0) {
      if (s_new_forcible_list == 0) {
         fprintf(out, ","); openingComma = true;
         fprintf(out, "[forcible ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_forcible_list; i++) {
         fprintf(out, "-[%d]", old_forcible_list[i]);
         if (i < (s_old_forcible_list-1) )
            fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_forcible_list > 0) fprintf(out, "]");
   }

   /* Transitions */
   if (s_new_tran_list > 0) {
      if (openingComma == false) openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[trans ");
      for (i=0; i < s_new_tran_list; i++) {
         fprintf(out, "+[%d,%d,%d]", new_tran_list[i].i,
                                     new_tran_list[i].e,
                                     new_tran_list[i].j);
         if (i < (s_new_tran_list-1) ) fprintf(out, ",");
      }
   }

   if (s_old_tran_list > 0) {
      if (s_new_tran_list <= 0) {
         if (openingComma == false) openingComma = true;
         fprintf(out, ",");
         fprintf(out, "[trans ");
      } else {
         fprintf(out, ",");
      }

      for (i=0; i < s_old_tran_list; i++) {
         fprintf(out, "-[%d,%d,%d]", old_tran_list[i].i,
                                     old_tran_list[i].e,
                                     old_tran_list[i].j);
         if (i < (s_old_tran_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   } else {
      if (s_new_tran_list > 0) fprintf(out, "]");
   }

   /* Vocal */
   if (s_vocal_list > 0) {
      openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[voc ");
      for (i=0; i < s_vocal_list; i++) {
         fprintf(out, "[%ld,%ld]", vocal_list[i].data1,
                                   vocal_list[i].data2);
         if (i < (s_vocal_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Vocal uniform */
   if (s_map_list > 0) {
      openingComma = true;
      fprintf(out, ",");
      fprintf(out, "[unif ");
      for (i=0; i < s_map_list; i++) {
         fprintf(out, "[%ld,%ld]", map_list[i].data1,
                                   map_list[i].data2);
         if (i < (s_map_list-1) ) fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   if (reach_operation)
      fprintf(out, ",rch");

   fprintf(out, ")");
   fprintf(out, "  (%d,%d)\n\n", s1, count_tran(t1,s1, &d, &d, &d));
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void edit_p()
{
   t1 = NULL; s1 = s2 = 0;
   t2 = NULL;
   quit = false;

   old_state_list = NULL; s_old_state_list = 0;
   new_mark_list = NULL; s_new_mark_list = 0;
   old_mark_list = NULL; s_old_mark_list = 0;
   new_forcible_list = NULL; s_new_forcible_list = 0;
   old_forcible_list = NULL; s_old_forcible_list = 0;
   vocal_list = NULL; s_vocal_list = 0;
   map_list = NULL; s_map_list = 0;
   new_tran_list = NULL; s_new_tran_list = 0;
   old_tran_list = NULL; s_old_tran_list = 0;
   reach_operation = false;

   edit_r();

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;         /* Reset memory function to zero */
   } else {
      if (!quit) {
        edit_makeit();
        clear();
        move(7,0);
        printw("EDITING COMPLETE"); println();
        user_pause();
      }
   }

   freedes(s1, &t1);
   free(old_state_list);
   free(new_mark_list);
   free(old_mark_list);
   free(old_forcible_list);
   free(new_forcible_list);
   free(vocal_list);
   free(map_list);
   free(new_tran_list);
   free(old_tran_list);
}

void edit_ap()
{
   timed_event *t2;
   INT_T s2;
   t1 = NULL; s1 = s2 = 0;
   t2 = NULL;
   quit = false;

   old_state_list = NULL; s_old_state_list = 0;
   new_mark_list = NULL; s_new_mark_list = 0;
   old_mark_list = NULL; s_old_mark_list = 0;
   new_forcible_list = NULL; s_new_forcible_list = 0;
   old_forcible_list = NULL; s_old_forcible_list = 0;
   vocal_list = NULL; s_vocal_list = 0;
   new_tran_list = NULL; s_new_tran_list = 0;
   old_tran_list = NULL; s_old_tran_list = 0;
   ch_timebounds = NULL; s_ch_timebounds = 0;
   reach_operation = false;

   edit_ar(&s2, &t2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;         /* Reset memory function to zero */
   } else {
      if (!quit) {
        edit_amakeit(s2, t2);
        clear();
        move(7,0);
        printw("EDITING COMPLETE"); println();
        user_pause();
      }
   }

   freedes(s1, &t1);
   free(old_state_list);
   free(new_mark_list);
   free(old_mark_list);
   free(vocal_list);
   free(new_tran_list);
   free(old_tran_list);
   free(old_forcible_list);
   free(new_forcible_list);
   free(ch_timebounds);
}

