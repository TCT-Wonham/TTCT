#ifndef _DES_PROC_H
#define _DES_PROC_H

#include <stdio.h>
#include "des_data.h"


extern void trim_endstates(INT_S *s, state_node **t);
extern void addpart(INT_S e, INT_S **L, INT_S size, INT_B *ok);
extern void merge_forcible(INT_T s1, INT_T *t1, INT_S *s2, INT_T **t2);
extern void set_aforcible(INT_S s1, INT_T *t1, INT_T *s2, timed_event **t2,
			  INT_B flag);
extern int merge_aforcible(INT_T s1, timed_event *t1, INT_T *s2, 
			    timed_event **t2);
extern void gensublist(INT_T, INT_T*, INT_T, INT_T*, INT_T*, INT_T**, INT_T*,
		       INT_T**);
extern void remove_alt_forcible(INT_S s1, INT_T *t1, INT_S *s2, INT_T **t2);
extern void comp2(INT_S s1, state_node *t1, INT_T s2, timed_event *t2,
           INT_S s3, state_node *t3, INT_T s4, timed_event *t4,
	   INT_S *s5, state_node **t5, INT_T *s6, timed_event **t6,
           INT_S **macro_ab, INT_S **macro_c);
extern void cp_tim_info(INT_S s1, state_node *t1, INT_S *s2, state_node **t2, 
		 INT_S *macro_c);
extern void areach(INT_S *s1, state_node **t1, INT_T *s2, timed_event **t2);
extern void isoa1(INT_S s1, INT_S s2, INT_S s3, INT_S s4,
	   state_node *t1, timed_event *t2, state_node *t3, timed_event *t4, 
	   INT_B *inflag, INT_S *mapState);
extern void merge_adeftime(INT_T s_list, INT_T *list, INT_T *s2, 
			   timed_event **t2);
extern void remove_aforcible(INT_T *s1, timed_event **t1, INT_T s_list, 
			     INT_T *list);

/* For selfloop */
extern void gentran(INT_T, INT_T*, INT_S, state_node*);

/* For sync */
extern void sync2(INT_S, state_node*, INT_S, INT_T*, INT_S, state_node*,
                  INT_S, INT_T*, INT_S*, state_node**, INT_S*, INT_T**,
		  INT_S**, INT_S**);

/* For meet */
extern void meet2(INT_S, state_node*, INT_S, state_node*,
                  INT_S*, state_node**, INT_S**, INT_S**);

/* For nonconflict */
extern void nc_meet2(INT_S, state_node*, INT_S, state_node*,
                  INT_S*, state_node**, INT_S**, INT_S**);

/* For Trim */
extern void trim1(INT_S*, state_node**, INT_S*, INT_T**);
extern void trima1(INT_S*, state_node**, INT_T*, timed_event**);

/* For Supcon */
extern void trim2(INT_S*, state_node**, INT_S*, INT_T**, INT_S*);
extern void shave1(INT_S, state_node*, INT_S, INT_T*,
		   INT_S*, state_node**, INT_S*, INT_T**, 
		   INT_S*);

/* For Mutex */
extern void mutex1(INT_S*, state_node**, INT_T, INT_T*, INT_S, INT_S, INT_S*,
                   state_pair*, INT_S);
extern void reach(INT_S*, state_node**, INT_S*, INT_T**);

/* For Condat */
extern void condat1(state_node *, INT_S, INT_S, INT_S, state_node*, 
		    INT_S, INT_T*, INT_S*, state_node**, INT_S*);
extern void condat2(state_node *t1, INT_S s1, INT_S s2,state_node *t2, INT_S s3, state_node *t3,
	INT_S s4, INT_T *t4, INT_S *s5, state_node **t5,
	INT_S *macro_c);

/* For Minimize */
extern void minimize(INT_S *, state_node**);

/* For complement */
extern void complement1(INT_S*, state_node**, INT_T, INT_T*);

/* For project0 */
extern void project0(INT_S*, state_node**, INT_S*, INT_T**, INT_T, INT_T*);

/* For isomorph */
extern void compare_states(INT_S, INT_S, INT_B*, INT_S*, state_pair**, INT_S*, state_node*, state_node*);

/* For BFS-recode */
extern void b_reach(tran_node*, INT_S, state_node**, INT_S);

/* For check determinism */
extern INT_B checkdet(INT_S,state_node*);

/* For editing */
extern INT_B exist_forcible(INT_T, tran_node*, INT_S, INT_T*);
extern void gendifflist1(INT_T, tran_node*, INT_T, tran_node*, INT_T*,
			 INT_T**);
extern void remove_forcible(INT_S*, INT_T**, INT_T, INT_T*);

extern void purgebadstates(INT_S, state_node**);

extern void b_recode(INT_S, state_node**, INT_S*, INT_S**);

extern void vocalize_des(state_node**, INT_S*, quad__t**, INT_S*);

extern void iso1(INT_S, INT_S, INT_S, INT_S, state_node*, INT_T*,
		 state_node*, INT_T*, INT_B *, INT_S *);

extern void gentranlist(INT_S s1, state_node *t1, INT_T *s2, INT_T **t2);
extern void gentranlist1(INT_S s1, state_node *t1, INT_S *s2, INT_T **t2);

extern INT_S count_tran(state_node* t1,
			INT_S s1, int *marker, int *vocal, int *silent);

extern INT_B compute_controllable(state_node*, INT_S);

extern void isolate_state(state_node *des, int states, int state);

extern int is_deterministic(state_node *des, int states,
			    triple **non_det_list);

extern INT_B nonconflict(INT_S s, state_node *t);
extern void recode_min(INT_S s1, state_node *t1,	INT_S s2,	state_node *t2,	INT_S *mapState);

extern void print_des_stat_header(FILE *out, char *name, INT_S s, INT_S init);
extern INT_B print_marker_states(FILE *out, state_node *t1, INT_S s1);
extern INT_B print_vocal_output(FILE *out, state_node *t1, INT_S s1);
extern INT_B print_transitions(FILE *out, state_node *t1, INT_S s1);
extern INT_B print_aforcible_states(FILE *out, timed_event *t1, INT_T s1);
extern INT_B print_timebounds(FILE *out, timed_event *t1, INT_T s1);
extern INT_B print_forcible_states(FILE *out, INT_T *t1, INT_S s1);
extern INT_B print_timer_info(FILE *out, state_node *t1, INT_S s1);

#endif
