#ifndef PRINTER_H
#define PRINTER_H

#include <stdio.h>

extern int PS_Header(FILE* fptr);
extern int PS_FileHeader(FILE* fptr, char* filename);
extern int PS_SetFont(FILE* fptr, char* font);
extern int PS_StartPage(FILE* fptr);
extern int PS_EndPage(FILE* fptr);
extern int PS_Footer(FILE* fptr);
extern int MODE_init();

extern char  mode_landscape[6];
extern char  mode_twinpage[6];
extern char  mode_doublesize[6];
extern float mode_sheetheight;
extern float mode_sheetwidth;
extern float mode_page_margin;
extern float mode_bind_margin;
extern float mode_col_margin;
extern char  mode_noborder[6];
extern float mode_headersize;
extern float mode_bodyfontwidth;
extern float mode_bodyfontheight;
extern float mode_columns;
extern float mode_lines;

#endif
