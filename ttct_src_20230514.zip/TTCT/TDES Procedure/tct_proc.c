#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>
//#include <unistd.h>
#include <windows.h>
#include <direct.h>
//#include <dirent.h>
/* #include <pwd.h> */

#include "tct_proc.h"
#include "ttct_io.h"
#include "tct_curs.h"
#include "des_proc.h"
#include "display.h"
#include "outcon.h"
#include "hicons.h"
#include "higen.h"
#include "cnorm.h"
#include "setup.h"
#include "ats2tds.h"
#include "aas2ads.h"
#include "convert.h"
#include "ps.h"
#include "supred.h"
#include "localize.h"


//extern int alphasort (const struct dirent **a, const struct dirent **b);

/*#if defined(__DOS32__) || defined(__BORLANDC__)
#include <dos.h>
#endif*/

/* Module variables - local to this module. */
static filename   name1, name2, name3, name4, names1[MAX_DESS],names2[MAX_DESS];
static filename   fname1, fname2, fname3, fname4;
static INT_B    quit;

static char long_name1[255];
static char long_name2[255];
static char long_name3[255];
static char long_name4[255];
static long_filename long_names1[MAX_DESS];
static long_filename long_names2[MAX_DESS];
int supreduce_flag;

/*#if defined(__UNIX__)*/
static time_t start_time, stop_time;
/*#elif defined(__BORLANDC__) || defined(__DOS32__)
static struct time start_time, stop_time;
#endif*/

#define SEPC   '\\'
#define SEP    "\\"

#define NULLCommandSet "NnIi"

void setuserpath(char *ini_file)
{
   FILE *in, *out;
   INT_B  use_default = false;
   char currentDir[256];
   int err;
   int clock;
   char clock_str[10];

   /* A defect in some version of Linux code dump if it is provided 
      with a non-existent file.   This is a workaround. */
   if (_access(ini_file, 0) != 0)
   {
      use_default = true;
   } 
   else
   {   
      in = fopen(ini_file, "rt");
      if (in == NULL)
      {
         use_default = true;
      }
      else
      {
/*         fscanf(in, "%s", path); */
         fgets(path, 255, in);
         if (path[strlen(path)-1] == '\n')
           path[strlen(path)-1] = '\0';

         _getcwd(currentDir, 255);
         if (_chdir(path) == -1)
            use_default = true;
         else
         {
            strcpy(prefix, path);
            strcat(prefix, SEP);
         }
         _chdir(currentDir);
         
         /* Attempt to read the clock setting if any */
         err = fscanf(in, "%s %d", clock_str, &clock);
         if (err > 0)
         {
            if (strcmp(clock_str, "CLOCK") == 0)
               timing_mode = clock;
         }      

         fclose(in);
       }
   }

   if (use_default)
   {
      _getcwd(path, 255);

      if (path[strlen(path)-1] != SEPC)
        strcat(path, SEP);
      strcat(path, "user");

      strcpy(prefix, path);
      strcat(prefix, SEP);
   }

   dos_uppercase(path);
   dos_uppercase(prefix);

   out = fopen(ini_file, "wt");
   if (out != NULL)
   {
      fprintf(out, "%s\n", path);
      fprintf(out, "CLOCK %d\n", timing_mode);
      fclose(out);
   }
}

void not_yet()
{
   clear();
   move(1,2); addstr("Not yet available! ");
   move(2,2); addstr("Press a key to continue ");
   refresh();

   read_key();
}

void user_pause()
{
   char ch;

   move(23,0); clrtoeol();
   printw("Press <Enter> to return to TTCT Procedures  ");
   refresh();
   ring_bell();
   do {
     ch = read_key();
   } while (ch != CEnter);
}

void echo_save(char *name)
{
   move(19,0); clrtoeol(); refresh();
   move(20,0); clrtoeol(); refresh();
   move(21,0); clrtoeol(); refresh();
   move(20,0);
   printw("%s has been filed as %s%s%s",name, prefix, name, EXT_DES);
   refresh();
   user_pause();
}

void echo_asave(char *name)
{
   move(19,0); clrtoeol(); refresh();
   move(20,0); clrtoeol(); refresh();
   move(21,0); clrtoeol(); refresh();
   move(20,0);
   printw("%s has been filed as %s%s%s",name, prefix, name, EXT_ADS);
   refresh();
   user_pause();
}


void echo_free()
{
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Freeing memory:  Please wait...");
   refresh();
}

/* Update the string to uppercase if we are running in DOS */
char *dos_uppercase(char *string)
{
//#if defined(__GO32__) 
   int length, i;

   length = (int)strlen(string);
   for (i=0; i<length; i++) {
      string[i] = toupper(string[i]);
   }
//#endif
   return string;
}

static char makeit_filename[80];

char *get_makeit()
{
    strcpy(makeit_filename, prefix);
    strcat(makeit_filename, "MAKEIT.TXT");
    return makeit_filename;
}

void mergeChop(int offset)
{
   char tempstr[255];
   FILE *in, *out;
   int col;
   char ch;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;

   setvbuf(out, NULL, _IOFBF, 4000);

   memset(tempstr, ' ', offset);
   tempstr[offset] = '\0';

   in = fopen("tmp.$$$", "r");
   col = 0;
   while ( (ch = fgetc(in)) && (!feof(in)) ) {
      col++;
      if (ch == '\n') {
        col = 0;
      } else if (col >= 75) {
        if (ch != '\n') {
           fprintf(out, "\n");
           fprintf(out, "%s", tempstr);
           col = offset+1;
        }
      }
      fprintf(out, "%c", ch);
   }

   fclose(in);
   fclose(out);

   /* Remove tempory file */
   _unlink("tmp.$$$");
}

void mark_start_time()
{
/*#if defined(__UNIX__)*/
   start_time = time(NULL);
/*#elif defined(__BORLANDC__) || defined(__DOS32__)
   gettime(&start_time);
#endif*/
}

void mark_stop_time()
{
/*#if defined(__UNIX__)*/
   stop_time = time(NULL);
/*#elif defined(__BORLANDC__) || defined(__DOS32__)
   gettime(&stop_time);
#endif*/
}

/*#if defined(__UNIX__)*/

char *cdifftime(time_t s1, time_t s2)
{
   static char timestr[30];
   /* difftime returns a double */
   sprintf(timestr, "%6.0f sec", difftime(s2,s1));
   return timestr;
}

/*#elif defined(__BORLANDC__) || defined(__DOS32__)

char *cdifftime(struct time s1, struct time s2)
{
   long s1_sec, s2_sec, diff_sec;
   static char timestr[30];
   struct time t;

   /* Convert the hour, minutes and seconds to the equivalent hundred secs 
   s1_sec = (((long) (s1.ti_hour)*60*60 + (long)(s1.ti_min)*60 + (long)(s1.ti_sec))*100 + (long)(s1.ti_hund));
   s2_sec = (((long) (s2.ti_hour)*60*60 + (long)(s2.ti_min)*60 + (long)(s2.ti_sec))*100 + (long)(s2.ti_hund));

   if (s2_sec < s1_sec)
      s2_sec = s2_sec + 24*60*60*100;
   diff_sec = s2_sec - s1_sec;

   t.ti_hund = diff_sec % 100;
   t.ti_sec  = (diff_sec / 100) % 60;
   t.ti_min  = (diff_sec / 100 / 60) % 60;
   t.ti_hour = (diff_sec / 100 / 60 / 60) % 24;

   sprintf(timestr, "%02d:%02d:%02d.%02d",
                    t.ti_hour, t.ti_min, t.ti_sec, t.ti_hund);
   return timestr;
}

#endif*/

void appendTime(FILE *out, int offset)
{
   char tempstr[20];

   if (timing_mode) {
      fprintf(out, "\n");

      memset(tempstr, ' ', offset);
      tempstr[offset] = '\0';
      fprintf(out, "%sComputing time = %s", tempstr,
         cdifftime(start_time, stop_time));
   }
}

void display_conflict_tran(triple* list,
                           INT_S s_list)
{
   INT_S i, count;
   char ch;
   short curLabel;

   println();
   printw("Nondeterministic transitions: ");

   curLabel = -1;
   i = 0; count = 0;
   do {
      if (_wherey() > 19) {
        move(23,0);
        printw("Press <Enter> to page transitions  ");
        refresh();
        do {
           ch = read_key();
        } while (ch != CEnter);
        clear();
        esc_footer();
        println();
        printw("Nondeterministic transitions: "); println();
      }

      if (((short) list[i].e) != curLabel) {
        if ( (count % 4) != 0) println();
        count = 0;
        println();
        curLabel = (short) list[i].e;
      }

      printw("[%5ld,%3d,%5ld]  ", list[i].i, list[i].e, list[i].j);
      count++;
      if ( (count % 4) == 0 ) println();
      i++;

   } while (i < s_list);
   println();
}

void check_determinism(state_node* t1, INT_S s1,
                       char* name, INT_B* quit, INT_B flag)
{
   INT_S i, curEntrance;
   INT_T j, cur;
   INT_B first, ok;
   triple *nonDetList;
   INT_S s_nonDetList;
   char ch;

   nonDetList = NULL; s_nonDetList = 0;

   clear();
   esc_footer();
   println();
   printw("Check %s for nondeterminism?  (y/*n)  ", name);
   refresh();
   ch = read_key();
   if (ch == CEnter) {
      println();
   } else {
      addch(ch);
   }

   println();
   if (ch == CEsc) {
     *quit = true;
     return;
   }

   if ( (ch == 'Y') || (ch == 'y') ) {
      for (i=0; i< s1; i++) {
         first = true;
         if (t1[i].numelts > 0) {
             cur = t1[i].next[0].data1;
             curEntrance = t1[i].next[0].data2;
         }
         for (j=1; j < t1[i].numelts; j++) {
            if (cur == t1[i].next[j].data1) {
               if (first) {
                  addtriple(i,cur,curEntrance, &nonDetList, s_nonDetList, &ok);
                  if (ok) s_nonDetList++;
               }
               first = false;
               addtriple(i,cur,t1[i].next[j].data2, &nonDetList, s_nonDetList, &ok);
              if (ok) s_nonDetList++;
            } else {
               first = true;
               cur = t1[i].next[j].data1;
               curEntrance = t1[i].next[j].data2;
            }
         }
      }

      println();
      if (s_nonDetList == 0) {
         printw("%s is OK.", name);
      } else {
         printw("WARNING: %s is nondeterministic!", name); println();
         display_conflict_tran(nonDetList, s_nonDetList);
         if (_wherey() > 19) {
            clear();
            esc_footer();
         }
         println();
         printw("Please revise %s using the editor.", name); println();
      }

      /* Prompt user to continue? */
      if (flag) {
        move(23,0);
        printw("Press <Enter> to continue  ");
        refresh();
        do {
           ch = read_key();
        } while (ch != CEnter);
      }
   }

   if (nonDetList != NULL) free(nonDetList);
}

/* compare two INT_T values */
int cmp_intt(const void *int1, const void *int2) {
   INT_T first = *(const INT_T*) int1;
   INT_T second = *(const INT_T*) int2;
   if (first < second)
      return -1;
   if (first == second)
      return 0;
   return 1;
}

INT_B chk_for_tick(INT_S *s1, state_node **t1) 
{
   INT_T s_list, *list, tick;
   
   tick = TICK;
   gentranlist(*s1, *t1, &s_list, &list);
   if (bsearch(&tick, list, s_list, sizeof(INT_T), cmp_intt) != NULL)
      return true;
   return false;
}   

void create_header()
{
   printw("CREATE"); println();
   println();
}

void create_states()
{
   println();
   printw("States will be numbered 0,1,2,3,...."); println();
   printw("The initial state is 0."); println();
   println();
   printw("Enter total number of states...  ");
}

void create_name()
{
   printw("CREATE(%s)", name1); println();
   println();
}

void create_marker()
{
   println();
   printw("Enter list of marker states in {0,1,...,Size-1}"); println();
   printw("To mark all states, enter '*'"); println();
   println();
   printw("To quit, enter -1"); println();
   println();
}

void create_forcible(INT_T *list, INT_T size)
{
   int i, col, row;

   println();
   printw("Enter list of forcible events in");
   println();
   println();
   printw("[ ");
   for (i = 0; i < size; i++) { 
      col = _wherex();
      row = _wherey();
      if (list[i] != TICK) 
	 printw("%5d", list[i]);
      if (col >= 75) {
	 move(row+1,5);
	 col = 5;
	 row++;
      }
   }
   printw("]");
   println();
   println();
   printw("To quit, enter -1"); println();
   println();
}

void create_vocal()
{
   println();
   printw("Enter vocal states with output: integer in 10,...,99"); println();
   println();
   printw("To quit, enter -1 for State."); println();
   println();
}

void create_transitions(int flag)
{
    println();
    printw("Enter transitions using:"); println();
    println();
    printw("   States                : integers 0,1,2,...,Size-1"); println();
    if (flag == 0)
       printw("   Tick event            : 0"); println();
    printw("   Uncontrollable Events : even integers 2,4,... <= 998"); println();
    printw("   Controllable Events   : odd integers 1,3,5,... <= 999"); println();
    println();
    printw("To quit, enter -1 for Source State."); println();
    println();
}
void create_timebounds()
{
    println();
    printw("Enter time bounds for transitions using:"); println();
    println();
    printw("   Time bounds           : integers 0,1,2,...,%d",MAX_TIME); println();
    printw("   Lower Time Bound      : RETURN signifies 0"); println();
    printw("   Upper Time Bound      : RETURN signifies Infinity"); println();
    println();
/*    printw("To quit, enter -1 for Source State."); println();
    println(); */
}

/* create of activity graph transitions */
void create_atransitions()
{
    println();
    printw("Enter transitions using:"); println();
    println();
    printw("   States                : integers 0,1,2,...,Size-1"); println();
/*    printw("   Tick event            : 0"); println(); */
    printw("   Uncontrollable Events : even integers 2,4,... <= 998"); println();
    printw("   Controllable Events   : odd integers 1,3,5,... <= 999"); println();
    println();
    printw("To quit, enter -1 for Source State."); println();
    println();
}

void create_common(state_node **t1, INT_S *s1, int flag)
{
   INT_S   i,j;
   INT_T   e;
   INT_S   mark, state;
   INT_V   vocal_output;
   INT_B ok;
   char    ch;
   int     row, col, a;
   short   sign_i;

   create_states();
   esc_footer();
   refresh();
   *s1 = (INT_S) readint(&ch, 0, MAX_STATES);
   if (ch == CEsc) {
     quit = true;
     return;
   }

   *t1 = newdes(*s1);
   if ((*s1 != 0) && (*t1 == NULL)) {
      mem_result = 1;
      return;
   }
   /* handle trivial case*/
   if (*s1 == 0) 
      return;

   println();

   /* Get marker states */
   create_marker();
   do {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,0);
         col = 0;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         create_name();
         create_marker();
         println();
         println();
         esc_footer();
         col = _wherex();
         row = _wherey();
      }

      mark = (INT_S) readintall(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (ch == '*')
      {
         for (i=0; i < *s1; i++) 
           (*t1)[i].marked = true;
         break;
      }
      if (mark != -1) {
         (*t1)[mark].marked = true;
      }
     if (col+10 >= 75) {
         move(row+1,0);
         col = 0;
         row++;
      } else {
         move(row, col+10);
      }
   } while (mark != -1);

   /* Add the transitions */
   //scrollok(stdscr,1);
   clear();
   create_name();
   create_transitions(flag);
   esc_footer();
   do {
      if (_wherey() > 21) {
         //scrl(1);
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol(); //Justin0622
         move(24,0); //Justin0622
		 scroll_line();//Justin0622
#if defined(__GO32__)
         println();
#endif

         for (a=0; a < 11; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         create_name();
         create_transitions(flag);
         esc_footer();
         move(row,col); 
      }

      printw("Source State:  ");
      i = (INT_S) readint(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
          quit = true; return;
      }
      if (i == -1) break;

      tab(25);
      printw("Event Label:  ");
      if (flag == 1) {
	 sign_i = (short) readtickint(&ch, -1, MAX_TRANSITIONS);
      } else {
	 sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
      }
      if (ch == CEsc) {
         quit = true; return;
      }
      if (sign_i == -1) break;
      e = (INT_T) sign_i;

      tab(50);
      printw("Target State:  ");
      j = (INT_S) readint(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
         quit = true; return;
      }
      if (j == -1) break;
      println();

      addordlist1(e, j, &(*t1)[i].next, (*t1)[i].numelts, &ok);
      if (ok) (*t1)[i].numelts++;
   } while (i != -1);

   if (chk_for_tick(s1, t1) || flag == 1)
      return;

   /* Get Vocal states */
   clear();
   create_name();
   create_vocal();
   esc_footer();
   do {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23, 0); clrtoeol();
         move(24, 0);
         //println();
		 scroll_line();//Justin0622

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         create_name();
         create_vocal();
         esc_footer();
         move(row, col);

/*       clear();
         create_vocal();
         println();
         println();
         esc_footer(); */
      }

      printw("State:  ");
      state = (INT_S) readint(&ch, -1, (*s1)-1);
      if (ch == CEsc) {
          quit = true; return;
      }
      if (state == -1) break;

      tab(20);
      printw("Output:  ");
      vocal_output = (INT_V) readint(&ch, 10, 99);
      if (ch == CEsc) {
         quit = true; return;
      }
      if (vocal_output == -1) break;
      println();

      (*t1)[state].vocal = vocal_output;
   } while (state != -1);
}

/* Get timebounds of activities */
void get_timebounds(INT_T s_list, INT_T *list, INT_T *s_tbl, timed_event **tbl)
{
   INT_S   i, old_s_tbl;
   INT_T   j, l;
   int     row, col, a;
   char    ch;

   /*trivial case*/
   if (s_list == 0)
      return;

   old_s_tbl = *s_tbl;

   /* expand and initialize timed event array */
   *tbl = (timed_event*) realloc(*tbl, 
				 sizeof(timed_event) * (*s_tbl + s_list));
   memset(*tbl + *s_tbl, 0, s_list * sizeof(timed_event));

   if (*tbl == NULL) {
      mem_result = 1;
      return;
   }

   /* ask for time bounds for events */
   clear();
   create_header();
   create_timebounds();
   esc_footer();
   for (i=0; i < s_list; i++) {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);
         println();

         for (a=0; a < 11; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         create_header();
         create_timebounds();
         esc_footer();
         move(row,col);
      }

      printw("Event %4d  ",list[i]);
      printw("Lower Time Bound:  ");
      l = (INT_T) readdefint(&ch, 0, MAX_TIME);
      if (ch == CEsc) {
          quit = true; return;
      } else if (ch == CEnter) {
	 l = 0;
	 printw("%d",l);
      }
/*      if (i == -1) break;

      tab(25);
      printw("Event Label:  ");
      sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
         quit = true; return;
      }
      if (sign_i == -1) break;
      e = (INT_T) sign_i; */

      tab(50);
      printw("Upper Time Bound:  ");
      if (list[i] % 2 == 0) {
	 j = (INT_T) readdefint(&ch, l, MAX_TIME);
	 if (ch == CEsc) {
	    quit = true; return;
	 } else if (ch == CEnter) {
	    j = MAX_TIME;
	    printw("%d",j);
	 }
      } else {
	 printw("Inf");
	 j = MAX_TIME;
      }
/*      if (j == -1) break;*/
      println();

      /* Insert time bounds for event */
      if (old_s_tbl == 0) {
	 (*s_tbl)++;
	 (*tbl)[i].label = list[i];
	 (*tbl)[i].low   = l;
	 (*tbl)[i].upper = j;
      } else {
	 /* Do a binary search. */
	 INT_B found;
	 INT_T pos, lower, upper;
	 found = false;
	 pos = 0;
	 if (*s_tbl > 1) {
	    lower = 1;
	    upper = *s_tbl;
	    while ( (found == false) && (lower <= upper) ) {
	       pos = (lower + upper) / 2;
	       if (list[i] == (*tbl)[pos-1].label) {
		  found = true;
		  pos = pos-1;
	       } else if (list[i] > (*tbl)[pos-1].label) {
		  lower = pos+1;
	       } else {
		  upper = pos-1;
	       }
	    }
	    
	    if (found == false) {
	       if (list[i] < (*tbl)[pos-1].label)
		  pos--;
	    }
	 } else if (*s_tbl == 1) {
	    if (list[i] == (*tbl)[0].label) {
	       found = true;
	       pos = 0;
	    } else if (list[i] > (*tbl)[0].label) {
	       pos = 1;
	    }
	 }
	 if (found == false) {
	    (*s_tbl)++;
	    if (pos < *s_tbl - 1) {
	       memmove(&(*tbl)[pos+1], &(*tbl)[pos], 
		       (*s_tbl - 1 - pos) * sizeof(timed_event));
	    }
	    (*tbl)[pos].label = list[i];
	    (*tbl)[pos].low = l;
	    (*tbl)[pos].upper = j;
	 } else {
	    printw("Transition exists! Has to be fixed!");
	    user_pause();
	 }
      }
   }

   /* decrease size of *tbl if some transitions did already exist */  
   if (*s_tbl != old_s_tbl + s_list) {
      *tbl = (timed_event*) realloc(*tbl, 
				    sizeof(timed_event) * *s_tbl);
   }
}

/* Get forcible events */
void get_forcible(INT_T s_list, INT_T *list, INT_T *s_flist, INT_T **flist)
{
   char    ch;
   int     row, col, forcible;

   if (s_list > 1 || (s_list == 1 && list[0] != TICK)) {
      create_forcible(list, s_list);
      do {
	 col = _wherex();
	 row = _wherey();
	 if (col >= 75) {
	    move(row+1,0);
	    col = 0;
	    row++;
	 }
	 if (_wherey() > 21) {
	    clear();
            create_name();
	    create_forcible(list, s_list);
	    println();
	    println();
	    esc_footer();
	    col = _wherex();
	    row = _wherey();
	 }
	 
	 forcible = readcheckint(&ch, -1, MAX_TRANSITIONS, s_list, list);
	 if (ch == CEsc) {
	    quit = true;
	    return;
	 }
	 if (forcible != -1) {
	    forcible = (INT_T) forcible;
	    /* create unordered list of forcible events*/
	    (*flist) = (INT_T*) realloc((*flist),++(*s_flist) * sizeof(INT_T));
	    (*flist)[(*s_flist)-1] = forcible;
	 }
	 if (col+10 >= 75) {
	    move(row+1,0);
	    col = 0;
	    row++;
	 } else {
	    move(row, col+10);
	 }
      } while (forcible != -1);
      /* sort forcible list*/
      if (s_flist > 0)
	 qsort(*flist, *s_flist, sizeof(INT_T), cmp_intt);
   }
}

/* find index in timebounds list*/
void find_timebounds(INT_T s1, timed_event *t1, INT_T label, INT_T *index)
{  
   /* Do a binary search. */
   INT_B found;
   INT_T pos, lower, upper;
   found = false;
   pos = 0;
   if (s1 > 1) {
      lower = 1;
      upper = s1;
      while ( (found == false) && (lower <= upper) ) {
	 pos = (lower + upper) / 2;
	 if (label == t1[pos-1].label) {
	    found = true;
	    pos = pos-1;
	 } else if (label > t1[pos-1].label) {
	    lower = pos+1;
	 } else {
	    upper = pos-1;
	 }
      }
   } else if (s1 == 1) {
      if (label == t1[0].label) {
	 found = true;
	 pos = 0;
      } else if (label > t1[0].label) {
	 pos = 1;
      }
   }
   if (found == true) {
      *index = pos;
   }
}

/* compare ordered list of events and ordered list of timers and insert
   new timers in timer list and remove non existing timers */
void set_timer(INT_T *s1, timer_info **t1, INT_T s0, tran_node *t0, 
	       INT_S s2, timed_event* t2, INT_T label) 
{
   INT_T i, j, tran_index;
   
   i = j = 0;
   
   while ( (i < s0) && (j < *s1) ) {
      if (t0[i].data1 == (*t1)[j].num) {
	 /*reset timer of taken transition*/
	 if ((*t1)[j].num == label) {
	    find_timebounds((INT_T)s2, t2, label, &tran_index);
	    if (t2[tran_index].upper == MAX_TIME) 
	       (*t1)[j].value = t2[tran_index].low;
	    else 
	       (*t1)[j].value = t2[tran_index].upper;
	 }
	 i++;
	 j++;
	 continue;
      }
      if (t0[i].data1 > (*t1)[j].num) {
	 if (j < *s1 -1) {
	    memmove(&(*t1)[j], &(*t1)[j+1], (*s1-1-j) * sizeof(timer_info));
	 }
	 *t1 = (timer_info*) realloc(*t1, --(*s1) * sizeof(timer_info));
      } else {
	 *t1 = (timer_info*) realloc(*t1, ++(*s1) * sizeof(timer_info));
	 if (j < *s1 - 1) {
	    memmove(&(*t1)[j+1], &(*t1)[j], 
		    (*s1 - 1 - j) * sizeof(timer_info));
	 }
	 find_timebounds((INT_T)s2, t2, t0[i].data1, &tran_index);
	 (*t1)[j].num = t0[i].data1;
	 if (t2[tran_index].upper == MAX_TIME) 
	    (*t1)[j].value = t2[tran_index].low;
	 else 
	    (*t1)[j].value = t2[tran_index].upper;
	 i++;
	 j++;
      }
   }
   
   if (i >= s0) {
      if (j < *s1) {
	 *t1 = (timer_info*) realloc(*t1, j * sizeof(timer_info));
	 *s1 = j;
      }
      return;
   }
   
   while (i < s0) {
      *t1 = (timer_info*) realloc(*t1, ++(*s1) * sizeof(timer_info));
      find_timebounds((INT_T)s2, t2, t0[i].data1, &tran_index);
      (*t1)[j].num = t0[i].data1;
      if (t2[tran_index].upper == MAX_TIME)
	 (*t1)[j].value = t2[tran_index].low;
      else {
	 (*t1)[j].value = t2[tran_index].upper;
      }
      i++;
      j++;
   }
}   

/* create timed state and check if it already exists */
void create_timed(INT_S s1, state_node *t1, INT_S s2, timed_event *t2,
		  INT_S *s3, state_node **t3, INT_S oldstate, INT_S tmpstate, 
		  INT_S state, part_node **convmap, INT_T label, INT_B flag)
{
   INT_B ok, ok1;
   state_node *tmp;
   INT_S exstate, temp;
   INT_T j, tran_index, comp;

   /* we don't allocate a new state_node, assuming this is already done*/
   /* rely on ordered transition list*/
   memcpy(&(*t3)[*s3], &t1[tmpstate], sizeof(state_node));
   (*t3)[*s3].nstinfo = (state_info*) calloc(1, sizeof(state_info));
   (*t3)[*s3].nstinfo[0].state = tmpstate;
   (*t3)[*s3].next = NULL;
   (*t3)[*s3].numelts = 0;
   /* copy timer info from previous state*/
   (*t3)[*s3].numtimer = (*t3)[state].numtimer;
   (*t3)[*s3].ntimer = (timer_info*) calloc((*t3)[state].numtimer, 
					sizeof(timer_info));
   memcpy((*t3)[*s3].ntimer, (*t3)[state].ntimer, 
	  (*t3)[*s3].numtimer * sizeof(timer_info));
   
   if (label == TICK) {
      for (j = 0; j < (*t3)[*s3].numtimer; j++)
	 if ((*t3)[*s3].ntimer[j].value != 0)
	    (*t3)[*s3].ntimer[j].value--;
/*      ok = false;
      if ((*t3)[*s3].numtimer == (*t3)[state].numtimer) 
	 ok = !(memcmp((*t3)[*s3].ntimer, (*t3)[state].ntimer, 
		       sizeof(timer_info) * (*t3)[*s3].numtimer));
      if (ok) exstate = state;*/
   } else {
      set_timer(&(*t3)[*s3].numtimer, &(*t3)[*s3].ntimer, t1[tmpstate].numelts,
		t1[tmpstate].next, s2, t2, label);
   }
   
   if (flag) {
      if (label != TICK) {
	 for (j=0; j<t1[tmpstate].numelts; j++) {
	    find_timebounds((INT_T)s2, t2, (*t3)[*s3].ntimer[j].num, &tran_index);
	    if (t2[tran_index].upper == MAX_TIME)
	       comp = t2[tran_index].low;
	    else
	       comp = t2[tran_index].upper;
	    if ((*t3)[*s3].ntimer[j].value != comp) {
	       (*t3)[*s3].marked = false;
	       break;
	    }
	 }
      } else {	 
	 (*t3)[*s3].marked = false;
      }
   }

   ok = false;
   for (j = 0; j < (*convmap)[tmpstate].numelts; j++) {
      temp = (*convmap)[tmpstate].next[j];
      if ((*t3)[*s3].numtimer == (*t3)[temp].numtimer) { 
	 ok = !(memcmp((*t3)[*s3].ntimer, (*t3)[temp].ntimer, 
		       sizeof(timer_info) * (*t3)[*s3].numtimer));
	 if (ok) {
	    exstate = (*convmap)[tmpstate].next[j];
	    break;
	 }
      }
   }
   tmp = &(*t3)[state];
   tmp->next = (tran_node*) realloc(tmp->next, 
				    sizeof(tran_node) * ++(tmp->numelts));
   if (label == TICK) {
      if (ok == false) {
	 addordlist1(label, *s3, &tmp->next, tmp->numelts - 1, &ok1);
	 addpart(*s3, &(*convmap)[tmpstate].next, 
		 (*convmap)[tmpstate].numelts, &ok);
	 if (ok) (*convmap)[tmpstate].numelts++;
	 (*s3)++;
      } else {
	 addordlist1(label, exstate, &tmp->next, tmp->numelts - 1, &ok1);
	 free((*t3)[*s3].nstinfo);
	 free((*t3)[*s3].ntimer);
      }
   } else {
      tmp->next[tmp->numelts-1].data1 = label;
      if (ok == false) {
	 tmp->next[tmp->numelts-1].data2 = *s3;
	 addpart(*s3, &(*convmap)[tmpstate].next, 
		 (*convmap)[tmpstate].numelts, &ok);
	 if (ok) (*convmap)[tmpstate].numelts++;
	 (*s3)++;
      } else {
	 tmp->next[tmp->numelts-1].data2 = exstate;
	 free((*t3)[*s3].nstinfo);
	 free((*t3)[*s3].ntimer);
      }
   }
}

/* Get forcible activities */
void get_aforcible(INT_T s_list, INT_T *list, INT_T *s_flist,  INT_T **flist)
{
   char    ch;
   int     row, col, forcible;

   if (s_list > 0) {
      create_forcible(list, s_list);
      do {
	 col = _wherex();
	 row = _wherey();
	 if (col >= 75) {
	    move(row+1,0);
	    col = 0;
	    row++;
	 }
	 if (_wherey() > 21) {
	    clear();
	    create_forcible(list, s_list);
	    println();
	    println();
	    esc_footer();
	    col = _wherex();
	    row = _wherey();
	 }
	 
	 forcible = readcheckint(&ch, -1, MAX_TRANSITIONS, s_list, list);
	 if (ch == CEsc) {
	    quit = true;
	    return;
	 }
	 if (forcible != -1) {
	    forcible = (INT_T) forcible;
	    /* create unordered list of forcible events*/
	    (*flist) = (INT_T*) realloc((*flist),++(*s_flist) * sizeof(INT_T));
	    (*flist)[(*s_flist)-1] = forcible;
	 }

	 if (col+10 >= 75) {
	    move(row+1,0);
	    col = 0;
	    row++;
	 } else {
	    move(row, col+10);
	 }
      } while (forcible != -1);
      /* sort forcible list*/
      if (*s_flist > 0) {
	 qsort(*flist, *s_flist, sizeof(INT_T), cmp_intt);
      }
   }
}

void create_r(state_node **t1, INT_S *s1, INT_T **t2,  INT_S *s2)
{
   INT_T   s_list, *list, s_flist, *flist;
   INT_S   init;

   s_flist = 0;
   flist = NULL;

   clear();
   create_header();
   refresh();

   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, true);
   if (quit) return;

   create_common(t1, s1, 0);
   if (quit) return;

   /* get list of all used transitions*/
   s_list = 0;
   gentranlist(*s1, *t1, &s_list, &list);
   get_forcible(s_list, list, &s_flist, &flist);
   if (quit) return;
   merge_forcible(s_flist, flist, s2, t2);

   /* Check for non-determinism */
   check_determinism(*t1, *s1, name1, &quit, false);
   if (quit) return;

   init = 0L;
   if (mem_result != 1);
      filetds(name1, *s1, init, *t1, *s2, *t2);
   refresh();
   echo_save(name1);
}

/* create an activity graph */
void create_ar(state_node **t1, INT_S *s1, timed_event **tbl, INT_T *s_tbl)
{
   INT_S   init;
   INT_T   *list, s_list;
   INT_T   s_flist, *flist;

   flist = NULL;
   s_flist = 0;

   clear();
   create_header();
   refresh();

   quit = getname("Enter name of ADS ...  ", EXT_ADS, name1, fname1, true);
   if (quit) return;

   create_common(t1, s1, 1);

   /* get transition list */
   s_list = 0;
   gentranlist(*s1, *t1, &s_list, &list);
   get_timebounds(s_list, list, s_tbl, tbl);
   if (quit) return;
   get_aforcible(s_list, list, &s_flist, &flist);
   if (quit) return;
   set_aforcible(s_flist, flist, s_tbl, tbl, true);

   /* Check for non-determinism */
   check_determinism(*t1, *s1, name1, &quit, false);
   if (quit) return;

   init = 0L;
   if (mem_result != 1);
      fileads(name1, *s1, init, *t1, *s_tbl, *tbl);
   refresh();
   echo_asave(name1);
}

void create_amakeit(state_node *t1, INT_S s1, timed_event *t2, INT_T s2) 
{
   FILE* out;
   INT_S i, j, size;
   INT_T k;
   int d;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = ACreate(%s", name1, name1);

   /* Mark list */
   size = num_mark_states(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[mark ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].marked) {
            fprintf(out, "%d", i);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = num_vocal_output(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[voc ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].vocal > 0) {
            fprintf(out, "[%ld,%d]", i, t1[i].vocal);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   if (s2 > 0) {
      fprintf(out, ",");
      fprintf(out, "[time bounds ");
      for (i=0; i < s2; i++) {
	 fprintf(out, "[%d,%d,%d]", t2[i].label, t2[i].low, t2[i].upper);
	 if (i < s2-1)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }
   

   /* Forcible list */
   size = num_forcible_events(t2, s2);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[forcible ");
      j = 0;
      for (i=0; i < s2; i++) {
         if (t2[i].forcible) {
            fprintf(out, "%d", t2[i].label);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = count_tran(t1, s1, &d, &d, &d);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[tran ");
      j = 0;
      for (i=0; i < s1; i++) {
         for (k=0; k < t1[i].numelts; k++) {
            fprintf(out, "[%ld,%d,%ld]", i, t1[i].next[k].data1,
                                            t1[i].next[k].data2);
            j++;
            if (j < size)
               fprintf(out, ",");
          }
      }
      fprintf(out, "]");
   }

   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)\n\n", s1, size);
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name1)+3);
}

void create_makeit(state_node *t1, INT_S s1, INT_T *t2, INT_S s2)
{
   FILE* out;
   INT_S i, j, size;
   INT_T k;
   int d;

   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   fprintf(out, "%s = Create(%s", name1, name1);

   /* Mark list */
   size = num_mark_states(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[mark ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].marked) {
            fprintf(out, "%d", i);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = num_vocal_output(t1, s1);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[voc ");
      j = 0;
      for (i=0; i < s1; i++) {
         if (t1[i].vocal > 0) {
            fprintf(out, "[%ld,%d]", i, t1[i].vocal);
            j++;
            if (j < size)
               fprintf(out, ",");
         }
      }
      fprintf(out, "]");
   }

   size = count_tran(t1, s1, &d, &d, &d);
   if (size > 0) {
      fprintf(out, ",");
      fprintf(out, "[tran ");
      j = 0;
      for (i=0; i < s1; i++) {
         for (k=0; k < t1[i].numelts; k++) {
            fprintf(out, "[%ld,%d,%ld]", i, t1[i].next[k].data1,
                                            t1[i].next[k].data2);
            j++;
            if (j < size)
               fprintf(out, ",");
          }
      }
      fprintf(out, "]");
   }

   /* Forcible list */
   if (s2 > 0) {
      fprintf(out, ",");
      fprintf(out, "[forcible ");
      j = 0;
      for (i=0; i < s2; i++) {
	 fprintf(out, "%d", t2[i]);
	 j++;
	 if (j < s2)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)\n\n", s1, size);
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name1)+3);
}

int ask_create_r()
{
   int option;
   char ch;
   INT_S s1, init, i; state_node *t1;
   
   s1 = 0; t1 = NULL;

   clear();
   create_header();
   esc_footer();
   refresh();

    println();
   printw("1. .TDS file (prompts user to enter TDS data fast and sequentially;"); println();
   printw("   any entry errors can be corrected later using Edit)"); println();
   println();
   printw("2. .ATS  file (provides user with TDS template for flexible ASCII"); println();
   printw("   text file editing)"); println();
   //println();
   //printw("3. .TDS  file (provides user with a DES)"); println();
   

   println();
   println();
   printw("Please choose Option 1, or 2 ....  ");

   option = readint(&ch, 1, 3);
   if (ch == CEsc)
   {
     quit = true;
     return 1;
   }

   if (option == 1)
      return 0;
      
    
    if(option == 3){
    	println();
   		println();
    	quit = getname("Enter name of DES ....  ", ".DES", name1, fname1, false);
   		if (quit) return 1;
   		
   		quit = getname("Enter name of TDS ...  ", EXT_DES, name2, fname2, true);
   		if (quit) return 1;
   		
   		//printw("test1\n");
    	//system("pause");
    	init = 0L;
    	getdes(name1, &s1, &init, &t1);
    	
    	//printw("test\n");
    	//system("pause");
    	for(i = 0; i < s1; i ++){
    		t1[i].nstinfo = NULL;
    		t1[i].ntimer = NULL;
    		t1[i].numtimer = 0;
		}
    	
    	init = 0L;
   		if (mem_result != 1)
      		filetds(name2, s1, init, t1, 0, NULL);
      	freedes(s1, &t1);
      	return 2;
    	
	}

   println();
   println();
   printw("Generate ATS file with template"); println();
   println();

   quit = getname("Enter name of ATS ....  ", EXT_ATS, name1, fname1, true);
   if (quit) return 1;

   generate_ats_file(fname1, name1);

   if (_wherey() > 17)
   {
      move(16,0); clrtoeol();
      move(17,0); clrtoeol();
      move(18,0); clrtoeol();
      move(19,0); clrtoeol();
      move(20,0); clrtoeol();
      move(21,0); clrtoeol();
      move(17,0);
   }
   println();
   printw("Now exit to OS, use your ASCII editor to complete the file"); println();
   printw("%s,", fname1); println();
   printw("return to TTCT, and use FD to convert"); println();
   printw("%s%s to %s%s", name1, EXT_ATS, name1, EXT_DES); println();
   user_pause();

   return 1;
}


int ask_create_ar()
{
   int option;
   char ch;

   clear();
   create_header();
   esc_footer();
   refresh();

   println();
   printw("1. .ADS file (prompts user to enter ADS data fast and sequentially;"); println();
   printw("   any entry errors can be corrected later using Edit)"); println();
   println();
   printw("2. .AAS  file (provides user with ADS template for flexible ASCII"); println();
   printw("   text file editing)"); println();

   println();
   println();
   printw("Please choose Option 1 or 2 ....  ");

   option = readint(&ch, 1, 2);
   if (ch == CEsc)
   {
     quit = true;
     return 1;
   }

   if (option == 1)
      return 0;

   println();
   println();
   printw("Generate AAS file with template"); println();
   println();

   quit = getname("Enter name of AAS ....  ", EXT_AAS, name1, fname1, true);
   if (quit) return 1;

   generate_aas_file(fname1, name1);

   if (_wherey() > 17)
   {
      move(16,0); clrtoeol();
      move(17,0); clrtoeol();
      move(18,0); clrtoeol();
      move(19,0); clrtoeol();
      move(20,0); clrtoeol();
      move(21,0); clrtoeol();
      move(17,0);
   }
   println();
   printw("Now exit to OS, use your ASCII editor to complete the file"); println();
   printw("%s,", fname1); println();
   printw("return to TTCT, and use FD to convert"); println();
   printw("%s%s to %s%s", name1, EXT_AAS, name1, EXT_ADS); println();
   user_pause();

   return 1;
}

void create_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1;
   INT_S s2;
   INT_S result = 0;

   t1 = NULL;
   t2 = NULL;
   s1 = 0;
   s2 = 0;

   result = ask_create_r();
   if (result == 0) {
   		create_r(&t1, &s1, &t2, &s2);
   } else
      quit = true;

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
        create_makeit(t1, s1, t2, s2);
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
}

/* create activity graph */
void create_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   if (ask_create_ar()) {
      quit = true;
   } else {
      create_ar(&t1, &s1, &t2, &s2);
   }

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
        create_amakeit(t1, s1, t2, s2);
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
}

void selfloop_header() {
   printw("SELFLOOP"); println();
   println();
   printw("TDS2 = SELFLOOP (TDS1, EVENT_LIST)"); println();
   println();
}

void selfloop_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2, 
		 timed_event **list, INT_T *slist, INT_T **flist, 
		 INT_T *s_flist)
{
   INT_S      init;
   INT_T      i, *tmplist, s_tmplist;
   short      sign_i;
   INT_B    ok;
   char       ch;
   int        row, col;

   tmplist = NULL;
   s_tmplist = 0;
   clear();
   selfloop_header();
   quit = getname("Enter name of ADS1 to be augmented ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   printw("Same name for ADS2?   (*y/n)   ");
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch);  println();
      println();
      quit = getname("Enter new name for ADS2 ...............  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   } else {
      strcpy(name2, name1);
      println();  println();
   }

   printw("Enter list of events to be adjoined.  Terminate list with -1.");
   println();  println();  tab(5);
   sign_i = 0;
   while (sign_i != -1) {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,5);
         col = 5;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         printw("Continue to enter list of events to be adjoined.  ");
         printw("Terminate list with -1.");
         println();
         println(); tab(5);
         esc_footer();
         col = _wherex();
         row = _wherey();
      }

      sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (sign_i != -1) {
         i = (INT_T) sign_i;
	 addordlist(i, &tmplist, s_tmplist, &ok);
	 if (ok) s_tmplist++;
      }
      move(row, col+7);
   }

   get_timebounds((INT_S) s_tmplist, tmplist, slist, list);
   if (quit) return;
   get_aforcible((INT_S) s_tmplist, tmplist, s_flist, flist); 
   if (quit) return;

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   gentran(s_tmplist, tmplist, *s1, *t1);
   if (*s1 > 0) {
      merge_aforcible(*slist, *list, s2, t2);
      set_aforcible(*s_flist, *flist, s2, t2, true);
   }

   move(23,0); clrtoeol(); refresh();

   if (mem_result != 1)
      fileads(name2, *s1, init, *t1, *s2, *t2);
   mark_stop_time();
}

void selfloop_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2, 
		INT_T **list, INT_T *slist, INT_T **flist, INT_T *s_flist)
{
   INT_S      init;
   INT_T      i, *tmplist, s_tmplist;
   short      sign_i;
   INT_B    ok;
   char       ch;
   int        row, col;

   tmplist = NULL;
   s_tmplist = 0;
   clear();
   selfloop_header();
   quit = getname("Enter name of TDS1 to be augmented ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   printw("Same name for TDS2?   (*y/n)   ");
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch);  println();
      println();
      quit = getname("Enter new name for TDS2 ...............  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   } else {
      strcpy(name2, name1);
      println();  println();
   }

   printw("Enter list of events to be adjoined (0=tick).  Terminate list with -1.");
   println();  println();  tab(5);
   sign_i = 0;
   while (sign_i != -1) {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,5);
         col = 5;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         printw("Continue to enter list of events to be adjoined.  ");
         printw("Terminate list with -1.");
         println();
         println(); tab(5);
         esc_footer();
         col = _wherex();
         row = _wherey();
      }

      sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (sign_i != -1) {
         i = (INT_T) sign_i;
         addordlist(i, list, *slist, &ok);
         if (ok) (*slist)++;
	 addordlist(i, &tmplist, s_tmplist, &ok);
	 if (ok) s_tmplist++;
      }
      move(row, col+7);
   }
   get_forcible((INT_S) s_tmplist, tmplist, s_flist, flist);
   if (quit) return;

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   merge_forcible(*s_flist, *flist, s2, t2);
   gentran(*slist, *list, *s1, *t1);

   move(23,0); clrtoeol(); refresh();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, *s2, *t2);
   mark_stop_time();
}

void selfloop_makeit(state_node *t1, INT_S s1, INT_T *list, INT_T slist, 
		     INT_T *flist, INT_T s_flist)
{
   FILE* out;
   INT_T i, j;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Selfloop(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
     fprintf(out, "%d", list[i]);
     if (i+1 < slist)
       fprintf(out, ",");
   }
   fprintf(out, "]");

   /* Forcible list */
   if (s_flist > 0) {
      fprintf(out, ",");
      fprintf(out, "[new forcible ");
      j = 0;
      for (i=0; i < s_flist; i++) {
	 fprintf(out, "%d", flist[i]);
	 j++;
	 if (j < s_flist)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void selfloop_amakeit(state_node *t1, INT_S s1, timed_event *list, 
		      INT_T slist, INT_T *flist, INT_T s_flist)
{
   FILE* out;
   INT_T i, j;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = ASelfloop(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
     fprintf(out, "%d", list[i].label);
     if (i+1 < slist)
       fprintf(out, ",");
   }

   if (slist > 0) {
      fprintf(out, ",");
      fprintf(out, "[new time bounds ");
      for (i=0; i < slist; i++) {
	 fprintf(out, "[%d,%d,%d]", list[i].label, list[i].low, list[i].upper);
	 if (i < slist-1)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Forcible list */
   if (s_flist > 0) {
      fprintf(out, ",");
      fprintf(out, "[new forcible ");
      j = 0;
      for (i=0; i < s_flist; i++) {
	 fprintf(out, "%d", flist[i]);
	 j++;
	 if (j < s_flist)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void selfloop_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2, s_flist; 
   INT_T slist, *flist;
   timed_event *list;

   t1 = NULL;
   t2 = NULL;
   s2 = 0;
   list = NULL; slist = 0;
   flist = NULL; s_flist = 0;

   selfloop_ar(&t1, &s1, &t2, &s2, &list, &slist, &flist, &s_flist);

   if (mem_result == 1) {
      mem_result = 0;   /* Reset memory result counter */
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        selfloop_amakeit(t1, s1, list, slist, flist, s_flist);
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
   free(list);
   free(flist);
}

void selfloop_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1;
   INT_S s2;
   INT_T *list, slist, s_flist, *flist;

   t1 = NULL;
   t2 = NULL;
   s2 = 0;
   list = NULL; slist = 0;
   flist = NULL; s_flist = 0;

   selfloop_r(&t1, &s1, &t2, &s2, &list, &slist, &flist, &s_flist);

   if (mem_result == 1) {
      mem_result = 0;   /* Reset memory result counter */
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        selfloop_makeit(t1, s1, list, slist, flist, s_flist);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
   free(list);
   free(flist);
}

void convert_header() {
   printw("CONVERT"); println();
   println();
   printw("TDS = TIMED_GRAPH (ADS)"); println();
   println();
}

void trim_header() {
   printw("TRIM"); println();
   println();
   printw("DES2 = TRIM (DES1)"); println();
   println();
}

void trim_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2)
{
   INT_S      init;
   char       ch;

   clear();
   trim_header();
   quit = getname("Enter name of ADS1 to be trimmed ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter)
         addch(ch); 
      println();
      println();
      quit = getname("Enter new name for ADS2 ....  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait..."); 
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   trima1(s1, t1, s2, t2);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      fileads(name2, *s1, init, *t1, *s2, *t2);

   mark_stop_time();
}

void trim_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S      init;
   char       ch;

   clear();
   trim_header();
   quit = getname("Enter name of TDS1 to be trimmed ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   printw("Assign new name to %s?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter)
         addch(ch); 
      println();
      println();
      quit = getname("Enter new name for TDS2 ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait..."); 
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   trim1(s1, t1, s2, t2);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, *s2, *t2);

   mark_stop_time();
}

void convert_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2, 
		state_node **t3, INT_S *s3, INT_T **t4, INT_T *s4)
{
   INT_S state;
   part_node *convmap;
   INT_T i, j, s_list, *list;
   INT_T tran_index;
   INT_B ok;
   INT_B preempt; 
   timed_event *teh;
   timer_info *tih;
   INT_S counter;
   INT_S oldstate, tmpstate;

   INT_S      init;
   char       ch;
   char longfilename[100];
   INT_B    flag;

   clear();
   convert_header();
   quit = getname("Enter name of ADS to be converted ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   printw("Assign new name to %s?   (y/*n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') || (ch == CEnter)) {
      println();  println();
      make_filename_ext(longfilename, name1, EXT_DES);
      if (exist(longfilename)) {
	 ring_bell();
	 overwriteYN(name1);
	 refresh();
	 ch = read_key();
	 if (ch == CEnter) {
	    println();
	 } else {
	    printw("%c", ch);
	    println();
	 }
	 println();
	 if (ch == CEsc) 
	    return;
	 if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) {
	    strcpy(name2, name1);
	    refresh();
	 } else {
	    quit = getname("Enter new name for TDS ....  ",
			   EXT_DES, name2, fname2, true);
	    if (quit) return;
	 }
      } else {
	 strcpy(name2, name1);
      }
   } else {
      addch(ch);  println();
      println();
      quit = getname("Enter new name for TDS ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   } 

   printw("Mark only default timers ?   (*y/n)   ");//Justin0622
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n')) {
      println();  println();
      flag = false;
   } else {
      flag = true;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait..."); 
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }


   *s3 = 0;
   *t3 = NULL;
   if (*s1 > 0) { 
      state = 0;
      *t3 = (state_node*) calloc(*s1,sizeof(state_node));
      counter = *s1;
      convmap = (part_node*) calloc(*s1,sizeof(part_node));
      
      /* Copy first state*/
      memcpy(*t3, *t1, sizeof(state_node));
      *s3 = 1;
      (*t3)[0].numtimer = 0;
      (*t3)[0].ntimer = NULL;
      (*t3)[0].nstinfo = (state_info*) calloc(1, sizeof(state_info));
      (*t3)[0].nstinfo[0].state = 0;
      (*t3)[0].next = NULL;
      (*t3)[0].numelts = 0;
      set_timer(&(*t3)[0].numtimer, &(*t3)[0].ntimer, (*t1)[0].numelts, 
		(*t1)[0].next, *s2, *t2, TICK);

      addpart(0, &convmap[0].next, convmap[0].numelts, &ok);
      if (ok) convmap[0].numelts++;
      
      while (state < *s3) {
	 preempt = false;
	 /*rely on ordered transition list*/
	 oldstate = (*t3)[state].nstinfo[0].state;
	 for (i = 0; i < (*t3)[state].numtimer; i++) {
	    tih = &(*t3)[state].ntimer[i]; 
	    find_timebounds(*s2, *t2, tih->num, &tran_index);
	    teh = &(*t2)[tran_index];
	    tmpstate = (*t1)[oldstate].next[i].data2;	 
	    if (((tih->value > 0) && (teh->upper != MAX_TIME) &&
		 (tih->value <= teh->upper - teh->low)) || 
		((tih->value == 0) && (teh->upper == MAX_TIME))) {
	       if (*s3 >= counter) {
		  counter += 10;
		  *t3 = (state_node*) realloc(*t3, sizeof(state_node)*counter);
	       } 
	       create_timed(*s1, *t1, *s2, *t2, &(*s3), &(*t3), oldstate, 
			    tmpstate, state, &convmap, tih->num, flag);
	    }	    
	    if ((tih->value == 0) && (teh->upper != MAX_TIME)) {
	       if (*s3 >= counter) {
		  counter += 10;
		  *t3 = (state_node*) realloc(*t3, sizeof(state_node)*counter);
	       } 
	       create_timed(*s1, *t1, *s2, *t2, &(*s3), &(*t3), oldstate, 
			    tmpstate, state, &convmap, tih->num, flag);
	       preempt = true;
	    }
	 }
	 if (preempt == false) {
	    if (*s3 >= counter) {
	       counter += 10;
	       *t3 = (state_node*) realloc(*t3, sizeof(state_node) * counter);
	    } 
	    tmpstate = oldstate;
	    create_timed(*s1, *t1, *s2, *t2, &(*s3), &(*t3), oldstate, 
			 tmpstate, state, &convmap, TICK, flag);
	 }
	 state++;
      }
      
      *t3 = (state_node*) realloc(*t3, sizeof(state_node) * (*s3));
      gentranlist(*s3, *t3, &s_list, &list);
      *s4 = 0;
      *t4 = NULL;
      *t4 = (INT_T*) calloc(*s2, sizeof(INT_T));
      /*rely on ordered lists*/
      i = j = 0;
      while ( (i < s_list) && (j < *s2)) {
	 if (list[i] == TICK) {
	    i++;
	    continue;
	 }
	 if (list[i] == (*t2)[j].label) {
	    if ((*t2)[j].forcible)
	       (*t4)[(*s4)++] = list[i];
	    i++;
	    j++;
	    continue;
	 } else {
	    j++;
	 }
      }
      *t4 = (INT_T*) realloc(*t4, sizeof(INT_T) * (*s4));
   } else {
      *s3 = 0;
      *t3 = NULL;
      *s4 = 0;
      *t4 = NULL;
   }
   
   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s3, init, *t3, *s4, *t4);

   mark_stop_time();
}

void trim_makeit(state_node *t1,
                 INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Trim(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void trim_amakeit(state_node *t1,
		  INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = ATrim(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void trim_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL;
   t2 = NULL;

   trim_ar(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        trim_amakeit(t1, s1);
        user_pause();
      }
   }
   
   echo_free();
   free(t2);
   freedes(s1, &t1);
}

void trim_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1;
   INT_S s2;

   t1 = NULL;
   t2 = NULL;

   trim_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        trim_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
}

void convert_amakeit(state_node *t1, INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Timed_Graph(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void convert_ap()
{
   state_node *t1, *t3;
   timed_event *t2;
   INT_T *t4;
   INT_S s1, s3;
   INT_T s2, s4;

   t1 = t3 = NULL;
   t2 = NULL;
   t4 = NULL;
   s1 = s3  = 0;
   s2 = s4 = 0;

   convert_ar(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        convert_amakeit(t3, s3);
        user_pause();
      }
   }
   
   echo_free();
   free(t2);
   free(t4);
   freedes(s1, &t1);
   freedes(s3, &t3);
}

INT_B chk_diff_forcible(INT_S s1, state_node *t1, INT_T s2, INT_T *t2,
			  INT_S s3, state_node *t3, INT_T s4, INT_T *t4)
{
   INT_T s_tmp1, *tmp1, s_tmp2, *tmp2;
   INT_T s_sub1, *sub1, s_sub2, *sub2;
   INT_T *tmp3, *tmp4;
   INT_S s_tmp3, s_tmp4;
   
   gentranlist(s1, t1, &s_tmp1, &tmp1);
   gentranlist(s3, t3, &s_tmp2, &tmp2);
   gensublist(s_tmp1, tmp1, s_tmp2, tmp2, &s_sub1, &sub1, &s_sub2, &sub2);
   
   tmp3 = (INT_T*) malloc(s2 * sizeof(INT_T));
   memcpy(tmp3, t2, s2 * sizeof(INT_T));
   s_tmp3 = s2;
   tmp4 = (INT_T*) malloc(s4 * sizeof(INT_T));
   memcpy(tmp4, t4, s4 * sizeof(INT_T));
   s_tmp4 = s4;
   remove_alt_forcible(s_sub1, sub1, &s_tmp3, &tmp3);
   remove_alt_forcible(s_sub2, sub2, &s_tmp4, &tmp4);
   
   /*rely on ordered lists*/
   if (s_tmp3 == s_tmp4) { 
      if (memcmp(tmp3, tmp4, s_tmp3 * sizeof(INT_T)) == 0) {
	 return false;
      } else {
	 return true;
      }
   }
   return true;
}

INT_B chk_diff_aforcible(INT_S s1, state_node *t1, INT_T s2, timed_event *t2,
			   INT_S s3, state_node *t3, INT_T s4, timed_event *t4)
{
   INT_T s_tmp1, *tmp1, s_tmp2, *tmp2;
   INT_T s_sub1, *sub1, s_sub2, *sub2;
   INT_T *tmp3, *tmp4;
   INT_S s_tmp3, s_tmp4;
   INT_T i;

   gentranlist(s1, t1, &s_tmp1, &tmp1);
   gentranlist(s3, t3, &s_tmp2, &tmp2);
   gensublist(s_tmp1, tmp1, s_tmp2, tmp2, &s_sub1, &sub1, &s_sub2, &sub2);

   tmp3 = NULL;
   s_tmp3 = 0;
   for (i = 0; i < s2; i++) {
      if (t2[i].forcible) {
	 tmp3 = (INT_T*) realloc(tmp3, ++s_tmp3 * sizeof(INT_T));
	 tmp3[s_tmp3 - 1] = t2[i].label;
      }
   }
   tmp4 = NULL;
   s_tmp4 = 0;
   for (i = 0; i < s4; i++) {
      if (t4[i].forcible) {
	 tmp4 = (INT_T*) realloc(tmp4, ++s_tmp4 * sizeof(INT_T));
	 tmp4[s_tmp4 - 1] = t4[i].label;
      }
   }
   
   remove_alt_forcible(s_sub1, sub1, &s_tmp3, &tmp3);
   remove_alt_forcible(s_sub2, sub2, &s_tmp4, &tmp4);
   
   /*rely on ordered lists*/
   if (s_tmp3 == s_tmp4) { 
      if (memcmp(tmp3, tmp4, s_tmp3 * sizeof(INT_T)) == 0) {
	 return false;
      } else {
	 return true;
      }
   }
   return true;
}

void comp_header()
{
   printw("COMP"); println();
   println();
   printw("ADS3 = COMP (ADS1, ADS2)"); println();
   println();
}

void sync_header()
{
   printw("SYNC"); println();
   println();
   printw("TDS3 = SYNC (TDS1, TDS2)"); println();
   println();
}

void sync_blockevents_display(
         state_node *t1,   INT_S s1,
         state_node *t2,   INT_S s2,
         state_node *t3,   INT_S s3,
         INT_T **be, INT_T *s_be)
{
   INT_T *e1 = NULL; INT_T s_e1 = 0;
   INT_T *e3 = NULL; INT_T s_e3 = 0;
   INT_S i;  INT_T j;
   INT_B ok;

   /* Collect all events of t1 = L1 */
   for (i=0; i < s1; i++)
     for (j=0; j < t1[i].numelts; j++)
     {
        addordlist(t1[i].next[j].data1, &e1, s_e1, &ok);
        if (ok) s_e1++;
     }

   /* Collect all events for t2+t1 = L1+L2 = L12 */
   for (i=0; i < s2; i++)
      for (j=0; j < t2[i].numelts; j++)
      {
         addordlist(t2[i].next[j].data1, &e1, s_e1, &ok);
         if (ok) s_e1++;
      }

   /* Collect all events for t3 = L3 */
   for (i=0; i < s3; i++)
      for (j=0; j < t3[i].numelts; j++)
      {
         addordlist(t3[i].next[j].data1, &e3, s_e3, &ok);
         if (ok) s_e3++;
      }

   /* D = L12-L3 */
   for (j=0; j < s_e1; j++)
     if (!inlist(e1[j], e3, s_e3))
     {
        addordlist(e1[j], be, *s_be, &ok);
        if (ok) (*s_be)++;
     }

   move(20, 0); clrtoeol();
   move(21, 0);
   printw("Events blocked in %s: ", name3);
   if (*s_be == 0)
   {
      printw("None.\n");
   }
   else if (*s_be >= 8)
   {
      printw("See MAKEIT.TXT file.\n");
   }
   else
   {
      printw("[");
      for (j=0; j < *s_be; j++)
      {
         printw("%3d", (*be)[j]);
         if (j+1 < *s_be)
            printw(",");
      }
      printw("]");
   }

   free(e1);
   free(e3);
}

void sync_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
            state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
	    state_node **t5, INT_S *s5, INT_T **t6, INT_S *s6,
            INT_T **be, INT_T *s_be)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   sync_header();
   quit = getname("Enter name of TDS1 ....  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ", EXT_DES, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of TDS3 ....  ", EXT_DES, name3, fname3, true);
   if (quit) return;

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   if (chk_diff_forcible(*s1, *t1, (INT_T)*s2, *t2, *s3, *t3, (INT_T)*s4, *t4)) {
      move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }

   sync2(*s1,*t1,*s2,*t2,*s3,*t3,*s4,*t4,s5,t5,s6,t6,&macro_ab,&macro_c);

   if (mem_result != 1)
   {
     /* Display list of blocking events */
     sync_blockevents_display(*t1, *s1, *t3, *s3, *t5, *s5,
                              be, s_be);
   }

   move(23,0); clrtoeol(); refresh();

   if (mem_result != 1)
      filetds(name3, *s5, init, *t5, *s6, *t6);

   free(macro_ab);
   free(macro_c);

   mark_stop_time();
}

void comp_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2,
	     state_node **t3, INT_S *s3, timed_event **t4, INT_T *s4,
	     state_node **t5, INT_S *s5, timed_event **t6, INT_T *s6)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   comp_header();
   quit = getname("Enter name of ADS1 ....  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of ADS2 ....  ", EXT_ADS, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of ADS3 ....  ", EXT_ADS, name3, fname3, true);
   if (quit) return;

   move(22,0); clrtoeol(); refresh();
   move(23,0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (getads(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   if (chk_diff_aforcible(*s1, *t1, *s2, *t2, *s3, *t3, *s4, *t4)) {
      move(15,0);
      printw("The forcible events of both ADS are not consistent !");
      println();
      printw("Please resolve !");
      quit = true;
      user_pause();
      return;
   }

   comp2(*s1,*t1,*s2,*t2,*s3,*t3,*s4,*t4,s5,t5,s6,t6,&macro_ab,&macro_c);

   move(23,0); clrtoeol(); refresh();

   if (mem_result != 1)
      fileads(name3, *s5, init, *t5, *s6, *t6);

   free(macro_ab);
   free(macro_c);

   mark_stop_time();
}

void comp_amakeit(state_node *t1, INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Comp(%s,%s)", name3, name1, name2);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void sync_makeit(state_node *t3, INT_S s3,
                 INT_T *be, INT_T s_be)
{
   FILE* out;
   int d;
   INT_T i;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Sync(%s,%s)", name3, name1, name2);
   fprintf(out, "  (%ld,%ld)  ", s3, count_tran(t3, s3, &d, &d, &d));

   fprintf(out, "Blocked_events = ");
   if (s_be == 0)
   {
      fprintf(out, "None  ");
   }
   else
   {
      fprintf(out, "[");
      for (i=0; i < s_be; i++) {
         fprintf(out, "%d", be[i]);
         if (i+1 < s_be)
            fprintf(out, ",");
      }
      fprintf(out, "]  ");
   }

   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void sync_p()
{
   state_node *t1, *t3, *t5;
   INT_T *t2, *t4, *t6;
   INT_S s1, s2, s3, s4, s5, s6;
   INT_T s_blockevents, *blockevents;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;
   s1 = s3 = s5 = 0;
   s2 = s4 = s6 = 0;
   s_blockevents = 0; blockevents = NULL;

   sync_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6,
          &blockevents, &s_blockevents);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        sync_makeit(t5, s5,
                    blockevents, s_blockevents);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
   free(t2);
   free(t4);
   free(t6);
   free(blockevents);
}

/* build the composition of two ADS */
void comp_ap()
{
   state_node *t1, *t3, *t5;
   timed_event *t2, *t4, *t6;
   INT_S s1, s3, s5;
   INT_T s2, s4, s6;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;

   comp_ar(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        comp_amakeit(t5, s5);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
   free(t2);
   free(t4);
   free(t6);
}

void meet_header()
{
   printw("MEET"); println();
   println();
   printw("TDS3 = MEET (TDS1, TDS2)"); println();
   println();
}

void meet_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
            state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
	    state_node **t5, INT_S *s5, INT_T **t6, INT_S *s6)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;
   INT_T  s_list, *list;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   meet_header();
   quit = getname("Enter name of TDS1 ....  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ", EXT_DES, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of TDS3 ....  ", EXT_DES, name3, fname3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   if (chk_diff_forcible(*s1, *t1, (INT_T)*s2, *t2, *s3, *t3, (INT_T)*s4, *t4)) {
      move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }

   meet2(*s1,*t1,*s3,*t3,s5,t5,&macro_ab,&macro_c);
   
   gentranlist(*s5, *t5, &s_list, &list);
   *s6 = *s2;
   *t6 = (INT_T*) calloc(*s2,sizeof(INT_T));
   memcpy(*t6, *t2, sizeof(INT_T) * *s2);
   remove_forcible(s6, t6, s_list, list);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name3, *s5, init, *t5, *s6, *t6);

   free(macro_ab);
   free(macro_c);

   mark_stop_time();
}

void meet_makeit(state_node *t3,
                 INT_S s3)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Meet(%s,%s)", name3, name1, name2);
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3, &d, &d, &d));
   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void meet_p()
{
   state_node *t1, *t3, *t5;
   INT_T *t2, *t4, *t6;
   INT_S s1, s2, s3, s4, s5, s6;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;

   meet_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        meet_makeit(t5, s5);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
   free(t2);
   free(t4);
   free(t6);
}

void supcon_header()
{
   printw("SUPCON"); println();
   println();
   printw("TDS3 = SUPCON (TDS1, TDS2)"); println();
   println();
}

void supcon_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
              state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
	      state_node **t5, INT_S *s5, INT_T **t6, INT_S *s6)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;
   INT_T  s_list, *list;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   supcon_header();
   quit = getname("Enter name of plant generator TDS1 .............  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of legal language generator TDS2 ....  ",
                  EXT_DES, name2, fname2, false);
   if (quit) return;

   printw("Enter name of supremal"); println();
   quit = getname("  controllable sublanguage generator TDS3 ......  ",
                   EXT_DES, name3, fname3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   if (chk_diff_forcible(*s1, *t1, (INT_T)*s2, *t2, *s3, *t3, (INT_T)*s4, *t4)) {
      move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }

   meet2(*s1,*t1,*s3,*t3,s5,t5,&macro_ab,&macro_c);

   gentranlist(*s5, *t5, &s_list, &list);
   *s6 = *s2;
   *t6 = (INT_T*) calloc(*s2,sizeof(INT_T));
   memcpy(*t6, *t2, sizeof(INT_T) * *s2);
   remove_forcible(s6, t6, s_list, list);

   freedes(*s3,t3); *t3 = NULL;
   trim2(s5,t5,s6,t6,macro_c);

   shave1(*s1,*t1,*s2,*t2,s5,t5,s6,t6,macro_c);

   /* if state_info available, copy it */
   if (*s1 > 0 && (*t1)[0].nstinfo != NULL) 
      cp_tim_info(*s1,*t1,s5,t5,macro_c);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name3, *s5, init, *t5, *s6, *t6);

   if (macro_ab != NULL) free(macro_ab);
   if (macro_c != NULL) free(macro_c);

   mark_stop_time();
}

void supcon_makeit(state_node *t3,
                   INT_S s3)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Supcon(%s,%s)", name3, name1, name2);
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3, &d, &d, &d));
   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void supcon_p()
{
   state_node *t1, *t3, *t5;
   INT_T *t2, *t4, *t6;
   INT_S s1, s2, s3, s4, s5, s6;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;

   supcon_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        supcon_makeit(t5, s5);
        user_pause();
      }
   }

   echo_free();
   if (t1 != NULL) freedes(s1, &t1);
   if (t3 != NULL) freedes(s3, &t3);
   if (t5 != NULL) freedes(s5, &t5);
   if (t2 != NULL) free(t2);
   if (t4 != NULL) free(t4);
   if (t6 != NULL) free(t6);
}

void mutex_aheader()
{
   printw("MUTEX"); println();
   println();
   printw("ADS3 = MUTEX (ADS1, ADS2, EXCLUDED_STATE_PAIR_LIST)"); println();
   println();
}

void mutex_header()
{
   printw("MUTEX"); println();
   println();
   printw("TDS3 = MUTEX (TDS1, TDS2, EXCLUDED_STATE_PAIR_LIST)"); println();
   println();
}

void mutex_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
             state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
	     state_node **t5, INT_S *s5, INT_T **t6, INT_S *s6,
             state_pair **sp, INT_S *s_sp)
{
   INT_S  init;
   char   ch;
   INT_S  *macro_ab, *macro_c;
   INT_S i, j;
   INT_B ok;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   mutex_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                  EXT_DES, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of TDS3 ....  ",
                   EXT_DES, name3, fname3, true);
   if (quit) return;

   println();
   printw("Enter list of excluded state pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
         clear();
         mutex_header();
         printw("Continue to enter list of excluded state pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
      }

      i = (INT_S) readint(&ch, -1, MAX_STATES);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(15);
      j = (INT_S) readint(&ch, -1, MAX_STATES);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   /* Do work here */

   if (chk_diff_forcible(*s1, *t1, (INT_T)*s2, *t2, *s3, *t3, (INT_T)*s4, *t4)) {
      move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }

   sync2(*s1,*t1,*s2,*t2,*s3,*t3,*s4,*t4,s5,t5,s6,t6,&macro_ab,&macro_c);
   free(macro_c);
   mutex1(s5,t5, (INT_T)*s6, *t6, *s1,*s3,macro_ab,*sp,*s_sp);
   reach(s5,t5,s6,t6);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name3, *s5, init, *t5, *s6, *t6);

   free(macro_ab);

   mark_stop_time();
}

void mutex_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2,
	      state_node **t3, INT_S *s3, timed_event **t4, INT_T *s4,
	      state_node **t5, INT_S *s5, timed_event **t6, INT_T *s6,
	      state_pair **sp, INT_S *s_sp)
{
   INT_S  init;
   char   ch;
   INT_S  *macro_ab, *macro_c;
   INT_S i, j;
   INT_B ok;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   mutex_aheader();
   quit = getname("Enter name of ADS1 ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of ADS2 ....  ",
                  EXT_ADS, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of ADS3 ....  ",
                   EXT_ADS, name3, fname3, true);
   if (quit) return;

   println();
   printw("Enter list of excluded state pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
         clear();
         mutex_aheader();
         printw("Continue to enter list of excluded state pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
      }

      i = (INT_S) readint(&ch, -1, MAX_STATES);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(15);
      j = (INT_S) readint(&ch, -1, MAX_STATES);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (getads(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   /* Do work here */

   if (chk_diff_aforcible(*s1, *t1, *s2, *t2, *s3, *t3, *s4, *t4)) {
      move(15,0);
      printw("The forcible events of both ADS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }

   comp2(*s1,*t1,*s2,*t2,*s3,*t3,*s4,*t4,s5,t5,s6,t6,&macro_ab,&macro_c);
   free(macro_c);
/* has to be fixed   mutex1(s5,t5, *s6, *t6, *s1,*s3,macro_ab,*sp,*s_sp);*/
   areach(s5,t5,s6,t6);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      fileads(name3, *s5, init, *t5, *s6, *t6);

   free(macro_ab);

   mark_stop_time();
}

void mutex_amakeit(state_node *t3,
                  INT_S s3,
                  state_pair* sp,
                  INT_S s_sp)
{
   FILE* out;
   INT_S i;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = AMutex(%s,%s,[", name3, name1, name2);
   for (i=0; i < s_sp; i++) {
     fprintf(out, "[%ld,%ld]", sp[i].data1, sp[i].data2);
     if (i+1 < s_sp)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3, &d, &d, &d));
   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name3)+3);
}

void mutex_makeit(state_node *t3,
                  INT_S s3,
                  state_pair* sp,
                  INT_S s_sp)
{
   FILE* out;
   INT_S i;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Mutex(%s,%s,[", name3, name1, name2);
   for (i=0; i < s_sp; i++) {
     fprintf(out, "[%ld,%ld]", sp[i].data1, sp[i].data2);
     if (i+1 < s_sp)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3, &d, &d, &d));
   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name3)+3);
}

void mutex_p()
{
   state_node *t1, *t3, *t5;
   INT_T *t2, *t4, *t6;
   INT_S s1, s2, s3, s4, s5, s6;
   state_pair *sp;
   INT_S s_sp;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;
   s_sp = 0; sp = NULL;

   mutex_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6,
	   &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        mutex_makeit(t5, s5, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free(sp);
   free(t2);
   free(t4);
   free(t6);
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
}

void mutex_ap()
{
   state_node *t1, *t3, *t5;
   timed_event *t2, *t4, *t6;
   INT_S s1, s3, s5;
   INT_T s2, s4, s6;
   state_pair *sp;
   INT_S s_sp;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;
   s_sp = 0; sp = NULL;
   s1 =  s3 = s5  = 0;
   s2 = s4 = s6 = 0;

   mutex_ar(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6,
	   &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        mutex_amakeit(t5, s5, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free(sp);
   free(t2);
   free(t4);
   free(t6);
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
}

void condat_header()
{
   printw("CONDAT"); println();
   println();
   printw("DAT3 = CONDAT (TDS1, TDS2)");
   println();
   println();
}

void condat_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
              state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
	      state_node **t5, INT_S *s5, INT_T **t6, INT_S *s6,
              state_node **t7, INT_S *s7)
{
   INT_S  init;
   INT_S  *macro_ab, *macro_c;
   INT_T  s_list, *list;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   condat_header();
   quit = getname("Enter name of plant generator TDS1 ......  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of supervisor TDS2 ...........  ",
                  EXT_DES, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of control data file DAT3 ....  ",
                   EXT_DAT, name3, fname3, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   if (chk_diff_forcible(*s1, *t1, (INT_T)*s2, *t2, *s3, *t3, (INT_T)*s4, *t4)) {
      move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }

   meet2(*s1,*t1,*s3,*t3,s5,t5,&macro_ab,&macro_c);

   //freedes(*s3, t3); *t3 = NULL;
   free(macro_ab);
   
   *s6 = *s2;
   *t6 = (INT_T*) calloc(*s2,sizeof(INT_T));
   memcpy(*t6, *t2, sizeof(INT_T) * *s2);

   gentranlist(*s5, *t5, &s_list, &list);
   remove_forcible(s6, t6, s_list, list);
    
   condat2(*t1,*s1,*s3,*t3,*s5,*t5,*s6,*t6,s7,t7,macro_c); // finds both disabled and forced events
   //condat1(*t1,*s1,*s3,*s5,*t5,*s6,*t6,s7,t7,macro_c);  // just finds the disbaled events
   
   
   freedes(*s3, t3); *t3 = NULL;
   
   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name3, *s7, -1L, *t7, 0, NULL);

   free(macro_c);

   mark_stop_time();
}

void condat_makeit(state_node *t1, INT_S s1)
{
   FILE* out;
   int d;
   INT_S size;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Condat(%s,%s)", name3, name1, name2);

   size = count_tran(t1, s1, &d, &d, &d);
   if (compute_controllable(t1, s1))
      fprintf(out, "  Controllable.");
   else
      fprintf(out, "  Uncontrollable.");

   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void condat_p()
{
   state_node *t1, *t3, *t5, *t7;
   INT_T *t2, *t4, *t6;
   INT_S s1, s2, s3, s4, s5, s6, s7;

   t1 = t3 = t5 = t7 = NULL;
   t2 = t4 = t6 = NULL;
   s1 = s2 = s3 = s4 = s5 = s6 = s7 = 0;

   condat_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6,
	    &t7, &s7);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        condat_makeit(t7, s7);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   free(t4);
   free(t6);
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
   freedes(s7, &t7);
}

void minstate_aheader() {
   printw("MINSTATE"); println();
   println();
   printw("ADS2 = MINSTATE (ADS1)"); println();
   println();
}

void minstate_header() {
   printw("MINSTATE"); println();
   println();
   printw("TDS2 = MINSTATE (TDS1)"); println();
   println();
}

void minstate_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S      init;
   char       ch;

   clear();
   minstate_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   printw("Assign new name to %s ? (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter)
         addch(ch);  
      println();
      println();
      quit = getname("Enter name of TDS2 ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2 ,t2) == false) {
      quit = true;
      return;
   }

   reach(s1, t1, s2, t2);
   minimize(s1, t1);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, *s2, *t2);

   mark_stop_time();
}

void minstate_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2)
{
   INT_S      init;
   char       ch;

   clear();
   minstate_aheader();
   quit = getname("Enter name of ADS1 ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   printw("Assign new name to %s ? (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      strcpy(name2, name1);
      println();  println();
   } else {
      if (ch != CEnter)
         addch(ch);
      println();
      println();
      quit = getname("Enter name of ADS2 ....  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2 ,t2) == false) {
      quit = true;
      return;
   }

   areach(s1, t1, s2, t2);
   minimize(s1, t1);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      fileads(name2, *s1, init, *t1, *s2, *t2);

   mark_stop_time();
}

void minstate_amakeit(state_node *t1,
		      INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = AMinstate(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void minstate_makeit(state_node *t1,
                     INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Minstate(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void minstate_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;

   minstate_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        minstate_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
}

void minstate_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;
   
   minstate_ar(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        minstate_amakeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
}

void complement_aheader() {
   printw("COMPLEMENT"); println();
   println();
   printw("ADS2 = COMPLEMENT (ADS1, LIST)"); println();
   println();
}

void complement_header() {
   printw("COMPLEMENT"); println();
   println();
   printw("TDS2 = COMPLEMENT (TDS1, LIST)"); println();
   println();
}

void complement_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
                  INT_T **list, INT_T *slist, INT_T **flist, INT_T *s_flist)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B    ok;
   char       ch;
   int        row, col;

   clear();
   complement_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                  EXT_DES, name2, fname2, true);
   if (quit) return;

   printw("Compute complement using event labels of TDS1 only? (*y/n)  ");
   refresh();
   ch = read_key();
   if (ch == CEsc) {
     quit = true;
     return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch); println(); println();
      printw("Enter auxiliary LIST of event labels not in TDS1;"); println();
      printw("type -1 to quit:");  println();
      println();  tab(5);

      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           complement_header();
           printw("Continue to enter auxilary LIST");
           printw("of event labels not in TDS1;"); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, list, *slist, &ok);
           if (ok) (*slist)++;
        }
        move(row, col+7);
      }
   }
   get_forcible((INT_S) *slist, *list, s_flist, flist);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   merge_forcible(*s_flist, *flist, s2, t2);
 
   complement1(s1, t1, *slist, *list);
   reach(s1, t1, s2, t2);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, *s2, *t2);

   mark_stop_time();
}

void complement_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2,
		   timed_event **list, INT_T *slist, INT_T **flist, 
		   INT_T *s_flist)
{
   INT_S      init;
   INT_T      i, *tmplist, s_tmplist;
   short      sign_i;
   INT_B    ok;
   char       ch;
   int        row, col;

   tmplist = NULL;
   s_tmplist = 0;
   clear();
   complement_aheader();
   quit = getname("Enter name of ADS1 ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of ADS2 ....  ",
                  EXT_ADS, name2, fname2, true);
   if (quit) return;

   printw("Compute complement using event labels of ADS1 only? (*y/n)  ");
   refresh();
   ch = read_key();
   if (ch == CEsc) {
     quit = true;
     return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch); println(); println();
      printw("Enter auxiliary LIST of event labels not in ADS1;"); println();
      printw("type -1 to quit:");  println();
      println();  tab(5);

      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           complement_aheader();
           printw("Continue to enter auxilary LIST");
           printw("of event labels not in ADS1;"); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, &tmplist, s_tmplist, &ok);
           if (ok) s_tmplist++;
        }
        move(row, col+7);
      }
   }

   get_timebounds((INT_S) s_tmplist, tmplist, slist, list);
   if (quit) return;
   get_aforcible((INT_S) s_tmplist, tmplist, s_flist, flist); 
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   merge_aforcible(*slist, *list, s2, t2);
   set_aforcible(*s_flist, *flist, s2, t2, true);

   complement1(s1, t1, s_tmplist, tmplist);
   areach(s1, t1, s2, t2);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      fileads(name2, *s1, init, *t1, *s2, *t2);

   mark_stop_time();
}

void complement_amakeit(state_node *t1, INT_S s1, timed_event *list, 
			INT_T slist, INT_T *flist, INT_T s_flist)
{
   FILE* out;
   INT_T i, j;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = AComplement(%s,", name2, name1);
   if (slist > 0)
      fprintf(out, "["); 
   for (i=0; i < slist; i++) {
     fprintf(out, "%d", list[i].label);
     if (i+1 < slist)
       fprintf(out, ",");
   }

   if (slist > 0) {
      fprintf(out, ",");
      fprintf(out, "[new time bounds ");
      for (i=0; i < slist; i++) {
	 fprintf(out, "[%d,%d,%d]", list[i].label, list[i].low, list[i].upper);
	 if (i < slist-1)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }

   /* Forcible list */
   if (s_flist > 0) {
      fprintf(out, ",");
      fprintf(out, "[new forcible ");
      j = 0;
      for (i=0; i < s_flist; i++) {
	 fprintf(out, "%d", flist[i]);
	 j++;
	 if (j < s_flist)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void complement_makeit(state_node *t1, INT_S s1, INT_T *list, INT_T slist,
		       INT_T *flist, INT_T s_flist)
{
   FILE* out;
   INT_T i, j;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Complement(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
     fprintf(out, "%d", list[i]);
     if (i+1 < slist)
       fprintf(out, ",");
   }

   /* Forcible list */
   if (s_flist > 0) {
      fprintf(out, ",");
      fprintf(out, "[new forcible ");
      j = 0;
      for (i=0; i < s_flist; i++) {
	 fprintf(out, "%d", flist[i]);
	 j++;
	 if (j < s_flist)
	    fprintf(out, ",");
      }
      fprintf(out, "]");
   }
   fprintf(out, ")");

   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void complement_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;
   INT_T *list, slist, s_flist, *flist;

   t1 = NULL;
   t2 = NULL;
   list = NULL; slist = 0;
   flist = NULL; s_flist = 0;

   complement_r(&t1, &s1, &t2, &s2, &list, &slist, &flist, &s_flist);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        complement_makeit(t1, s1, list, slist, flist, s_flist); 
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
   free(flist);
   free(list);
}

void complement_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T slist, s_flist, *flist, s2;
   timed_event *list;

   t1 = NULL;
   t2 = NULL;
   list = NULL; slist = 0;
   flist = NULL; s_flist = 0;
   s1 = s2 = 0;

   complement_ar(&t1, &s1, &t2, &s2, &list, &slist, &flist, &s_flist);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        complement_amakeit(t1, s1, list, slist, flist, s_flist);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
   free(flist);
   free(list);
}

void isomorph_header() {
   printw("ISOMORPH"); println();
   println();
   printw("ISOMORPH (TDS1, TDS2)"); println();
   println();
}

void isomorph_aheader() {
   printw("ISOMORPH"); println();
   println();
   printw("ISOMORPH (ADS1, ADS2)"); println();
   println();
}

void printlist1(INT_S s1,
                state_node *t1,
                INT_B *flag,
                INT_S *mapState)
{
   INT_S i;
   int   ytop1, ytop2, windowheight, temp;
   char  ch;

   if (s1 == 0) return;

   ytop1 = _wherey();
   windowheight = 23 - ytop1;
   for (i=0; i < s1; i++) {
     if (mapState[i] != i) {
       *flag = false;
       ytop2 = _wherey() - ytop1 - 1;
       if (ytop2 > windowheight - 3) {
          move(windowheight+ytop1, 0);
          printw("Press <Enter> to page corresponding states or <ESC> to return  ");
          refresh();
          do {
             ch = read_key();
          } while ( (ch != CEnter) && (ch != CEsc) );

          for (temp=ytop1; temp < 25; temp++) {
             move(temp, 0);
             clrtoeol();
          }

          move(1+ytop1, 0);
       }
       printw("  [ %5d, %5d ]  ", i, mapState[i]);
     }
   }
   println();
}

void isomorph_makeit(INT_B is_iso,
                     INT_B identity,
                     INT_S *mapState,
                     INT_S s1)
{
   FILE* out;
   INT_S i;
   int   offset;
   INT_B firstElem;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   if (is_iso) {
     fprintf(out, "true");
     offset = 7;
   } else {
     fprintf(out, "false");
     offset = 8;
   }

   fprintf(out, " = Isomorph(%s,%s", name2, name1);
   if (identity) {
     fprintf(out, ";identity");
   } else {
     if (is_iso) {
        firstElem = true;
        fprintf(out, ";[");
        for (i=0; i < s1; i++) {
           if (mapState[i] != i) {
              if (firstElem) {
                 firstElem = false;
              } else {
                 fprintf(out, ",");
              }
              fprintf(out, "[%ld,%ld]", i, mapState[i]);
           }
        }
        fprintf(out, "]");
     }
   }
   fprintf(out, ")");

   appendTime(out, offset);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop(offset);
}

void isomorph_amakeit(INT_B is_iso,
		      INT_B identity,
		      INT_S *mapState,
		      INT_S s1)
{
   FILE* out;
   INT_S i;
   int   offset;
   INT_B firstElem;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;

   if (is_iso) {
     fprintf(out, "true");
     offset = 7;
   } else {
     fprintf(out, "false");
     offset = 8;
   }

   fprintf(out, " = AIsomorph(%s,%s", name2, name1);
   if (identity) {
     fprintf(out, ";identity");
   } else {
     if (is_iso) {
        firstElem = true;
        fprintf(out, ";[");
        for (i=0; i < s1; i++) {
           if (mapState[i] != i) {
              if (firstElem) {
                 firstElem = false;
              } else {
                 fprintf(out, ",");
              }
              fprintf(out, "[%ld,%ld]", i, mapState[i]);
           }
        }
        fprintf(out, "]");
     }
   }
   fprintf(out, ")"); 
   appendTime(out, offset);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop(offset);
}

void isomorph_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2,
		 state_node **t3, INT_S *s3, timed_event **t4, INT_T *s4)
{
   INT_S    init;
   INT_B  identity;
   INT_B  is_iso;
   INT_B  flag;
   INT_S    *mapState;
   int      x,y;

   mapState = NULL;
   clear();
   isomorph_aheader();
   quit = getname("Enter name of ADS1 ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of ADS2 ....  ",
                  EXT_ADS, name2, fname2, false);
   if (quit) return;

   x = _wherex();
   y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   if (getads(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   identity = false;
   is_iso   = false;
   flag     = false;

   if ( (strcmp(name1,name2) == 0) || ((*s1 == 0) && (*s2 == 0)) ) {
     is_iso   = true;
     identity = true;
   } else {
     /* Need some memory here - Allocate map state */
     mapState = (INT_S*) calloc(*s1, sizeof(INT_S));

     if ((*s1 != 0) && (mapState == NULL)) {
       mem_result = 1;
       return;
     }
     memset(mapState, -1, sizeof(INT_S)*(*s1));

     flag = true;
     isoa1(*s1, *s2, *s3, *s4, *t1, *t2, *t3, *t4, &flag, mapState);
     if (flag) is_iso = true;
   }

   if (mem_result == 1) {
      free(mapState);
      return;
   }

   mark_stop_time();

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   move(y,x);

   /* Output the answer */
   if (is_iso) {
      printw("%s and %s are isomorphic, under state correspondence",
              name1, name2);
      println();
      println();
      if (flag) {
         printlist1(*s1,*t1,&flag,mapState);
         if (flag) {
            printw("   IDENTITY"); println();
            identity = true;
         }
      } else {
         printw("   IDENTITY"); println();
      }
   } else {
      printw("%s and %s are not isomorphic",name1,name2); println();
   }

   isomorph_amakeit(is_iso, identity, mapState, *s1);
   move(23,0); clrtoeol();

   free(mapState);
}

void isomorph_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
                state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4)
{
   INT_S    init;
   INT_B  identity;
   INT_B  is_iso;
   INT_B  flag;
   INT_S    *mapState;
   int      x,y;

   mapState = NULL; 
   clear();
   isomorph_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                  EXT_DES, name2, fname2, false);
   if (quit) return;

   x = _wherex();
   y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   identity = false;
   is_iso   = false;
   flag     = false;

   if ( (strcmp(name1,name2) == 0) || ((*s1 == 0) && (*s2 == 0)) ) {
     is_iso   = true;
     identity = true;
   } else {
     /* Need some memory here - Allocate map state */
     mapState = (INT_S*) calloc(*s1, sizeof(INT_S));

     if ((*s1 != 0) && (mapState == NULL)) {
       mem_result = 1;
       return;
     }
     memset(mapState, -1, sizeof(INT_S)*(*s1));

     flag = true;
     iso1(*s1, *s2, *s3, *s4, *t1, *t2, *t3, *t4, &flag, mapState);
     if (flag) is_iso = true;
   }

   if (mem_result == 1) {
      free(mapState);
      return;
   }

   mark_stop_time();

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   move(y,x);

   /* Output the answer */
   if (is_iso) {
      printw("%s and %s are isomorphic, under state correspondence",
              name1, name2);
      println();
      println();
      if (flag) {
         printlist1(*s1,*t1,&flag,mapState);
         if (flag) {
            printw("   IDENTITY"); println();
            identity = true;
         }
      } else {
         printw("   IDENTITY"); println();
      }
   } else {
      printw("%s and %s are not isomorphic",name1,name2); println();
   }

   isomorph_makeit(is_iso, identity, mapState, *s1);
   move(23,0); clrtoeol();

   free(mapState);
}

void isomorph_p()
{
   state_node *t1, *t3;
   INT_T *t2, *t4;
   INT_S s1, s2, s3, s4;

   t1 = t3 = NULL;
   t2 = t4 = NULL;

   isomorph_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
	 user_pause();
      }
   }

   echo_free();
   free(t2);
   free(t4);
   freedes(s1, &t1);
   freedes(s3, &t3);
}

void isomorph_ap()
{
   state_node *t1, *t3;
   timed_event *t2, *t4;
   INT_S s1, s3;
   INT_T s2, s4;

   t1 = t3 = NULL;
   t2 = t4 = NULL;
   s1 =  s3  = 0;
   s2 = s4 = 0;

   isomorph_ar(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
	 user_pause();
      }
   }

   echo_free();
   free(t2);
   free(t4);
   freedes(s1, &t1);
   freedes(s3, &t3);
}

void nonconflict_header()
{
   printw("NONCONFLICT"); println();
   println();
   printw("NONCONFLICT (TDS1, TDS2)"); println();
   println();
}

void nonconflict_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
                   state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
                   state_node **t5, INT_S *s5,
                   INT_B *flag)
{
   INT_S   init;
   INT_S   *macro_ab, *macro_c;
   int     x,y;

   macro_ab = NULL;  macro_c  = NULL;

   clear();
   nonconflict_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                  EXT_DES, name2, fname2, false);
   if (quit) return;

   x = _wherex();
   y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   nc_meet2(*s1,*t1,*s3,*t3,s5,t5,&macro_ab,&macro_c);
   *flag = nonconflict(*s5,*t5);
   mark_stop_time();
   if (mem_result == 1) {
      if (macro_ab != NULL); free(macro_ab);
      if (macro_c != NULL); free(macro_c);
      return;
   }

   move(23,0); clrtoeol();
   move(y,x);
   println();
   println();
   if (*flag)
      printw("%s and %s are NONCONFLICTING", name1, name2);
   else
      printw("%s and %s are CONFLICTING!", name1, name2);
   println();

   free(macro_ab);
   free(macro_c);
}

void nonconflict_makeit(INT_B flag)
{
   FILE* out;
   int offset;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   if (flag) {
      fprintf(out, "true");
      offset = 7;
   } else {
      fprintf(out, "false");
      offset = 8;
   }
   fprintf(out, " = Nonconflict(%s,%s)", name1, name2);
   appendTime(out, offset);
   fprintf(out, "\n\n");
   fclose(out);
}

void nonconflict_p()
{
   state_node *t1, *t3, *t5;
   INT_T *t2, *t4;
   INT_S s1, s2, s3, s4, s5;
   INT_B flag;

   t1 = t3 = t5 = NULL;
   t2 = t4 = NULL;

   nonconflict_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &flag);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        nonconflict_makeit(flag);
	user_pause();
      }
   }

   echo_free();
   free(t2);
   free(t4);
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
}

void bfs_recode_aheader() {
   printw("REACH & BREADTH-FIRST SEARCH RECODE"); println();
   println();
   printw("ADS2 = RECODE (ADS1)"); println();
   println();
}

void bfs_recode_header() {
   printw("REACH & BREADTH-FIRST SEARCH RECODE"); println();
   println();
   printw("TDS2 = RECODE (TDS1)"); println();
   println();
}

void bfs_recode_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
                  INT_S *s3)
{
   INT_S      init;
   INT_S      *recode_array;

   recode_array = NULL;

   clear();
   bfs_recode_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                  EXT_DES, name2, fname2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   reach(s1, t1, s2, t2);
   b_recode(*s1,t1,s3,&recode_array);

   move(23,0); clrtoeol();

   if (mem_result != 1) {
      filetds(name2, *s3, init, *t1, *s2, *t2);
      *s1 = *s2;
   }

   free(recode_array);

   mark_stop_time();
}

void bfs_recode_ar(state_node **t1, INT_S *s1, timed_event **t2, INT_T *s2,
                  INT_S *s3)
{
   INT_S      init;
   INT_S      *recode_array;

   recode_array = NULL;

   clear();
   bfs_recode_aheader();
   quit = getname("Enter name of ADS1 ....  ",
                  EXT_ADS, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of ADS2 ....  ",
                  EXT_ADS, name2, fname2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   areach(s1, t1, s2, t2);
   b_recode(*s1,t1,s3,&recode_array);

   move(23,0); clrtoeol();

   if (mem_result != 1) {
      fileads(name2, *s3, init, *t1, *s2, *t2);
      *s1 = *s2;
   }

   free(recode_array);

   mark_stop_time();
}

void bfs_recode_amakeit(state_node *t1,
                       INT_S s1,
                       INT_S s2)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = ARecode(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s2, count_tran(t1, s2, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void bfs_recode_makeit(state_node *t1,
                       INT_S s1,
                       INT_S s2)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Recode(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s2, count_tran(t1, s2, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void bfs_recode_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2, s3;

   s1 = s2 = s3 = 0;
   t1 = NULL;
   t2 = NULL;

   bfs_recode_r(&t1, &s1, &t2, &s2, &s3);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        bfs_recode_makeit(t1, s1, s3);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
}

void bfs_recode_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1, s3;
   INT_T s2;

   s1 = s3 = 0;
   s2 = 0;
   t1 = NULL;
   t2 = NULL;

   bfs_recode_ar(&t1, &s1, &t2, &s2, &s3);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        bfs_recode_amakeit(t1, s1, s3);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
}

static int *dir_stack;
static int size_dir_stack;
static int total_dir;
static INT_B multiPage;
static int ii;
static char ch;

void directory_header(char *name)
{
   printw("FILES IN: %s", dos_uppercase(name));
   move(3,0);
}

#if !defined(__GO32__)

void directory_output_page_control(INT_B lastPage)
{
//   int k;

   continue_page(" D=PgDn  U=PgUp  Esc (Exit Directory)  ");

   do {
      refresh();
      ch = read_key();
      ch=toupper(ch);
      
      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                           sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               directory_header(path);
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0; 
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   directory_header(path);
}

INT_B display_directory_output(struct _finddata_t *namelist, int num_entries)
//INT_B display_directory_output(struct dirent *namelist, int num_entries)
{
   char buf[80];
   int max_str = 0;
   int k;

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; 
   size_dir_stack = 0;

   /* Either 1, 2 or 4 columns due to the length of the files */
   for (ii=0; ii < num_entries; ii++) {
      if (max_str < (int)strlen(namelist[ii].name))
         max_str = (int)strlen(namelist[ii].name);
   }
   max_str +=2;  /* Add two spaces for blanks */

   if (max_str < 20)
   {
      sprintf(buf, "%%-18s  ");
   }
   else if (max_str < 40)
   {
      sprintf(buf, "%%-38s  ");
   }
   else
   {
      sprintf(buf, "%%-78s  ");
   }

   ii = 0;
   do {
      while (ii < num_entries) {
        if (strlen(namelist[ii].name) > 80)
        {
           for (k=0; k < 80; k++)
              printw("%c", (namelist[ii].name)[k]);
        }
        else
           printw(buf, namelist[ii].name); 

        total_dir++;

        if (_wherey() >= 21) {
           directory_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     directory_output_page_control(true);
     if (quit) {
        free(dir_stack); dir_stack = NULL;
        return true;
     }
   } while ( (ch != CEnter) && (ch != CPgDn) );

   return false;
}

void directory_p()
{
  // struct dirent **namelist, **list;
   struct _finddata_t *namelist;//, *list;
   //struct _finddata_t*
   int num_entries;//, i;
   char dir[256];
   char ch;

   namelist = NULL;
   quit = false;

   strcpy(dir, path);
   strcat(dir, "\\*.*");

   //num_entries = scandir(dir, &namelist, NULL, alphasort);
   num_entries = scandir(dir, &namelist);

   clear();
   directory_header(path);

   if (num_entries) {
      display_directory_output(namelist, num_entries);
	  free(namelist);
      /* Free the entries */
     // for (i=0, list=namelist; i<num_entries; i++) {
     //    free(list);
     //    list++;
     // }
     // free(namelist);
   } else {
      move(7,0);
      printw("NO FILES IN %s", dos_uppercase(path));

      move(23,0); clrtoeol();
      printw("Press <Enter> to return to TTCT Procedures  ");
      refresh();
      do {
        ch = read_key();
      } while (ch != CEnter);
   }
}

#else    /* DOS */

void directory_output_page_control(INT_B lastPage)
{
   continue_page("D=PgDn  U=PgUp  Esc (Exit Directory)  ");

   do {
      refresh();
      ch = read_key();
      ch=toupper(ch);

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               directory_header(path);
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   directory_header(path);
}

INT_B display_directory_output(struct _finddata_t *namelist, int num_entries)
{
   char buf[80];
   int col_count=0;

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;
   ii = 0;
   
   do {
      while (ii < num_entries) {
        if (namelist[ii].attrib == _A_SUBDIR) {
           sprintf(buf, "[%s]", namelist[ii].name);
           printw("%-22s    ", buf);
           col_count++;
        } else {
           printw("%-22s    ", namelist[ii].name);
           col_count++;
        }
        total_dir++;
        if  (col_count >= 3 ) {
           println();
           col_count=0;
        }            

        if (_wherey() >= 22) {
           directory_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     directory_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   return false;
}

void directory_p()
{
   struct _finddata_t *namelist;
   int num_entries;
   char dir[100];
   char ch;

   namelist = NULL;
   quit = false;

   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);

   clear();
   directory_header(path);

   if (num_entries) {
      display_directory_output(namelist, num_entries);
      free(namelist);
   } else {
      move(7,0);
      printw("NO FILES IN %s", dos_uppercase(path));

      move(23,0); clrtoeol();
      printw("Press <Enter> to return to TTCT Procedures  ");
      refresh();
      do {
        ch = read_key();
      } while (ch != CEnter);
   }
}

#endif

void vocalize_header() {
   printw("VOCALIZE"); println();
   println();
   printw("TDS2 = VOCALIZE (TDS1, VOCAL_LIST)"); println();
   println();
}

void vocalize_list()
{
    printw("Enter list of triples [source state, event, vocal output]."); println();
    printw("To vocalize all instances of an event, enter * for Exit state."); println();
    printw("Press <Enter> after each element and quit with -1."); println();
    println();
}

void vocalize_r(state_node **t1,
                INT_S *s1,
                quad__t **list,
                INT_S *slist)
{
   INT_S      init;
   INT_S      i,j,ii;
   short      sign_i;
   INT_T      e;
   INT_V      v;
   INT_B    ok;
   char       ch;
   INT_S      s2;
   INT_T      *t2;
   INT_B    allstate, input_error;
   int        col, row, a;

   clear();
   vocalize_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname2, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                   EXT_DES, name2, fname2, true);
   if (quit) return;

   /* For this function, we load the DES file here */
   init = 0L;
   if (gettds(name1, s1, &init, t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   /* check if there are ticks in the structure and complain */
   if (chk_for_tick(s1, t1)) {
      printw("There are either TICKs in your TDS (operation not defined)");
      println();
      printw("or you used %d as event label which is reserved for TICK",TICK);
      println();
      printw("In the latter case you can use Convert to remap event labels.");
      free(t2);
      user_pause();
      quit = true;
      return;
   }
 
   clear();
   vocalize_header();
   vocalize_list();
   esc_footer();
   do  {
      if (_wherey() > 21) {
         col = _wherex(); row = _wherey()-1;
         move(23, 0); clrtoeol();
         move(24, 0);
         //println();//Justin0622
		 scroll_line();//Justin0622

         for (a=0; a < 8; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         vocalize_header();
         vocalize_list();
         esc_footer();
         move(row, col);
      }

      allstate = false;
      printw("Source state:  ");
      i = (INT_S) readintall(&ch, -1, (*s1)-1);

      if (ch == CEsc) {
          quit = true;
          return;
      }
    
      if (ch == '*') allstate = true;
      if (i == -1) break;

      tab(20);
      printw("Event:  ");
      sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (sign_i == -1) break;
      e = (INT_T) sign_i;

      tab(40);
      printw("Target state vocal output:  ");
      v = (INT_V) readint(&ch, -1, 99);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (v == -1) break;

      input_error = false;
      if (allstate) {
         if ( (e <= (INT_T) MAX_TRANSITIONS) &&
              ((10 <= v) && (v <= 99)) )
         {
             for (ii=0; ii < *s1 ; ii++)
             {
                 if (is_valid_transition(ii,e,&j,*t1, *s1))
                 {
                    add_quad(ii,e,j,v,list,*slist,&ok);
                    if (ok) (*slist)++;
                 }
             }
             println();
         } else {
             input_error = true;
         }
      } else {
         /* Filter errors */
         if ( ((0 <= i) && (i < (*s1) )) &&
              (e <= (INT_T) MAX_TRANSITIONS) &&
              ((10 <= v) && (v <= 99)) &&
             is_valid_transition(i,e,&j,*t1,*s1) ) {
             println();
             add_quad(i,e,j,v,list,*slist,&ok);
             if (ok) (*slist)++;
         } else {
             input_error = true;
         }
      }

      if (input_error)
      {
         if (_wherey() > 21) {
            clear();
            vocalize_header();
            vocalize_list();
            esc_footer();
            println();
         }
         ring_bell();
         println();
         println();
         printw("This entry is illegal; please reenter!"); println();
         println();

         if (_wherey() > 19) {
            println();
            println();
            move(22,0);
         }
      }
   } while(1);

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   /* Processing done here */
   mark_start_time();
   vocalize_des(t1,s1,list,slist);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, s2, t2);
   mark_stop_time();
   free(t2);
}

void vocalize_makeit(state_node *t1,
                     INT_S s1,
                     quad__t *list,
                     INT_S slist)
{
   FILE* out;
   INT_T i;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Vocalize(%s,[", name2, name1);
   for (i=0; i < slist; i++) {
     fprintf(out, "[%ld,%d,%ld]", list[i].a, list[i].b, list[i].c);
     if (i+1 < slist)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void vocalize_p()
{
   state_node *t1;
   INT_S s1;
   quad__t* list; INT_S slist;

   t1 = NULL;
   list = NULL; slist = 0;

   vocalize_r(&t1, &s1, &list, &slist);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        vocalize_makeit(t1, s1, list, slist);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   free(list);
}

void vocal_err_msg()
{
   move(10,0); clrtoeol();
   move(11,0); clrtoeol();
   move(12,0); clrtoeol();
   move(13,0); clrtoeol();
   move(14,0); clrtoeol();
   move(15,0); clrtoeol();
   move(10,0); clrtoeol();
   printw("_____________________________________________________________________________"); println();
   println();
   printw("        Sorry! Initial state 0 of TDS1 must be silent (output 0)."); println();
   println();
   printw("        Computation cancelled."); println();
   printw("_____________________________________________________________________________");
   println();
}

void outconsis_header() {
   printw("OUTCONSIS"); println();
   println();
   printw("TDS2 = OUTCONSIS (TDS1)"); println();
   println();
}

void outconsis_r(state_node **t1,
                 INT_S *s1)
{
   INT_S      init;
   INT_S      s2;
   INT_T      *t2;

   clear();
   outconsis_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                   EXT_DES, name2, fname2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   if (*s1 > 0) {
      if ((*t1)[0].vocal != 0) {
         vocal_err_msg();
         user_pause();
         quit = true;
         return;
      }
   }

   /* check if there are ticks in the structure and complain */
   if (chk_for_tick(s1, t1)) {
      move(15,0);
      printw("There are either TICKs in your TDS (operation not defined)");
      println();
      printw("or you used %d as event label which is reserved for TICK",TICK);
      println();
      printw("In the latter case you can use Convert to remap event labels.");
      free(t2);
      user_pause();
      quit = true;
      return;
   }

   outcon_des(t1,s1,&t2,&s2);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, s2, t2);

   mark_stop_time();
   free(t2);
}

void outconsis_makeit(state_node *t1,
                      INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Outconsis(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void outconsis_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;

   outconsis_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        outconsis_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void hiconsis_header() {
   printw("HICONSIS"); println();
   println();
   printw("TDS2 = HICONSIS (TDS1)"); println();
   println();
}

void hiconsis_r(state_node **t1,
                INT_S *s1)
{
   INT_S      init;
   INT_S      s2;
   INT_T      *t2;

   clear();
   hiconsis_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                   EXT_DES, name2, fname2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   if (*s1 > 0) {
      if ((*t1)[0].vocal != 0) {
         vocal_err_msg();
         user_pause();
         quit = true;
         return;
      }
   }

   /* check if there are ticks in the structure and complain */
   if (chk_for_tick(s1, t1)) {
      move(15,0);
      printw("There are either TICKs in your TDS (operation not defined)");
      println();
      printw("or you used %d as event label which is reserved for TICK",TICK);
      println();
      printw("In the latter case you can use Convert to remap event labels.");
      free(t2);
      user_pause();
      quit = true;
      return;
   }

   if (hiconsis_des(t1,s1,&t2,&s2) == true) {
      move(10,0); clrtoeol();
      move(11,0); clrtoeol();
      move(12,0); clrtoeol();
      move(13,0); clrtoeol();
      move(14,0); clrtoeol();
      move(15,0); clrtoeol();
      move(10,0); clrtoeol();
      printw("___________________________________________________________________________"); println();
      println();
      printw("               Sorry! Vocal output overflow."); println();
      println();
      printw("               Computation cancelled."); println();
      printw("___________________________________________________________________________"); println();
      user_pause();
      quit = true;
      return;
   }

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, s2, t2);

   mark_stop_time();
   free(t2);
}

void hiconsis_makeit(state_node *t1,
                     INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Hiconsis(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void hiconsis_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;

   hiconsis_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        hiconsis_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void higen_header() {
   printw("HIGEN"); println();
   println();
   printw("TDS2 = HIGEN (TDS1)"); println();
   println();
}

void higen_r(state_node **t1,
             INT_S *s1)
{
   INT_S      init;
   INT_T      *list, slist;
   INT_S      s2;
   INT_T      *t2;

   list = NULL; slist = 0;

   clear();
   higen_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                   EXT_DES, name2, fname2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   if (*s1 > 0) {
      if ((*t1)[0].vocal != 0) {
         vocal_err_msg();
         user_pause();
         quit = true;
         return;
      }
   }

   /* check if there are ticks in the structure and complain */
   if (chk_for_tick(s1, t1)) {
      move(15,0);
      printw("There are either TICKs in your TDS (operation not defined)");
      println();
      printw("or you used %d as event label which is reserved for TICK",TICK);
      println();
      printw("In the latter case you can use Convert to remap event labels.");
      free(t2);
      user_pause();
      quit = true;
      return;
   }

   higen_des(t1, s1, &list, &slist);

   /* Project the answer onto [0] */
/*   if (slist == 0) {
      reach(s1, t1);
      minimize(s1, t1);
   } else {
      project1(s1,t1,slist,list);
      if (*s1 > 1) {
         reach(s1, t1);
         minimize(s1,t1);
      }
   } */
   project0(s1,t1,&s2,&t2,slist,list); 

   free(list);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, s2, t2);
   mark_stop_time();
   free(t2);
}

void higen_makeit(state_node *t1,
                  INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Higen(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void higen_p()
{
   state_node *t1;
   INT_S s1;

   t1 = NULL;

   higen_r(&t1, &s1);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        higen_makeit(t1, s1);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void supnorm_header()
{
   printw("SUPNORM"); println();
   println();
   printw("TDS3 = SUPNORM (TDS1, TDS2, NULL_EVENT_LIST)"); println();
   println();
}

void supnorm_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
               state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
               state_node **t5, INT_S *s5, INT_T **t6, INT_S *s6,
               INT_T **list, INT_T *slist)
{
   INT_S  init;
   char   ch;
   short  sign_i;
   INT_T  i;
   int    row, col;
   INT_B ok;

   clear();
   supnorm_header();
   quit = getname("Enter name of legal language generator TDS1 ...  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of plant generator TDS2 ............  ",
                  EXT_DES, name2, fname2, false);
   if (quit) return;

   quit = getname("Enter name of TDS3 ....  ",
                   EXT_DES, name3, fname3, true);
   if (quit) return;

   printw("Enter list of event labels to be nulled by projection;"); println();
   printw("terminate list with -1."); println();
   println();  tab(5);
   sign_i = 0;
   while (sign_i != -1) {
      col = _wherex();
      row = _wherey();
      if (col >= 75) {
         move(row+1,5);
         col = 5;
         row++;
      }
      if (_wherey() > 21) {
         clear();
         supnorm_header();
         printw("Continue to enter list of event labels to be ");
         printw("nulled by projection;"); println();
         printw("terminate list with -1."); println();
         println(); tab(5);
         esc_footer();
         col = _wherex();
         row = _wherey();
      }

      sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (sign_i != -1) {
         i = (INT_T) sign_i;
         addordlist(i, list, *slist, &ok);
         if (ok) (*slist)++;
      }
      move(row, col+7);
   }
   println(); println();

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* check if there are ticks in the structure and complain */
   if (chk_for_tick(s1, t1)) {
      move(15,0);
      printw("There are either TICKs in your TDS (operation not defined)");
      println();
      printw("or you used %d as event label which is reserved for TICK",TICK);
      println();
      printw("In the latter case you can use Convert to remap event labels.");
      user_pause();
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s3, &init, t3, s4, t4) == false) {
      quit = true;
      return;
   }

   /* check if there are ticks in the structure and complain */
   if (chk_for_tick(s3, t3)) {
      printw("There are either TICKs in your TDS (operation not defined)");
      println();
      printw("or you used %d as event label which is reserved for TICK",TICK);
      println();
      printw("In the latter case you can use Convert to remap event labels.");
      quit = true;
      return;
   }

   suprema_normal(*t1, *s1, *t2, *s2, *t3, *s3, *t4, *s4, t5, s5, 
		  t6, s6, *list, *slist);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name3, *s5, init, *t5, *s6, *t6);
   mark_stop_time();
}

void supnorm_makeit(state_node *t3,
                    INT_S s3,
                    INT_T *sp,
                    INT_T s_sp)
{
   FILE* out;
   INT_S i;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Supnorm(%s,%s,[", name3, name1, name2);
   for (i=0; i < s_sp; i++) {
     fprintf(out, "%d", sp[i]);
     if (i+1 < s_sp)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3, &d, &d, &d));
   appendTime(out, (int)strlen(name3)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name3)+3);
}

void supnorm_p()
{
   state_node *t1, *t3, *t5;
   INT_T *t2, *t4, *t6;
   INT_S s1, s2, s3, s4, s5, s6;
   INT_T *sp;
   INT_T s_sp;

   t1 = t3 = t5 = NULL;
   t2 = t4 = t6 = NULL;
   s1 = s2 = s3 = s4 = s5 = s6 = 0;
   s_sp = 0; sp = NULL;

   supnorm_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &t5, &s5, &t6, &s6, 
	     &sp, &s_sp);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        supnorm_makeit(t5, s5, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s3, &t3);
   freedes(s5, &t5);
   free(t2);
   free(t4);
   free(t6);
}

void project_header() {
   printw("PROJECT"); println();
   println();
   printw("TDS2 = PROJECT (TDS1, NULL [or IMAGE])"); println();
   println();
}

void gen_complement_list(state_node *t1,
                         INT_S s1,
                         INT_T *imagelist, INT_T s_imagelist,
                         INT_T **list, INT_T *slist)
{
   INT_S i;
   INT_T j;
   INT_B ok;

   for (i=0; i < s1; i++)
   {
      for (j=0; j < t1[i].numelts; j++)
      {
         if (!inlist(t1[i].next[j].data1, imagelist, s_imagelist))
         {
            addordlist(t1[i].next[j].data1, list, *slist, &ok);
            if (ok) (*slist)++;
         }
      }
   }
}

void project_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
               INT_T **list, INT_T *slist,
               INT_T **imagelist, INT_T *s_imagelist,
               INT_B *null_flag)
{
   INT_S      init;
   INT_T      i;
   short      sign_i;
   INT_B    ok;
   char       ch;
   int        row, col;

   clear();
   project_header();
   quit = getname("Enter name of TDS1 to project .........  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 to project onto ....  ",
                   EXT_DES, name2, fname2, true);
   if (quit) return;

   if (_wherey() > 15) clear();

   println();
   printw("Enter either"); println();
   println();
   printw("  NULL (list of event labels erased by projection)"); println();
   println();
   printw("or"); println();
   println();
   printw("  IMAGE (event labels retained)"); println();
   println();

   do {
	   if (_wherey() > 20)
	   {
		   clear();
		   project_header();
		   esc_footer();
	   }    

	   printw("NULL/IMAGE ? (n/i) ");
	   refresh();
	   ch = read_key();
	   if (ch == CEsc) {
		   quit = true;
		   return;
	   }   

	   if (ch != CEnter) {
		   printw("%c", ch);
	   }
	   println();
	   println();
   } while (strchr(NULLCommandSet, ch) == NULL);

 /*  printw("NULL/IMAGE (n/i)  ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   addch(ch);
   println();
   println();
   if ( (ch == 'n') || (ch == 'N') ) {
      *null_flag = false;
   }*/

   if ((ch == 'N') || (ch == 'n'))
	   *null_flag = true;
   else
	   *null_flag = false;

   if (*null_flag)
   {
      printw("Enter list of event labels to be nulled by projection (Tick = 0);"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be nulled by projection (Tick = 0);"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
            quit = true;
            return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, list, *slist, &ok);
           if (ok) (*slist)++;
        }
        move(row, col+7);
     }
     println(); println();

   }
   else
   {

      printw("Enter list of event labels to be retained (Tick = 0);"); println();
      printw("terminate list with -1."); println();
      println();  tab(5);
      sign_i = 0;
      while (sign_i != -1) {
        col = _wherex();
        row = _wherey();
        if (col >= 75) {
           move(row+1,5);
           col = 5;
           row++;
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be retained (Tick = 0);"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }

        sign_i = (short) readint(&ch, -1, MAX_TRANSITIONS);
        if (ch == CEsc) {
           quit = true;
           return;
        }
        if (sign_i != -1) {
           i = (INT_T) sign_i;
           addordlist(i, imagelist, *s_imagelist, &ok);
           if (ok) (*s_imagelist)++;
         }
        move(row, col+7);
     }
     println(); println();

   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   if (!(*null_flag))
   {
      gen_complement_list(*t1, *s1,
                          *imagelist, *s_imagelist,
                          list, slist);
   }

   remove_alt_forcible(*slist, *list, s2, t2);

/*   if (*slist == 0) {
      reach(s1, t1);
      minimize(s1, t1);
   } else {
      project1(s1,t1,*slist,*list);
      if (*s1 > 1) {
         reach(s1, t1);
         minimize(s1,t1);
      }
   }
*/
   project0(s1,t1,s2,t2,*slist,*list);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s1, init, *t1, *s2, *t2);
   mark_stop_time();
}

void project_makeit(state_node *t1,
                    INT_S s1,
                    INT_T *list,
                    INT_T slist,
                    INT_T *imagelist,
                    INT_T s_imagelist,
                    INT_B null_flag
                   )
{
   FILE* out;
   INT_T i;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Project(%s,", name2, name1);

   if (null_flag)
   {
      fprintf(out, "Null[");
      for (i=0; i < slist; i++) {
        fprintf(out, "%d", list[i]);
        if (i+1 < slist)
          fprintf(out, ",");
      }
   }
   else
   {
      fprintf(out, "Image[");
      for (i=0; i < s_imagelist; i++) {
        fprintf(out, "%d", imagelist[i]);
        if (i+1 < s_imagelist)
          fprintf(out, ",");
      }
   }

   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void project_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;
   INT_T *list, slist;
   INT_B null_flag = true;
   INT_T *imagelist;
   INT_T s_imagelist;

   t1 = NULL;
   t2 = NULL;
   list = NULL; slist = 0;
   imagelist = NULL; s_imagelist = 0;

   project_r(&t1, &s1, &t2, &s2, &list, &slist, &imagelist, &s_imagelist, &null_flag);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        project_makeit(t1, s1, list, slist, imagelist, s_imagelist, null_flag);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
   free(list);
   free(imagelist);
}

void eventmap_header()
{
   printw("CONVERT"); println();
   println();
   printw("TDS2 = CONVERT (TDS1, EVENT_MAP_PAIR_LIST)"); println();
   println();
}

void eventmap_r(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2,
                state_node **t3, INT_S *s3, INT_T **t4, INT_S *s4,
                state_pair **sp, INT_S *s_sp, INT_T **flist, INT_T *s_flist)
{
   INT_S  init;
   char   ch;
   INT_S i, j;
   INT_B ok;
   INT_T *list;
   INT_T s_list;
   int   row, col, a;

   list = NULL; s_list = 0;

   clear();
   eventmap_header();
   quit = getname("Enter name of TDS1 ....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....  ",
                  EXT_DES, name2, fname2, true);
   if (quit) return;

   clear();
   eventmap_header();
   println();
   esc_footer();

   printw("Enter list of event label pairs."); println();
   printw("Press <Enter> after each element and quit with -1:"); println();
   println();
   i = 0;
   while (i != -1) {
      if (_wherey() > 21) {
/*         clear();
         eventmap_header();
         printw("Continue to enter list of event label pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
 */
         col = _wherex(); row = _wherey()-1;
         move(23,0); clrtoeol();
         move(24,0);
         //println();
		 scroll_line();//Justin0622

         for (a=0; a < 7; a++) {
            move(a,0); clrtoeol();
         }

         move(0,0);
         eventmap_header();
         printw("Continue to enter list of event label pairs."); println();
         printw("Press <Enter> after each element and quit with -1:"); println();
         println();
         esc_footer();
         move(row, col);
      }

      printw("Old value:  ");
      i = (INT_S) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (i == -1) break;

      tab(25);
      printw("New value:  ");
      j = (INT_S) readint(&ch, -1, MAX_TRANSITIONS);
      if (ch == CEsc) {
          quit = true;
          return;
      }
      if (j == -1) break;

      addstatepair(i, j, sp, *s_sp, &ok);
      if (ok) (*s_sp)++;

      println();
   }

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Do work here */
   eventmap_des(*t1,*s1,t3,s3,*sp,*s_sp,&list,&s_list,&ok);

   if (s_list != 0) project0(s3,t3,s4,t4,s_list,list);

   gentranlist(*s3, *t3, &s_list, &list);
   *s4 = *s2;
   *t4 = (INT_T*) calloc(*s2,sizeof(INT_T));
   memcpy(*t4, *t2, sizeof(INT_T) * *s2);
   remove_forcible(s4, t4, s_list, list);
/*   get_forcible(s_list, list, s4, t4, s_flist, flist);
   merge_forcible*/
   move(23,0); clrtoeol();
   free(list);

   if (mem_result != 1)
      filetds(name2, *s3, init, *t3, *s4, *t4);

   mark_stop_time();
}

void eventmap_makeit(state_node *t3,
                     INT_S s3,
                     state_pair* sp,
                     INT_S s_sp)
{
   FILE* out;
   INT_S i;
   int d;

   /* Write to a tempory file */
   out = fopen("tmp.$$$", "w");
   if (out == NULL) return;
   fprintf(out, "%s = Convert(%s,[", name2, name1);
   for (i=0; i < s_sp; i++) {
     fprintf(out, "[%ld,%ld]", sp[i].data1, sp[i].data2);
     if (i+1 < s_sp)
       fprintf(out, ",");
   }
   fprintf(out, "])");
   fprintf(out, "  (%ld,%ld)", s3, count_tran(t3, s3, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);

   /* Merge file into MAKEIT.TXT */
   mergeChop((int)strlen(name2)+3);
}

void eventmap_p()
{
   state_node *t1, *t3;
   INT_T *t2, *t4;
   INT_S s1, s2, s3, s4;
   state_pair *sp;
   INT_T s_flist, *flist;
   INT_S s_sp;

   t1 = t3 = NULL;
   t2 = t4 = NULL;
   s_sp = 0; sp = NULL;
   s_flist = 0; flist = NULL;

   eventmap_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &sp, &s_sp, &flist, 
	      &s_flist);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        eventmap_makeit(t3, s3, sp, s_sp);
        user_pause();
      }
   }

   echo_free();
   free(sp);
   free(t2);
   free(t4);
   freedes(s1, &t1);
   freedes(s3, &t3);
}

void allevent_des(state_node **t1,
                  INT_S *s1,
                  state_node **t2,
                  INT_S *s2)
{
    INT_S i;
    INT_T j;
    INT_B ok;

    *s2 = 1;
    *t2 = newdes(*s1);
    (*t2[0]).marked = true;

    for (i=0; i < *s1; i++)
    {
       for (j=0; j < (*t1)[i].numelts; j++)
       {
           addordlist1( (*t1)[i].next[j].data1, 0, &(*t2)[0].next, (*t2)[0].numelts, &ok);
           if (ok) (*t2[0]).numelts++;
       }
    }
}

void allevent_header() {
   printw("ALLEVENTS"); println();
   println();
   printw("TDS2 = ALLEVENTS (TDS1)"); println();
   println();
}

void allevent_r(state_node **t1, INT_S *s1,
                INT_T **t2, INT_S *s2,
                state_node **t3, INT_S *s3)
{
   INT_S      init;
//   char       ch;
   INT_T      s_list, *list;

   clear();
   allevent_header();
   quit = getname("Enter name of TDS1 to be searched .....  ",
                  EXT_DES, name1, fname1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 ....................  ",
                  EXT_DES, name2, fname2, true);
   if (quit) return;

   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();

   init = 0L;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   allevent_des(t1, s1, t3, s3);
   gentranlist(*s3, *t3, &s_list, &list);
   remove_forcible(s2, t2, s_list, list);

   move(23,0); clrtoeol();

   if (mem_result != 1)
      filetds(name2, *s3, init, *t3, *s2, *t2);

   mark_stop_time();
}

void allevent_makeit(state_node *t1,
                     INT_S s1)
{
   FILE* out;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Allevents(%s)", name2, name1);
   fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d));
   appendTime(out, (int)strlen(name2)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void allevents_p()
{
   state_node *t1, *t3;
   INT_S s1, s3;
   INT_T *t2;
   INT_S s2;

   t1 = t3 = NULL;
   s1 = s3 = 0;
   t2 = NULL;
   s2 = 0;

   allevent_r(&t1, &s1, &t2, &s2, &t3, &s3);

   if (mem_result == 1) {
      mem_result = 0;
      OutOfMemoryMsg();
      user_pause();
   } else {
      if (!quit) {
        allevent_makeit(t3, s3);
        user_pause();
      }
   }

   echo_free();
   free(t2);
   freedes(s1, &t1);
   freedes(s3, &t3);
}

void export_des_header()
{
   printw("EXPORT"); println();
   println();
   printw("EXPORT(TDS)"); println();
   println();
}

void export_des_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, i, j, total_edge;
   FILE *out;
   char longname[99];

   clear();
   export_des_header();
   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Check for DAT */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     user_pause();
     quit = true;
     return;
   }
   println();

   println();
   /* Get filename to export to */
   quit = getname("ASCII text file name ... ", EXT_DAV, name2, fname2, true);
   if (quit) return;
   sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
   out = fopen(longname, "w");

   fprintf(out, "menu(file(new))\n");
   
   if (*s1 > 0) {
      fprintf(out, "graph(update([");
      i=0;
      if ((*t1)[0].marked) {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i);
      } else {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"OBJECT\",\"%d\")])",i,i); 
      }
      for (i=1; i< *s1; i++) {
	 if ((*t1)[i].marked) {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 } else {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"circle\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 }
      }
      fprintf(out, "],[]))\n");
   }
   
   total_edge = 0;
   if (*s1 > 0) {
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "graph(update([],[new_edge(\"%d\",\"\",[],\"%d\",\"%d\")]))\n",total_edge,i,(*t1)[i].next[j].data2);
	    total_edge++;
	 }
      }
   }
   fclose(out);
}

void export_altdes_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, i, j, total_edge, total_tran, count;
   FILE *out;
   char longname[99];

   clear();
   export_des_header();
   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Check for DAT */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     user_pause();
     quit = true;
     return;
   }
   println();

   println();
   /* Get filename to export to */
   quit = getname("ASCII text file name ... ", EXT_DAV, name2, fname2, true);
   if (quit) return;
   sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
   out = fopen(longname, "w");

   fprintf(out, "menu(file(new))\n");
   
   if (*s1 > 0) {
      fprintf(out, "graph(update([");
      i=0;
      if ((*t1)[0].marked) {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i);
      } else {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"OBJECT\",\"%d\")])",i,i); 
      }
      for (i=1; i< *s1; i++) {
	 if ((*t1)[i].marked) {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 } else {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"circle\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 }
      }
      fprintf(out, "],[]))\n");
   }

   if (*s1 > 0) {
      count = 0;
      total_tran = 0;
      fprintf(out, "graph(update([");
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "new_node(\"%d\",\"\",[a(\"_GO\",\"text\"),a(\"OBJECT\",\"%d\")]),", *s1+total_tran,(*t1)[i].next[j].data1);
	    total_tran++;
	    count++;
	    if (count==20) {
	       fprintf(out, "\b],[]))\n");
	       fprintf(out, "graph(update([");
	       count = 0;
	    }
	 }
      }
      
      fprintf(out, "\b],[]))\n");
      total_tran = 0;
      total_edge = 0;
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "graph(update([],[");
	    fprintf(out, "new_edge(\"%d\",\"\",[a(\"_DIR\",\"none\")],\"%d\",\"%d\"),",total_edge,i,*s1+total_tran);
	    fprintf(out, "\b]))\n");
	    total_edge++;
	    fprintf(out, "graph(update([],[");
	    fprintf(out, "new_edge(\"%d\",\"\",[],\"%d\",\"%d\"),",total_edge,*s1+total_tran,(*t1)[i].next[j].data2);
	    fprintf(out, "\b]))\n");
	    total_edge++;
	    total_tran++;
	 }
      }
      fprintf(out,"\b]))\n");
   }
   fclose(out);
}

void export_gml_des_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, i, j;//, count;
   FILE *out;
   char longname[99];

   clear();
   export_des_header();
   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Check for DAT */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     user_pause();
     quit = true;
     return;
   }
   println();

   println();
   /* Get filename to export to */
   quit = getname("ASCII text file name ... ", EXT_DAV, name2, fname2, true);
   if (quit) return;
   sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
   out = fopen(longname, "w");

   fprintf(out, "graph [\nVendor \"TTCT\"\ndirected 1\n");
   
   if (*s1 > 0) {
      i=0;
      if ((*t1)[0].marked) {
	 fprintf(out, "node [\nid %d\ngraphics [\nx 10\ny 10\nw 10\nh 10\ntype \"rectangle\"\n]\n]\n",i+1);
      } else {
	 fprintf(out, "node [\nid %d\ngraphics [\nx 10\ny 10\nw 20\nh 20\ntype \"oval\"\n]\n]\n",i+1);
      }
      for (i=1; i< *s1; i++) {
	 if ((*t1)[i].marked) {
	    fprintf(out, "node [\nid %d\ngraphics [\nx 10\ny 10\nw 10\nh 10\ntype \"rectangle\"\n]\n]\n",i+1);
	 } else {
	    fprintf(out, "node [\nid %d\ngraphics [\nx 10\ny 10\nw 10\nh 10\ntype \"oval\"\n]\n]\n",i+1);
	 }
      }
   }

   if (*s1 > 0) {
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "edge [\nsource %d\ntarget %d\nlabel \"%d\"\n]\n",i+1,(*t1)[i].next[j].data2 + 1,(*t1)[i].next[j].data1);
	 }
      }
      
      fprintf(out, "]\n");
   }
   fclose(out);
}

void export_place_des_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, i, j;//, count;
   FILE *out;
   char longname[99];

   clear();
   export_des_header();
   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Check for DAT */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     user_pause();
     quit = true;
     return;
   }
   println();

   println();
   /* Get filename to export to */
   quit = getname("ASCII text file name ... ", EXT_DAV, name2, fname2, true);
   if (quit) return;
   sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
   out = fopen(longname, "w");

   if (*s1 > 0) {
      i=0;
      fprintf(out, "(%d) () %d node\n",i,i);
      for (i=1; i< *s1; i++) {
	 fprintf(out, "(%d) () %d node\n",i,i);
      }
   }

   if (*s1 > 0) {
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "(%d) %d %d edge\n",(*t1)[i].next[j].data1,i,(*t1)[i].next[j].data2);
	 }
      }
   }
   fclose(out);
}

void export_ads_header()
{
   printw("EXPORT"); println();
   println();
   printw("EXPORT(ADS)"); println();
   println();
}

void export_ads_r(state_node** t1, INT_S *s1, timed_event **t2, INT_T *s2)
{
   INT_S init, i, j, total_edge;
   FILE *out;
   char longname[99];

   clear();
   export_ads_header();
   quit = getname("Enter name of ADS ...  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Check for DAT */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     user_pause();
     quit = true;
     return;
   }
   println();

   println();
   /* Get filename to export to */
   quit = getname("ASCII text file name ... ", EXT_DAV, name2, fname2, true);
   if (quit) return;
   sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
   out = fopen(longname, "w");

   fprintf(out, "menu(file(new))\n");
   
   if (*s1 > 0) {
      fprintf(out, "graph(update([");
      i=0;
      if ((*t1)[0].marked) {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i);
      } else {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"OBJECT\",\"%d\")])",i,i); 
      }
      for (i=1; i< *s1; i++) {
	 if ((*t1)[i].marked) {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 } else {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"circle\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 }
      }
      fprintf(out, "],[]))\n");
   }

   if (*s1 > 0) {
      total_edge = 0;
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "graph(update([],[new_edge(\"%d\",\"\",[],\"%d\",\"%d\")]))\n",total_edge,i,(*t1)[i].next[j].data2);
	    total_edge++;
	 }
      }
   }
   fclose(out);
}

void export_altads_r(state_node** t1, INT_S *s1, timed_event **t2, INT_T *s2)
{
   INT_S init, i, j, total_edge, total_tran, count;
   FILE *out;
   char longname[99];

   clear();
   export_ads_header();
   quit = getname("Enter name of ADS ...  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Check for DAT */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     user_pause();
     quit = true;
     return;
   }
   println();

   println();
   /* Get filename to export to */
   quit = getname("ASCII text file name ... ", EXT_DAV, name2, fname2, true);
   if (quit) return;
   sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
   out = fopen(longname, "w");

   fprintf(out, "menu(file(new))\n");
   
   if (*s1 > 0) {
      fprintf(out, "graph(update([");
      i=0;
      if ((*t1)[0].marked) {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i);
      } else {
	 fprintf(out, "new_node(\"%d\",\"\",[a(\"OBJECT\",\"%d\")])",i,i); 
      }
      for (i=1; i< *s1; i++) {
	 if ((*t1)[i].marked) {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"rhombus\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 } else {
	    fprintf(out, ",new_node(\"%d\",\"\",[a(\"_GO\",\"circle\"),a(\"OBJECT\",\"%d\")])",i,i); 
	 }
      }
      fprintf(out, "],[]))\n");
   }

   if (*s1 > 0) {
      total_tran = 0;
      count = 0;
      fprintf(out, "graph(update([");
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "new_node(\"%d\",\"\",[a(\"_GO\",\"text\"),a(\"OBJECT\",\"%d\")]),", *s1+total_tran,(*t1)[i].next[j].data1);
	    total_tran++;
	    count++;
	    if (count==20) {
	       fprintf(out, "\b],[]))\n");
	       fprintf(out, "graph(update([");
	       count = 0;
	    }
	 }
      }
      
      fprintf(out, "\b],[]))\n");
      total_tran = 0;
      total_edge = 0;
      for (i=0; i < *s1; i++) {
	 for (j=0; j < (*t1)[i].numelts; j++) {
	    fprintf(out, "graph(update([],[");
	    fprintf(out, "new_edge(\"%d\",\"\",[a(\"_DIR\",\"none\")],\"%d\",\"%d\"),",total_edge,i,*s1+total_tran);
	    fprintf(out, "\b]))\n");
	    total_edge++;
	    fprintf(out, "graph(update([],[");
	    fprintf(out, "new_edge(\"%d\",\"\",[],\"%d\",\"%d\"),",total_edge,*s1+total_tran,(*t1)[i].next[j].data2);
	    fprintf(out, "\b]))\n");
	    total_edge++;
	    total_tran++;
	 }
      }
      fprintf(out,"\b]))\n");
   }
   fclose(out);
}

void print_des_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(TDS)"); println();
   println();
}

void print_ads_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(ADS)"); println();
   println();
}

void print_ads_r(state_node** t1, INT_S *s1, timed_event **t2, INT_T *s2)
{
   INT_S init, nTransitions;
   FILE *out;
//   char ch;
   int d;
   char longname[99];

   clear();
   print_ads_header();
   quit = getname("Enter name of ADS ...  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display ADS to screen */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     printw("Use print DAT command."); println();
     user_pause();
     quit = true;
     return;
   }
   println();

   /* Ask user if he/she wants to print to a file 
   do {
     println();
/*#if defined(__UNIX__)
     printw("Print to line printer?  (*y/n) ");
/*#else
     printw("Print to LPT1?  (*y/n) ");
#endif
     refresh();
     ch = read_key();
     if (ch == CEsc) {
        quit = true;
        return;
     }
     if (ch == CEnter) ch = 'y';
     printw("%c", ch); println();
   } while (strchr("YNyn", ch) == NULL);

   if (ch == 'n' || ch == 'N') {*/
      println();
      /* Get filename to print to */
      quit = getname("ASCII text file name ... ", EXT_PDS, name2, fname2, true);
      if (quit) return;
      sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
      out = fopen(longname, "w");
      /*} else {
/*#if defined(__DOS32__) || defined(__BORLANDC__)
      out = stdprn;
#endif
   }*/

   print_des_stat_header(out, name1, *s1, init);

   if (num_mark_states(*t1, *s1) > 0) {
      quit = print_marker_states(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "marker states: none\n");
      fprintf(out, "\n");
   }

   if (num_vocal_output(*t1, *s1) > 0) {
      quit = print_vocal_output(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "\n");
      fprintf(out, "vocal states: none\n");
      fprintf(out, "\n");
   }

   if (num_forcible_events(*t2, *s2) > 0) {
      quit = print_aforcible_states(out, *t2, *s2);
      if (quit) return;
   } else {
      fprintf(out, "\n");
      fprintf(out, "forcible events: none\n");
      fprintf(out, "\n");
   }

   if (*s2 > 0) {
      quit = print_timebounds(out, *t2, *s2);
      if (quit) return;
   }   

   nTransitions = count_tran(*t1, *s1, &d, &d, &d);
   if (nTransitions > 0) {
      quit = print_transitions(out, *t1, *s1);
      if (quit) return;
    } else {
      fprintf(out, "transition table : empty\n");
   }

/*#if defined(__DOS32__) || defined(__BORLANDC__)
   if (out != stdprn) {
     fclose(out);
   } else {
     fprintf(out, "\n");
     fprintf(out, "%s printed.", name1);
   }
#endif*/
   fclose(out);
}

void print_des_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, nTransitions;
   FILE *out;
//   char ch;
   int d;
   char longname[99];

   clear();
   print_des_header();
   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display DES to screen */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     printw("Use print DAT command."); println();
     user_pause();
     quit = true;
     return;
   }
   println();

   /* Ask user if he/she wants to print to a file 
   do {
     println();
/*#if defined(__UNIX__)
     printw("Print to line printer?  (*y/n) ");
/*#else
     printw("Print to LPT1?  (*y/n) ");
#endif
     refresh();
     ch = read_key();
     if (ch == CEsc) {
        quit = true;
        return;
     }
     if (ch == CEnter) ch = 'y';
     printw("%c", ch); println();
   } while (strchr("YNyn", ch) == NULL);

   if (ch == 'n' || ch == 'N') {*/
      println();
      /* Get filename to print to */
      quit = getname("ASCII text file name ... ", EXT_PDS, name2, fname2, true);
      if (quit) return;
      sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
      out = fopen(longname, "w");
      /* } else {
/*#if defined(__DOS32__) || defined(__BORLANDC__)
      out = stdprn;
#endif
   }*/

   print_des_stat_header(out, name1, *s1, init);

   if (num_mark_states(*t1, *s1) > 0) {
      quit = print_marker_states(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "marker states: none\n");
      fprintf(out, "\n");
   }

   if (num_vocal_output(*t1, *s1) > 0) {
      quit = print_vocal_output(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "\n");
      fprintf(out, "vocal states: none\n");
      fprintf(out, "\n");
   }

   if (*s2 > 0) {
      quit = print_forcible_states(out, *t2, *s2);
      if (quit) return;
   } else {
      fprintf(out, "\n");
      fprintf(out, "forcible events: none\n");
      fprintf(out, "\n");
   }

   if (*s1 > 0 && (*t1)[0].ntimer != NULL) {
      quit = print_timer_info(out, *t1, *s1);
      if (quit) return;
   } else {
      printw("No timer and state information available !"); println();
      println();
   }

   nTransitions = count_tran(*t1, *s1, &d, &d, &d);
   if (nTransitions > 0) {
      quit = print_transitions(out, *t1, *s1);
      if (quit) return;
    } else {
      fprintf(out, "transition table : empty\n");
   }

/*#if defined(__DOS32__) || defined(__BORLANDC__)
   if (out != stdprn) {
     fclose(out);
   } else {
     fprintf(out, "\n");
     fprintf(out, "%s printed.", name1);
   }
#endif*/
   fclose(out);
}

void print_des_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   print_des_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void print_ads_p()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   print_ads_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void export_des_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   export_des_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void export_altdes_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   export_altdes_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void export_gml_des_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   export_gml_des_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void export_place_des_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   export_place_des_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void export_ads_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   export_ads_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
}

void export_altads_ap()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   export_altads_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   echo_free();
   freedes(s1, &t1);
   free(t2);
}

void print_dat_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(DAT)"); println();
   println();
}

void print_dat_header_stat(FILE *out)
{
    fprintf(out, "%s\n", name1);
    fprintf(out, "\n\n");
    fprintf(out, "Control data are displayed as a list of supervisor states\n");
    fprintf(out, "where disabling occurs, together with the events that must\n");
    fprintf(out, "be disabled there. If TICK is disabled f signifies the events\n");
    fprintf(out, "which are forced.\n\n");
    fprintf(out, "control data:\n");
}

INT_B print_dat(FILE *out,
                  state_node *t1,
                  INT_S s1)
{
   INT_S k, i, prevNumTran;
   INT_T j;
   INT_T realtrans;
   INT_B leftSide;

   leftSide = false;
   prevNumTran = 0;

   fprintf(out, "\n");
   for (i=0; i < s1; i++) {
     realtrans = t1[i].numelts - t1[i].vocal;
     if (t1[i].numelts > 0) {
       if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
         fprintf(out, "\n");
         fprintf(out, "%-4s", " ");
         leftSide = true;
       } else {
         for (k=prevNumTran; k <=6; k++)
            fprintf(out, "%-5s", " ");
         leftSide = false;
       }
       fprintf(out, "%-4d:", i);
       prevNumTran = t1[i].numelts;
     }

     for (j=0; j< t1[i].numelts; j++) {
       if (j < realtrans) {
	  fprintf(out, "%4d ", t1[i].next[j].data1);
       } else {
	  fprintf(out, "%4df", t1[i].next[j].data1);
       }
       if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
          fprintf(out, "\n");
          fprintf(out, "%9s", " ");
       }
     }
   }
   fprintf(out, "\n");
   return false;
}

void print_dat_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, nTransitions;
   FILE *out;
//   char ch;
   int d;
   char longname[99];

   clear();
   print_dat_header();
   quit = getname("Enter name of DAT ...  ", EXT_DAT, name1, fname1, false);
   if (quit) return;

   init = -1;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display DAT to screen */
   if (init != -1) {
     clear();
     println();
     printw("This is a TDS file.");   println();
     printw("Use print TDS command."); println();
     user_pause();
     quit = true;
     return;
   }
   println();

   /* Ask user if to direct output to print or to file */
   /* For now dump to printer 
   do {
     println();
/*#if defined(__UNIX__)
     printw("Print to line printer?  (*y/n) ");
/*#else
     printw("Print to LPT1?  (*y/n) ");
#endif
     refresh();
     ch = read_key();
     if (ch == CEsc) {
        quit = true;
        return;
     }
     if (ch == CEnter) ch = 'y';
     printw("%c", ch); println();
   } while (strchr("YNyn", ch) == NULL);

   if (ch == 'n' || ch == 'N') {*/
      println();
      /* Get filename to print to */
      quit = getname("ASCII text file name ... ", EXT_PDT, name2, fname2, true);
      if (quit) return;
      sprintf(longname, "%s%s%s", prefix, name2, EXT_DAV);
      out = fopen(longname, "w");
      /*} else {
/*#if defined(__DOS32__) || defined(__BORLANDC__)
      out = stdprn;
#endif
   }*/

   print_dat_header_stat(out);
   nTransitions = count_tran(*t1, *s1, &d, &d, &d);
   if (nTransitions > 0) {
      quit = print_dat(out, *t1, *s1);
      if (quit) return;
   } else {
      fprintf(out, "empty.\n");
   }

/*#if defined(__DOS32__) || defined(__BORLANDC__)
   if (out != stdprn) {
     fclose(out);
   } else {
     fprintf(out, "\n");
     fprintf(out, "%s printed.", name1);
   }
#else*/
   fclose(out);
/*#endif*/
}

void print_dat_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL;
   t2 = NULL;

   s1 = s2 = 0;

   print_dat_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void print_ascii_header()
{
   printw("PRINT"); println();
   println();
   printw("PRINT(TXT)"); println();
   println();
}

void print_ascii_p()
{
   clear();
   print_ascii_header();
   quit = getname("Enter name of TXT ...  ", EXT_TXT, name1, fname1, false);
   if (quit) return;
}

void file_des_header()
{
   printw("FILE"); println();
   println();
   printw("FILE(TDS)"); println();
   println();
}

void file_ads_header()
{
   printw("FILE"); println();
   println();
   printw("FILE(ADS)"); println();
   println();
}

void file_des_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
   INT_S init, nTransitions;
   FILE *out;
   char ch;
   char fullname[81];
   int ascii_output = 0;  /* 0 = .ATS, 1 = PDS, 2 = PSS */
   int d;

   clear();
   file_des_header();
   quit = getname("Enter name of TDS ....  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display DES to screen */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     printw("Use file DAT command."); println();
     user_pause();
     quit = true;
     return;
   }

   /* Ask user if he/she want to file as ASCII text or Postscript */
   println();
   printw("File as ATS (.ATS) or ASCII Text (.PDS) or Postscript (.PSS)?  (*A/T/P) ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   addch(ch);
   println();
   println();

   if (ch == 't' || ch == 'T') {
      ascii_output = 1;
      /* Get filename */
      quit = getname("Enter ASCII text file name ....  ", EXT_PDS, name2, fname2, true);
      if (quit) return;
      strcpy(fullname, fname2);
      /* sprintf(fullname, "%s%s%s", prefix, name2, EXT_PDS); */
   }
   else if (ch == 'p' || ch == 'P') {
      ascii_output = 2;
      /* Get filename for Postscript */
      quit = getname("Enter the Postcript file name ....  ", EXT_PSS, name2, fname2, true);
      if (quit) return;
      strcpy(fullname, fname2);
      /* sprintf(fullname, "%s%s%s", prefix, name2, EXT_PSS); */
   } else {
      ascii_output = 0;
      /* Get filename for .ATS */
      quit = getname("Enter the ATS file name ....  ", EXT_ATS, name2, fname2, true);
      if (quit) return;
      strcpy(fullname, fname2);
      /* sprintf(fullname, "%s%s%s", prefix, name2, EXT_ATS); */
   }
   out = fopen(fullname, "w");

   /**** ASCII file format to file ****/
   if (ascii_output == 1)
   {
      print_des_stat_header(out, name1, *s1, init);
      fprintf(out, "\n");

      if (num_mark_states(*t1, *s1) > 0) {
        quit = print_marker_states(out, *t1, *s1);
        if (quit) return;
      } else {
        fprintf(out, "marker states: none\n");
        fprintf(out, "\n");
      }

      if (num_vocal_output(*t1, *s1) > 0) {
        quit = print_vocal_output(out, *t1, *s1);
        if (quit) return;
      } else {
        fprintf(out, "\n");
        fprintf(out, "vocal states: none\n");
        fprintf(out, "\n");
      }

      if (*s2 > 0) {
        quit = print_forcible_states(out, *t2, *s2);
        if (quit) return;
      } else {
        fprintf(out, "\n");
        fprintf(out, "forcible events: none\n");
        fprintf(out, "\n");
      }

      if (*s1 > 0 && (*t1)[0].ntimer != NULL) {
        quit = print_timer_info(out, *t1, *s1);
        if (quit) return;
      } else {
        printw("No timer and state information available !"); println();
        println();
      }

      nTransitions = count_tran(*t1, *s1, &d, &d, &d);
      if (nTransitions > 0) {
        quit = print_transitions(out, *t1, *s1);
        fprintf(out, "\n");
        if (quit) return;
      } else {
        fprintf(out, "transition table : empty\n");
     }
   }
   else if (ascii_output == 2) /***** Postscript *****/
   {
      postscript_outputfile(name1, out, *t1, *s1, *t2, *s2);
   }
   else
   {
      tds_to_ats(name1, out, *t1, *s1, *t2, *s2);
   }

   fclose(out);

   move(22,0); clrtoeol();
   if (ascii_output == 0)
      printw("%s%s has been copied to %s%s", name1, EXT_DES, name2, EXT_ATS);
   else if (ascii_output == 1)
      printw("%s%s has been copied to %s%s", name1, EXT_DES, name2, EXT_PDS);
   else
      printw("%s%s has been copied to %s%s", name1, EXT_DES, name2, EXT_PSS);
   user_pause();
}

void file_ads_r(state_node** t1, INT_S *s1, timed_event **t2, INT_T *s2)
{
   INT_S init, nTransitions;
   FILE *out;
   char ch;
   char fullname[81];
   int ascii_output = 0;  /* 0 = .AAS, 1 = PTS, 2 = PSS */
   int d;

   clear();
   file_ads_header();
   quit = getname("Enter name of ADS ....  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   if (getads(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display ADS to screen */
   if (init == -1) {
     clear();
     println();
     printw("This is a DAT file.");   println();
     printw("Use file DAT command."); println();
     user_pause();
     quit = true;
     return;
   }

   /* Ask user if he/she want to file as ASCII text or Postscript */
   println();
   printw("File as AAS (.AAS) or ASCII Text (.PDS) or Postscript (.PSS)?  (*A/T/P) ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   addch(ch);
   println();
   println();

   if (ch == 't' || ch == 'T') {
      ascii_output = 1;
      /* Get filename */
      quit = getname("Enter ASCII text file name ....  ", EXT_PDS, name2, fname2, true);
      if (quit) return;
      strcpy(fullname, fname2);
      /* sprintf(fullname, "%s%s%s", prefix, name2, EXT_PDS); */
   }
   else if (ch == 'p' || ch == 'P') {
      ascii_output = 2;
      /* Get filename for Postscript */
      quit = getname("Enter the Postcript file name ....  ", EXT_PSS, name2, fname2, true);
      if (quit) return;
      strcpy(fullname, fname2);
      /* sprintf(fullname, "%s%s%s", prefix, name2, EXT_PSS); */
   } else {
      ascii_output = 0;
      /* Get filename for .ATS */
      quit = getname("Enter the AAS file name ....  ", EXT_AAS, name2, fname2, true);
      if (quit) return;
      strcpy(fullname, fname2);
      /* sprintf(fullname, "%s%s%s", prefix, name2, EXT_AAS); */
   }
   out = fopen(fullname, "w");

   /**** ASCII file format to file ****/
   if (ascii_output == 1)
   {
      print_des_stat_header(out, name1, *s1, init);
      fprintf(out, "\n");

      if (num_mark_states(*t1, *s1) > 0) {
        quit = print_marker_states(out, *t1, *s1);
        if (quit) return;
      } else {
        fprintf(out, "marker states: none\n");
        fprintf(out, "\n");
      }

      if (num_vocal_output(*t1, *s1) > 0) {
        quit = print_vocal_output(out, *t1, *s1);
        if (quit) return;
      } else {
        fprintf(out, "\n");
        fprintf(out, "vocal states: none\n");
        fprintf(out, "\n");
      }

      if (num_forcible_events(*t2, *s2) > 0) {
        quit = print_aforcible_states(out, *t2, *s2);
        if (quit) return;
      } else {
        fprintf(out, "\n");
        fprintf(out, "forcible events: none\n");
        fprintf(out, "\n");
      }

      if (*s2 > 0) {
         quit = print_timebounds(out, *t2, *s2);
         if (quit) return;
      }   

      nTransitions = count_tran(*t1, *s1, &d, &d, &d);
      if (nTransitions > 0) {
        quit = print_transitions(out, *t1, *s1);
        fprintf(out, "\n");
        if (quit) return;
      } else {
        fprintf(out, "transition table : empty\n");
     }
   }
   else if (ascii_output == 2) /***** Postscript *****/
   {
      postscript_a_outputfile(name1, out, *t1, *s1, *t2, *s2);
   }
   else
   {
      ads_to_aas(name1, out, *t1, *s1, *t2, *s2);
   }

   fclose(out);

   move(22,0); clrtoeol();
   if (ascii_output == 0)
      printw("%s%s has been copied to %s%s", name1, EXT_ADS, name2, EXT_AAS);
   else if (ascii_output == 1)
      printw("%s%s has been copied to %s%s", name1, EXT_ADS, name2, EXT_PDS);
   else
      printw("%s%s has been copied to %s%s", name1, EXT_ADS, name2, EXT_PSS);
   user_pause();
}

void file_des_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL; 
   t2 = NULL;
   s1 = s2 = 0;

   file_des_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void file_ads_p()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;

   t1 = NULL; 
   t2 = NULL;
   s1 = s2 = 0;

   file_ads_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void file_dat_header()
{
   printw("FILE"); println();
   println();
   printw("FILE(DAT)"); println();
   println();
}

void file_dat_r(state_node** t1, INT_S *s1,
                INT_T **t2, INT_S *s2)
{
   INT_S init, nTransitions;
   FILE *out;
   char ch;
   char fullname[81];
   INT_B ascii_output;
   int d;

   clear();
   file_dat_header();
   quit = getname("Enter name of DAT ....  ", EXT_DAT, name1, fname1, false);
   if (quit) return;

   init = -1;
   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display DAT to screen */
   if (init != -1) {
     clear();
     println();
     printw("This is a TDS file.");   println();
     printw("Use file TDS command."); println();
     user_pause();
     quit = true;
     return;
   }

   /* Ask user if he/she want to file as ASCII text or Postscript */
   println();
   printw("File as ASCII text (.PDT) or Postscript (.PST)?  (*A/P) ");

   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }
   addch(ch);
   println();
   println();

   if (ch == 'p' || ch == 'P') {
      ascii_output = false;
      /* Get filename to as Postscript */
      quit = getname("Enter the Postcript file name ....  ", EXT_PST, name2, fname2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_PST);
   } else {
      ascii_output = true;
      /* Get filename to as Postscript */
      quit = getname("Enter ASCII text file name ....  ", EXT_PDT, name2, fname2, true);
      if (quit) return;
      sprintf(fullname, "%s%s%s", prefix, name2, EXT_PDT);
   }
   out = fopen(fullname, "w");


   /**** ASCII file format to file ****/
   if (ascii_output)
   {
      print_dat_header_stat(out);
      nTransitions = count_tran(*t1, *s1, &d, &d, &d);
      if (nTransitions > 0) {
        quit = print_dat(out, *t1, *s1);
        fprintf(out, "\n");
        if (quit) return;
      } else {
        fprintf(out, "empty.\n");
      }
   }
   else  /* Postscript */
   {
      postscript_dat_output(name1, out, *t1, *s1);
   }
   fclose(out);

   move(22,0); clrtoeol();
   if (ascii_output)
      printw("%s%s has been copied to %s%s", name1, EXT_DAT, name2, EXT_PDT);
   else
      printw("%s%s has been copied to %s%s", name1, EXT_DAT, name2, EXT_PST);
   user_pause();
}

void file_dat_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;

   t1 = NULL; s1 = 0;
   t2 = NULL; s2 = 0;

   file_dat_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void file_ats_header()
{
   printw("FILE"); println();
   println();
   printw("TDS2 = FILE(ATS1)"); println();
   println();
}

void file_aas_header()
{
   printw("FILE"); println();
   println();
   printw("ADS2 = FILE(AAS1)"); println();
   println();
}

void file_ats_r(state_node** t1, INT_S *s1,
                INT_T **t2, INT_S *s2)
{
   INT_S init;
   int return_code;
   long num_err = 0;
   ats_err_log_t *err_log = NULL;
   long i;
   char ch;

   clear();
   file_ats_header();
   quit =    getname("Enter name of ATS1 ........  ", EXT_ATS, name1, fname1, false);
   if (quit) return;

   printw("Same name for TDS2?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch);  println();
      println();
      quit = getname("Enter new name for TDS2 ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   } else {
      if (ch != CEnter)
         addch(ch);
      strcpy(name2, name1);
      println();  
      quit = getname2("Enter new name for TDS2 ....  ",
                     EXT_DES, name2, fname2, true);
      if (quit) return;
   }

     strcpy(long_name1, "");
   make_filename_ext(long_name1, name1, EXT_ATS);
   
   return_code = ats_2_tds(long_name1, &err_log, &num_err, t1, s1, t2, s2);

   if (mem_result == 1) {
      free(err_log);
      return;
   }

   if (return_code == 0)
   {
      init = 0;
      filetds(name2, *s1, init, *t1, *s2, *t2);

      if (!quit) {
         refresh();
         echo_save(name1);
      }
      return;
   }

   if (_wherey() > 12)
   {
      clear();
      file_ats_header();
      println();
   }

   println();
   printw("Error(s) reading file: %s", fname1); println();
   println();

   for (i=0; (i < num_err) && (i < 10); i++)
   {
      if (err_log[i].line_num2 != -1)
      {
         printw("  %s at lines %ld and %ld.",
                ats_error_str[err_log[i].fail_code],
                err_log[i].line_num2, err_log[i].line_num1);
         println();
      }
      else if (err_log[i].line_num1 != -1)
      {
         printw("  %s at line %ld.",
                ats_error_str[err_log[i].fail_code],
                err_log[i].line_num1);
         println();
      }
      else
      {
         printw("  %s", ats_error_str[err_log[i].fail_code]);
         println();
      }
   }
   user_pause();

   quit = true;

   free(err_log);
}

void file_aas_r(state_node** t1, INT_S *s1,
                timed_event **t2, INT_T *s2)
{
   INT_S init;
   int return_code;
   long num_err = 0;
   aas_err_log_t *err_log = NULL;
   long i;
   char ch;

   clear();
   file_aas_header();
   quit =    getname("Enter name of AAS1 ........  ", EXT_AAS, name1, fname1, false);
   if (quit) return;

   printw("Same name for ADS2?   (*y/n)   ", name1);
   refresh();
   ch = read_key();
   if (ch == CEsc) {
      quit = true;
      return;
   }

   if ( (ch == 'N') || (ch == 'n') ) {
      addch(ch);  println();
      println();
      quit = getname("Enter new name for ADS2 ....  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   } else {
      if (ch != CEnter)
         addch(ch);
      strcpy(name2, name1);
      println();  
      quit = getname2("Enter new name for ADS2 ....  ",
                     EXT_ADS, name2, fname2, true);
      if (quit) return;
   }
    strcpy(long_name1, "");
   make_filename_ext(long_name1, name1, EXT_AAS);
   return_code = aas_2_ads(long_name1, &err_log, &num_err, t1, s1, t2, s2);

   if (mem_result == 1) {
      free(err_log);
      return;
   }

   if (return_code == 0)
   {
      init = 0;
      fileads(name2, *s1, init, *t1, *s2, *t2);

      if (!quit) {
         refresh();
         echo_asave(name1);
      }
      return;
   }

   if (_wherey() > 12)
   {
      clear();
      file_aas_header();
      println();
   }

   println();
   printw("Error(s) reading file: %s", fname1); println();
   println();

   for (i=0; (i < num_err) && (i < 10); i++)
   {
      if (err_log[i].line_num2 != -1)
      {
         printw("  %s at lines %ld and %ld.",
                aas_error_str[err_log[i].fail_code],
                err_log[i].line_num2, err_log[i].line_num1);
         println();
      }
      else if (err_log[i].line_num1 != -1)
      {
         printw("  %s at line %ld.",
                aas_error_str[err_log[i].fail_code],
                err_log[i].line_num1);
         println();
      }
      else
      {
         printw("  %s", aas_error_str[err_log[i].fail_code]);
         println();
      }
   }
   user_pause();

   quit = true;

   free(err_log);
}

/* Remove the extension */
void file_split(char* path, char *name, char *ext) {
   char *ptr;
   int  pos;

   strcpy(name, path);
   ptr = strrchr(name, '.');
   if (ptr == NULL) {   /* No extension */
      ext = NULL;
      return;
   }

   pos = (int)(ptr-name);
   name[pos] = '\0';

   strcpy(ext, &(path[pos+1]));
}

int fail_num_entries;
int ok_convert;

void fail_file_ats_header()
{
   printw("FILE"); println();
   println();
   printw("TDS2 = FILE(ATS1)"); println();
   println();
   println();
   printw("1.  File one .ATS to .TDS"); println();
   println();
   printw("2.  File all .ATS to .TDS"); println();
   println();
   println();
   printw("Please choose Option 1 or 2 ....  2"); println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();
   printw("Failures:  ");
}

void fail_file_aas_header()
{
   printw("FILE"); println();
   println();
   printw("ADS2 = FILE(AAS1)"); println();
   println();
   println();
   printw("1.  File one .AAS to .ADS"); println();
   println();
   printw("2.  File all .AAS to .ADS"); println();
   println();
   println();
   printw("Please choose Option 1 or 2 ....  2"); println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();
   printw("Failures:  ");
}

#if !defined(__GO32__)

void ats2tds_output_page_control(INT_B lastPage)
{
   move(20,0); clrtoeol();
   printw("Locate .ATS errors by inspection or by FD/ATS->TDS/Option 1."); 
   println();
   printw("Use your ASCII Editor to correct.");
   continue_page("D=PgDn  U=PgUp  Esc (Exit)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               fail_file_ats_header();
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   fail_file_ats_header();
}

INT_B ats2tds_directory_output(struct _finddata_t *namelist, int num_entries)
{
   char buf[80];
   int max_str = 0;
   int  k;
   int  column;

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;

   /* Either 1, 2 or 4 columns due to the length of the files */
   for (ii=0; ii < num_entries; ii++) {
      if (max_str < (int)strlen(namelist[ii].name))
         max_str = (int)strlen(namelist[ii].name);
   }
   max_str += 2;  /* Add two spaces for blanks */

   if (max_str < 17)
   {
      sprintf(buf, "%%-15s  ");
      column = 4;
   }
   else if (max_str < 34)
   {
      sprintf(buf, "%%-32s  ");
      column = 2;
   } 
   else
   {
      sprintf(buf, "%%-66s  ");
      column = 1;
   }

   ii = 0;
   do {
      while (ii < num_entries) {
        if (strlen(namelist[ii].name) > 68)
        {
           for (k=0; k < 68; k++)
              printw("%c", namelist[ii].name[k]);
        }
        else
            printw(buf, namelist[ii].name);

        total_dir++;
        if (total_dir % column == 0)
        {
           println();
           printw("%-11s", "");
        }

        if (_wherey() >= 19) {
           ats2tds_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     ats2tds_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   free(dir_stack); dir_stack = NULL;
   return false;
}

void all_ats_to_tds()
{
   struct _finddata_t *namelist;//, **list;
   int num_entries;
   char dir[256];
//   char ch;
   char ext1[256];
   int i;
   state_node *t;
   INT_S s;
   INT_T *t2;
   INT_S s2;
   INT_S init;
   int return_code;
   long line_num;
   long line_num2 = -1;
   struct _finddata_t *fail_namelist = NULL;
   struct stat buf;

   namelist = NULL;

   fail_num_entries = 0;
   ok_convert = 0;

   strcpy(dir, path);
   strcat(dir, "/.");    /* Must provide a path */

  // num_entries = scandir(dir, &namelist, NULL, alphasort);
    num_entries = scandir(dir, &namelist);

   for (i= 0; i < num_entries; i++) {
      t = NULL; s = 0;
      t2 = NULL; s2 = 0;
      line_num2 = -1;

      sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name); 
      strcpy(name1, namelist[i].name);
      file_split(name1, name1, ext1);
      strcpy(name2, name1);   /* Input name1 and name2 are the same name */
      stat(long_name1, &buf);

      //if ( S_ISREG(buf.st_mode) && (strcmp(ext1, "ats") == 0) ) 
		  if (  (strcmp(ext1, "ats") == 0) )
      {
         sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name);

         return_code = ats_2_tds_all(long_name1, &line_num, &line_num2, &t, &s, &t2, &s2);
 
         if ((return_code == 0) && (mem_result != 1))
         {
            init = 0;
            filetds(name2, s, init, t, s2, t2);
            create_makeit(t, s, t2, s2);
            ok_convert++;
         }
         else
         {
            fail_num_entries++;
            fail_namelist = (struct _finddata_t *) realloc(fail_namelist, sizeof(struct _finddata_t )*fail_num_entries);
            fail_namelist[fail_num_entries-1] = (namelist[i]);
         }

         mem_result = 0;
      }

      freedes(s, &t);
      free(t2);
   }

//   for (i=0, list=namelist; i<num_entries; i++) {
//      free(*list);
 //     *list++;
 //  }
   free(namelist);

   println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();

   if (fail_num_entries == 0)
   {
      printw("Failures: %d", fail_num_entries); println();
      user_pause();
   }
   else
   {
      printw("Failures:  ");
      quit = false;
      ats2tds_directory_output(fail_namelist, fail_num_entries);
   }

   free(fail_namelist);
}

#else  /* Not UNIX */

void ats2tds_output_page_control(INT_B lastPage)
{
   move(20,0); clrtoeol();
   printw("Locate .ATS errors by inspection or by FD/ATS->TDS/Option 1."); println();
   printw("Use your ASCII Editor to correct.");
   continue_page("D=PgDn  U=PgUp  Esc (Exit)  ");

   do {
      refresh();
      ch = read_key();
      ch=toupper(ch);

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               fail_file_ats_header();
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   fail_file_ats_header();
}

INT_B ats2tds_directory_output(struct _finddata_t *namelist, int num_entries)
{
   char buf[80];

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;
   ii = 0;

   do {
      while (ii < num_entries) {
        if (namelist[ii].attrib == _A_SUBDIR) {
           sprintf(buf, "[%s]", namelist[ii].name);
           printw("%-12s   ", buf);
        } else {
           printw("%-12s   ", namelist[ii].name);
        }
        total_dir++;
        if (total_dir % 4 == 0)
        {
          println();
          printw("%-11s", "");
        }

        if (_wherey() >= 19) {
           ats2tds_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     ats2tds_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   free(dir_stack); dir_stack = NULL;
   return false;
}

void all_ats_to_tds()
{
   struct _finddata_t *namelist;
   int num_entries;
   char dir[256];
//   char ch;
   char ext1[4];
   int i;
   state_node *t;
   INT_S s;
   INT_T *t2; 
   INT_S s2;
   INT_S init; 
   int return_code;
   long line_num;
   long line_num2 = -1;
   struct _finddata_t *fail_namelist = NULL;

   fail_num_entries = 0;
   ok_convert = 0;

   strcpy(dir, path);
   strcat(dir, SEP);
   strcat(dir, "*.ATS");

   num_entries = scandir(dir, &namelist);

   for (i= 0; i < num_entries; i++) {
      t = NULL; s = 0;
      t2 = NULL; s2 = 0;
      line_num2 = -1;

      if (namelist[i].attrib != _A_SUBDIR)
      {
         sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name);
         strcpy(name1, namelist[i].name);
         file_split(name1, name1, ext1);
         strcpy(name2, name1);   /* Input name1 and name2 are the same name */

         return_code = ats_2_tds_all(long_name1, &line_num, &line_num2, &t, &s, &t2, &s2);

         if ((return_code == 0) && (mem_result != 1))
         {
            init = 0;
            filetds(name2, s, init, t, s2, t2);
            create_makeit(t, s, t2, s2);
            ok_convert++;
         }
         else
         {
            fail_num_entries++;
            fail_namelist = (struct _finddata_t*) realloc(fail_namelist, sizeof(struct _finddata_t)*fail_num_entries);
            fail_namelist[fail_num_entries-1] = namelist[i];
         }

         mem_result = 0;
      }

      freedes(s, &t);
      free(t2);
   }
   free(namelist);

   println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();

   if (fail_num_entries == 0)
   {
      printw("Failures: %d", fail_num_entries); println();
      user_pause();
   }
   else
   {
      printw("Failures:  ");
      quit = false;
      ats2tds_directory_output(fail_namelist, fail_num_entries);
   }

   free(fail_namelist);
}

#endif

int ask_file_ats_r()
{
   int option;
   char ch;

   clear();
   file_ats_header();
   esc_footer();
   refresh();

   println();
   printw("1.  File one .ATS to .TDS"); println();
   println();
   printw("2.  File all .ATS to .TDS"); println();

   println();
   println();
   printw("Please choose Option 1 or 2 ....  ");

   option = readint(&ch, 1, 2);
   if (ch == CEsc)
   {
     quit = true;
     return 1;
   }

   if (option == 1)
      return 0;

   all_ats_to_tds();

   quit = true;
   return 1;
}

void file_ats_p()
{
   state_node *t1;
   INT_T *t2;
   INT_S s1, s2;


   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   if (ask_file_ats_r()) {
      quit = true;
   } else {
      file_ats_r(&t1, &s1, &t2, &s2);
   }

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
         create_makeit(t1, s1, t2, s2);
      }
   }

   freedes(s1, &t1);
   free(t2);
}

#if !defined(__GO32__)

void aas2ads_output_page_control(INT_B lastPage)
{
   move(20,0); clrtoeol();
   printw("Locate .AAS errors by inspection or by FD/AAS->ADS/Option 1."); 
   println();
   printw("Use your ASCII Editor to correct.");
   continue_page("D=PgDn  U=PgUp  Esc (Exit)  ");

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               fail_file_aas_header();
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   fail_file_aas_header();
}

INT_B aas2ads_directory_output(struct _finddata_t  *namelist, int num_entries)
{
   char buf[80];
   int max_str = 0;
   int  k;
   int  column;

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;

   /* Either 1, 2 or 4 columns due to the length of the files */
   for (ii=0; ii < num_entries; ii++) {
      if (max_str < (int)strlen(namelist[ii].name))
         max_str = (int)strlen(namelist[ii].name);
   }
   max_str += 2;  /* Add two spaces for blanks */

   if (max_str < 17)
   {
      sprintf(buf, "%%-15s  ");
      column = 4;
   }
   else if (max_str < 34)
   {
      sprintf(buf, "%%-32s  ");
      column = 2;
   } 
   else
   {
      sprintf(buf, "%%-66s  ");
      column = 1;
   }

   ii = 0;
   do {
      while (ii < num_entries) {
        if (strlen(namelist[ii].name) > 68)
        {
           for (k=0; k < 68; k++)
              printw("%c", namelist[ii].name[k]);
        }
        else
            printw(buf, namelist[ii].name);

        total_dir++;
        if (total_dir % column == 0)
        {
           println();
           printw("%-11s", "");
        }

        if (_wherey() >= 19) {
           aas2ads_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     aas2ads_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   free(dir_stack); dir_stack = NULL;
   return false;
}

void all_aas_to_ads()
{
   struct _finddata_t *namelist;//, **list;
   int num_entries;
   char dir[256];
//   char ch;
   char ext1[256];
   int i;
   state_node *t;
   INT_S s;
   timed_event *t2;
   INT_T s2;
   INT_S init;
   int return_code;
   long line_num;
   long line_num2 = -1;
   struct _finddata_t *fail_namelist = NULL;
   struct stat buf;

   namelist = NULL;

   fail_num_entries = 0;
   ok_convert = 0;

   strcpy(dir, path);
   strcat(dir, "/.");    /* Must provide a path */

   //num_entries = scandir(dir, &namelist, NULL, alphasort);
   num_entries = scandir(dir, &namelist);
   for (i= 0; i < num_entries; i++) {
      t = NULL; s = 0;
      t2 = NULL; s2 = 0;
      line_num2 = -1;

      sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name); 
      strcpy(name1, namelist[i].name);
      file_split(name1, name1, ext1);
      strcpy(name2, name1);   /* Input name1 and name2 are the same name */
      stat(long_name1, &buf);

	 // if ( S_ISREG(buf.st_mode) && (strcmp(ext1, "aas") == 0) ) 
      if ( (strcmp(ext1, "aas") == 0) ) 
      {
         sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name);

         return_code = aas_2_ads_all(long_name1, &line_num, &line_num2, &t, &s, &t2, &s2);
 
         if ((return_code == 0) && (mem_result != 1))
         {
            init = 0;
            fileads(name2, s, init, t, s2, t2);
            create_amakeit(t, s, t2, s2);
            ok_convert++;
         }
         else
         {
            fail_num_entries++;
            fail_namelist = (struct _finddata_t*) realloc(fail_namelist, sizeof(struct _finddata_t)*fail_num_entries);
            fail_namelist[fail_num_entries-1] = (namelist[i]);
         }

         mem_result = 0;
      }

      freedes(s, &t);
      free(t2);
   }

   //for (i=0, list=namelist; i<num_entries; i++) {
    //  free(*list);
    //  *list++;
   //}
   free(namelist);

   println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();

   if (fail_num_entries == 0)
   {
      printw("Failures: %d", fail_num_entries); println();
      user_pause();
   }
   else
   {
      printw("Failures:  ");
      quit = false;
      aas2ads_directory_output(fail_namelist, fail_num_entries);
   }

   free(fail_namelist);
}

#else  /* Not UNIX */

void aas2ads_output_page_control(INT_B lastPage)
{
   move(20,0); clrtoeol();
   printw("Locate .AAS errors by inspection or by FD/AAS->ADS/Option 1."); println();
   printw("Use your ASCII Editor to correct.");
   continue_page("D=PgDn  U=PgUp  Esc (Exit)  ");

   do {
      refresh();
      ch = read_key();
      ch=toupper(ch);

      switch(ch) {
         case CEsc:
            quit = true;
            free(dir_stack); dir_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                          sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               size_dir_stack++;
               dir_stack = (int*) realloc(dir_stack,
                                  sizeof(int)* size_dir_stack);
               dir_stack[size_dir_stack-1] = ii;
            } else{
               clear();
               fail_file_aas_header();
               return;
            }
            break;
         case CPgUp:
            if (size_dir_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (size_dir_stack >= 2) {
                  ii = dir_stack[size_dir_stack-2];
                  size_dir_stack -= 2;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);

                  /* Put back the last pop */
                  size_dir_stack++;
                  dir_stack = (int*) realloc(dir_stack,
                                     sizeof(int) * size_dir_stack);
                  dir_stack[size_dir_stack-1] = ii;
               } else {
                  ii = 0;
                  size_dir_stack = 0;
                  free(dir_stack); dir_stack = NULL;
               }
               total_dir = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   clear();
   fail_file_aas_header();
}

INT_B aas2ads_directory_output(struct _finddata_t *namelist, int num_entries)
{
   char buf[80];

   multiPage = false;
   total_dir = 0;
   dir_stack = NULL; size_dir_stack = 0;
   ii = 0;

   do {
      while (ii < num_entries) {
        if (namelist[ii].attrib == _A_SUBDIR) {
           sprintf(buf, "[%s]", namelist[ii].name);
           printw("%-12s   ", buf);
        } else {
           printw("%-12s   ", namelist[ii].name);
        }
        total_dir++;
        if (total_dir % 4 == 0)
        {
          println();
          printw("%-11s", "");
        }

        if (_wherey() >= 19) {
           aas2ads_output_page_control(false);
           if (quit) return true;
        }
        ii++;
     }
     aas2ads_output_page_control(true);
     if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) );

   free(dir_stack); dir_stack = NULL;
   return false;
}

void all_aas_to_ads()
{
   struct _finddata_t *namelist;
   int num_entries;
   char dir[256];
//   char ch;
   char ext1[4];
   int i;
   state_node *t;
   INT_S s;
   timed_event *t2; 
   INT_T s2;
   INT_S init; 
   int return_code;
   long line_num;
   long line_num2 = -1;
   struct _finddata_t *fail_namelist = NULL;

   t = NULL; s = 0;
   t2 = NULL; s2 = 0;

   fail_num_entries = 0;
   ok_convert = 0;

   strcpy(dir, path);
   strcat(dir, SEP);
   strcat(dir, "*.AAS");

   num_entries = scandir(dir, &namelist);

   for (i= 0; i < num_entries; i++) {
      t = NULL; s = 0;
      t2 = NULL; s2 = 0;
      line_num2 = -1;

      if (namelist[i].attrib != _A_SUBDIR)
      {
         sprintf(long_name1, "%s%s%s", path, SEP, namelist[i].name);
         strcpy(name1, namelist[i].name);
         file_split(name1, name1, ext1);
         strcpy(name2, name1);   /* Input name1 and name2 are the same name */

         return_code = aas_2_ads_all(long_name1, &line_num, &line_num2, &t, &s, &t2, &s2);

         if ((return_code == 0) && (mem_result != 1))
         {
            init = 0;
            fileads(name2, s, init, t, s2, t2);
            create_amakeit(t, s, t2, s2);
            ok_convert++;
         }
         else
         {
            fail_num_entries++;
            fail_namelist = (struct _finddata_t*) realloc(fail_namelist, sizeof(struct _finddata_t)*fail_num_entries);
            fail_namelist[fail_num_entries-1] = namelist[i];
         }

         mem_result = 0;
      }

      freedes(s, &t);
      free(t2);
   }
   free(namelist);

   println();
   println();
   printw("Number of successful filings is: %d", ok_convert); println();
   println();

   if (fail_num_entries == 0)
   {
      printw("Failures: %d", fail_num_entries); println();
      user_pause();
   }
   else
   {
      printw("Failures:  ");
      quit = false;
      aas2ads_directory_output(fail_namelist, fail_num_entries);
   }

   free(fail_namelist);
}

#endif

int ask_file_aas_r()
{
   int option;
   char ch;

   clear();
   file_aas_header();
   esc_footer();
   refresh();

   println();
   printw("1.  File one .AAS to .ADS"); println();
   println();
   printw("2.  File all .AAS to .ADS"); println();

   println();
   println();
   printw("Please choose Option 1 or 2 ....  ");

   option = readint(&ch, 1, 2);
   if (ch == CEsc)
   {
     quit = true;
     return 1;
   }

   if (option == 1)
      return 0;

   all_aas_to_ads();

   quit = true;
   return 1;
}

void file_aas_p()
{
   state_node *t1;
   timed_event *t2;
   INT_S s1;
   INT_T s2;


   t1 = NULL;
   t2 = NULL;
   s1 = s2 = 0;

   if (ask_file_aas_r()) {
      quit = true;
   } else {
      file_aas_r(&t1, &s1, &t2, &s2);
   }

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
         create_amakeit(t1, s1, t2, s2);
      }
   }

   freedes(s1, &t1);
   free(t2);
}

long *file_stack;
long file_stack_size;

INT_B intro_page_control(INT_B lastPage, FILE *in)
{
   char ch;
   long fpos;

   move(23,0); clrtoeol();

#if !defined(__GO32__)
   printw(" D=PgDn  U=PgUp  Esc (Return to Main Options)  ");
#else
   printw(" D=PgDn  U=PgUp  Esc (Return to Main Options)  ");
#endif

   do {
       refresh();
       ch = read_key();

       switch(ch) {
          case CEsc:
            free(file_stack); file_stack = NULL;
            file_stack_size = 0;
            return true;

          case CPgDn:
          case CEnter:
            if (lastPage == true)
            {
               ch = 0;
               ring_bell();
            } else {
               file_stack_size++;
               file_stack = (long*) realloc(file_stack,
                                   sizeof(long) * file_stack_size);
               file_stack[file_stack_size-1] = ftell(in);
            }
            break;

          case CPgUp:
            if (file_stack_size == 0)
            {
               ch = 0;
               ring_bell();
            } else {
               if (file_stack_size >= 2) {
                  fpos = file_stack[file_stack_size-2];
                  file_stack_size -= 2;
                  file_stack = (long*) realloc(file_stack,
                                       sizeof(long) * file_stack_size);

                  /* Put back the last pop */
                  file_stack_size++;
                  file_stack = (long*) realloc(file_stack,
                                       sizeof(long) * file_stack_size);
                  file_stack[file_stack_size-1] = fpos;
               } else {
                  fpos = 0;
                  file_stack_size = 0;
                  free(file_stack); file_stack = NULL;
               }
               fseek(in, fpos, SEEK_SET);
            }
            break;

       }
   } while ( (ch != CEnter) && (ch != CPgUp) && (ch != CPgDn) );

   return false;
}

void introduction_p()
{
   FILE  *in;
   char  line[255];
//   char  ch;
   char info_file[20];

   strcpy(info_file, "ttctinfo.txt");

/*#if !defined(__GO32__) */
   /* A defect in some versions of Linux core dumps if 
      it is provided with a non-existing file.
      This is a workaround. */
   if (_access(info_file, 0) != 0) 
   {
      clear();
      move(7,0); printw("FILE TTCTINFO.TXT NOT FOUND!"); println();
/*      printw("(alternatively see http://pc5.isr.uni-stuttgart.de/ttct/manual/index.html)"); println(); */
      user_pause();
      return;
   }
/* #endif */

   in = fopen(info_file, "r");

   setvbuf(in, NULL, _IOFBF, 4000);

   if (in == NULL) {
      clear();
      move(7,0); printw("FILE TTCTINFO.TXT NOT FOUND!"); println();
/*    printw("(alternatively see http://pc5.isr.uni-stuttgart.de/ttct/manual/index.html)"); println(); */
      user_pause();
      return;
   }

   clear();
   while(1) {

      while ( fgets(line, 254, in) != NULL ) {
         switch(line[0]) {
           case '#': println();
                     break;
           case '$': 
/*                   move(23,0); clrtoeol();
                     printw("Press <Enter> to continue or <ESC> to exit  ");
                     refresh();
                     do {
                        ch = read_key();
                     } while ( (ch != CEnter) && (ch != CEsc) );
                     if (ch == CEsc) {
                       fclose(in);
                       return;
                     }
                     clear();
                     return;
*/
                     if (intro_page_control(false, in))
                     {
                        fclose(in);
                        return;
                     } else {
                        clear();
                     }
                     break;
           default:  if (strlen(line) > 0) {
                        line[strlen(line)-1] = '\0';
                     }
                     printw("%s", line); println();
         }
      }
/*    move(23,0); clrtoeol();
      printw("Press <Enter> to return to Main Options  ");
      refresh();
      do {
         ch = read_key();
      } while (ch != CEnter);
      fclose(in);
*/
      if (intro_page_control(true, in))
      {
         fclose(in);
         return;
      }
      clear();
   }
}

void reset_directory_header()
{
   char dir[_MAX_PATH];

   clear();
   println();
   println();
   printw("            RESETTING USER FILE DIRECTORY PATH");
   println();
   println();
   printw("Files that you create while using TTCT will be stored, by default,"); println();
   printw("in the current directory.  However, it is often convenient to copy"); println();
   printw("these files into a ramdisk or other location for speed of processing "); println();
   printw("during the session."); println();
   println();
   printw("If you wish to use an alternative directory, enter the corresponding"); println();
   printw("path (e.g.  C: or C:\\TTCT ) in response to the prompt.");println();println();
  /* printw("path (e.g. C: or C:\ USER) in response to the prompt.");*/
   
   
   

   println();
   
/*   getcwd(dir, 99); */
   strcpy(dir, path);
   printw("Current directory path is %s. OK?  (*y/n)  ", dos_uppercase(dir));
}

void reset_directory_p()
{
   char ch;
   char tempPath[256];
  // char tempi[256];
   char currentDir[256];
//   char ini[99];
//   struct passwd *p;
   FILE *f;

   reset_directory_header();
   refresh();
   ch = read_key();
   if (ch == CEsc) return;

   if ( (ch == 'N') || (ch == 'n') ) {
       addch(ch); println(); println();
       printw("Have you created an alternative user directory? (*y/n)  ");
       refresh();
       ch = read_key();
       if (ch == CEsc) return;

       if ( (ch == 'N') || (ch == 'n') ) {
          addch(ch); println(); println();
/*#if defined (__UNIX__)*/
          printw("Create new directory at the OS level,"); println();
/*#else
          printw("Create new directory by means of MKDIR at the DOS level,"); println();
#endif*/
          printw("then restart TTCT."); println();
          println();
          printw("Press any key to continue   ");
          refresh();
          ch = read_key();
/*#if defined (__UNIX__)*/
          return;
/*#else
          exit(0);
#endif*/
       }

       strcpy(tempPath,"");
       println(); println();
       printw("Enter path for new user directory:  ");
       refresh();
       ch = read_filename(tempPath, 1, 79);
       if (ch == CEsc) return;

       /* Verify that the given directory exists */
       _getcwd(currentDir, 255);
      /* if (tempPath[1] != ':') {
          strcpy(tempi,currentDir);
          strcat(tempi, SEP);
          strcat(tempi,tempPath);
  	      strcpy(tempPath,tempi);
       }
       if (tempPath[strlen(tempPath)-1] != SEPC)
	      strcat(tempPath, SEP);*/

       if (_chdir(tempPath) == -1) {
         println();
         println();
         printw("Directory %s does not exist!", tempPath);
         move(23,0); clrtoeol();
         printw("Press <Enter> to return TTCT Procedures  ");
         refresh();
         do {
           ch = read_key();
         } while (ch != CEnter);
       } else {
         /* TCT version would save the path in a variable
            that would be used to indicate the current directory */
         /* In TTCT, we will allow the path to be changed */
	     /* reverted to old behaviour (christian) */
         strcpy(path,tempPath);

		 if (tempPath[strlen(tempPath)-1] != '\\')
			 strcat(tempPath, "\\");

	     strcpy(prefix,tempPath);

		 _chdir(currentDir);

	     //strcpy(ini,"");
/*	 p = getpwuid(getuid());
	 strcat(ini,p->pw_dir); 
	 if (ini[strlen(ini)-1] != '/') */
        // strcat(ini, SEP);
	     //strcat(ini,INIFILE);  
	     f=fopen(ttct_ini_file,"wt");
		 if(f!= NULL){
			fprintf(f,"%s\n",path);
			fprintf(f, "CLOCK %d\n", timing_mode);
			fclose(f);
		 }

	 
/*#ifndef __UNIX__
         if (tempPath[strlen(tempPath)-1] != '\\')
             strcat(tempPath, "\\");
         strcpy(prefix, tempPath);

         chdir(currentDir);
#endif*/
       }
   }
}

void bell_control_p()
{
   ring_active = !ring_active;
   ring_bell();
}

void display_control_p()
{
   debug_mode = !debug_mode;
}

void timing_control_p()
{
   timing_mode = !timing_mode;
}

void check_des_header()
{
   printw("CHECK TDS SANITY"); println();
   println();
   printw("CHECK (TDS1)"); println();
   println();
}

void check_des_r(state_node** t1, INT_S *s1)
{
   INT_S init;
   int   x,y;
   INT_B flag;

   clear();
   check_des_header();

   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   init = 0L;
/* has to be fixed  if (getdes(name1, s1, &init, t1) == false) {
      quit = true;
      return;
   }*/

   x = _wherex(); y = _wherey();
   move(22,0); clrtoeol();
   move(23,0); clrtoeol();
   printw("Processing:  Please wait...");
   refresh();

   flag = check_des_sanity(*t1, *s1);
   move(23,0); clrtoeol();
   move(y,x);
   println();
   println();

   if (flag) {
      printw("%s is OK.", name1);
   } else {
      printw("%s is insane.", name1);
   }
}

void check_des_p()
{

   state_node *t1;
   INT_S s1;

   t1 = NULL;

   check_des_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   } else {
      if (!quit) {
         user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
}

void supreduce_header() {
   printw("SUPREDUCE"); println();
   println();
   printw("TDS3 = SUPREDUCE(TDS1,TDS2)"); println();
   println();
}

void supreduce_r(state_node **t1, INT_S *s1,
                 state_node **t2, INT_S *s2,
                 state_node **t3, INT_S *s3,
                 state_node **t4, INT_S *s4,
                 INT_S *lb,
                 double long *cr)
{
   INT_S init;
//   INT_B flag;
   INT_T *ft1,*ft2;
   INT_S fs1,fs2;
   INT_T  s_list, *list;
   INT_S  *macro_ab, *macro_c;
   state_node  *t5, *t7;
   INT_T  *t6;
   INT_S  s5, s6, s7;

   INT_S fs;
   INT_T *ft;

   clear();
   supreduce_header();
   
   strcpy(long_name1, "");
   strcpy(long_name2, "");
   strcpy(long_name3, "");
   strcpy(long_name4, "");
   
   quit = getname("Enter name of plant generator TDS1 ..........  ", EXT_DES, name1,long_name1, false);
   if (quit) return;

   quit = getname("Enter name of TDS2 [= Supcon(TDS1,TDS?)] ....  ", EXT_DES, name2,long_name2, false);
   if (quit) return;

   //quit = getname("Enter name of DAT2 [= Condat(TDS1,TDS2)] ....  ", EXT_DAT, name3,long_name3, false);
   //if (quit) return;

   quit = getname("Enter name of TDS3 ..........................  ", EXT_DES, name4,long_name4, true);
   if (quit) return;

   move(22, 0); clrtoeol(); refresh();
   move(23, 0); clrtoeol(); refresh();
   printw("Processing:  Please wait...");
   refresh();

   mark_start_time();
    /*
   strcpy(long_name1, "");
   strcpy(long_name2, "");
   strcpy(long_name3, "");
   strcpy(long_name4, "");
   make_filename_ext(long_name1, name1, EXT_DES);
   make_filename_ext(long_name2, name2, EXT_DES);
   make_filename_ext(long_name3, name3, EXT_DAT);
   make_filename_ext(long_name4, name4, EXT_DES);
*/
// check if the forcible events of plant and super are the same.

   
   init = 0L;
   if (gettds(name1, s1, &init, t1, &fs1, &ft1) == false) {
      quit = true;
      return;
   }

   init = 0L;
   if (gettds(name2, s2, &init, t2,&fs2, &ft2) == false) {
      quit = true;
      return;
   }

   if (chk_diff_forcible(*s1, *t1, (INT_T)fs1, ft1, *s2, *t2, (INT_T)fs2, ft2)) {
      move(15,0);
      printw("The forcible events of both TDS are not consistent !");
      println();
      printw("Please resolve !");
      user_pause();
      quit = true;
      return;
   }
   
   // construct the .DAT file i.e condat( TDS1,TDS2) but without forcing events only disabled evetns
   


    t5 = t7 = NULL;
    t6 = NULL;
    s5 = s6 = s7 = 0;
   
   
   meet2(*s1,*t1,*s2,*t2,&s5,&t5,&macro_ab,&macro_c);
  
   free(macro_ab);
   
   s6 = fs1;
   t6 = (INT_T*) calloc(fs1,sizeof(INT_T));
   memcpy(t6, ft1, sizeof(INT_T) * fs1);

   gentranlist(s5, t5, &s_list, &list);
   remove_forcible(&s6, &t6, s_list, list);
    
   condat1(*t1,*s1,*s2,s5,t5,s6,t6,&s7,&t7,macro_c); // just finds the disabled events
   
   
   
   move(16,0); clrtoeol();
   strcpy(name3,name2);
   strcat(name3,"tmp");
   
   if (mem_result != 1)
      filetds(name3, s7, -1L, t7, 0, NULL);

   strcpy(long_name3, "");
   make_filename_ext(long_name3, name3, EXT_DAT);
   
   
   free(t5);free(t6);free(t7);free(list);free(macro_c);
   
   
   // End of making condat file
   
   
   supreduce_flag = supreduce(long_name1,long_name2,long_name3,long_name4,lb,cr);

//INT_B gettds(char *name, INT_S *size, INT_S *init, state_node **data, INT_S *size1, INT_T **data1)

   //fs=(*fs1);
   //ft=(*ft1);
   fs=0;
   ft=NULL;
   
   move(23,0); clrtoeol();
   if (mem_result != 1)
   {
      switch (supreduce_flag)
      {
        case 0: /* File was generated */
                init = 0;
                gettds(name4, s4, &init, t4,&fs,&ft);
                filetds(name4, *s4, init, *t4,fs1,ft1);
                break;
        case -1: /* NULL result case */
                init = 0;
                filetds(name4, *s4, init, *t4,fs,ft);
                *cr = 0;
                *lb = 0;
                break;
        case -2: /* copy name2 -> name4 */
                init = 0;
                if (gettds(name2, s4, &init, t4,&fs,&ft) == false) {
                  quit = true;
                  return;
                }
                filetds(name4, *s4, init, *t4,fs,ft);
                *cr = 1;
                *lb = *s4;
                break;
      }
   }

   mark_stop_time();
   
   remove(long_name3);
   free(ft1);
   free(ft2);
   free(ft);
}

void supreduce_makeit (state_node* t1,
                      INT_S s1,
                      INT_S lb)
{
   FILE* out;
//   INT_S size;
   int d;

   out = fopen(get_makeit(), "a");
   if (out == NULL) return;
   fprintf(out, "%s = Supreduce(%s,%s)", name4, name1, name2);
   fprintf(out, "  (%ld,%ld;slb=%ld)", s1, count_tran(t1, s1,&d,&d,&d), lb);
   appendTime(out, (int)strlen(name4)+3);
   fprintf(out, "\n\n");
   fclose(out);
}

void supreduce_p()
{
   state_node *t1, *t2, *t3, *t4;
   INT_S s1, s2, s3, s4;
   INT_S lb;
   double long cr;
   float cr2;

   t1 = t2 = t3 = t4 = NULL;
   s1 = s2 = s3 = s4 = 0;
   lb = 0;
   cr = 0;

   supreduce_flag = 0;
   supreduce_r(&t1, &s1, &t2, &s2, &t3, &s3, &t4, &s4, &lb, &cr);

   if (mem_result == 1) {
      mem_result = 0;   /* Reset memory result counter */
      OutOfMemoryMsg();
      user_pause();
   } else if (supreduce_flag > 0) {
      move(22,0); clrtoeol(); refresh();
      printw("Internal error %d", supreduce_flag);
      supreduce_flag = 0;
      user_pause();
   } else {
      if (!quit) {
         supreduce_makeit(t4, s4, lb);

         move(19,0); clrtoeol(); refresh();
         move(20,0); clrtoeol(); refresh();
         move(21,0); clrtoeol(); refresh();
         move(20,0);
         cr2 = (float) cr;
         printw("Simplified supervisor %s has %d states; compression ratio = ", name4, s4);
         printw("%f", cr2);
         move(21,0); clrtoeol(); refresh();
         printw("Lower bound estimate of minimal state size: %d", lb);
         refresh();
         user_pause();
      }
   }

   echo_free();
   freedes(s1, &t1);
   freedes(s2, &t2);
   freedes(s3, &t3);
   freedes(s4, &t4);
}


//void supreduce_p()
//{
  // not_yet();
//}

void convert_tdes_header(int flag)
{
    if(flag == 0){
        printw("CONVERT_ADS");
    }else if(flag == 1)
        printw("CONVERT_TDS"); 
    println();
    println();
    if(flag == 0)
       printw("GIF = CONVERT(ADS)");
    else if(flag == 1)
       printw("JPG = CONVERT(TDS)");
    println();
    println();
}

INT_B convert_r(int flag)
{
    int x,y;
    int result;
    char ch;
    int format_change = 0;
    
    result = 0;
    
    clear();
    convert_tdes_header(flag);
    refresh();
    
    if(flag == 0){
       quit = getname("Enter name of ADS ...............................  ", EXT_ADS, name1, fname1, false);
    } else if(flag == 1)
       quit = getname("Enter name of TDS ...............................  ", EXT_DES, name1, fname1, false);
    if(quit) return true;
    
    printw("Assign new name to %s?  (y/*n)  ", name1);
    refresh();
    ch = read_key();
    if(ch == CEsc){
       quit = true;
       return true;
    }
    if(ch == 'Y' || ch == 'y'){
       println();
       println(); 
       if(flag == 0)
           quit = getname("Enter name of GIF ...............................  ", EXT_GIF, name2, fname2, true);
       else if(flag == 1)       
           quit = getname("Enter name of JPG ...............................  ", EXT_GIF, name2, fname2, true);
       if(quit) return true;

    } else{
       if(ch != CEnter)
          printw("%c",ch);
       strcpy(name2,name1);
       println();
       println();
    }    
    
   /* println();     
    printw("Convert TDS format to DES format? (y/*n) ");
    refresh();
    ch = read_key();
    if(ch == CEsc){
         quit = 1;
         return true;
    }
    if(ch != CEnter)
       printw("%c",ch);
    println(); println();
    if(ch == 'y' || ch == 'Y'){
       format_change = 1;
    }*/
    if(_wherey() > 21) {
         convert_tdes_header(flag);
         esc_footer();
    }
    x = _wherex();
    y = _wherey();
    move(22,0); clrtoeol();
    move(23,0); clrtoeol();
    printw("Processing:  Please wait... ");
    refresh();
    
    move(y,x);
    refresh();
    
    mark_start_time();
    
    result = convert_program(name1,name2, flag, format_change);
    
    mark_stop_time();     
     
    if (result == 0)  {
        move(22,0); clrtoeol();
        move(23,0); clrtoeol();
        move(y,0);  clrtoeol();
        move(y+1,0);clrtoeol();
        move(y+2,0);clrtoeol();
        move(y,x); 
        if(flag == 0)
           printw("\n%s.DES successfully converted to %s%s",name1,name2, EXT_GIF);
        else if(flag == 1)
           printw("\n%s.DES successfully converted to %s%s",name1,name2, EXT_JPG);
        println();
        println();
        println();
        println();
        printw("Call DE to display transition diagram.");        
        //convert_des_makeit(name1,name2);
        return true;
     } else if(result == -2){
        printw("\nOut of Capability, %s.DES is too huge to convert!\n",name1);
     }
      else{
        return false;
     }
    return true;
}
void convert_p(int flag)
{
     if(!convert_r(flag)){
        user_pause();
        return;
     }
     if(mem_result == 1){
         mem_result = 0;
         OutOfMemoryMsg();
         user_pause();
     }
     else{
         if(!quit)
            user_pause();
     }     
     echo_free();
}
void display_header(int flag)
{
     if(flag == 0)
        printw("DISPLAY ADS");
     else
        printw("DISPLAY TDS");
     println();
     println();
     if(flag == 0)
        printw("DISPLAY(ADS)");
     else
        printw("DISPLAY(TDS)");
     println();
     println();
}
void user_pause_d(HANDLE hProcess)
{
   char ch;
//   char cmdline[MAX_PATH];

   DWORD dwExitCode;

   move(23,0); clrtoeol();
   printw("Press <Enter> to return to TTCT Procedures  ");
   refresh();
   do {
     ch = read_key();
   } while (ch != CEnter);

   GetExitCodeProcess(hProcess,&dwExitCode); 

   if(dwExitCode == STILL_ACTIVE && hProcess != NULL)
      TerminateProcess(hProcess,0); 
   
}
void display_p(int flag)
{
     char fullname[MAX_PATH];
     char tmp_path[MAX_PATH];
	 char cwd[MAX_PATH];
     char cmdline[1024];
     char systemdirectory[1024];
//     char *pos;
     int errorno;
     
     
//     FILE *f1;
     STARTUPINFO si;
     PROCESS_INFORMATION pi;
    
     clear();
     display_header(flag);
     refresh();
     
     if(flag == 0)
        quit = getname("Enter name of GIF file for display...................  ", EXT_GIF, name1, long_name1, false);
     else if(flag == 1)
        quit = getname("Enter name of GIF file for display...................  ", EXT_JPG, name1, long_name1, false);
     if(quit) return;
     
     GetSystemDirectory(systemdirectory,MAX_PATH);
	 // Get the path of the gif to be displayed
	 strcpy(fullname, "");	
	 strcpy(tmp_path, "");
	 strcpy(cwd, "");
	 _getcwd(cwd, MAX_PATH);
	 if(strchr(prefix,':')){		
		 _chdir(prefix);
		 _getcwd(tmp_path, MAX_PATH);
		 strcat(tmp_path, "\\");
		 _chdir(cwd);
	 }else{
		 strcpy(tmp_path, cwd);
		 strcat(tmp_path, "\\");
		 strcat(tmp_path, prefix);
	 }
	 if(flag == 0){
		sprintf(fullname, "%s%s.GIF", tmp_path, name1);
	 } else if(flag == 1){
		 sprintf(fullname, "%s%s.JPG", tmp_path, name1);
	 }

     
     si.cb = sizeof(STARTUPINFO);
     GetStartupInfo(&si);
     si.wShowWindow = SW_SHOW;
     si.dwFlags = STARTF_USESHOWWINDOW;
     strcpy(cmdline,"");
     sprintf(cmdline,"%s\\rundll32.exe %s\\shimgvw.dll,ImageView_Fullscreen ",systemdirectory,systemdirectory);    
     //strcat(cmdline,long_name1);
	 strcat(cmdline,fullname);
     //printw(cmdline);
     errorno = CreateProcess(NULL,(LPTSTR)cmdline,NULL,NULL,TRUE,0,NULL,NULL,&si,&pi);  
     
     if(errorno == 0){
       println();
       println();
       printw("error happened");  
       user_pause();             
     } else{
       user_pause_d(pi.hProcess);
     }
}

void localize_header1()
{
     printw("LOCALIZE");println();
     println();
     printw("{LOC1,LOC2,...} = LOCALIZE(PLANT,{PLANT1,PLANT2,...},SUPER)");println();
     println();
}

void localize_header2()
{
     printw("LOCALIZE");println();
     println();
     printw("(DES3, DES4) = LOCALIZE(DES1,DES2,EVENT_LIST)");println();
     println();
}


void localize_makeit1(INT_S sfile, INT_S sloc, char ch, INT_B equ_flag)
{
     FILE* out;
     INT_S s1; state_node *t1;
     INT_S init,i;
     INT_S fs; INT_T *ft;
     int d;
     
     s1 = 0; t1 = NULL;
     fs = 0;
     ft = NULL;
     
     out = fopen(get_makeit(), "a");
     if (out == NULL) return;
     
     
     for(i = 0; i < sloc; i ++){
        fprintf(out,"%s",names2[i]);
        fprintf(out," = Localize(%s,%s,%s)", name1,names1[i],name2);
        init = 0L;
        gettds(names2[i],&s1,&init,&t1, &fs, &ft);
        fprintf(out, "  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d)); 
        appendTime(out, (int)strlen(names2[i]) + 3);
        /*if(i < sloc - 1)
          fprintf(out, "  \n\n");
        else*/
        fprintf(out, "\n\n");
        freedes(s1,&t1);
        s1 = 0; t1 = NULL;
        free(ft);
        ft = NULL;
     }
     /*if(ch == 'y' || ch == 'Y'){
        if(equ_flag)
           fprintf(out,"true");
        else
           fprintf(out,"false");
        fprintf(out," = ControlEqu(%s, (",name1);
        for(i = 0; i < sloc; i ++){
           fprintf(out,"%s",names2[i]);
           if(i < sloc - 1)
              fprintf(out,", ");
        }
        fprintf(out,"), %s)", name2);
        if(equ_flag)
            appendTime(out, 7);
        else
            appendTime(out, 8);
        fprintf(out, "\n\n");
     }*/

     fclose(out);
     
     //localize_stdcmd(name1, name2, sfile, names1, sloc, names2, ch, equ_flag);
}

void localize_makeit2(INT_S s1, state_node*t1, INT_S s2, state_node *t2, INT_T s_tlist, INT_T *tlist)
{
     FILE* out;
     INT_S i;
     int d;
     
     out = fopen(get_makeit(), "a");
     if (out == NULL) return;

     fprintf(out,"%s = Localize(%s,%s,[", name3,name1,name2);

     for(i = 0; i < s_tlist; i ++){
        fprintf(out, "%ld", tlist[i]);
        if(i < s_tlist - 1)
           fprintf(out, ",");
     }
     fprintf(out, "]");

     fprintf(out, ")  (%ld,%ld)", s1, count_tran(t1, s1, &d, &d, &d)); 
     appendTime(out, sizeof(name3 + 3));     
     fprintf(out, "\n\n");
     
     fprintf(out,"%s = Localize(%s,%s, [Tick])", name4,name1,name2);

     fprintf(out, "  (%ld,%ld)", s2, count_tran(t2, s2, &d, &d, &d)); 
     appendTime(out, sizeof(name4 + 3));     
     fprintf(out, "\n\n");

     fclose(out);
}
void localize_p1()
{    
     INT_S init,i;
     INT_S sfile,sloc;
     char prompt[100];
//     char long_txtname[MAX_PATH]; 
     int x,y; 
     INT_B equ_flag;
     int result, mode;

     //s1 = s2 = 0;
     //t1 = t2 = NULL;
     sfile = sloc = 0;
     equ_flag = false;
     mode = 0;
     
     clear();
     localize_header1();
     refresh();
     result = 0;
     
     quit = getname("Enter name of PLANT ......... ",EXT_DES,name1,long_name1, false);
     if(quit) return;
          
     printw("Enter number of independent plant components ... (between 1 and %d) ", MAX_DESS);
     sfile = readint(&ch,1,MAX_DESS); println();
     if(ch == CEsc){
        quit = true;
        return;
     }
     println();
     for(i = 0; i < sfile; i ++){
        strcpy(prompt,"");
        sprintf(prompt,"Enter name of PLANT%d ........ ",i + 1);
        if(_wherey() > 19){
           clear();
           localize_header1();
           esc_footer();
        }
        quit = getname(prompt,EXT_DES,names1[i],long_names1[i], false);
        if(quit) return;
     }
     if(_wherey() > 19){
        clear();
        localize_header1();
        esc_footer();
     }
     quit = getname("Enter name of SUPER ......... ",EXT_DES,name2,long_name2, false);
     if(quit) return;
     
     if(_wherey() > 12){
        clear();
        localize_header1();
        esc_footer();
     }
     printw("Enter number of local controllers ... (between 1 and %d) ",sfile);
     sloc = readint(&ch,1,sfile); println();println();
     if(ch == CEsc){
        quit = true;
        return;
     }
     for(i = 0; i < sloc; i ++){ 
        strcpy(prompt,"");
        sprintf(prompt,"Enter name of LOC%d ........ ",i + 1);
        if(_wherey() > 19){
           clear();
           localize_header1();
           esc_footer();
        }
        quit = getname(prompt,EXT_DES,names2[i],long_names2[i], true);
        if(quit) return;
     }
     
     println();     
     printw("Execute clean up procedure?  (*y/n)");
     refresh();
     ch = read_key();
     if(ch == CEsc){
         quit = 1;
         return;
     }
     if(ch != CEnter)
        printw("%c",ch);
     //println(); println();
     if(ch == 'n' || ch == 'N'){
        mode = 1;
     }
     x = _wherex();
     y = _wherey();
     move(22,0); clrtoeol();
     move(23,0); clrtoeol();
     printw("Processing:  Please wait... ");
     refresh();
         
     move(y,x);
     refresh();
     
     if(_wherey() > 12){
        clear();
        localize_header1();
        esc_footer();
     }
     
     //strcpy(long_txtname,"");
     //make_filename_ext(long_txtname,name2,".TXT");
     
     mark_start_time();
     
     //result = localize_runProgram(sfile,sloc,name1,name2,names1,names2);
     result = localize_proc(sfile,sloc,name1,name2,names1,names2,mode);
     
     mark_stop_time();
     
     if(result != 0){
        quit = 1;
        goto LOCALIZE_LABEL;
     }
     
     for(i = 0; i < sloc; i ++){
        init = 0L;
        strcpy(long_names2[i],"");
        make_filename_ext(long_names2[i],names2[i],EXT_DES);
        if(!exist(long_names2[i])){
           quit = true;
           break;
        }
     }
     if(quit)
        goto LOCALIZE_LABEL;
     println();
     
     if (_wherey() > 17)
     {
         clear();
         localize_header1();
         esc_footer();
     } 
     println();     
     printw("Confirm localization control-equivalent to %s?  (y/*n)",name2);
     refresh();
     ch = read_key();
     if(ch == CEsc){
         quit = 1;
         return;
     }
     if(ch != CEnter)
        printw("%c",ch);
     println(); println();
     if(ch == 'y' || ch == 'Y'){
        if(sfile != sloc){
            printw("The number of independent components is different with the number \n");
            printw("of local controllers, cannot check control-equivalent.\n");
        } else{
         // check_control_equ(sfile,name1,name2,names1,names2,&equ_flag);
          if(equ_flag)
             printw("Localization succeeds!\n");     
          else
             printw("Localization fails!\n");
        }
     }    
LOCALIZE_LABEL:
     if(mem_result == 1){
        mem_result = 0;
        OutOfMemoryMsg();
     } else{
        if(!quit){
           localize_makeit1(sfile,sloc,ch, equ_flag);     
        } 
     } 
     //user_pause();   

}
void localize_p2()
{    
     int col, row, x, y;
     short sign_i;
     INT_T i, *tlist, s_tlist;
     state_node *t1, *t2;
     INT_S s1, s2;
     INT_B ok;
     int result = 0;
     INT_S init;
	 INT_S fs1, fs2; INT_T *ft1, *ft2;
     
     s_tlist = 0;
     tlist = NULL;
     s1 = s2 = 0;
     t1 = t2 = NULL;
     
     clear();
     localize_header2();
     refresh();
     
     
     quit = getname("Enter name of plant generator DES1 ......... ",EXT_DES,name1,long_name1, false);
        if(quit) return;
          
     quit = getname("Enter name of legal language generator DES2 .... ",EXT_DES,name2,long_name2,false);
     if(quit) return;
     
     quit = getname("Enter name of localized event controller DES3 .... ",EXT_DES,name3,long_name3, true);
     if(quit) return;
     
     quit = getname("Enter name of localized tick controller DES4 .... ",EXT_DES,name4,long_name4, true);
     if(quit) return;
     
     if(_wherey() > 12){
        clear();
        localize_header2();
        esc_footer();
     }
     
     printw("Enter list of event labels to be checked by localize;"); println();
     printw("terminate list with -1."); println();
     println(); tab(5);
     sign_i = 0;
     while(sign_i != -1){
        col = _wherex();
        row = _wherey();
        if(col > 75){           
           col = 5; row ++;
           move(row, col);
        }
        if (_wherey() > 21) {
           clear();
           printw("Enter list of event labels to be checked by localize;"); println();
           printw("terminate list with -1."); println();
           println(); tab(5);
           esc_footer();
           col = _wherex();
           row = _wherey();
        }
        sign_i = (short)readint(&ch, -1, MAX_TRANSITIONS);
        if(ch == CEsc){
           quit = 1;
           goto EXLOCALIZE_LABEL;
        }
        if(sign_i != -1){
           i = (INT_T)sign_i;
           addordlist(i, &tlist, s_tlist, &ok);
           if(ok) s_tlist ++;
        }
        move(row, col + 7);
     }
     
     println();
     x = _wherex();
     y = _wherey();
     move(22,0); clrtoeol();
     move(23,0); clrtoeol();
     printw("Processing:  Please wait... ");
     refresh();
         
     move(y,x);
     refresh();
     
     mark_start_time();     
     
     result = localize_proc1(name1,name2,name3, name4, s_tlist, tlist);

     mark_stop_time();
     

     
     fs1 = fs2 = 0;  ft1 = ft2 = NULL;
     
     if(result == 0){
        init = 0;
        gettds(name3, &s1, &init, &t1, &fs1, &ft1);
        init = 0;
        gettds(name4, &s2, &init, &t2, &fs2, &ft2);           
     
     }else{
        quit = 1;
     }

EXLOCALIZE_LABEL:
     if(mem_result == 1){
        mem_result = 0;
        OutOfMemoryMsg();
     } else{
        if(!quit){
           localize_makeit2(s1, t1, s2, t2, s_tlist, tlist);     
        } 
     } 
     
     free(tlist);
     freedes(s1, &t1);
     freedes(s2, &t2);
     free(ft1);
     free(ft2);
}

void localize_p()
{
//     char ch;
     int mode;
     
     clear();
     printw("LOCALIZE");println();
     println();
     refresh();
     
    /* println();
     printw("1. Localize SUPER to Each Component DES"); println();
     println();
     printw("2. Localize SUPER to Each Controllable Event"); println();
     println();
     println();
     
     printw("Please choose Option 1, or 2 ... ");
     mode = readint(&ch, 1, 2);
     if (ch == CEsc)
     {
        quit = true;
        return;
     }*/
     mode = 2;
     if(mode ==1){
        localize_p1();
     }else if(mode == 2)
        localize_p2();
        
     user_pause();
     
}


