#ifndef _EDITOR_H
#define _EDITOR_H

extern void edit_p();
extern void edit_ap();

#endif

