#include <stdio.h>
#include <stdlib.h>
#include "des_proc.h"
#include "outcon.h"

static INT_B *split_state;
static color_t *color_state;
static INT_S   *sibling_list;
static INT_B stable;

void inset(INT_S state, state_node** t, INT_S *s,
           tran_node** in_set, INT_T* s_in_set)
{
    INT_S i;
    INT_T ee, j;
    INT_S jj;
    INT_B ok;

    for (i=0; i < *s; i++) {
        for (j=0; j < (*t)[i].numelts; j++) {
          ee = (*t)[i].next[j].data1;
          jj = (*t)[i].next[j].data2;
          if (jj == state) {
             addordlist1(ee, i, in_set, *s_in_set, &ok);
             if (ok) (*s_in_set)++;
          }
        }
    }
}

void move_init_state(tran_node *in_set, INT_T s_in_set,
                     state_node** t, INT_S *s)
{
    INT_S i;
    INT_T j, e;
    INT_B ok;

    if (s_in_set > 0) {
       *t = (state_node*) realloc(*t, sizeof(state_node)*(*s+1));
       (*t)[*s].marked = (*t)[0].marked;
       (*t)[*s].vocal  = (*t)[0].vocal;
       (*t)[*s].nstinfo = NULL;
       (*t)[*s].numtimer = 0;
       (*t)[*s].ntimer = NULL;
       (*t)[*s].numelts = 0;
       (*t)[*s].next   = NULL;
       split_state = (INT_B*) realloc(split_state, (*s+1)*sizeof(INT_B));
       color_state = (color_t*) realloc(color_state, (*s+1)*sizeof(color_t));
       sibling_list = (INT_S*) realloc(sibling_list, (*s+1)*sizeof(INT_S));
       split_state[*s] = false;
       color_state[*s] = green_color;
       sibling_list[*s] = 0;

       for (j=0; j < (*t)[0].numelts; j++) {
          addordlist1((*t)[0].next[j].data1, (*t)[0].next[j].data2,
                      &(*t)[*s].next, (*t)[*s].numelts, &ok);
          if (ok) (*t)[*s].numelts++;
       }

       /* All transitions referencing state(0) now reference state(new) */
       for (j=0; j < s_in_set; j++) {
          i = in_set[j].data2;
          e = in_set[j].data1;
          delete_ordlist1(e, 0, &(*t)[i].next, (*t)[i].numelts, &ok);
          if (ok) (*t)[i].numelts--;
          addordlist1(e, *s, &(*t)[i].next, (*t)[i].numelts, &ok);
          if (ok) (*t)[i].numelts++;
       }
       (*s)++;
    }
}

void setcolor(INT_S i, color_t color,
              state_node **t, INT_S *s)
{
   color_state[i] = color;
   if ( (*t)[i].vocal > 0) {
      if ( (*t)[i].vocal <= 99) {
          if (color == green_color) {
             (*t)[i].vocal *= 10;
          } else if (color == red_color) {
             (*t)[i].vocal = (*t)[i].vocal*10+1;
          }
      } else {
         if (color == green_color) {
             (*t)[i].vocal = ((*t)[i].vocal / 10) * 10;
         } else if (color == red_color) {
             (*t)[i].vocal = ((*t)[i].vocal / 10) * 10 + 1;
         }
     }
   }
}

static void initialize(state_node** t, INT_S *s)
{
   tran_node *in_set; INT_T s_in_set;
   INT_S i;

   in_set = NULL;
   s_in_set = 0;

   for (i=0 ; i < *s; i++) {
     setcolor(i, green_color, t, s);
   }

   if (*s > 0) {
     inset(0, t, s, &in_set, &s_in_set);
     move_init_state(in_set, s_in_set, t, s);
   }

   free(in_set);
}

static INT_B uncont(INT_T e)
{
   return ((e % 2) == 0);  /* Even */
}

static INT_B cont(INT_T e)
{
   return ((e % 2) != 0);  /* Odd */
}

color_t outcolor(state_node *t, INT_S i, INT_T e)
{
   color_t *cs;
   cs = color_state;

   if ( ( (cs[i] == red_color) && (t[i].vocal == 0) &&
          uncont(e) ) || (cont(e) ) ) {
      return red_color;
   } else if ( ( (cs[i] == green_color) && (t[i].vocal == 0) &&
               uncont(e) ) ||
               ( (t[i].vocal != 0) && uncont(e) ) ) {
      return green_color;
   } else {
      return amber_color;
   }
}

color_t newcolor(state_node** t, INT_S *s,
                 tran_node* in_set, INT_T s_in_set)
{
   color_t color_value, next_color;
   INT_T j;
   INT_B first;

   if (s_in_set > 0) {
      color_value = amber_color;
      first = true;
      j = 0;
      do {

         if (first) {
             first = false;
             color_value = outcolor(*t, in_set[j].data2, in_set[j].data1);
         } else {
             next_color = outcolor(*t, in_set[j].data2, in_set[j].data1);
             if (next_color != color_value)
                 color_value = amber_color;
         }
         j++;
      } while ((j < s_in_set) && color_value != amber_color);
   } else {
      color_value = green_color;
   }
   return color_value;
}


void recolor_states(state_node **t, INT_S *s)
{
   INT_S i;
   tran_node *in_set; INT_T s_in_set;
   color_t old_color, new_color;

   in_set = NULL;  s_in_set = 0;

   for (i=0; i < *s; i++) {
      old_color = color_state[i];
      inset(i, t, s, &in_set, &s_in_set);
      new_color = newcolor(t, s, in_set, s_in_set);
      if (new_color != old_color) {
         stable = false;
         setcolor(i, new_color, t, s);
      }
      free(in_set); in_set = NULL;  s_in_set = 0;
   }
}

void make_sibling(INT_S state, INT_S *count, state_node **t, INT_S *s)
{
   INT_S sibling;

   /* Enlarge "t" */
   *t = (state_node*) realloc(*t, sizeof(state_node)*(*s+1));
   (*t)[*s].marked = (*t)[state].marked;
   (*t)[*s].vocal  = 0;
   (*t)[*s].nstinfo = NULL;
   (*t)[*s].numtimer = 0;
   (*t)[*s].ntimer = NULL;
   (*t)[*s].numelts = 0;
   (*t)[*s].next   = NULL;
   split_state = (INT_B*) realloc(split_state, (*s+1)*sizeof(INT_B));
   color_state = (color_t*) realloc(color_state, (*s+1)*sizeof(color_t));
   sibling_list = (INT_S*) realloc(sibling_list, (*s+1)*sizeof(INT_S));
   split_state[*s] = false;
   color_state[*s] = green_color;
   sibling_list[*s] = 0;

   sibling = *s;

   sibling_list[state] = sibling;
   sibling_list[sibling] = state;

   setcolor(state, green_color, t, s);
   split_state[state] = true;
   setcolor(sibling, red_color, t, s);
   split_state[sibling] = true;

   (*s)++;
}

void make_new_outputs(INT_S i, state_node** t, INT_S *s)
{
   INT_S sibling;

   if ( (*t)[i].vocal > 0) {
       sibling = sibling_list[i];
       (*t)[sibling].vocal = (*t)[i].vocal;
       (*t)[sibling].vocal++;
   }
}

void outset(INT_S i, state_node** t, INT_S *s,
            tran_node** out_set, INT_T* s_out_set)
{
    INT_T ee, j;
    INT_B ok;
    INT_S ii;

    for (j=0; j < (*t)[i].numelts; j++) {
       ee = (*t)[i].next[j].data1;
       ii = (*t)[i].next[j].data2;
       addordlist1(ee, ii, out_set, *s_out_set, &ok);
       if (ok) (*s_out_set)++;
    }
}

void make_new_trans(state_node **t, INT_S i,
                    tran_node *in_set, INT_T s_in_set,
                    tran_node *out_set, INT_T s_out_set)
{
    INT_S sibling;
    INT_T j;
    INT_B ok;
    INT_S ii; INT_T ee;

    sibling = sibling_list[i];
    if (s_in_set > 0) {
        for (j=0; j < s_in_set; j++) {
            if (outcolor(*t, in_set[j].data2, in_set[j].data1) == red_color) {
                ii = in_set[j].data2;
                ee = in_set[j].data1;
                delete_ordlist1(ee, i, &(*t)[ii].next, (*t)[ii].numelts, &ok);
                if (ok) (*t)[ii].numelts--;
                addordlist1(ee, sibling, &(*t)[ii].next, (*t)[ii].numelts, &ok);
                if (ok) (*t)[ii].numelts++;
            }
        }
    }

    if (s_out_set > 0) {
        for (j=0; j < s_out_set; j++) {
          ii = out_set[j].data2;
          ee = out_set[j].data1;
          if ( (ii == i) && (cont(ee) || ((*t)[sibling].vocal == 0))) {
             ii = sibling;
          }
          addordlist1(ee, ii, &(*t)[sibling].next, (*t)[sibling].numelts, &ok);
          if (ok) (*t)[sibling].numelts++;
        }
    }
}

void split_amber_states(INT_S i, INT_S *count, state_node **t, INT_S *s)
{
   tran_node *in_set;  INT_T s_in_set;
   tran_node *out_set; INT_T s_out_set;

   in_set = NULL;    s_in_set = 0;
   out_set = NULL;   s_out_set = 0;

   make_sibling(i, count, t, s);
   make_new_outputs(i, t, s);
   inset(i, t, s, &in_set, &s_in_set);
   outset(i, t, s, &out_set, &s_out_set);
   make_new_trans(t, i, in_set, s_in_set, out_set, s_out_set);

   free(in_set);
   free(out_set);
}

void switch_oldtrans(INT_S i, state_node **t, INT_S *s)
{
   INT_S sibling;
   tran_node *in_set; INT_T s_in_set;
   INT_T j;
   INT_S ii;
   INT_T ee;
   INT_B ok;

   in_set = NULL; s_in_set = 0;

   sibling = sibling_list[i];
   inset(i, t, s, &in_set, &s_in_set);
   if (s_in_set > 0) {
      for (j=0; j < s_in_set; j++) {
          ii = in_set[j].data2;
          ee = in_set[j].data1;
          if (outcolor(*t, ii, ee) == red_color) {
             delete_ordlist1(ee, i, &(*t)[ii].next, (*t)[ii].numelts, &ok);
             if (ok) (*t)[ii].numelts--;
             addordlist1(ee, sibling, &(*t)[ii].next, (*t)[ii].numelts, &ok);
             if (ok) (*t)[ii].numelts++;
          }
      }
   }
   free(in_set);
}

void fix_amber_states(state_node **t, INT_S *s)
{
   INT_S size, i;
   INT_S count;

   size = *s;
   count = *s;
   for (i=0; i < size; i++) {
      if (color_state[i] == amber_color) {
         if (! split_state[i]) {
             split_amber_states(i, &count, t, s);
         } else {
             switch_oldtrans(i, t, s);
         }
      }
   }
}

void outcon_des(state_node** t1, INT_S* s1, INT_T **t2, INT_S *s2)
{
   /* Allocate memory for "color" and "split".
      The size is the same as "s1"
   */

   split_state = (INT_B*) calloc(*s1, sizeof(INT_B));
   color_state = (color_t*) calloc(*s1, sizeof(color_t));
   sibling_list = (INT_S*)  calloc(*s1, sizeof(INT_S));

   if ( (split_state == NULL) || (color_state == NULL) ||
        (sibling_list == NULL) ) {
      free(split_state);
      free(color_state);
      free(sibling_list);
      mem_result = 1;
      return;
   }

   initialize(t1,s1);
   do {
       stable = true;
       recolor_states(t1,s1);   /* return stable = false unless OCC achieved */
       if (stable == false)
          fix_amber_states(t1,s1);
   } while (!stable);

   free(split_state);
   free(color_state);
   free(sibling_list);

   /* Minimize t1 */
   reach(s1, t1, s2, t2); 
   minimize(s1, t1);
}
