#ifndef _HICONS_H
#define _HICONS_H

#include "des_data.h"

extern INT_B hiconsis_des(state_node **t1, INT_S *s1, INT_T **t2, INT_S *s2);

#endif
