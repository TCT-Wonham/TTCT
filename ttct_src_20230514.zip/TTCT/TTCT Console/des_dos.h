#ifndef _DES_DOS_H
#define _DES_DOS_H

#include <alloc.h>

/* Use this version of tran_node for testing in BC compiler */
typedef struct tran_node {
   INT_S data2;
   INT_T data1;
   INT_T data3;
} tran_node;

/* Used for recoding of states for testing in BC compiler */
typedef struct recode_node {
   INT_S   recode;
   boolean reached;
} recode_node;

/* State map */
typedef struct state_map {
   boolean marked;
   INT_S state;
   INT_S numelts;
   INT_S *next;
} state_map;

#endif

