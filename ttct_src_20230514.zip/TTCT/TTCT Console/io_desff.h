
/*
 *
 *   TCTRealX: io_desff.h
 *
 *   for the Control System Group 
 *   University of Toronto, Ontario, Canada
 *
 *   by Cedric DELAYRE  --- July 1996
 *   delayre@emi.u-bordeaux.fr
 */


#ifndef __INCLUDE_IODESFF
# define __INCLUDE_IODESFF

#include <stdio.h>
#include "des_data.h"

extern long
write_tds_to_file( state_node *data, INT_S elemts, int init, INT_T *data1,
		   INT_S elemts1, FILE *out );

extern long
write_ades_to_file( state_node *data, int elemts, timed_event *data1,
		    int elemts1, int init, FILE *out );

extern state_node*
read_old_des_file( FILE *in, int *elemts, int *init );

extern state_node*
read_new_tds_file( FILE *in, int *elemts, int *init, INT_S *elemts1, 
		   INT_T **data1 );

extern state_node*
read_ades_file(FILE *in, int *elemts, int *init, INT_T *elemts1,
	       timed_event **data1);

#endif
