#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tct_curs.h"
//#include <unistd.h>
#include <sys/stat.h>
/*#include <pwd.h> */
#include "wtct.h"
#include "tct_proc.h"
#include "display.h"
#include "ttct_io.h"
#include "tct_curs.h"
#include "editor.h"
#include "show.h"
#include "setup.h"
#include <direct.h>

#define CommandSet  "0123456789PHRNIBEDSOXGFAUC"
#define ACommandSet "0123456IBEDSOXGFTUC"
#define MCommandSet "IRBTAXCO"
void proc_acommand(char ch);
void x_command() ;

int Aflag=0;
int Tflag=0;

/* Confirm_right_size:
   Determines if the size is correct: ie. 80x24 or greater */
//void confirm_right_size() {
/*#if defined(__UNIX__)*/
//   if ((stdscr->_maxy < 23) || (stdscr->_maxx < 78)) {
//     endwin();
//     printf("Current size: %hdx%hd\n", stdscr->_maxx, stdscr->_maxy);
//     printf("Screen must be at least 80x24\n");
 //    exit(1);
//   } 
/*#endif*/ 
//}

void process_h_command(char ch)
{
    switch (ch) {
      case '0': vocalize_p();     break;
      case '1': outconsis_p();    break;
      case '2': hiconsis_p();     break;
      case '3': higen_p();        break;
      case '4': allevents_p();    break;
      case '5': check_des_p();    break;    /* Invisible to the user */
   }       
}

void hierchical()
{
    char ch;

    ch = get_command();
    ch = toupper(ch);
    process_h_command(ch);
}

void process_r_command(char ch)
{
    switch (ch) {
      case '1' : supnorm_p();     break;
    }
}

void partial_obs()
{
     char ch;

     ch = get_command();
     ch = toupper(ch);
     process_r_command(ch);
}

void process_p_command(char ch)
{
    switch (ch) {
      case '0' : project_p();     break;
      case '1' : eventmap_p();    break;
    }
}

void p_proc()
{
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_p_command(ch);
}

void process_s_command(char ch)
{
   switch (ch) {
     case 'E': show_des_p();     break;
     case 'A': show_dat_p();     break;
     case 'X': show_ascii_p();   break;
   }
}

void process_s_acommand(char ch)
{
   switch (ch) {
     case 'E': show_ads_p();     break;
	/*case 'A': show_dat_p();     break;
     case 'X': show_ascii_p();   break;*/
   }
}

void s_proc()
{
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_s_command(ch);   
}

void s_aproc()
{
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_s_acommand(ch);   
}

void process_o_acommand(char ch)
{
   switch (ch) {
      case 'E': print_ads_p();    break;
/*      case 'A': print_dat_p();    break;
      case 'X': print_ascii_p();  break;*/
   }
}

void process_o_command(char ch)
{
   switch (ch) {
      case 'E': print_des_p();    break;
      case 'A': print_dat_p();    break;
      case 'X': print_ascii_p();  break;
   }
}

void process_g_command(char ch)
{
   switch (ch) {
      case 'A': export_des_p();  break;
      case 'B': export_altdes_p(); break;
      case 'C': export_gml_des_p(); break; 
      case 'D': export_place_des_p(); break; 
	 /* case 'X': print_ascii_p();  break;*/
   }
}

void process_g_acommand(char ch)
{
   switch (ch) {
      case 'A': export_ads_ap();  break;
      case 'B': export_altads_ap(); break;
   /* case 'A': print_dat_p();    break;
      case 'X': print_ascii_p();  break;*/
   }
}

void o_proc() {
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_o_command(ch);
}

void g_proc() {
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_g_command(ch);
}

void o_aproc() {
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_o_acommand(ch);
}

void process_f_command(char ch)
{
   switch (ch) {
      case 'E': file_des_p();    break;
      case 'A': file_dat_p();    break;
      case 'D': file_ats_p();    break;
   }
}

void f_proc() {
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_f_command(ch);
}

void process_f_acommand(char ch)
{
   switch (ch) {
      case 'E': file_ads_p(); break;
      case 'D': file_aas_p(); break;
   }
}

void f_aproc() {
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_f_acommand(ch);
}

void g_aproc() {
   char ch;

   ch = get_command();
   ch = (char) toupper(ch);
   process_g_acommand(ch);
}

void process_1_command(char ch)
{
   switch (ch) {
     case CEnter: selfloop_p();   break;
     case '0'   : complement_p(); break;
     case '1'   : localize_p(); break;
   }
}

void _1_proc() {
   char ch;
  
   ch = get_command();
   ch = (char) toupper(ch);
   process_1_command(ch);
}
void process_c_command(char ch, int flag){
   switch(ch){
      case 'E': convert_p(flag);
   }

}
void _c_command(int flag){
    char ch;
    ch = get_command();
    ch = (char)toupper(ch);
    process_c_command(ch, flag);
}
void process_d_command(char ch, int flag){
   switch(ch){
      case 'E': display_p(flag);
   }

}
void _d_command(int flag){
    char ch;
    ch = get_command();
    ch = (char)toupper(ch);
    process_d_command(ch, flag);
}

/*
void process_command(char ch)
{
   switch (ch) {
     case '0': acommand();      break; /*create_p();      break; 
     case '1': _1_proc();       break;
     case '2': trim_p();        break;
     case '3': sync_p();        break;
     case '4': meet_p();        break;
     case '5': supcon_p();      break;
     case '6': mutex_p();       break;
     case '7': condat_p();      break;
     case '8': supreduce_p();   break;
     case '9': minstate_p();    break;
     case 'P': p_proc();        break;
     case 'I': isomorph_p();    break;
     case 'N': nonconflict_p(); break;
     case 'B': bfs_recode_p();  break;
     case 'E': edit_p();        break;
     case 'D': directory_p();   break;
     case 'S': s_proc();        break;
/*   case 'O': o_proc();        break; */
 /*    case 'F': f_proc();        break;
     case 'G': g_proc();        break;
     case 'H': hierchical();    break;
     case 'R': partial_obs();   break;
   }
}
*/

/* showing the menu for the activitiy graphs */
void acommand() 
{
   int x,y;
   char ch;

   do {
      adv_act_menu(); /* display the selection */
      refresh();
      x = _wherex();
      y = _wherey();
      do {
         move(y,x);
         ch = get_command();
         ch = (char) toupper(ch);
         refresh();
      } while (strchr(ACommandSet, ch) == NULL);

      proc_acommand(ch);

    } while ((ch != 'X') && (ch != 'T' ) );
}

void process_command(char ch)
{
   switch (ch) {
     case '0': create_p();      break; 
     case '1': _1_proc();       break;
     case '2': trim_p();        break;
     case '3': sync_p();        break;
     case '4': meet_p();        break;
     case '5': supcon_p();      break;
     case '6': mutex_p();       break;
     case '7': condat_p();      break;
     case '8': supreduce_p();   break;
     case '9': minstate_p();    break;
     case 'P': p_proc();        break;
     case 'I': isomorph_p();    break;
     case 'N': nonconflict_p(); break;
     case 'B': bfs_recode_p();  break;
     case 'E': edit_p();        break;
     case 'U': directory_p();   break;
     case 'S': s_proc();        break;
/*   case 'O': o_proc();        break; */
     case 'F': f_proc();        break;
     case 'G': g_proc();        break;
     case 'H': hierchical();    break;
     case 'R': partial_obs();   break;
     case 'A': Aflag=1;      break;
     case 'C': _c_command(1);    break;
     case 'D': _d_command(1);     break;
    /* case 'X': x_command();      break;*/
   }
}

void tcommand() 
{
   int x,y;
   char ch;

   do {
      advance_menu();
      refresh();
      x = _wherex();
      y = _wherey();
      do {
         move(y,x);
         ch = get_command();
         ch = (char) toupper(ch);
         refresh();
      } while (strchr(CommandSet, ch) == NULL);

      process_command(ch);

    } while ((ch != 'X') && (ch != 'A' ) );
}

/* process commands for activity graphs */
void proc_acommand(char ch)
{
   switch (ch) {
     case '0': create_ap();     break;
     case '1': selfloop_ap();   break;
     case '2': trim_ap();       break;
     case '3': convert_ap();    break;
     case '4': comp_ap();       break;
     case '5': mutex_ap();      break; 
/*     case '5': minstate_ap();   break; */
     case '6': complement_ap(); break;
     case 'I': isomorph_ap();   break;
/*     case '5': supcon_p();      break;
     case '7': condat_p();      break;
     case 'P': p_proc();        break;
     case 'N': nonconflict_p(); break;*/
     case 'B': bfs_recode_ap(); break;
     case 'E': edit_ap();       break;
     case 'U': directory_p();   break;
     case 'S': s_aproc();       break;
/*     case 'O': o_aproc();       break; */
     case 'F': f_aproc();       break;
     case 'G': g_aproc();       break; 
     case 'T': Tflag=1;       break;
     case 'C': _c_command(0);    break;
     case 'D': _d_command(0);    break;
     //case 'C': convert_act_p();   break;
   /*  case 'X': x_command();      break;*/
/*     case 'H': hierchical();    break;
     case 'R': partial_obs();   break;*/
   }
}


void exit_os_p()
{
	//    INT_OS result;

	//    if (result) {}   /* To remove warning */

	not_yet();
}

void process_m_command(char ch)
{
    switch (ch) {
      case 'I': introduction_p();          break;
      case 'R': reset_directory_p();       break;
      case 'B': bell_control_p();          break;
      case 'A': acommand();                break;
      case 'T': tcommand();                break;
      case 'D': display_control_p();       break;
      case 'O': exit_os_p();               break;
      case 'C': timing_control_p();        break;
   }
}


int getline(char s[], int lim, FILE* f) {
   int c,i;

   i = 0;
   while (--lim > 0 && (c=getc(f)) != EOF && c != '\n')
      s[i++] = c;
   s[i] = '\0';
   return i;
}



int wtct_init(char *ctct_exe_file) {
//   struct stat s;
/*   struct passwd *p; */
   char ini[_MAX_PATH],info[_MAX_PATH];
//   char  str[99];
//   FILE  *f;
   char *ptr;
   char currentDir[_MAX_PATH];
   int  pos;
   
   initscr();                   /* Initialize curses */
   nonl(); cbreak(); noecho();  /* To get character-at-a-time input */  

   /* Set the directory path up */
   strcpy(ini,"");
   if (_fullpath(ini, ctct_exe_file, _MAX_PATH) == NULL)
   {
	   _getcwd(currentDir, 255);
	   ptr = strchr(currentDir, '\\');
	   if (ptr != NULL)
	   {
		   ptr[0] = 0;
		   strcpy(ttct_ini_file, currentDir);
		   strcat(ttct_ini_file, "\\");
		   strcat(ttct_ini_file, "ttct.ini");
	   } 
	   else
	   {
		   strcat(ttct_ini_file, "C:");
		   strcat(ttct_ini_file, "\\");
		   strcat(ttct_ini_file, "ttct.ini");   
	   }       
   }
   else 
   {
	   ptr = strrchr(ini, '\\');
	   pos = ptr-ini;

	   if (pos < 0) pos = 0;

	   strncpy(ttct_ini_file, ini, pos+1);
	   ttct_ini_file[pos+1] = '\0';
	   strcat(ttct_ini_file, "ttct.ini");
   }

   if (_fullpath(info, ctct_exe_file, _MAX_PATH) == NULL){
	   strcpy(info_file,"TTCT_Info");
   }
   else
   {
	   ptr = strrchr(info, '\\');
	   pos = ptr-info;

	   if (pos < 0) pos = 0;

	   strncpy(info_file, info, pos+1);
	   info_file[pos+1] = '\0';         
	   strcat(info_file, "TTCT_Info");
   }

   setuserpath(ttct_ini_file);
   
     
   return 0;
}

int wtct_run() {
   char version_str[80];
   char ch;
   int x,y;

   sprintf(version_str, "TTCT 2023.05.14");   /* YYYY/MM/DD */

/*#if defined(__BORLANDC__)
   strcat(version_str, " BORLAND C/C++");
#endif

#if defined(AUTOTEST)
   strcat(version_str, " autotest");
#endif*/

   clear();
   tct_logo(version_str);
   move(0,0);
   refresh();
   ch = read_key();

   clear();
   do {
    if  (( Aflag == 0 ) && (Tflag == 0 )) {
       main_menu();
       refresh();
       x = _wherex();
       y = _wherey();
       do {
          ch = get_command();
          ch = (char) toupper(ch);
          move(y,x);
          refresh();
       } while (strchr(MCommandSet, ch) == NULL);
       process_m_command(ch);
    } else {
        if ( Aflag == 1 ) {     /* Check if there exist an A command in TTG procedures */
              process_m_command('A');
              Aflag=0;
              ch='A';
        }
        if ( Tflag == 1 ) {     /* Check if there exist an T command in ATG procedures */ 
              process_m_command('T');
              Tflag=0;
              ch='T';
        }     
    }  
      
   } while (ch != 'X');

   return 0;
}

int wtct_done() {
   clear();  refresh();
   endwin();                    /* End curses */
   return 0;
}

void x_command() {
   char ch;
   int x,y;
   
   do {
      main_menu();
      refresh();
      x = _wherex();
      y = _wherey();
      do {
          ch = get_command();
          ch = (char) toupper(ch);
          move(y,x);
          refresh();
      } while (strchr(MCommandSet, ch) == NULL);

      process_m_command(ch);
   } while (ch != 'X');
   
   wtct_done();
   
}
