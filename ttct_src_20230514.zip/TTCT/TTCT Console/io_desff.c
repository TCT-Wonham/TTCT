/*
 *
 *   TCTRealX: io_desff.c --- Input/Output operations on DES files
 *
 *   for the Control System Group 
 *   University of Toronto, Ontario, Canada
 *
 *   by Cedric DELAYRE  --- July 1996
 *   delayre@emi.u-bordeaux.fr
 */

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "des_data.h"
#include "io_desff.h"

/*** some constants */

static const char *header         = "TCTRealX DES file version 1.0";
static const char end_text_header = (char)0x01a;
static const char *signature      = "Z8^0L;1";
static const int endian           = 0xff00aa55;
static const int delimiter        = -1;
static const int first_block_type = 0;
static const int second_block_type= 1;
static const int timed_block_type = 2;
static const int stinfo_block_type= 3;
static const int timer_block_type = 4;
static const int end_DES_file[]   = { -1, 8, 0, 0 };
static const int size_last_block  = 4;

#define check_writing(a,b) if(!check_error_writing_file(a,b,__FILE__,__LINE__)) return 0;
#define check_reading(a,b) if(!check_error_reading_file(a,b,__FILE__,__LINE__)) return NULL;

static INT_B
check_error_writing_file( int count, int effective, char *source, int line );
static INT_B
check_error_reading_file( int count, int effective, char *source, int line );

/*
**  this function writes the new DES files format 1.0 (32bits) 
**     data represents the DES data structure
**     elemts the number of states in DES
**     init the initial state
**     out points to a write-only opened file
**  it returns the size in bytes of the written DES file
 */

long
write_tds_to_file(state_node *data, INT_S elemts, int init, INT_T *data1,
		  INT_S elemts1, FILE *out )
{
  int size_header = (int)strlen(header);
  int length_signature = (int)strlen(signature);
  long data_size_offset;
  int block_size;
  int dummy=0, i;
  INT_S z,yy;

  assert( out && elemts>=0 );
  
  /*** first, write the header to the output DES file */
  check_writing((int) fwrite( header,sizeof(char),size_header,out ),	size_header );

  /*** write the end of the text header, the signature and 
    the endian number */
  check_writing((int) fwrite( &end_text_header,sizeof(char),1,out ), 1 );
  check_writing((int) fwrite( signature,sizeof(char),length_signature,out ),
		 length_signature );
  check_writing((int) fwrite( &endian,sizeof(int),1,out ), 1 );

  /*** write the first block */
  check_writing((int) fwrite( &first_block_type,sizeof(int),1,out ), 1 );
  data_size_offset = ftell(out);
  check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);  /* get a safe place */
  check_writing((int) fwrite(&elemts,sizeof(int),1,out), 1); /* # of states */
  check_writing((int) fwrite(&init,sizeof(int),1,out), 1);   /* initial state */
  /* write the list of marker states */
  for (i=0; i<elemts; i++)
    {
      if (data[i].marked)
	{
	  check_writing((int) fwrite(&i,sizeof(int),1,out), 1);
	}
    }
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
  /* write the transition's nodes informations */
  for (i=0; i<elemts; i++)
    {
      if (data[i].numelts == 0) continue;
      check_writing((int) fwrite(&i,sizeof(int),1,out), 1);  /* write exit state */
      /* write the number of transitions */
      check_writing( (int)fwrite(&(data[i].numelts),sizeof(short),1,out), 1);
      /* and the transitions */
	  for (z=0; z < data[i].numelts; z++) {
		  yy = (unsigned long) data[i].next[z].data1;
		  yy = yy << 22;
		  yy = yy | data[i].next[z].data2;
		//  fwrite(&yy, sizeof(INT_S), 1, out);
		  check_writing( (int)fwrite(&yy,sizeof(INT_S),1,out), 1);
	  }
      //check_writing((int) fwrite(data[i].next,sizeof(tran_node),data[i].numelts,
	//		    out), data[i].numelts);
    }
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
  /* write the output vocals */
  for (i=0; i<elemts; i++)
    {
      if (!data[i].vocal) continue;
      check_writing((int) fwrite(&i,sizeof(int),1,out), 1);
      dummy = data[i].vocal;
      check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);
    }
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);

  /* Update the block size  */
  block_size = (int)(ftell(out) - data_size_offset);
  fseek(out, data_size_offset, SEEK_SET);
  check_writing((int) fwrite(&block_size,sizeof(int),1,out), 1);
  fseek(out, 0, SEEK_END);

  if (elemts1 != 0) {
     /*** write second block */
     check_writing((int) fwrite( &second_block_type,sizeof(int),1,out ), 1 );
     data_size_offset = ftell(out);
     check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);  /*get a safe place*/
     check_writing((int) fwrite(&elemts1,sizeof(int),1,out), 1); /* # of events */
     /* check_writing( fwrite(&init,sizeof(int),1,out), 1);  initial state */
     
     /* write the list of forcible events */
     check_writing((int) fwrite(data1,sizeof(INT_T),elemts1,out), elemts1);
     check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
     
     /* Update the block size  */
     block_size = (int)(ftell(out) - data_size_offset);
     fseek(out, data_size_offset, SEEK_SET);
     check_writing((int) fwrite(&block_size,sizeof(int),1,out), 1);
     fseek(out, 0, SEEK_END);
  }

  if (elemts != 0 && data[0].nstinfo != NULL) {
     /*** write third block */
     check_writing((int) fwrite( &stinfo_block_type,sizeof(int),1,out ), 1 );
     data_size_offset = ftell(out);
     check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);  /*get a safe place*/
     check_writing((int) fwrite(&elemts,sizeof(int),1,out), 1); /* # of events */
     /* check_writing( fwrite(&init,sizeof(int),1,out), 1);  initial state */
     
     /* write the state info of each state */
     for (i=0; i < elemts; i++) {
	check_writing((int) fwrite(&data[i].nstinfo[0].state,
			      sizeof(INT_S),1,out), 1);
     }
     check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
     
     /* Update the block size  */
     block_size = (int)(ftell(out) - data_size_offset);
     fseek(out, data_size_offset, SEEK_SET);
     check_writing((int) fwrite(&block_size,sizeof(int),1,out), 1);
     fseek(out, 0, SEEK_END);
  }

  if (elemts != 0 && data[0].ntimer != NULL) {
     /*** write fourth block */
     check_writing((int) fwrite( &timer_block_type,sizeof(int),1,out ), 1 );
     data_size_offset = ftell(out);
     check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);  /*get a safe place*/
     check_writing((int) fwrite(&elemts,sizeof(int),1,out), 1); /* # of events */
     /* check_writing( fwrite(&init,sizeof(int),1,out), 1);  initial state */
     
     /* write the timer information */
     for (i=0; i<elemts; i++) {
	if (data[i].numtimer == 0) continue;
	check_writing((int) fwrite(&i,sizeof(INT_S),1,out), 1);/* write state*/
	/* write the number of timers */
	check_writing((int) fwrite(&(data[i].numtimer),sizeof(INT_T),1,out), 1);
	/* and the timer info */
	check_writing((int) fwrite(data[i].ntimer,sizeof(timer_info),
			      data[i].numtimer, out), data[i].numtimer);
     }
     check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
     
     /* Update the block size  */
     block_size = (int)(ftell(out) - data_size_offset);
     fseek(out, data_size_offset, SEEK_SET);
     check_writing((int) fwrite(&block_size,sizeof(int),1,out), 1);
     fseek(out, 0, SEEK_END);
  }
  
  /*** write the last block */
  check_writing((int) fwrite( end_DES_file,sizeof(int),size_last_block,out),
		 size_last_block );

  return ftell(out);
}

/* write new activity graph to file; added block for transition list */
long
write_ades_to_file( state_node *data, int elemts, timed_event *data1, 
		    int elemts1, int init, FILE *out )
{
  int size_header = (int)strlen(header);
  int length_signature = (int)strlen(signature);
  long data_size_offset;
  int block_size;
  int dummy=0, i;
  INT_S z,yy;

  assert( out && elemts>=0 );
  
  /*** first, write the header to the output DES file */
  check_writing((int) fwrite( header,sizeof(char),size_header,out ),	size_header );

  /*** write the end of the text header, the signature and 
    the endian number */
  check_writing((int) fwrite( &end_text_header,sizeof(char),1,out ), 1 );
  check_writing((int) fwrite( signature,sizeof(char),length_signature,out ),
		 length_signature );
  check_writing((int) fwrite( &endian,sizeof(int),1,out ), 1 );

  /*** write the first block */
  check_writing((int) fwrite( &first_block_type,sizeof(int),1,out ), 1 );
  data_size_offset = ftell(out);
  check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);  /* get a safe place */
  check_writing((int) fwrite(&elemts,sizeof(int),1,out), 1); /* # of states */
  check_writing((int) fwrite(&init,sizeof(int),1,out), 1);   /* initial state */
  /* write the list of marker states */
  for (i=0; i<elemts; i++)
    {
      if (data[i].marked)
	{
	  check_writing((int) fwrite(&i,sizeof(int),1,out), 1);
	}
    }
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
  /* write the transition's nodes informations */
  for (i=0; i<elemts; i++)
    {
      if (data[i].numelts == 0) continue;
      check_writing((int) fwrite(&i,sizeof(int),1,out), 1);  /* write exit state */
      /* write the number of transitions */
      check_writing((int) fwrite(&(data[i].numelts),sizeof(short),1,out), 1);
      /* and the transitions */
	  for (z=0; z < data[i].numelts; z++) {
		  yy = (unsigned long) data[i].next[z].data1;
		  yy = yy << 22;
		  yy = yy | data[i].next[z].data2;
		  //  fwrite(&yy, sizeof(INT_S), 1, out);
		  check_writing( (int)fwrite(&yy,sizeof(INT_S),1,out), 1);
	  }
      //check_writing((int) fwrite(data[i].next,sizeof(tran_node),data[i].numelts,
	//		    out), data[i].numelts);
    }
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);
  /* write the output vocals */
  for (i=0; i<elemts; i++)
    {
      if (!data[i].vocal) continue;
      check_writing((int) fwrite(&i,sizeof(int),1,out), 1);
      dummy = data[i].vocal;
      check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);
    }
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);

  /* Update the block size  */
  block_size = (int)(ftell(out) - data_size_offset);
  fseek(out, data_size_offset, SEEK_SET);
  check_writing((int) fwrite(&block_size,sizeof(int),1,out), 1);
  fseek(out, 0, SEEK_END);

  /*** write second block */
  check_writing((int) fwrite( &timed_block_type,sizeof(int),1,out ), 1 );
  data_size_offset = ftell(out);
  check_writing((int) fwrite(&dummy,sizeof(int),1,out), 1);  /* get a safe place */
  check_writing((int) fwrite(&elemts1,sizeof(int),1,out), 1); /* # of states */
  /* check_writing( fwrite(&init,sizeof(int),1,out), 1);  initial state */

  /* write the list of timebounds of events */
  check_writing((int) fwrite(data1,sizeof(timed_event),elemts1,out), elemts1);
  check_writing((int) fwrite(&delimiter,sizeof(int),1,out), 1);

  /* Update the block size  */
  block_size = (int)(ftell(out) - data_size_offset);
  fseek(out, data_size_offset, SEEK_SET);
  check_writing((int) fwrite(&block_size,sizeof(int),1,out), 1);
  fseek(out, 0, SEEK_END);
  
  /*** write the last block */
  check_writing((int) fwrite( end_DES_file,sizeof(int),size_last_block,out),
		 size_last_block );

  return ftell(out);
}


/*
** This functions reads a DES from the old format 2.00 of a DES file (16bits)
**   it returns the DES data structure receiving the file's content
**   elemts is the number of DES states
**   init is the initial state of the DES
**   in points to the read-only DES file
 */

state_node*
read_old_des_file( FILE *in, int *elemts, int *init )
{
  short oldint;
  state_node *the_des;
  int nb_states, initial_state;

  assert( in && elemts && init );

  /* reads the number of states */
  check_reading((int) fread(&oldint,sizeof(short),1,in), 1);
  nb_states = (int)oldint;
  assert( nb_states>=0 );
  the_des = newdes(nb_states);
  assert( the_des );
  /* reads the initial state */
  check_reading((int) fread(&oldint,sizeof(short),1,in), 1);
  initial_state = (int)oldint;

  /* reads the marker states list */
  while (!feof(in))
    {
      int marker;

      check_reading((int) fread(&oldint,sizeof(short),1,in), 1);
      if (oldint == -1) break;
      marker = (int)oldint;
      assert( marker>=0 && marker<nb_states );
      the_des[marker].marked = true;
    }

  /* reads the transitions informations */
  while (!feof(in))
    {
      short target, event, source;

      check_reading((int) fread(&source,sizeof(short),1,in), 1);
      if (source == -1 || feof(in)) break;
      check_reading((int) fread(&event,sizeof(short),1,in), 1);
      check_reading((int) fread(&target,sizeof(short),1,in), 1);
      add_transition( the_des, nb_states, (int)source, (int)event,
		      (int)target );
    }

  fseek(in,2*sizeof(short),SEEK_CUR);
  fread(&oldint,sizeof(short),1,in);

  /* reads vocal output states */
  while (!feof(in))
    {
      short state, output;

      check_reading((int) fread(&state,sizeof(short),1,in), 1);
      if (state == -1) break;
      check_reading((int) fread(&output,sizeof(short),1,in), 1);
      assert( state>=0 && state<nb_states );
      the_des[state].vocal=output;
    }

  /* some other stuff... */
  *init = initial_state;
  *elemts = nb_states;
  return the_des;
}

/*
** This functions reads a DES from the new format 1.0 of a DES file (32bits)
**   it returns the DES data structure receiving the file's content
**   elemts is the number of DES states
**   init is the initial state of the DES
**   in points to the read-only DES file
 */

state_node*
read_new_tds_file( FILE *in, int *elemts, int *init, INT_S *elemts1, 
		   INT_T **data1)
{
  state_node *the_des;
  int nb_states, initial_state, blocktype;
  int length_signature= (int)strlen(signature);
  char string[1024];
  int read_endian;
  INT_S yy;

  assert( in && elemts && init );
  *elemts1 = 0;
  *data1 = NULL;

  /* seek for the position after the text header */
  while (!feof(in))
    {
      char dummy;

      check_reading((int) fread(&dummy,sizeof(char),1,in), 1);
      if (dummy==end_text_header)
	break;
    }
  assert(!feof(in));

  /* reads the signature */
  check_reading((int) fread(string,sizeof(char),length_signature,in),
		 length_signature );
  string[length_signature]='\0';
  if ((int)strcmp(signature,string) != 0)
    {
      fprintf(stderr,"TDS file reading: signature is different (abort)");
      return NULL;
    }

  /* reads the endian */
  check_reading((int) fread(&read_endian,sizeof(int),1,in), 1);
  if (read_endian!=endian)
    {
      fprintf(stderr,"TDS file reading: endian is incorrect (abort)");
      return NULL;
    }  

  /* we are reading for the number of states */
  fseek(in,8,SEEK_CUR);
  check_reading((int) fread(&nb_states,sizeof(int),1,in), 1);
  check_reading((int) fread(&initial_state,sizeof(int),1,in), 1);
  the_des = newdes(nb_states);
  assert(the_des);

  /* list of marker states */
  while (!feof(in))
    {
      int marker;

      check_reading((int) fread(&marker,sizeof(int),1,in), 1);
      if (marker==-1)
	break;
      the_des[marker].marked = true;
    }

  /* list for transitions */
  while (!feof(in))
    {
      int source;
      short nb_trans,i;
      tran_node trans;

      check_reading((int) fread(&source,sizeof(int),1,in), 1);
      if (source==-1)
	break;
      check_reading((int) fread(&nb_trans,sizeof(short),1,in), 1);
      for (i=0; i<nb_trans; i++)
	{
		check_reading((int) fread(&yy,sizeof(INT_S),1,in), 1);
		trans.data1 = (INT_T) ((unsigned long) yy >> 22);
		trans.data2 = (yy & 0x003FFFFF);

	  //check_reading((int) fread(&trans,sizeof(tran_node),1,in), 1);
	  add_transition( the_des, nb_states, source,
			  (int)trans.data1, (int)trans.data2 );
	}
    }

  /* reads for vocal outputs */
  while (!feof(in))
    {
      int state, voc;

      check_reading((int) fread(&state,sizeof(int),1,in), 1);
      if (state==-1)
	break;
      check_reading((int) fread(&voc,sizeof(int),1,in), 1);
      the_des[state].vocal = voc;
    }

  /* read next blocks */
  while (!feof(in)) {
     INT_B unknown;
     unknown = true;
     check_reading((int) fread(&blocktype,sizeof(int),1,in), 1);
     if (blocktype == second_block_type) {
	unknown = false;
	fseek(in,sizeof(int),SEEK_CUR);
	/*int dummy;*/
	while (!feof(in)) {
	   int dummy;
	   check_reading((int) fread(&dummy,sizeof(int),1,in), 1);
	   if (dummy == -1) break;
	   *elemts1 = (INT_S) dummy;
	   if (*elemts1 == 0) break;
	   else {
	      *data1 = (INT_T*) calloc(*elemts1, sizeof(INT_T));
	      check_reading((int) fread(*data1,sizeof(INT_T),*elemts1,in), *elemts1);
	   }
	}
     }
     if (blocktype == stinfo_block_type) {
	unknown = false;
	fseek(in,sizeof(int),SEEK_CUR);
	/*int dummy;*/
	while (!feof(in)) {
	   int dummy;
	   INT_S i;
	   check_reading((int) fread(&dummy,sizeof(int),1,in), 1);
	   if (dummy == -1) break;
	   /*if (nb_states != (INT_S) dummy) {
	      printw("Something is wrong here! Please report !");
	      user_pause();
	      break;
	   }*/
	   if (nb_states == 0) break;
	   else {
	      state_info *tmp;
	      for (i=0; i < nb_states; i++) {
		 tmp = the_des[i].nstinfo;
		 tmp =(state_info*)calloc(1, sizeof(state_info));
		 check_reading((int) fread(&tmp->state,sizeof(INT_S),1,in), 1);
		 the_des[i].nstinfo = tmp;
	      }
	   }
	}
     }
     if (blocktype == timer_block_type) {
	int dummy;
	unknown = false;
	fseek(in,sizeof(int),SEEK_CUR);
	check_reading((int) fread(&dummy,sizeof(int),1,in), 1);
	if (dummy == -1) break;
	/*if (nb_states != (INT_S) dummy) {
	   printw("Something is wrong here! Please report !");
	   user_pause();
	   break;
	}*/
	while (!feof(in)) {
	   INT_S source;
	   INT_T nb_trans;
	   timer_info *tmp;

	   check_reading((int) fread(&source,sizeof(INT_S),1,in), 1);
	   if (source==-1)
	      break;
	   check_reading((int) fread(&nb_trans,sizeof(INT_T),1,in), 1);
	   the_des[source].numtimer = nb_trans;
	   /* rely on ordered timer info */
	   tmp = the_des[source].ntimer;
	   tmp = (timer_info*) calloc(nb_trans, sizeof(timer_info));
	   check_reading((int) fread(tmp,sizeof(timer_info),nb_trans,in), nb_trans);
	   the_des[source].ntimer = tmp;
	}
     }
 
     if (blocktype == -1) {
	int dummy;

	check_reading((int) fread(&dummy,sizeof(int),1,in), 1);
	if (dummy == 8)
	   break;
	/*else {
	   printw("Something is wrong here ! Please report!");
	}*/
     }

     /* hack for compability with old Linux CTCT which was broken IMHO with 
	regard to its own block structure */
     if (blocktype == 8) {
	break;
     }
     if (unknown) {
	/*int dummy;
	check_reading(fread(&dummy,sizeof(int),1,in),1);
	/*forward over block 
	fseek(in, dummy, SEEK_CUR);
	had to take this out because the DOS CTCT files don't even have 
	a correct last block to rely on*/
	break;
     }
  }

  /* some other stuff... */
  *init = initial_state;
  *elemts = nb_states;
  return the_des;
}

state_node*
read_ades_file( FILE *in, int *elemts, int *init, INT_T *elemts1, 
		timed_event **data1)
{
  state_node *the_des;
  int nb_states, initial_state;
  int length_signature = (int)strlen(signature);
  char string[1024];
  int read_endian, blocktype;
  INT_S yy;

  assert( in && elemts && init );

  /* seek for the position after the text header */
  while (!feof(in))
    {
      char dummy;

      check_reading((int) fread(&dummy,sizeof(char),1,in), 1);
      if (dummy==end_text_header)
	break;
    }
  assert(!feof(in));

  /* reads the signature */
  check_reading((int) fread(string,sizeof(char),length_signature,in),
		 length_signature );
  string[length_signature]='\0';
  if ((int)strcmp(signature,string) != 0)
    {
      fprintf(stderr,"TDS file reading: signature is different (abort)");
      return NULL;
    }

  /* reads the endian */
  check_reading((int) fread(&read_endian,sizeof(int),1,in), 1);
  if (read_endian!=endian)
    {
      fprintf(stderr,"TDS file reading: endian is incorrect (abort)");
      return NULL;
    }  

  /* we are reading for the number of states */
  fseek(in,8,SEEK_CUR);
  /*check_reading( fread(&block_size,sizeof(int),1,in), 1);*/
  check_reading((int) fread(&nb_states,sizeof(int),1,in), 1);
  check_reading((int) fread(&initial_state,sizeof(int),1,in), 1);
  the_des = newdes(nb_states);
  assert(the_des);

  /* list of marker states */
  while (!feof(in))
    {
      int marker;

      check_reading((int) fread(&marker,sizeof(int),1,in), 1);
      if (marker==-1)
	break;
      the_des[marker].marked = true;
    }

  /* list for transitions */
  while (!feof(in))
    {
      int source;
      short nb_trans,i;
      tran_node trans;

      check_reading((int) fread(&source,sizeof(int),1,in), 1);
      if (source==-1)
	break;
      check_reading((int) fread(&nb_trans,sizeof(short),1,in), 1);
      for (i=0; i<nb_trans; i++)
	{
		check_reading((int) fread(&yy,sizeof(INT_S),1,in), 1);
		trans.data1 = (INT_T) ((unsigned long) yy >> 22);
		trans.data2 = (yy & 0x003FFFFF);
	  //check_reading((int) fread(&trans,sizeof(tran_node),1,in), 1);
	  add_transition( the_des, nb_states, source,
			  (int)trans.data1, (int)trans.data2 );
	}
    }

  /* reads for vocal outputs */
  while (!feof(in))
    {
      int state, voc;

      check_reading((int) fread(&state,sizeof(int),1,in), 1);
      if (state==-1)
	break;
      check_reading((int) fread(&voc,sizeof(int),1,in), 1);
      the_des[state].vocal = voc;
    }
  
  /* read second block */
  if (!feof(in)) {
     check_reading((int) fread(&blocktype,sizeof(int),1,in), 1);
     if (blocktype == 2) {
	fseek(in,sizeof(int),SEEK_CUR);
	/*int dummy;*/
	while (!feof(in)) {
	   int dummy;
	   check_reading((int) fread(&dummy,sizeof(int),1,in), 1);
	   if (dummy == -1) break;
	   *elemts1 = (INT_T) dummy;
	   if (*elemts1 == 0) break;
	   else {
	      *data1 = (timed_event*) calloc(*elemts1, sizeof(timed_event));
	      check_reading((int) fread(*data1,sizeof(timed_event),*elemts1,in), *elemts1);
	   }
	}
     } else {
	*elemts1 = 0;
	*data1 = NULL;
     }
  }
  /* some other stuff... */
  *init = initial_state;
  *elemts = nb_states;
  return the_des;
}

INT_B
check_error_writing_file( int effective, int total, char *source, int line )
{
  if (total!=effective)
    {
      fprintf(stderr, "%s: %d: a writing error has occurred, only %d counts are written for a request of %d counts\n", source, line,
	      effective, total );
      return false;
    }
  return true;
}

INT_B
check_error_reading_file( int effective, int total, char *source, int line )
{
  if (total!=effective)
    {
      fprintf(stderr, "%s: %d: a reading error has occurred, only %d counts are readed for a request of %d counts\n", source, line,
	      effective, total );
      return false;
    }
  return true;
}

