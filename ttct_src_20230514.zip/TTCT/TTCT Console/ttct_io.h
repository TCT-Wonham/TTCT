#ifndef _IO_H
#define _IO_H

#include <stdio.h>
#include "des_data.h"

#define MAXSCREENY       22

/*#if defined(__UNIX__)*/
 // #include "curses.h"
  #define MAX_DES_NAME_LEN  20

  #define CBack      8
  #define CEsc       27
  #define CEnter     13
  #define CPgUp      'U'
  #define CPgDn      'D'
  #define BOT        'g'
/*  #define CPgUp      18
  #define CPgDn      22*/
/*#elif defined(__DOS32__) || defined(__BORLANDC__)
  #define MAX_DES_NAME_LEN  8

  #define CBack      8
  #define CEsc       27
  #define CEnter     13
  #define CPgUp      18
  #define CPgDn      3
#endif*/

extern FILE* auto_in;

extern char read_key();
extern char get_command();
extern INT_B getname(char*, char*, char*, char*, INT_B);
extern INT_B getname2(char*, char*, char*, char*, INT_B);
extern void tab(int);
extern int readint(char*, int, int);
extern int readintall(char*, int, int);
extern int readcheckint(char*, int, int, INT_S, INT_T*);
extern int readtickint(char*, int, int);
extern int readdefint(char*, int, int);
extern char read_filename(char*, int, int);
extern void make_filename_ext(char*, char*, char*);
extern int exist(char*);

#endif

