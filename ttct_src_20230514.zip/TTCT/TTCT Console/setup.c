#include "setup.h"

int ring_active = 0;        /* All turned off */
int debug_mode = 1;
int timing_mode = 0;
char path[80];
char prefix[80];
char ttct_ini_file[256];
char info_file[256];
