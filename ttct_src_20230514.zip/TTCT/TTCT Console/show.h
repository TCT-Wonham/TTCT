#ifndef _SHOW_H
#define _SHOW_H

extern void show_ads_p();
extern void show_des_p();
extern void show_dat_p();
extern void show_ascii_p();

#endif
