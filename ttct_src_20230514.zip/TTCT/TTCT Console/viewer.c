/*#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include "curses.h"
#include "viewer.h"
#include "io.h"
#include "des_data.h"
#include "tct_proc.h"
#include "display.h"
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include "tct_curs.h"
#include "viewer.h"
#include "ttct_io.h"
#include "des_data.h"
#include "tct_proc.h"
#include "display.h"
#include "setup.h"
/*
static boolean quit;
static FILE *in;
static INT_S *ascii_stack;
static INT_S s_ascii_stack;
static INT_S i, size;
static char ch;
static filename name;
static struct stat statbuf;
static struct tm *dt;
*/

static INT_B quit;
static INT_B bottom;
static FILE *in;
static INT_S *ascii_stack;
static INT_S s_ascii_stack;
static INT_S i, size;
static char ch;
static filename name;
static struct stat statbuf;
static struct tm *dt;


void view_header()
{
   char str[80];

   strftime(str, 80, "%Y.%m.%d", dt);

   clear();
   printw("%s     ", name);
   printw("%ld", size);
   if (size != 0) {
      printw(" (%3d%%)", (long) (i*100.0/size));
   } else {
      printw(" (%3d%%)", 0);
   }
   printw("%-35s DATE: %s", " ", str);
   println();
   println();
}

void viewer_page_control(INT_B lastPage)
{
/*#if defined(__UNIX__) || defined(__WIN32__)*/
      continue_page(" D=PgDn  U=PgUp  Esc (Exit Show)  ");
/*#else
      continue_page(" PgDn  PgUp  Esc (Exit Show)  ");
#endif*/

   do {
      refresh();
      ch = read_key();
      ch=toupper(ch);
      
      switch(ch) {
         case CEsc:
            quit = true;
            free(ascii_stack); ascii_stack = NULL;
            return;
         case 'D' : /*CPgDn:*/
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_ascii_stack++;
               ascii_stack = (INT_S*) realloc(ascii_stack,
                                      sizeof(INT_S)* s_ascii_stack);
               ascii_stack[s_ascii_stack-1] = i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_ascii_stack++;
               ascii_stack = (INT_S*) realloc(ascii_stack,
                                      sizeof(INT_S)* s_ascii_stack);
               ascii_stack[s_ascii_stack-1] = i;
            }
            break;
         case 'U' : /*CPgUp:*/
            if (s_ascii_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_ascii_stack >= 2) {
                  i = ascii_stack[s_ascii_stack-2];
                  s_ascii_stack -= 2;
                  ascii_stack = (INT_S*) realloc(ascii_stack,
                                         sizeof(INT_S)* s_ascii_stack);

                  /* Put back the last pop */
                  s_ascii_stack++;
                  ascii_stack = (INT_S*) realloc(ascii_stack,
                                         sizeof(INT_S)* s_ascii_stack);
                  ascii_stack[s_ascii_stack-1] = i;
                  /* Move file pointer to new position */
                  fseek(in, i, SEEK_SET);
               } else {
                  i = 0;
                  s_ascii_stack = 0;
                  free(ascii_stack); ascii_stack = NULL;
                  fseek(in, i, SEEK_SET);
               }
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != 'U' /*CPgUp*/) && (ch != 'D' /*CPgDn*/) );

   view_header();
}

static long filesize(FILE *f)
{
    long cur, size;

    cur = ftell(f);
    fseek(f, 0, SEEK_END);

    size = ftell(f);
    fseek(f, cur, SEEK_SET);

    return size;
}

void ziptolastpage(FILE* in)
{
   INT_S line_count;
   INT_S col;

   line_count = 2;
   col = 0;
   i = 0;

   while (!feof(in)) {
      ch = fgetc(in);
      if (ch == '\n') {
         line_count++;
         col = 0;
      } else if (ch == '\r') {
      } else {
         col++;
         if (col >= 80) {
           line_count++;
           col = 1;
         }
      }
      if (line_count >= 22) {
         i = ftell(in);
         s_ascii_stack++;
         ascii_stack = (INT_S*) realloc(ascii_stack,
                                sizeof(INT_S)* s_ascii_stack);
         ascii_stack[s_ascii_stack-1] = i;

         line_count = 2;
         col = 0;
      }
   }

/*
  if (s_ascii_stack > 0) {
      i = ascii_stack[s_ascii_stack-1];
      s_ascii_stack -= 1;
      ascii_stack = (INT_S*) realloc(ascii_stack,
                             sizeof(INT_S)* s_ascii_stack);
   } else {
      i = 0;
   }
*/
   /* Move file pointer to new position */
   fseek(in, i, SEEK_SET);
}

void ascii_viewer(char* longname,
                  char* shortname)
{
    strcpy(name, shortname);

    in = fopen(longname, "r");
    if (in == NULL) return;

    fstat(_fileno(in), &statbuf);
    dt = localtime(&statbuf.st_atime);

    /* Setup a buffer for faster IO */
    setvbuf(in, NULL, _IOFBF, 32000);

    size = filesize(in);

    quit = false;
    i = 0;
    ascii_stack = NULL; s_ascii_stack = 0;

#if defined(__UNIX__)
    if (strcmp(shortname, "makeit") == 0)
       ziptolastpage(in);
#else
    if (_stricmp(shortname, "MAKEIT") == 0)
       ziptolastpage(in);
#endif

    view_header();
    do {
       while(!feof(in)) {
         ch = fgetc(in);
         if (ch == '\n') {
            println();
         } else if (ch == '\r') {
         } else if (ch == EOF) {
         } else {
            printw("%c", ch);
         }
         if (_wherey() >= 22) {
           i = ftell(in);
           viewer_page_control(false);
           if (quit) break;
         }
       }
       if (quit) break;
       viewer_page_control(true);
    } while ( (ch != CEnter) && (ch != CPgDn) );

    fclose(in);
    if (ascii_stack != NULL) free(ascii_stack);
}

void ascii_print(char* longname, char* name)
{
}

