#include "ttct_io.h"
#include "display.h"
#include "tct_curs.h"
#include "setup.h"
//#include <unistd.h> 
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

FILE* auto_in;

char read_key()
{
//	char ch1;
	int ch;

	/*if (autotest) {
		fread(&ch1, sizeof(char), 1, auto_in);
		if (feof(auto_in)) exit(255);
		if (ch1 == 26) exit(255);
		return ch1;
	}*/

	ch = getch();
	if (ch == 0) {
		switch (getch()) {
		case 73: ch = CPgUp;
			break;
		case 81: ch = CPgDn;
			break;
		}
	} 
	return (char) ch;
}

char get_command()
{
   char ch;

   clrtoeol();
   refresh();

   ch = read_key();
   addch(ch);
   refresh();
   return ch;
}

INT_B validfilename(char *s,
                      int lmin,
                      int lmax)
{
  int n;

  n = (int)strlen(s);
  if ( (n >= lmin) && (n <= lmax) ) {
    return true;
  } else {
    return false;
  }
}

char read_filename(char* name,
                   int lmin,
                   int lmax)
{
   int x,y;
   char s[255];
   int p;
   char ch;
   INT_B start, stop;
   char buf[10];

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     move(y, x+p);
     refresh();
     ch = read_key();
//#if defined(__GO32__) 
     ch = toupper(ch);
//#endif
     if ( (ch >= 0x20) ) {
        if (start) strcpy(s, "");
        if ((int)strlen(s) < lmax) {
           sprintf(buf, "%c", ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (ch == CEnter) {
        if (validfilename(s, lmin, lmax)) {
           strcpy(name, s);
           stop = true;
        } else {
           ring_bell();
        }
     } else if (ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return ch;
}

/* Construct the full filename base on the name and the extension */
void make_filename_ext(char* longfilename,
                       char* name,
                       char* ext)
{
   int len;
   strcpy(longfilename, prefix);

  /* Trim excessive blank characters from the name */
   if (name[0] == ' ')
   {
      len = (int)strlen(name);
      memmove(name, &(name[1]), len-1);
      name[len-1] = '\0';
   }

   if (name[0] == ' ')
   {
      len = (int)strlen(name);
      memmove(name, &(name[1]), len-1);
      name[len-1] = '\0';
   }

   strcat(longfilename, name);
   strcat(longfilename, ext);
}

/* Determine if the file exist on the disk */
int exist(char* s)
{
   return (_access(s, 0) == 0);
}

INT_B getname(char *prompt,
                char *ext,
                char *name,
                char *fullname,
                INT_B newflag)
{
   INT_B quit;
   char ch;
   char longfilename[100];
   char uext[5];
   INT_B existing; 
   int i;

   existing = false;
   quit = false;
   strcpy(name, "");
   strcpy(uext, "");
   strcpy(longfilename, "");

   for (i=0; i <= (int)strlen(ext); i++) 
     uext[i] = toupper(ext[i]);

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }
     printw("%s", prompt);
     esc_footer();
     refresh();
     ch = read_filename(name, 1, MAX_DES_NAME_LEN);
     println();
     if (ch == CEsc) {
        quit = true;
     } else {
        make_filename_ext(longfilename, name, ext);
        if (newflag) {
           if ( exist(longfilename) ) {
              ring_bell();
              overwriteYN(name);
              refresh();
              ch = read_key();
              if (ch == CEnter) {
                 println();
              } else {
                 printw("%c", ch);
                 println();
              }
              println();
              if (ch == CEsc) quit = true;
              if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) 
              {  
                 existing = true;
                 strcpy(fullname, longfilename);
              }
              refresh();
           } else {
              strcpy(fullname, longfilename);
              existing = true;
           }
        } else {
            if (! exist(longfilename) ) {

#if !defined (__GO32__)
              /* Try to find a match with upper case version */
              make_filename_ext(longfilename, name, uext);
              if (! exist(longfilename) ) {
                 ring_bell();
                 doesNotExist(name);
                 println();
                 refresh();
                 existing = false;
              } else {
                 strcpy(fullname, longfilename);
                 existing = true;
              }
#else
              ring_bell();
              doesNotExist(name);
              println();
              refresh();
              existing = false;
#endif
            } else {
              strcpy(fullname, longfilename);
              existing = true;           
            }
        }
     }
   } while ( (quit == false) && (existing == false));
   println();
   refresh();

   return quit;
}

INT_B getname2(char *prompt,
                char *ext,
                char *name,
                char *fullname,
                INT_B newflag)
{
   INT_B quit;
   char ch;
   char longfilename[100];
   char uext[5];
   INT_B existing;
   int i;
   INT_B first_time = true;

   existing = false;
   quit = false;
   strcpy(uext, "");
   strcpy(longfilename, "");

   for (i=0; i <= (int)strlen(ext); i++)
     uext[i] = toupper(ext[i]);

   do {
     if ( _wherey() > MAXSCREENY ) {
        clear();
        println();
     }

     if (first_time == false) {
       printw("%s", prompt);
       esc_footer();
       refresh();
       ch = read_filename(name, 1, MAX_DES_NAME_LEN);
       println();
     }
     first_time = false;

     if (ch == CEsc) {
        quit = true;
     } else {
        make_filename_ext(longfilename, name, ext);
        if (newflag) {
           if ( exist(longfilename) ) {
              ring_bell();
              overwriteYN(name);
              refresh();
              ch = read_key();
              if (ch == CEnter) {
                 /*println();*/
              } else {
                 printw("%c", ch);
                 println();
              }
              println();
              if (ch == CEsc) quit = true;
              if ( (ch == 'Y') || (ch == 'y') || (ch == CEnter) ) 
              {  
                 existing = true;
                 strcpy(fullname, longfilename);
              }
              refresh();
           } else {
              strcpy(fullname, longfilename);
              existing = true;
           }
        } else {
            if (! exist(longfilename) ) {

#if !defined (__GO32__)
              /* Try to find a match with upper case version */
              make_filename_ext(longfilename, name, uext);
              if (! exist(longfilename) ) {
                 ring_bell();
                 doesNotExist(name);
                 println();
                 refresh();
                 existing = false;
              } else {
                 strcpy(fullname, longfilename);
                 existing = true;
              }
#else
              ring_bell();
              doesNotExist(name);
              println();
              refresh();
              existing = false;
#endif
            } else {
              strcpy(fullname, longfilename);
              existing = true;
            }
        }
     }
   } while ( (quit == false) && (existing == false));
   println();
   refresh();

   return quit;
}

/* Move over "n" spaces */
void tab(int n)
{
   int y;
   y = _wherey(); move(y,n);
}

INT_B validint(char *s,
                 int lmin,
                 int lmax)
{
   int n;
   if (strcmp(s, "0") == 0) {
     n = 0;
   } else {
     /* Known bug - if user enters "1-", it will be converted to "1".
        Fix needed for this minor bug. */
     n = atoi(s);
     if (n == 0) return false;
   }

   return ((n >= lmin) && (n <= lmax));
}

INT_B validtickint(char *s,
		     int lmin,
		     int lmax)
{
   int n;
   if (strcmp(s, "0") == 0) {
     n = 0;
   } else {
     /* Known bug - if user enters "1-", it will be converted to "1".
        Fix needed for this minor bug. */
     n = atoi(s);
     if (n == 0) return false;
   }
   if (n == TICK) return false;
   return ((n >= lmin) && (n <= lmax));
}

INT_B validcheckint(char *s,
		      INT_S size,
		      INT_T *list)
{
   int n, i;
   if (strcmp(s, "0") == 0) {
     n = 0;
   } else {
     /* Known bug - if user enters "1-", it will be converted to "1".
        Fix needed for this minor bug. */
     n = atoi(s);
     if (n == 0) return false;
   }

   if (n == TICK) return false;
   if (n == -1) return true;

   for (i = 0; i < size; i++) 
      if (n == list[i]) return true;
   return false;
}

/* Read in an integer (short).  Return true if aborted with ESC key */
int readint(char *ch,
            int lmin,
            int lmax)
{
   int x,y;
   char s[255];
   int p, n;
   INT_B start, stop;
   char buf[20];
   int maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = max(maxlen, (int)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = max(maxlen, (int)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) ) {
        if (start) strcpy(s, "");
        if ((((int)strlen(s) < maxlen) && (strlen(s) > 0) && (*ch != '-')) ||
	    (strlen(s) == 0)) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (validint(s, lmin, lmax)) {
           n = (int) atoi(s);
           stop = true;
           break;
        } else {
           ring_bell();
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read integer in the range (lmin,lmax).
 * Besides integers, "*" is equal to all numbers.
 */
int readintall(char *ch,
            int lmin,
            int lmax)
{
   int x,y;
   char s[255];
   int p, n;
   INT_B start, stop;
   char buf[20];
   int maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = max(maxlen, (int)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = max(maxlen, (int)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) || (*ch == '*') ) {
        if (start) strcpy(s, "");
        if ( (((int)strlen(s) < maxlen) && (strlen(s) > 0) && (*ch != '-')) ||
             (strlen(s) == 0) )  {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (strcmp(s, "*") == 0) {
           n = 0;
           *ch = '*';
           stop = true;
           break;
        }

        if (strchr(s, '*') != NULL)
        {
           ring_bell();
        }
        else
        {
           if (validint(s, lmin, lmax)) {
              n = (int) atoi(s);
              stop = true;
              break;
           } else {
              ring_bell();
           }
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read in an integer (short) and check that it's not TICK.
   Return true if aborted with ESC key */
int readtickint(char *ch,
            int lmin,
            int lmax)
{
   int x,y;
   char s[255];
   int p, n;
   INT_B start, stop;
   char buf[20];
   int maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = max(maxlen, (int)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = max(maxlen, (int)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) ) {
        if (start) strcpy(s, "");
        if ((((int)strlen(s) < maxlen) && (strlen(s) > 0) && (*ch != '-')) ||
	    (strlen(s) == 0)) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (validtickint(s, lmin, lmax)) {
           n = (int) atoi(s);
           stop = true;
           break;
        } else {
           ring_bell();
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read in an integer (short) and check if it's in list.  Return true if 
aborted with ESC key */
int readcheckint(char *ch,
		 int lmin,
		 int lmax,
		 INT_S size,
		 INT_T *list)
{
   int x,y;
   char s[255];
   int p, n;
   INT_B start, stop;
   char buf[20];
   int maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = max(maxlen, (int)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = max(maxlen, (int)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( (*ch == '-') || ((*ch >= '0') && (*ch <= '9')) ) {
        if (start) strcpy(s, "");
        if ((((int)strlen(s) < maxlen) && (strlen(s) > 0) && (*ch != '-')) ||
	    (strlen(s) == 0)) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (validcheckint(s, size, list)) {
           n = (int) atoi(s);
           stop = true;
           break;
        } else {
           ring_bell();
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

/* Read in an integer (short) or accept a return.  Return true if aborted 
   with ESC key */
int readdefint(char *ch,
               int lmin,
               int lmax)
{
   int x,y;
   char s[255];
   int p, n;
   INT_B start, stop;
   char buf[20];
   int maxlen;

   maxlen = 0;
   sprintf(buf, "%d", lmin);   maxlen = max(maxlen, (int)strlen(buf));
   sprintf(buf, "%d", lmax);   maxlen = max(maxlen, (int)strlen(buf));

   strcpy(s, "");
   x = _wherex();
   y = _wherey();
   start = true;
   stop = false;
   n = p = 0;

   while(!stop) {
     move(y,x);
     clrtoeol();
     printw("%s", s);
     esc_footer();
     move(y, x+p);
     refresh();
     *ch = read_key();
     if ( ((*ch >= '0') && (*ch <= '9')) ) {
        if (start) strcpy(s, "");
        if ((((int)strlen(s) < maxlen) && (strlen(s) > 0) && (*ch != '-')) ||
	    (strlen(s) == 0)) {
           sprintf(buf, "%c", *ch);
           strcat(s, buf);
           p++;
        } else {
           ring_bell();
        }
     } else if (*ch == CBack) {   /* Backspace */
        if (p > 0) {
           s[strlen(s)-1] = '\0';
           p--;
        }
     } else if (*ch == CEnter) {
        if (validint(s, lmin, lmax)) {
           n = (int) atoi(s);
	   *ch = '0';
           stop = true;
           break;
        } else if (strcmp(s,"") == 0) {
	   stop = true;
	   break;
	} else {
           ring_bell();
        }
     } else if (*ch == CEsc) {
        stop = true;
     } else {
        ring_bell();
     }
     start = false;
   }

   return n;
}

