#ifndef _PS_H
#define _PS_H

#include <stdio.h>
#include "des_data.h"

extern void postscript_outputfile(char *name,
                                  FILE *out,
                                  state_node *t1,
                                  INT_S s1, 
                                  INT_T *t2,
                                  INT_S s2);

extern void postscript_a_outputfile(char *name,
	FILE *out,
	state_node *t1,
	INT_S s1, 
	timed_event *t2,
	INT_S s2);

extern void postscript_dat_output(char *name,
                                  FILE *out,
                                  state_node *t1,
                                  INT_S s1);

#endif
