#ifndef _ATS2TDS_H
#define _ATS2TDS_H

#include "des_data.h"

#define ATS_FILE_DOES_NOT_EXIST       1
#define ATS_FILE_TOO_SHORT            2
#define ATS_UNKNOWN                   3
#define ATS_FILENAME_EMPTY            4
#define ATS_FILENAME_TOO_LONG         5
#define ATS_STATE_LABEL_EXPECTED      6
#define ATS_STATE_TOO_SMALL           7
#define ATS_STATE_TOO_LARGE           8
#define ATS_MARK_LABEL_EXPECTED       9
#define ATS_MARK_TOO_SMALL            10
#define ATS_MARK_TOO_LARGE            11
#define ATS_VOCAL_LABEL_EXPECTED      12
#define ATS_VOCAL_TOO_SMALL           13
#define ATS_VOCAL_TOO_LARGE           14
#define ATS_TRANS_LABEL_EXPECTED      15
#define ATS_TRANS_TOO_SMALL           16
#define ATS_TRANS_TOO_LARGE           17
#define ATS_STATE_UNKNOWN             18
#define ATS_MARK_UNKNOWN              19
#define ATS_VOCAL_UNKNOWN             20
#define ATS_TRANS_UNKNOWN             21
#define ATS_EXIT_STATE_TOO_SMALL      22
#define ATS_EXIT_STATE_TOO_LARGE      23
#define ATS_ENTRANCE_STATE_TOO_SMALL  24
#define ATS_ENTRANCE_STATE_TOO_LARGE  25
#define ATS_FORCE_LABEL_EXPECTED      26
#define ATS_FORCE_UNKNOWN             27
#define ATS_FORCE_NOT_IN_LIST         28
#define ATS_NONDETERMINISTIC          29
#define MAX_ATS_ERROR_STR             (ATS_NONDETERMINISTIC+1)

typedef char ats_t[60];
extern ats_t ats_error_str[MAX_ATS_ERROR_STR];

typedef struct ats_err_log_t {
   int  fail_code;
   long line_num1;
   long line_num2;
} ats_err_log_t;

extern int ats_2_tds(char*, ats_err_log_t**, long*, state_node**, INT_S*, INT_T**, INT_S*);
extern int ats_2_tds_all(char*, long*, long*, state_node**, INT_S*, INT_T**, INT_S*);
extern int generate_ats_file(char*, char*);
extern int tds_to_ats(char*, FILE*, state_node*, INT_S, INT_T*, INT_S);

#endif
