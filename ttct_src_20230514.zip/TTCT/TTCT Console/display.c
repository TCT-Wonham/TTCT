
//#include <stdio.h>
//#include <direct.h>
//#include <ttct_io.h>
//#include <dirent.h>
//#include <stdlib.h>
//#include <string.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/stat.h>

#include "tct_curs.h"
#include "setup.h"
#include "display.h"

/*#if defined(__BORLANDC__)
#include <alloc.h>
#elif defined(__DOS32__)
#include <dpmi.h>
#endif*/

void print_fix_filename(char *name, int width)
{
	int i, len, prefix_to_print;

	len = (int)strlen(name);

	if (len >= width)
	{

		for (i=0; i < 3; i++)
			printw("%c", name[i]);
		printw("...");

		prefix_to_print = width - 7;

		for (i=len-prefix_to_print; i < len; i++)
			printw("%c", name[i]);

	}
	else 
	{
		printw("%s", name);
	}
}

void main_menu()
{
   int xLeft;
   int y;

   xLeft = 24;
   y     = 9;
  
   clear();
   move(4,    xLeft); addstr("PROGRAM TTCT");
   move(7,    xLeft); addstr("MAIN OPTIONS");
   move(y,    xLeft); addstr("I:  Introduction to TTCT");
   move(y+1,  xLeft); addstr("A:  TTCT Procedures (Activity Transition Graph)");
   move(y+2,  xLeft); addstr("T:  TTCT Procedures (Timed Transition Graph)");
   move(y+3,  xLeft); addstr("R:  Reset USER File Directory Path");
   move(y+4,  xLeft); printw("B:  Bell (%s)", ring_active ? "On":"Off");
/*   move(y+5,  xLeft); printw("D:  Debug mode (%s)", debug_mode ? "On":"Off");*/
   move(y+5,  xLeft); printw("C:  Clocking mode (%s)", timing_mode ? "On":"Off");
  /* move(y+6,  xLeft); addstr("O:  OS Shell");*/
   move(y+6,  xLeft); addstr("X:  Quit TTCT");
   move(y+11, xLeft); addstr("Option desired?    ");
}

void display_memory(int y, int x)
{
/*#if defined(__BORLANDC__)
   move(y,x);
   printw("# of bytes free on heap: %lu\n", coreleft());
#elif defined(__DOS32__)
   _go32_dpmi_meminfo info;

   _go32_dpmi_get_free_memory_information(&info);
   move(y,x);
   printw("# of bytes free on heap: %d\n", info.available_memory);
#else
#endif*/
}

/*#if defined(__UNIX__)*/

void advance_menu() {
   int xLeft;    /* left column offset   */
   int xMiddle;  /* middle column offset */
   int xRight;   /* right column offset  */
   int y;        /* row offset           */
   char dir[_MAX_PATH];
   int num_entries;
   struct _finddata_t *namelist;
   //dir *dirh;

   xLeft   = 5;
   xMiddle = 31;
   xRight  = 53;
   y       = 4;

   clear();
   move(3   ,xMiddle);  addstr("TTCT PROCEDURES: TTGs");

   /* Left command list panel */
   move(y+2 ,xLeft);  addstr("0: Create");
   move(y+3 ,xLeft);  addstr("1: Selfloop");
   move(y+4 ,xLeft);  addstr("2: Trim");
   move(y+5 ,xLeft);  addstr("3: Sync");
   move(y+6 ,xLeft);  addstr("4: Meet");
   move(y+7 ,xLeft);  addstr("5: Supcon");
   move(y+8 ,xLeft);  addstr("6: Mutex");
   move(y+9 ,xLeft);  addstr("7: Condat");
   move(y+10,xLeft);  addstr("8: Supreduce");
   move(y+11,xLeft);  addstr("9: Minstate");
   move(y+12,xLeft);  addstr("10: Complement");
   move(y+13,xLeft);  addstr("11: Localize");

   /* Middle command list panel */
   move(y+2 ,xMiddle); addstr("P0: Project");
   move(y+3 ,xMiddle); addstr("P1: Convert");

   move(y+5 ,xMiddle); addstr("H0: Vocalize");
   move(y+6 ,xMiddle); addstr("H1: Outconsis");
   move(y+7 ,xMiddle); addstr("H2: Hiconsis"); 
   move(y+8 ,xMiddle); addstr("H3: Higen");
   move(y+9, xMiddle); addstr("H4: Allevents");

   move(y+12,xMiddle);  addstr("R1: Supnorm");

   /* Right command list panel */
   move(y+2 ,xRight);  addstr("I: Isomorph");
   move(y+3 ,xRight);  addstr("N: Nonconflict");

   move(y+4 ,xRight);  addstr("E: Edit");
   move(y+5 ,xRight);  addstr("B: BFS-recode");
   move(y+6 ,xRight);  addstr("U: User file directory");
   move(y+7 ,xRight);  addstr("SE/SA/SX: Show TDS/DAT/TXT");
/*   move(y+9 ,xRight);  addstr("OE/OA/OX: Print DES/DAT/TXT"); */
   move(y+8, xRight);  addstr("FE/FA/FD: File TDS/DAT/ATS");
   move(y+9, xRight);  addstr("GA/GB: Export DaVinci file");
   move(y+10,xRight);  addstr("CE/DE: Convert/Display TDS");
   move(y+12,xRight);  addstr("A: Go to ATG procedures");
   move(y+13,xRight);  addstr("X: Exit to main menu");

   /* Display some useful information */
   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);
   free(namelist);

   move(y+17, xLeft); printw("User directory: "); print_fix_filename(path,59);
   if (num_entries < 0) {
      move(y+19, xLeft); printw("Number files: DIRECTORY NOT SET!");//Justin0628
   } else { 
      move(y+19, xLeft); printw("Number files: %d", num_entries);//Justin0628
   }

   /* Command Prompt */
   move(y+15,xMiddle); addstr("Procedure desired: ");
}

void adv_act_menu() {
   int xLeft;    /* left column offset   */
   int xMiddle;  /* middle column offset */
   int xRight;   /* right column offset  */
   int y;        /* row offset           */
   char dir[_MAX_PATH];
   int num_entries;
	struct _finddata_t *namelist;
//   DIR *dirh;

   xLeft   = 5;
   xMiddle = 31;
   xRight  = 53;
   y       = 5;

   clear();
   move(3   ,xMiddle);  addstr("TTCT PROCEDURES: ATGs");

   /* Left command list panel */
   move(y+2 ,xLeft);  addstr("0: Create");
   move(y+3 ,xLeft);  addstr("1: Selfloop");
   move(y+4 ,xLeft);  addstr("2: Trim");
   move(y+5 ,xLeft);  addstr("3: Timed Graph");
   move(y+6 ,xLeft);  addstr("4: Compose");
   move(y+7 ,xLeft);  addstr("5: Mutex");
/*   move(y+7 ,xLeft);  addstr("5: Minstate"); */
   move(y+8, xLeft);  addstr("6: Complement");
/*   move(y+7 ,xLeft);  addstr("5: Supcon");
   move(y+9 ,xLeft);  addstr("7: Condat");

    Middle command list panel 
   move(y+2 ,xMiddle); addstr("P0: Project");
   move(y+3 ,xMiddle); addstr("P1: Convert");

   move(y+5 ,xMiddle); addstr("H0: Vocalize");
   move(y+6 ,xMiddle); addstr("H1: Outconsis");
   move(y+7 ,xMiddle); addstr("H2: Hiconsis"); 
   move(y+8 ,xMiddle); addstr("H3: Higen");

   move(y+11,xMiddle);  addstr("R1: Supnorm");*/

   /* Right command list panel */
  // move(y+2 ,xRight);  addstr("I: Isomorph");
   move(y+11 ,xLeft);  addstr("I: Isomorph");
/*   move(y+3 ,xRight);  addstr("N: Nonconflict");*/

   move(y+2 ,xRight);  addstr("E: Edit");
   move(y+3 ,xRight);  addstr("B: BFS-recode");
   move(y+4 ,xRight);  addstr("U: User file directory");
   move(y+5 ,xRight);  addstr("SE: Show ADS");
/*   move(y+9 ,xRight);  addstr("OE: Print ADS"); */
   move(y+6, xRight);  addstr("FE/FD: File ADS/AAS");
   move(y+7, xRight);  addstr("GA/GB: Export DaVinci file");
   move(y+8, xRight);  addstr("CE/DE: Convert/Display ADS");
   move(y+10,xRight);  addstr("T: Go to TTG procedures");
   move(y+11,xRight);  addstr("X: Exit to main menu");

   /* Display some useful information */
   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);
   free(namelist);

   move(y+17, xLeft); printw("User directory: "); print_fix_filename(path,59);
   if (num_entries < 0) {
      move(y+19, xLeft); printw("Number files: DIRECTORY NOT SET!");//Justin0628
   } else { 
      move(y+19, xLeft); printw("Number files: %d", num_entries);//Justin0628
   }

   /* Command Prompt */
   move(y+15,xMiddle); addstr("Procedure desired: ");
}

/*#else

void advance_menu() {
   int xLeft;    /* left column offset   
   int xMiddle;  /* middle column offset 
   int xRight;   /* right column offset  
   int y;        /* row offset           
   char dir[100];
   int num_entries;
   struct ffblk *namelist;

   xLeft   = 5;
   xMiddle = 31;
   xRight  = 53;
   y       = 5;

   clear();
   move(3   ,xMiddle);  addstr("TTCT PROCEDURES");

   /* Left command list panel 
   move(y+2 ,xLeft);  addstr("0: Create");
   move(y+3 ,xLeft);  addstr("1: Selfloop");
   move(y+4 ,xLeft);  addstr("2: Trim");
   move(y+5 ,xLeft);  addstr("3: Sync");
   move(y+6 ,xLeft);  addstr("4: Meet");
   move(y+7 ,xLeft);  addstr("5: Supcon");
   move(y+8 ,xLeft);  addstr("6: Mutex");
   move(y+9 ,xLeft);  addstr("7: Condat");
   move(y+10,xLeft);  addstr("8: Minstate");
   move(y+11,xLeft);  addstr("9: Complement");

   /* Middle command list panel 
   move(y+2 ,xMiddle); addstr("P0: Project");
   move(y+3 ,xMiddle); addstr("P1: Convert");

   move(y+5 ,xMiddle); addstr("H0: Vocalize");
   move(y+6 ,xMiddle); addstr("H1: Outconsis");
   move(y+7 ,xMiddle); addstr("H2: Hiconsis"); 
   move(y+8 ,xMiddle); addstr("H3: Higen");

   move(y+11,xMiddle);  addstr("R1: Supnorm");

   /* Right command list panel 
   move(y+2 ,xRight);  addstr("I: Isomorph");
   move(y+3 ,xRight);  addstr("N: Nonconflict");

   move(y+5 ,xRight);  addstr("E: Edit");
   move(y+6 ,xRight);  addstr("B: BFS-recode");
   move(y+7 ,xRight);  addstr("D: User file directory");
   move(y+8 ,xRight);  addstr("SE/SA/SX: Show DES/DAT/TXT");
   move(y+9 ,xRight);  addstr("OE/OA/OX: Print DES/DAT/TXT");
   move(y+11,xRight);  addstr("X: Exit to main menu");

   /* Display some useful information 
   strcpy(dir, path);
   strcat(dir, "\\*.*");

   num_entries = scandir(dir, &namelist);
   free(namelist);

   move(y+15, xLeft); printw("User directory: %s", path);
   if (num_entries < 0) {
      move(y+16, xLeft); printw("Number files: DIRECTORY NOT SET!");
   } else {
      move(y+16, xLeft); printw("Number files: %d", num_entries);
   }

   /* For DOS32 to BORLAND C/C++, try to display the amount of memory 
   display_memory(y+17,xLeft);

   /* Command Prompt 
   move(y+13,xMiddle); addstr("Procedure desired: ");
}


#endif*/

/* void tct_logo(version)
char *version;
{
   int i;

   move(4,14);
   for (i=0; i < 26; i++)
     printw("* ");
   for (i=0; i < 14; i++) {
     move(4+i, 14);
     printw("*");
     move(4+i, 64);
     printw("*");
   }

   move(18,14);
   for (i=0; i < 26; i++)
     printw("* ");

   move(7 ,19);    addstr(version);
   move(10,19);    addstr("Systems Control Group");
   move(11,19);    addstr("Dept of Electrical & Computer Engineering");
   move(12,19);    addstr("University of Toronto");
   move(13,19);    addstr("Toronto, Ontario M5S 1A4");
   move(14,19);    addstr("CANADA");
} */

void tct_logo(char *version)
{
   move(5,7);  printw("        OOOO");
   move(6,7);  printw("       O    O            TTTTTTT   TTTTTTT   CCCCC   TTTTTTT");
   move(7,7);  printw("<----> O    O              T         T     C     C     T");
   move(8,7);  printw("       O    O             T         T     C           T");
   move(9,7);  printw("        OOOO             T         T     C     C     T");
   move(10,7); printw("        /  \\            T         T       CCCCC     T");
   move(11,7); printw("       /    \\");
   move(12,7); printw("      /      \\          %s", version);
   move(13,7); printw("     v        v");
   move(14,7); printw("  OOOO        OOOO      Systems Control Group");
   move(15,7); printw(" O    O      O    O     Dept of Electrical & Computer Engineering");
   move(16,7); printw(" O    O <--> O    O     University of Toronto");
   move(17,7); printw(" O    O      O    O     Toronto, Ontario M5S 1A4");
   move(18,7); printw("  OOOO        OOOO      CANADA");
}


void statusline(char *s)
{
   int x,y;

   x = _wherex();
   y = _wherey();
   move(23,0); clrtoeol(); printw(s);
   move(y,x);
}

void esc_footer()
{
   statusline("Press <ESC> to cancel");
}

void overwriteYN(char *s)
{
   println();
   printw("Filename %s already exists.  OK to overwrite?  (*y/n)  ", s);
}

void doesNotExist(char *s)
{
   println();
   printw("Filename %s not in directory!", s);
   println();
}

void OutOfMemoryMsg()
{
   move(16,0); clrtoeol();
   printw("Problem too large -- out of memory!");
   println();
}

void continue_page(char *s)
{
   move(23,0); clrtoeol();
   printw("%s", s);
}

void continue2_page(char *s1, char* s2)
{
   move(22,0); clrtoeol();
   printw("%s", s1);
   move(23,0); clrtoeol();
   printw("%s", s2);
}
