/*
 * Program: TTCT
 *
 * $Header: /home/chris/devel/repos/ttct/ctct.c,v 1.3 1998/07/27 13:09:48 chris Exp $
 * Hierarchical and supervisor control of discrete event systems.
 *
 */
#include <stdio.h>
//#include <stdio.h>
#include "wtct.h"
#include "io.h"

/*extern yyparse();*/


int main(int argc, char *argv[])
{
/*   FILE *in;
   char ch;*/

   /* If there are any parameters then assume they maybe TTCT DES files */
   if (argc > 1)
     {/*
       if ((int)strcmp(argv[1],"-") == 0)
	 {
	   /* we must read the script file from stdin 
	   yyparse();
	   exit(0);
	 }
       in = fopen(argv[1], "rb");
       if (in == NULL) {
         printf("Error reading %s\n", argv[1]);
         return 1;
       }
       
       ch = 0;
       while ((ch != 26) && !feof(in)) {
         fread(&ch, sizeof(char), 1, in);
         printf("%c", ch);
       }
       fclose(in);
       
       return 0;
   */}

   wtct_init(argv[0]);
   wtct_run();
   wtct_done();

   return 0;
}

