#ifndef _AAS2ADS_H
#define _AAS2ADS_H

#include "des_data.h"

#define AAS_FILE_DOES_NOT_EXIST       1
#define AAS_FILE_TOO_SHORT            2
#define AAS_UNKNOWN                   3
#define AAS_FILENAME_EMPTY            4
#define AAS_FILENAME_TOO_LONG         5
#define AAS_STATE_LABEL_EXPECTED      6
#define AAS_STATE_TOO_SMALL           7
#define AAS_STATE_TOO_LARGE           8
#define AAS_MARK_LABEL_EXPECTED       9
#define AAS_MARK_TOO_SMALL            10
#define AAS_MARK_TOO_LARGE            11
#define AAS_VOCAL_LABEL_EXPECTED      12
#define AAS_VOCAL_TOO_SMALL           13
#define AAS_VOCAL_TOO_LARGE           14
#define AAS_TRANS_LABEL_EXPECTED      15
#define AAS_TRANS_TOO_SMALL           16
#define AAS_TRANS_TOO_LARGE           17
#define AAS_STATE_UNKNOWN             18
#define AAS_MARK_UNKNOWN              19
#define AAS_VOCAL_UNKNOWN             20
#define AAS_TRANS_UNKNOWN             21
#define AAS_EXIT_STATE_TOO_SMALL      22
#define AAS_EXIT_STATE_TOO_LARGE      23
#define AAS_ENTRANCE_STATE_TOO_SMALL  24
#define AAS_ENTRANCE_STATE_TOO_LARGE  25
#define AAS_FORCE_LABEL_EXPECTED      26
#define AAS_FORCE_UNKNOWN             27
#define AAS_FORCE_NOT_IN_LIST         28
#define AAS_TIME_LABEL_EXPECTED       29
#define AAS_TIME_UNKNOWN              30
#define AAS_TIME_LOW_TOO_SMALL        31
#define AAS_TIME_LOW_TOO_LARGE        32
#define AAS_TIME_UPPER_TOO_SMALL      33
#define AAS_TIME_UPPER_TOO_LARGE      34
#define AAS_TIME_EVENT_NOT_IN_LIST    35
#define AAS_TIME_EVENT_EXIST          36
#define AAS_TIME_MISSING_EVENTS       37
#define AAS_NONDETERMINISTIC          38
#define MAX_AAS_ERROR_STR             (AAS_NONDETERMINISTIC+1)

typedef char aas_t[60];
extern aas_t aas_error_str[MAX_AAS_ERROR_STR];

typedef struct aas_err_log_t {
   int  fail_code;
   long line_num1;
   long line_num2;
} aas_err_log_t;

extern int aas_2_ads(char*, aas_err_log_t**, long*, state_node**, INT_S*, timed_event**, INT_T*);
extern int aas_2_ads_all(char*, long*, long*, state_node**, INT_S*, timed_event**, INT_T*);
extern int generate_aas_file(char*, char*);
extern int ads_to_aas(char*, FILE*, state_node*, INT_S, timed_event*, INT_T);

#endif
