#ifndef _VIEWER_H
#define _VIEWER_H

extern void ascii_viewer(char*, char*);
extern void ascii_print(char*, char*);
extern void ziptolastpage(FILE* in);

#endif /* _VIEWER_H */
