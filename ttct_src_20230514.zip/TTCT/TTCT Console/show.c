#include <stdio.h>
#include <stdlib.h>
//#include "curses.h"
#include "tct_curs.h"
#include "ttct_io.h"
#include "des_data.h"
#include "des_proc.h"
#include "tct_proc.h"
#include "display.h"
#include "viewer.h"
#include "setup.h"

static filename name1;
static filename fname1;
static INT_B  quit;
static char option;
static INT_B option_check;

void show_des_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(TDS)"); println();
   println();
}

void show_ads_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(ADS)"); println();
   println();
}

void show_des_stat_header(char *name,
                          INT_S s,
                          INT_S init)
{
   clear();
   printw("%s    # states: %d", name, s);
   if (s > 0) {
      printw("    state set: 0 ... %d", s-1);
      printw("    initial state: %d", init); println();
   } else {
      printw("    state set: empty ");
      printw("    initial state: none"); println();
   }
}

/* Display marker states related variables */
static state_node *t1;
static INT_T *t2;
static INT_S init, s1, s2;
static INT_S i, total_marker;
static INT_S *marker_stack;
static INT_S s_marker_stack;
static char ch;
static INT_B multiPage;
static INT_B tds_or_ads_flag = true;

void show_continue_page()
{
   if (tds_or_ads_flag) 
   {
      continue2_page(" D=PgDn  U=PgUp  H(ead)  F(orcible events) I(nfo on timers)",
                     " V(ocal table)  T(ransition table)  Esc (Exit Show)  ");
   } 
   else
   {
      continue2_page(" D=PgDn  U=PgUp  H(ead)  V(ocal table)  E(vent time bound)",
                     " F(orcible events)  T(ransition table)  Esc (Exit Show)  ");
   }
}

void marker_states_page_control(INT_B lastPage)
{
   multiPage = true;
/* continue_page("Press <Enter> or n to page marker state table, p to page back or <ESC> to cancel  ");  */

   show_continue_page();

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 'f':
         case 'F':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(marker_stack);   marker_stack = NULL;
            return;
         case 'e':
         case 'E':
            if (tds_or_ads_flag == false)
	    {
               option = ch;
               option_check = true;
               free(marker_stack);   marker_stack = NULL;
               return;
            }
            break;
         case 'i':
         case 'I':
            if (tds_or_ads_flag == true)
            {
               option = ch;
               option_check = true;
               free(marker_stack);   marker_stack = NULL;
               return;
	    }
            break;
         case CEsc:
            quit = true;
            free(marker_stack);  marker_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_marker_stack++;
               marker_stack = (INT_S*) realloc(marker_stack,
                                       sizeof(INT_S)* s_marker_stack);
               marker_stack[s_marker_stack-1] = i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_marker_stack++;
               marker_stack = (INT_S*) realloc(marker_stack,
                                       sizeof(INT_S)* s_marker_stack);
               marker_stack[s_marker_stack-1] = i;
            } else{
               show_des_stat_header(name1, s1, init);
               return;
            }
            break;
         case CPgUp:
            if (s_marker_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_marker_stack >= 2) {
                  i = marker_stack[s_marker_stack-2];
                  s_marker_stack -= 2;
                  marker_stack = (INT_S*) realloc(marker_stack,
                                       sizeof(INT_S)* s_marker_stack);

                  /* Put back the last pop */
                  s_marker_stack++;
                  marker_stack = (INT_S*) realloc(marker_stack,
                                          sizeof(INT_S)* s_marker_stack);
                  marker_stack[s_marker_stack-1] = i;
               } else {
                  i = 0;
                  i--;  /* Main loop will increment it by one. */
                  s_marker_stack = 0;
                  free(marker_stack); marker_stack = NULL;
               }
               total_marker = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("marker states:       "); println();
   println();
}

static state_node *t1;
static INT_S init, s1;
static INT_T j;
static INT_S i, total_forcible;
static INT_S *forcible_stack;
static INT_S s_forcible_stack;
static char ch;
static INT_B multiPage;

void forcible_events_page_control(INT_B lastPage)
{
   multiPage = true;
/* continue_page("Press <Enter> or n to page forcible event table, p to page back or <ESC> to cancel  "); */
   show_continue_page();
   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 'f':
         case 'F':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(forcible_stack);   forcible_stack = NULL;
            return;
         case 'e':
         case 'E':
            if (tds_or_ads_flag == false)
	    {
               option = ch;
               option_check = true;
               free(forcible_stack);   forcible_stack = NULL;
               return;
            }
            break;
         case 'i':
         case 'I':
            if (tds_or_ads_flag == true)
            {
               option = ch;
               option_check = true;
               free(forcible_stack);   forcible_stack = NULL;
               return;
	    }
            break;
         case CEsc:
            quit = true;
            free(forcible_stack);
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_forcible_stack++;
               forcible_stack = (INT_S*) realloc(forcible_stack,
                                       sizeof(INT_S)* s_forcible_stack);
               forcible_stack[s_forcible_stack-1] = i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_forcible_stack++;
               forcible_stack = (INT_S*) realloc(forcible_stack,
                                       sizeof(INT_S)* s_forcible_stack);
               forcible_stack[s_forcible_stack-1] = i;
            } else{
               show_des_stat_header(name1, s1, init);
               return;
            }
            break;
         case CPgUp:
            if (s_forcible_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_forcible_stack >= 2) {
                  i = forcible_stack[s_forcible_stack-2];
                  s_forcible_stack -= 2;
                  forcible_stack = (INT_S*) realloc(forcible_stack,
                                       sizeof(INT_S)* s_forcible_stack);

                  /* Put back the last pop */
                  s_forcible_stack++;
                  forcible_stack = (INT_S*) realloc(forcible_stack,
                                          sizeof(INT_S)* s_forcible_stack);
                  forcible_stack[s_forcible_stack-1] = i;
               } else {
                  i = 0;
                  s_forcible_stack = 0;
                  free(forcible_stack); forcible_stack = NULL;
               }
               total_forcible = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("forcible events:       "); println();
   println();
}

void timer_info_page_control(INT_B lastPage)
{
   multiPage = true;
/*   continue_page("Press <Enter> or n to page timer information table, p to page back or <ESC> to cancel  "); */
   show_continue_page();
   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 'f':
         case 'F':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(forcible_stack);   forcible_stack = NULL;
            return;
         case 'e':
         case 'E':
            if (tds_or_ads_flag == false)
	    {
               option = ch;
               option_check = true;
               free(forcible_stack);   forcible_stack = NULL;
               return;
            }
            break;
         case 'i':
         case 'I':
            if (tds_or_ads_flag == true)
            {
               option = ch;
               option_check = true;
               free(forcible_stack);   forcible_stack = NULL;
               return;
	    }
            break;
         case CEsc:
            quit = true;
            free(forcible_stack);
	    return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_forcible_stack += 2;
               forcible_stack = (INT_S*) realloc(forcible_stack,
                                       sizeof(INT_S)* s_forcible_stack);
               forcible_stack[s_forcible_stack-2] = i;
               forcible_stack[s_forcible_stack-1] = j;
	    }
            break;
         case CEnter:
            if (lastPage == false) {
               s_forcible_stack += 2;
               forcible_stack = (INT_S*) realloc(forcible_stack,
                                       sizeof(INT_S)* s_forcible_stack);
               forcible_stack[s_forcible_stack-2] = i;
               forcible_stack[s_forcible_stack-1] = j;
            } else{
               show_des_stat_header(name1, s1, init);
            }
            break;
         case CPgUp:
            if (s_forcible_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_forcible_stack >= 4) {
                  i = forcible_stack[s_forcible_stack-4];
                  j = (INT_T)forcible_stack[s_forcible_stack-3];
                  s_forcible_stack -= 4;
                  forcible_stack = (INT_S*) realloc(forcible_stack,
                                       sizeof(INT_S)* s_forcible_stack);

                  /* Put back the last pop */
                  s_forcible_stack += 2;
                  forcible_stack = (INT_S*) realloc(forcible_stack,
                                          sizeof(INT_S)* s_forcible_stack);
                  forcible_stack[s_forcible_stack-2] = i;
                  forcible_stack[s_forcible_stack-1] = j;
               } else {
                  i = 0;
		  j = 0;
                  s_forcible_stack = 0;
                  free(forcible_stack); forcible_stack = NULL;
               }
            }
            break;
      }
      total_forcible = 0;
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("state and timer information:       "); println();
   println();
}

INT_B display_marker_states(state_node *t1,
                              INT_S s1)
{
   multiPage = false;
   total_marker = 0;
   marker_stack = NULL;  s_marker_stack = 0;
   i = 0;

   printw("marker states:       "); println();
   println();
   do {
      while (i < s1) {
         if (t1[i].marked) {
            printw("%7d  ", i);
            total_marker++;
            if (total_marker % 8 == 0) {
               println();
            }

            if (_wherey() >= 21) {
               marker_states_page_control(false);
               if (quit) return true;
               if (option_check) return false;
            }
         }
         i++;
      }
      if (multiPage) marker_states_page_control(true);
      i++;
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) && (option_check == false) );
   println();
   refresh();

/*   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         printw("%5d   ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            println();
            printw("%-21s", " ");
         }
      }
   }
   println();
   return false;
*/

   free(marker_stack);  marker_stack = NULL;
   return quit;
}

INT_B display_forcible_events(timed_event *t1, INT_T s1)
{
   multiPage = false;
   total_forcible = 0;
   forcible_stack = NULL;  s_forcible_stack = 0;
   i = 0;

   println();
   printw("forcible events:       "); println();
   println();
   do {
      while (i < s1) {
         if (t1[i].forcible) {
            printw("%7d   ", t1[i].label);
            total_forcible++;
            if (total_forcible % 8 == 0) {
               println();
            }

            if (_wherey() >= 21) {
               forcible_events_page_control(false);
               if (quit) return true;
               if (option_check) return false;
            }
         }
         i++;
      }
      if (multiPage) forcible_events_page_control(true);
      i++;
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) && (option_check == false) );
   println();
   refresh();

/*   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         printw("%5d   ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            println();
            printw("%-21s", " ");
         }
      }
   }
   println();
   return false;
*/

   free(forcible_stack);  forcible_stack = NULL;
   return quit;
}

INT_B display_forcible_list(INT_T *t1, INT_T s1)
{
   multiPage = false;
   total_forcible = 0;
   forcible_stack = NULL;  s_forcible_stack = 0;
   i = 0;

   println();
   printw("forcible events:       "); println();
   println();
   do {
      while (i < s1) {
	 printw("%7d  ", t1[i]);
	 total_forcible++;
	 if (total_forcible % 8 == 0) {
	    println();
	 }
	 
	 if (_wherey() >= 21) {
	    forcible_events_page_control(false);
	    if (quit) return true; 
            if (option_check) return false;
	 }
         i++;
      }
      if (multiPage) forcible_events_page_control(true);
      i++;
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) && (option_check == false) );
   println();
   refresh();

/*   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         printw("%5d   ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            println();
            printw("%-21s", " ");
         }
      }
   }
   println();
   return false;
*/

   free(forcible_stack); forcible_stack = NULL;
   return quit;
}

INT_B display_timer_info(state_node *t1, INT_S s1)
{
   multiPage = false;
   forcible_stack = NULL;  s_forcible_stack = 0;
   i = j = 0; 

   println();
   printw("State and timer information, in format     "); println();
   printw("[TTG state]: [ATG state] [event,timer], [event,timer],...");
   println();
   println();
   do {
      while (i < s1) {
	 if (_wherey() >= 21) {
	    timer_info_page_control(false);
	    if (quit) return true;
            if (option_check) return false;
	 }
	 total_forcible = 0;
	 if (j == 0)
	    printw("%5d  :  %5d  ", i, t1[i].nstinfo[0].state);
	 else
	    printw("%-17s", " ");
	 while (j < t1[i].numtimer) {
	    printw("[%5d, %5d]  ",t1[i].ntimer[j].num, t1[i].ntimer[j].value);
	    total_forcible++;
	    j++;
	    if ((total_forcible % 3 == 0) && j < t1[i].numtimer) {
	       println();
	       if (_wherey() >= 21) {
		  timer_info_page_control(false);
		  if (quit) return true;
		  if (j > 0) {
		     total_forcible = 0;
		     printw("%-17s", " ");
		  } else {
		     i--;
		     break;
		  }
	       } else {
		  printw("%-17s", " ");
	       }
	    }
	 }
	 println();
         i++;
	 j = 0;
      }
      if (multiPage) timer_info_page_control(true);
      i++;
      if (quit) return true;
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage == true) &&
             (quit == false) && (option_check == false) );
   println();
   refresh();

/*   for (i=0; i < s1; i++) {
      if (t1[i].marked) {
         printw("%5d   ", i);
         total_marker++;
         if ((total_marker % 7) == 0) {
            println();
            printw("%-21s", " ");
         }
      }
   }
   println();
   return false;
*/

   free(forcible_stack); forcible_stack = NULL;
   return quit;
}

/* Display vocal output variables */
static INT_S *vocal_stack;
static INT_S s_vocal_stack;
static INT_S total_vocal;

void vocal_output_page_control(INT_B lastPage)
{
   multiPage = true;
/*   continue_page("Press <Enter> or n to page vocal output table, p to page back or <ESC> to cancel  "); */

   do {
      refresh();
      ch = read_key();

      switch(ch) {
  case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 'f':
         case 'F':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(vocal_stack);   vocal_stack = NULL;
            return;
         case 'e':
         case 'E':
            if (tds_or_ads_flag == false)
	    {
               option = ch;
               option_check = true;
               free(vocal_stack);   vocal_stack = NULL;
               return;
            }
            break;
         case 'i':
         case 'I':
            if (tds_or_ads_flag == true)
            {
               option = ch;
               option_check = true;
               free(vocal_stack);   vocal_stack = NULL;
               return;
	    }
            break;
         case CEsc:
            quit = true;
            free(vocal_stack);
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_vocal_stack++;
               vocal_stack = (INT_S*) realloc(vocal_stack,
                                       sizeof(INT_S)* s_vocal_stack);
               vocal_stack[s_vocal_stack-1] = i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_vocal_stack++;
               vocal_stack = (INT_S*) realloc(vocal_stack,
                                       sizeof(INT_S)* s_vocal_stack);
               vocal_stack[s_vocal_stack-1] = i;
            } else{
               show_des_stat_header(name1, s1, init);
               return;
            }
            break;
         case CPgUp:
            if (s_vocal_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_vocal_stack >= 2) {
                  i = vocal_stack[s_vocal_stack-2];
                  s_vocal_stack -= 2;
                  vocal_stack = (INT_S*) realloc(vocal_stack,
                                       sizeof(INT_S)* s_vocal_stack);

                  /* Put back the last pop */
                  s_vocal_stack++;
                  vocal_stack = (INT_S*) realloc(vocal_stack,
                                          sizeof(INT_S)* s_vocal_stack);
                  vocal_stack[s_vocal_stack-1] = i;
               } else {
                  i = 0;
                  s_vocal_stack = 0;
                  free(vocal_stack); vocal_stack = NULL;
               }
               total_vocal = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("vocal states:       "); println();
   println();
}

/* Display timebound variables */
static INT_T *bound_stack;
static INT_T s_bound_stack;
static INT_T total_bounds;

void timebound_output_control(INT_B lastPage)
{
   multiPage = true;
/* continue_page("Press <Enter> or n to page time bound table, p to page back or <ESC> to cancel  "); */
   show_continue_page();
   do {
      refresh();
      ch = read_key();

      switch(ch) {
 case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 'f':
         case 'F':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(bound_stack);   bound_stack = NULL;
            return;
         case 'e':
         case 'E':
            if (tds_or_ads_flag == false)
	    {
               option = ch;
               option_check = true;
               free(bound_stack);   bound_stack = NULL;
               return;
            }
            break;
         case 'i':
         case 'I':
            if (tds_or_ads_flag == true)
            {
               option = ch;
               option_check = true;
               free(bound_stack);   bound_stack = NULL;
               return;
	    }
            break;
         case CEsc:
            quit = true;
            free(bound_stack);
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_bound_stack++;
               bound_stack = (INT_T*) realloc(bound_stack,
                                       sizeof(INT_T)* s_bound_stack);
               bound_stack[s_bound_stack-1] = (INT_T)i;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_bound_stack++;
               bound_stack = (INT_T*) realloc(bound_stack,
                                       sizeof(INT_T)* s_bound_stack);
               bound_stack[s_bound_stack-1] = (INT_T)i;
            } else{
               show_des_stat_header(name1, s1, init);
               return;
            }
            break;
         case CPgUp:
            if (s_bound_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_bound_stack >= 2) {
                  i = bound_stack[s_bound_stack-2];
                  s_bound_stack -= 2;
                  bound_stack = (INT_T*) realloc(bound_stack,
                                       sizeof(INT_T)* s_bound_stack);

                  /* Put back the last pop */
                  s_bound_stack++;
                  bound_stack = (INT_T*) realloc(bound_stack,
                                          sizeof(INT_T)* s_bound_stack);
                  bound_stack[s_bound_stack-1] = (INT_T)i;
               } else {
                  i = 0;
                  s_bound_stack = 0;
                  free(bound_stack); bound_stack = NULL;
               }
               total_bounds = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("event time bounds:       "); println();
   println();
}

INT_B display_vocal_output(state_node *t1,
                             INT_S s1)
{
   total_vocal = 0;
   multiPage = false;
   vocal_stack = NULL;  s_vocal_stack = 0;
   i = 0;

   println();
   printw("vocal states:      "); println();
   if (_wherey() >= 22) {
      vocal_output_page_control(false);
      if (quit) return true;
      if (option_check) return false;
   } else {
      println();
   }

   do {
      while (i < s1) {
        if (_wherey() >= 21)
           vocal_output_page_control(false);
        if (quit) return true;
        if (option_check) return false;

        if (t1[i].vocal > 0) {
           /* Tempory format fix */
           if (s1 < 100000)
              printw("[%5ld,%4d]   ", i, t1[i].vocal);
           else if (s1 < 1000000)
              printw("[%6ld,%4d]  ", i, t1[i].vocal);
           else
              printw("[%7ld,%4d] ", i, t1[i].vocal);

           total_vocal++;
           if ((total_vocal % 5) == 0) {
             println();
           }
        }
        i++;
      }
      if (multiPage) vocal_output_page_control(true);
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage != false) &&
             (quit != true) && (option_check != true) );
   println();

   free(vocal_stack);  vocal_stack = NULL;

/*   println();
   printw("vocal states:       "); println();
   for (i=0; i < s1; i++) {
      if (t1[i].vocal > 0) {
         printw("[%5d,%4d]   ", i, t1[i].vocal);
         total_vocal++;
         if ((total_vocal % 5) == 0) {
            println();
         }
      }
   }
   println();
*/
   return false;
}

/* Display timebounds of events */
INT_B display_timebounds(timed_event *t1,
                             INT_T s1)
{
   total_bounds = 0;
   multiPage = false;
   bound_stack = NULL;  s_bound_stack = 0;
   i = 0;

   println();
   printw("event time bounds:      "); println();
   if (_wherey() >= 21) {
      timebound_output_control(false);
      if (quit) return true;
      if (option_check) return false;
   } else {
      println();
   }

   do {
      while (i < s1) {
        if (_wherey() >= 21)
           timebound_output_control(false);
        if (quit) return true;
	if (t1[i].upper == MAX_TIME) {
	   printw("event: %3ld    [%5ld, Inf]",t1[i].label, t1[i].low);
	} else {
	   printw("event: %3ld    [%5ld,%4ld]",t1[i].label, t1[i].low, 
		  t1[i].upper);
	}
	println();
	total_bounds++;
        i++;
      }
      if (multiPage) timebound_output_control(true);
   } while ( (ch != CEnter) && (ch != CPgDn) && (multiPage != false) &&
             (quit != true) && (option_check == false) );
   println();

   free(bound_stack);  bound_stack = NULL;

/*   println();
   printw("vocal states:       "); println();
   for (i=0; i < s1; i++) {
      if (t1[i].vocal > 0) {
         printw("[%5d,%4d]   ", i, t1[i].vocal);
         total_vocal++;
         if ((total_vocal % 5) == 0) {
            println();
         }
      }
   }
   println();
*/
   return false;
}

/* Display transitions variables */
static state_pair *tran_stack;
static INT_S s_tran_stack;
static INT_S total_tran;
static INT_S num_transitions;
static INT_T j;

void transition_page_control(INT_B lastPage)
{
/* if (lastPage) {
      continue_page("Press <Enter> to return to TTCT Procedures  ");
   } else {
      continue_page("Press <Enter> or n to page transition table, p to page back or <ESC> to cancel  ");
   }
*/
  
   show_continue_page();
   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case 'h':
         case 'H':
         case 'v':
         case 'V':
         case 'f':
         case 'F':
         case 't':
         case 'T':
            option = ch;
            option_check = true;
            free(tran_stack);   tran_stack = NULL;
            return;
         case 'e':
         case 'E':
            if (tds_or_ads_flag == false)
	    {
               option = ch;
               option_check = true;
               free(tran_stack);   tran_stack = NULL;
               return;
            }
            break;
         case 'i':
         case 'I':
            if (tds_or_ads_flag == true)
            {
               option = ch;
               option_check = true;
               free(tran_stack);   tran_stack = NULL;
               return;
	    }
            break;
         case CEsc:
            quit = true;
            free(tran_stack); tran_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CPgUp:
            if (s_tran_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_tran_stack >= 2) {
                  i = tran_stack[s_tran_stack-2].data1;
                  j = (INT_T)tran_stack[s_tran_stack-2].data2;

                  s_tran_stack -= 2;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                       sizeof(state_pair)*s_tran_stack);

                  /* Put back the last pop */
                  s_tran_stack++;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
                  tran_stack[s_tran_stack-1].data1 = i;
                  tran_stack[s_tran_stack-1].data2 = j;
               } else {
                  i = 0;
                  j = 0;
                  s_tran_stack = 0;
                  free(tran_stack); tran_stack = NULL;
               }
               total_tran = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   show_des_stat_header(name1, s1, init);
   println();
   printw("# transitions: %d", num_transitions); println();
   println();
   printw("transitions: "); println();
   println();
}

INT_B display_transitions(state_node *t1,
                            INT_S s1)
{
   INT_T t;
   INT_S e;
   int d;

   total_tran = 0;
   multiPage = false;
   tran_stack = NULL;  s_tran_stack = 0;
   i = 0; j = 0;

   num_transitions = count_tran(t1, s1, &d, &d, &d);

   if (_wherey() >= 18)
   {
      transition_page_control(false);
      if (quit) return true;
      if (option_check) return false;
   }
   else 
   {
      println();
      printw("# transitions: %d", num_transitions); println();
      println();
      printw("transitions: "); println();
      println();

      if (_wherey() >= 21)
      {
         transition_page_control(false);
         if (quit) return true;
         if (option_check) return false;
      }
      else
         println();
   }

   if (s1 < 100000)
   {

   do {
      while (i < s1) {
        while (j < t1[i].numelts) {
          if (_wherey() >= 21)
             transition_page_control(false);
          if (quit) return true;
          if (option_check) return false;
          t = t1[i].next[j].data1;
          e = t1[i].next[j].data2;
          printw("[%5ld,%3d,%5ld]  ", i, t, e);
          total_tran++;
          if (total_tran % 4 == 0)
            println();
          j++;
        }
        j = 0;
        i++;
      }
      transition_page_control(true);
      if (quit) return true;
      if (option_check) return false;
   } while ( (ch != CEnter) );
   }

   else
   {
/* > 100000 states */
   do {
      while (i < s1) {
        while (j < t1[i].numelts) {
          if (_wherey() >= 21)
             transition_page_control(false);
          if (quit) return true;
          if (option_check) return false;
          t = t1[i].next[j].data1;
          e = t1[i].next[j].data2;
          printw("[%7ld,%3d,%7ld]  ", i, t, e);
          total_tran++;
          if (total_tran % 3 == 0)
            println();
          j++;
        }
        j = 0;
        i++;
      }
      transition_page_control(true);
      if (quit) return true;
      if (option_check) return false;
   } while ( ch != CEnter );
   
   }

   println();

   free(tran_stack); tran_stack = NULL;

/*   for (i=0; i < s1; i++) {
     for (j=0; j< t1[i].numelts; j++) {
       printw("[%5d,%3d,%5d]  ", i, t1[i].next[j].data1, t1[i].next[j].data2);
       total_tran++;
       if ((total_tran % 4) == 0) {
          println();
       }
     }
   } */
   return false;
}

INT_B display_empty_tran(void)
{
   total_tran = 0;
   multiPage = false;
   tran_stack = NULL;  s_tran_stack = 0;
   i = 0; j = 0;

   if (_wherey() > 18)
   {
      transition_page_control(false);
      if (quit) return true;
      if (option_check) return false;
   }

   printw("transition table : empty"); println();
   do {
      transition_page_control(true);
      if (quit) return true;
      if (option_check) return false;
   } while (ch != CEnter);

   return true;
}

void show_mark(state_node *t1, INT_S s1)
{
   INT_S num_mark;

   num_mark = num_mark_states(t1, s1);

   if ((num_mark == s1) && (s1 > 0)) {
      printw("marker states: all"); println();
      println();
   } else if (num_mark > 0L) {
      quit = display_marker_states(t1, s1);
      if (quit) return;
   } else {
      printw("marker states: none"); println();
      println();
   }
}

void show_forcible_list(INT_T *t2, INT_S s2)
{
   if (s2 > 0L) {
      quit = display_forcible_list(t2, (INT_T)s2);
      if (quit) return;
   } else {
      println();
      printw("forcible events: none"); println();
      println();
   }
}

void show_timer_info(state_node* t1, INT_S s1)
{
   if (s1 > 0 && t1[0].ntimer != NULL) {
      quit = display_timer_info(t1, s1);
      if (quit) return;
   }
}

void show_vocal(state_node *t1, INT_S s1)
{
   if (num_vocal_output(t1, s1) > 0L) {
      quit = display_vocal_output(t1, s1);
      if (quit) return;
   } else {
      println();
      printw("vocal states: none"); println();
      println();
   }
}

void show_transitions(state_node *t1, INT_S s1)
{
   INT_S nTransitions;
   int d;

   nTransitions = count_tran(t1, s1, &d, &d, &d);
   if (nTransitions > 0) {
      quit = display_transitions(t1, s1);
      if (quit) return;
   } else {
      display_empty_tran();
   }
}

void show_des_r(state_node** t1, INT_S *s1, INT_T **t2, INT_S *s2)
{
//   INT_S nTransitions;
//   int d;

   clear();
   show_des_header();
   quit = getname("Enter name of TDS ...  ", EXT_DES, name1, fname1, false);
   if (quit) return;

   if (gettds(name1, s1, &init, t1, s2, t2) == false) {
      quit = true;
      return;
   }

   /* Display TDS to screen */
   clear();
   if (init == -1) {
     println();
     printw("This is a DAT file.");   println();
     printw("Use show DAT command."); println();
     refresh();
     user_pause();
     quit = true;
     return;
   }

   show_des_stat_header(name1, *s1, init);
   println();
   refresh();

   option = 'H';
   option_check = false;
   do {
     switch(option) {
        case 'h':
        case 'H':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_mark(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_forcible_list(*t2, *s2);
             if (quit) return;
             if (option_check) break;

             show_timer_info(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_vocal(*t1, *s1);
             if (quit) return;
             if (option_check) break;
       
             show_transitions(*t1, *s1);
             if (quit) return; 
             break;

        case 'f':
        case 'F':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_forcible_list(*t2, *s2);
             if (quit) return;
             if (option_check) break;

             show_timer_info(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_vocal(*t1, *s1);
             if (quit) return;
             if (option_check) break;
       
             show_transitions(*t1, *s1);
             if (quit) return; 
             break;

        case 'i':
        case 'I':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_timer_info(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_vocal(*t1, *s1);
             if (quit) return;
             if (option_check) break;
       
             show_transitions(*t1, *s1);
             if (quit) return; 
             break;

        case 'v':
        case 'V':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_vocal(*t1, *s1);
             if (quit) return;
             if (option_check) break;
       
             show_transitions(*t1, *s1);
             if (quit) return; 
             break;
 
        case 't':
        case 'T': 
            show_des_stat_header(name1, *s1, init);
            println();
            refresh();

            show_transitions(*t1, *s1);
            if (quit) return;
            break;
     }
     option_check = false; 
   } while (quit == false);

/*   if (*s2 > 0L) {
      quit = display_forcible_list(*t2, *s2);
      if (quit) return;
   } else {
      printw("forcible events: none"); println();
      println();
   }
   */

/*   if (*s1 > 0 && (*t1)[0].ntimer != NULL) {
      quit = display_timer_info(*t1, *s1);
      if (quit) return;
   } else {
      println();
      printw("No state and timer information available !"); println();
      println();
   }
 */
}

void show_timebounds(timed_event *t2, INT_T s2)
{
   if (s2 > 0) {
      quit = display_timebounds(t2, s2);
      if (quit) return;
   } else {
      println();
      printw("No assigned time bounds"); println();
      println();
   }
}

void show_forcible_events(timed_event *t2, INT_T s2)
{
   if (num_forcible_events(t2, s2) > 0L) {
      quit = display_forcible_events(t2, s2);
      if (quit) return;
   } else {
      println();
      printw("forcible events: none"); println();
      println();
   }
}

void show_ads_r(state_node** t1,
                INT_S *s1)
{
//   INT_S nTransitions;
//   int d;
   INT_T s2;
   timed_event *t2;

   t2 = NULL;
   s2 = 0;
   clear();
   show_ads_header();
   quit = getname("Enter name of ADS ...  ", EXT_ADS, name1, fname1, false);
   if (quit) return;

   if (getads(name1, s1, &init, t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   /* Display DES to screen */
   clear();
   if (init == -1) {
     println();
     printw("This is a DAT file.");   println();
     printw("Use show DAT command."); println();
     refresh();
     user_pause();
     quit = true;
     return;
   }

   show_des_stat_header(name1, *s1, init);
   println();
   refresh();

   option = 'H';
   option_check = false;
   do {
     switch(option) {
        case 'h':
        case 'H':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_mark(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_vocal(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_timebounds(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_forcible_events(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_transitions(*t1, *s1);
             if (quit) return;
             break;

        case 'v':
        case 'V':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_vocal(*t1, *s1);
             if (quit) return;
             if (option_check) break;

             show_timebounds(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_forcible_events(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_transitions(*t1, *s1);
             if (quit) return;
             break;

        case 'e':
        case 'E':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_timebounds(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_forcible_events(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_transitions(*t1, *s1);
             if (quit) return;
             break;

        case 'f':
        case 'F':
             show_des_stat_header(name1, *s1, init);
             println();
             refresh();

             show_forcible_events(t2, s2);
             if (quit) return;
             if (option_check) break;

             show_transitions(*t1, *s1);
             if (quit) return;
             break;

        case 't':
        case 'T':
            show_des_stat_header(name1, *s1, init);
            println();
            refresh();

            show_transitions(*t1, *s1);
            if (quit) return;
            break;
     }
     option_check = false;
   } while (quit == false);

   free(t2);
}

void show_des_p()
{
   t1 = NULL;
   t2 = NULL;

   tds_or_ads_flag = true;

   show_des_r(&t1, &s1, &t2, &s2);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
   free(t2);
}

void show_ads_p()
{
   t1 = NULL;

   tds_or_ads_flag = false;

   show_ads_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

/* Dat variables */
static INT_S prevNumTran;
static INT_B leftSide;

void show_dat_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(DAT)"); println();
   println();
}

void dat_header()
{
    clear();
    printw("%s", name1); println();
    println();
    println();
    printw("Control data are displayed as a list of supervisor states"); println();
    printw("where disabling occurs, together with the events that must"); println();
    printw("be disabled or forced there."); println();
    println();
    /*printw("%s is:", name1); */
   /* printw("control data: "); println();*/
}

void dat_page_control(INT_B lastPage)
{
   if (lastPage) {
      continue_page("Press <Enter> to return to TTCT Procedures  ");
   } else {
      continue_page("Press <Enter> or n to page table, p to page back or <ESC> to cancel  ");
   }

   do {
      refresh();
      ch = read_key();

      switch(ch) {
         case CEsc:
            quit = true;
            free(tran_stack); tran_stack = NULL;
            return;
         case CPgDn:
            if (lastPage == true) {
               ch = 0;
               ring_bell();
            } else {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CEnter:
            if (lastPage == false) {
               s_tran_stack++;
               tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
               tran_stack[s_tran_stack-1].data1 = i;
               tran_stack[s_tran_stack-1].data2 = j;
            }
            break;
         case CPgUp:
            if (s_tran_stack == 0) {
               ch = 0;
               ring_bell();
            } else {
               if (s_tran_stack >= 2) {
                  i = tran_stack[s_tran_stack-2].data1;
                  j = (INT_T)tran_stack[s_tran_stack-2].data2;

                  s_tran_stack -= 2;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                       sizeof(state_pair)*s_tran_stack);

                  /* Put back the last pop */
                  s_tran_stack++;
                  tran_stack = (state_pair*) realloc(tran_stack,
                                          sizeof(state_pair)*s_tran_stack);
                  tran_stack[s_tran_stack-1].data1 = i;
                  tran_stack[s_tran_stack-1].data2 = j;
               } else {
                  i = 0;
                  j = 0;
                  s_tran_stack = 0;
                  free(tran_stack); tran_stack = NULL;
               }
               prevNumTran = 0;
               leftSide = false;
               total_tran = 0;
            }
            break;
      }
   } while ( ( ch != CEnter) && (ch != CEsc) && (ch != CPgUp) && (ch != CPgDn) );

   dat_header();
   println();
}

INT_B display_dat(state_node *t1,
                    INT_S s1)
{
	INT_S k;
	INT_T t;
	INT_T realtrans;

    printw("%s is:", name1); 
    if (compute_controllable(t1, s1))
      printw( "  Controllable.");
   else
      printw("  Uncontrollable.");
   
   println();println();
   printw("control data: "); println();
   


   tran_stack = NULL; s_tran_stack = 0;

   total_tran = 0;
   leftSide = false;
   prevNumTran = 0;
   i = 0; j = 0;

   do {
      while (i < s1) {
	 realtrans = t1[i].numelts - t1[i].vocal;
         if (t1[i].numelts > 0) {
	    if ((prevNumTran > 6) || (t1[i].numelts > 6) || 
		(leftSide == false)) {
	       println();
	       if (_wherey() >= 22)
		      dat_page_control(false);
	       if (quit) {
		      free(tran_stack);
		      return true;
	       }
	       
	       printw("%4s", " ");
	       leftSide = true;
	    } else {
	       for (k=prevNumTran; k < 6; k++)
		  printw("%5s", " ");
	       leftSide = false;
	    }
	    printw("%4d:", i);
	    prevNumTran = t1[i].numelts;
         }

         while (j < t1[i].numelts) {
            if (_wherey() >= 22)
               dat_page_control(false);
            if (quit) {
               free(tran_stack);
               return true;
            }

            t = t1[i].next[j].data1;
	    if (j < realtrans) { 
	       printw("%4d ", t);
	    } else {
	       printw("%4df", t);
	    }

            if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
               println();
               printw("%9s", " ");
            }
            j++;
         }
         j = 0;
         i++;
      }
      dat_page_control(true);
      if (quit) {
         free(tran_stack);
         return true;
      }
   } while ( (ch != CEnter) && (ch != CPgDn) );
   println();
   free(tran_stack);

/*   println();
   for (i=0; i < s1; i++) {
     if (t1[i].numelts > 0) {
       if ((prevNumTran > 6) || (t1[i].numelts > 6) || (leftSide == false)) {
         println();
         printw("%-4d", " ");
         leftSide = true;
       } else {
         for (k=prevNumTran; k <=6; k++)
            printw("%-5d", " ");
         leftSide = false;
       }
       printw("%-4d:", i);
       prevNumTran = t1[i].numelts;
     }

     for (j=0; j< t1[i].numelts; j++) {
       printw("%4d ", t1[i].next[j].data1);

       if ( (j != 0) && ((j % 12) == 0) && (j < prevNumTran-1) ) {
          println();
          printw("%9s", " ");
       }
     }
   }
*/
   return false;
}

void show_dat_r(state_node** t1,
                INT_S *s1)
{
   INT_S init, nTransitions;
   char ch;
   int d;
   INT_S s2;
   INT_T *t2;

   t2 = NULL;

   clear();
   show_dat_header();
   quit = getname("Enter name of DAT ...  ", EXT_DAT, name1, fname1, false);
   if (quit) return;

   init = -1;
   if (gettds(name1, s1, &init, t1, &s2, &t2) == false) {
      quit = true;
      return;
   }

   dat_header();
   nTransitions = count_tran(*t1, *s1, &d, &d, &d);
   if (nTransitions > 0) {
      quit = display_dat(*t1, *s1);
      if (quit) return;
   } else {
      printw("empty."); println();
      move(23,0); clrtoeol();
      printw("Press <Enter> to return to TTCT Procedure  ");
      refresh();
      do {
        ch = read_key();
      } while (ch != CEnter);
   }
}

void show_dat_p()
{
   t1 = NULL;

   show_dat_r(&t1, &s1);

   if (mem_result == 1) {
      OutOfMemoryMsg();
      user_pause();
      mem_result = 0;           /* Reset memory function to zero */
   }

   freedes(s1, &t1);
}

void show_ascii_header()
{
   printw("SHOW"); println();
   println();
   printw("SHOW(TXT)"); println();
   println();
}

void show_ascii_p()
{
   filename longname;

   clear();
   show_ascii_header();
   quit = getname("Enter name of TXT ...  ", EXT_TXT, name1, fname1, false);
   if (quit) return;

   sprintf(longname, "%s%s%s", prefix, name1, EXT_TXT);

   ascii_viewer(longname,name1);
}




