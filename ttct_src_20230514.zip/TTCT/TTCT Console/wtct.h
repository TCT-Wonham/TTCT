#ifndef _WTCT_H
#define _WTCT_H

/*#if defined(__UNIX__)*/
//#include <dirent.h>

/*#elif defined(__BORLANDC__) || defined(__DOS32__)
#include <dos.h>
#include <dir.h>

#endif*/

extern wtct_init(char*);
extern wtct_run();
extern wtct_done();

#endif

