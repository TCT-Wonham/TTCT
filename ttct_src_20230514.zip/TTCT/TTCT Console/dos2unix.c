/*
 *
 *   TCTRealX: dos2unixdes, a program that converts old DES files (16bits)
 *             to new format for UNIX (32bits) spec 2.00 => spec 1.0
 *
 *   for the Control System Group 
 *   University of Toronto, Ontario, Canada
 *
 *   by Cedric DELAYRE  --- July 1996
 *   delayre@emi.u-bordeaux.fr
 */

#include <stdio.h>
#include "des_data.h"
#include "io_desff.h"
#include "setup.h"

char prefix[80];

/*int
main( int argc, char **argv )
{
  state_node *the_des=NULL;
  FILE *in, *out;
  int nb_states, init_state, i;
  long size;
  INT_T *dummy;

  strcpy(prefix,""); 
  if (argc<2)
    {
      fprintf(stderr,"usage: %s <des file1> <des file2> ...\n",argv[0]);
      exit(128);
    }

  for (i=1; i<argc; i++)
    {
      printf("Converting %s... ",argv[i]);
      in = fopen( argv[i], "rb" );
      if (!in)
	{
	  printf("error! unable to open it, skipping.\n");
	  continue;
	}
      if (the_des)
	freedes(nb_states,&the_des);
      the_des = read_old_des_file( in, &nb_states, &init_state );
      fclose(in);
      
      dummy = NULL;
      out = fopen( argv[i], "wb" );
      if (!out)
	{
	  printf("error! unable to write on, skipping.\n");
	  continue;
	}
      size = write_tds_to_file( the_des, nb_states, init_state, dummy,0L,out );
      printf("ok, %ld bytes written\n",size);
      fclose(out);
    }

  printf("You have to rename the files from .des to .tds to use them with TTCT!");
  return 0;
}
*/