/* ASCII ADS to (Binary) ADS translation */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(__GO32__)
#include <io.h>
#endif

#include <ctype.h>
#include "des_data.h"
#include "setup.h"
#include "io.h"
#include "aas2ads.h"
#include "des_proc.h"

/* AAS file format:
# One line comments
FILENAME\n\r
State size (State set will be (0,1....,size-1)):

\n\r                         <--- End of number of states
Marker states:
                             <--- One marker per line
\n\r                         <--- End of marker states
Vocal states:
                             <--- One state vocal output (space to separate)
\n\r                         <--- End of vocal states
Transitions:
                             <--- One transition per line (space to separate)
\n\r                         <--- End of transitions
Event time bounds:
                             <--- "event lower upper" line (space to separate)
\n\r                         <--- End of event time bounds                     
Forcible events: 
                             <--- One forcible event per line
\n\r                         <--- End of forcible events
*/

#define A2D_NAME     1
#define A2D_STATE_L  2
#define A2D_STATE    3
#define A2D_MARK_L   4
#define A2D_MARK     5
#define A2D_VOCAL_L  6
#define A2D_VOCAL    7
#define A2D_TRANS_L  8
#define A2D_TRANS    9
#define A2D_TIME_L   10
#define A2D_TIME     11
#define A2D_FORCE_L  12
#define A2D_FORCE    13

aas_t aas_error_str[] = {
   "OK",                                          /*  0 */
   "File does not exist",                         /*  1 */
   "Unexpected end of file",                      /*  2 */
   "Internal error",                              /*  3 */
   "No file name present",                        /*  4 */
   "File name too long",                          /*  5 */
   "Expecting string 'State size'",               /*  6 */
   "State out of range",                          /*  7 */
   "State number too large",                      /*  8 */
   "Expecting string 'Marker states:'",           /*  9 */
   "Marker state out of range",                   /* 10 */
   "Marker state too large",                      /* 11 */
   "Expecting string 'Vocal states:'",            /* 12 */
   "Vocal output too small",                      /* 13 */
   "Vocal output too large",                      /* 14 */
   "Expecting string 'Transitions:'",             /* 15 */
   "Transition label out of range",               /* 16 */
   "Transition label too large",                  /* 17 */
   "Invalid state number",                        /* 18 */
   "Invalid marker state",                        /* 19 */
   "Invalid vocal output",                        /* 20 */ 
   "Invalid transition label",                    /* 21 */ 
   "Exit state out of range",                     /* 22 */
   "Exit state too large",                        /* 23 */
   "Entrance state out of range",                 /* 24 */
   "Entrance state too large",                    /* 25 */
   "Expecting string 'Forcible events:'",         /* 26 */ 
   "Invalid event label",                         /* 27 */
   "Forcible event not in list",                  /* 28 */
   "Expecting string 'Event time bounds:'",       /* 29 */ 
   "Invalid time bound",                          /* 30 */
   "Lower time bound out of range",               /* 31 */
   "Lower time bound too large",                  /* 32 */
   "Upper time bound out of range",               /* 33 */
   "Upper time bound too large",                  /* 34 */
   "Time event not in list",                      /* 35 */
   "Time event already exists",                   /* 36 */
   "Insufficient time events entered",            /* 37 */
   "Nondeterministic transition"                  /* 38 */
};

char des_filename[80];
static int a2d_state;
static state_node *t;
static INT_S s;
static timed_event *tt;
static INT_T ss;


typedef struct tranList_t {
   INT_S i;
   INT_T e;
   INT_S j;
   long line;
} tranList_t;

tranList_t *tranList;
long s_tranList;

static INT_T *temp_tt;
static INT_T temp_ss;

aas_err_log_t* aas_err_list;
long aas_err_num;
long aas_line_num;
long aas_line_num2;

void log_aas_err(int err, long line_num, long line_num2)
{
   aas_err_num++;
   aas_err_list = (aas_err_log_t*) realloc(aas_err_list, sizeof(aas_err_log_t)*(aas_err_num));
   aas_err_list[aas_err_num-1].fail_code = err;
   aas_err_list[aas_err_num-1].line_num1 = line_num;
   aas_err_list[aas_err_num-1].line_num2 = line_num2;
}

static int A2D_ReadName(char* line)
{
   int len;

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", des_filename);
   len = (int)strlen(des_filename);

   if (len <= 0)
   {
      log_aas_err(AAS_FILENAME_EMPTY, aas_line_num, -1);
      return AAS_FILENAME_EMPTY;
   }

/*   if (len > MAX_DES_NAME_LEN)
      return AAS_FILENAME_TOO_LONG;
*/
   a2d_state++;
   return 0;
}

static int A2D_StateLabel(char* line)
{
   char label[80];

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", label);

   if (strcmp(label, "State") != 0)
   {
      log_aas_err(AAS_STATE_LABEL_EXPECTED, aas_line_num, -1);
      return AAS_STATE_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

static int A2D_ReadState(char* line)
{
   int max_states = -1;
   int result = 0;

   if (strcmp(line, "") == 0)
      return 0;

   result = sscanf(line, "%ld", &max_states);
   if (result <= 0)
   {
      log_aas_err(AAS_STATE_UNKNOWN, aas_line_num, -1);
      return AAS_STATE_UNKNOWN;
   }

   if (max_states < 0)
   {
      log_aas_err(AAS_STATE_TOO_SMALL, aas_line_num, -1);
      return AAS_STATE_TOO_SMALL;
   }

   if (max_states > MAX_STATES)
   {
      log_aas_err(AAS_STATE_TOO_LARGE, aas_line_num, -1);
      return AAS_STATE_TOO_LARGE;
   }

   s = (INT_S) max_states;
   t = newdes(s);
   if (s != 0) {
     if (t == NULL) {
        mem_result = 1;
        return -1;
     }
   }

   a2d_state++;
   return 0;
}

static int A2D_MarkLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Marker states:") != 0)
   {
      log_aas_err(AAS_MARK_LABEL_EXPECTED, aas_line_num, -1);
      return AAS_MARK_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

static int A2D_ReadMark(char* line)
{
   int mark;
   INT_S i;
   int result;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/
   if (*line == '\0')
      return 0;

   if (strcmp(line, "Vocal states:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   if ( (strcmp(line, "*") == 0) ||
        (strcmp(line, " *") == 0) )
   {
      a2d_state++;

      for (i=0; i < s; i++)
         t[i].marked = true;
      return 0;
   }

   result = sscanf(line, "%d", &mark);

   if (result <= 0)
   {
     log_aas_err(AAS_MARK_UNKNOWN, aas_line_num, -1);
     return AAS_MARK_UNKNOWN;
   }

   if (mark < 0)
   {
     log_aas_err(AAS_MARK_TOO_SMALL, aas_line_num, -1);
     return AAS_MARK_TOO_SMALL;
   }

   if (mark >= s)
   {
     log_aas_err(AAS_MARK_TOO_LARGE, aas_line_num, -1);
     return AAS_MARK_TOO_LARGE;
   }

   t[mark].marked = true;
   return 0;
}

static int A2D_VocalLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Vocal states:") != 0)
   {
      log_aas_err(AAS_VOCAL_LABEL_EXPECTED, aas_line_num, -1);
      return AAS_VOCAL_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

static int A2D_ReadVocal(char* line)
{
   int state;
   int vocal;
   int result;
   int err;

   err = 0;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/

   if (*line == '\0')
      return 0;

   if (strcmp(line, "Transitions:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   result = sscanf(line, "%d %d", &state, &vocal);
   if (result <= 1)
   {
      log_aas_err(AAS_VOCAL_UNKNOWN, aas_line_num, -1);
      return AAS_VOCAL_UNKNOWN;
   }

   if (state < 0)
   {
      log_aas_err(AAS_STATE_TOO_SMALL, aas_line_num, -1);
      err = AAS_STATE_TOO_SMALL;
   }

   if (state >= s)
   {
      log_aas_err(AAS_STATE_TOO_LARGE, aas_line_num, -1);
      err = AAS_STATE_TOO_LARGE;
   }

   if (vocal <= 9)
   {
      log_aas_err(AAS_VOCAL_TOO_SMALL, aas_line_num, -1);
      err = AAS_VOCAL_TOO_SMALL;
   }

   if (vocal > 99)
   {
      log_aas_err(AAS_VOCAL_TOO_LARGE, aas_line_num, -1);
      err = AAS_VOCAL_TOO_LARGE;
   }

   if (err == 0)
      t[state].vocal = (INT_V) vocal;

   return err;
}

static int A2D_TransLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Transitions:") != 0)
   {
      log_aas_err(AAS_TRANS_LABEL_EXPECTED, aas_line_num, -1);
      return AAS_TRANS_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

static int A2D_ReadTrans(char* line, long *line_num, long *line_num2)
{
   int i, e, j, jj;
   INT_B ok;
   int result;
   long ii;
   int err;

   err = 0;

   if (*line == '\0')
     return 0;

   if (strcmp(line, "Event time bounds:") == 0)
   {
     a2d_state++;
     a2d_state++;

     gentranlist(s, t, &temp_ss, &temp_tt); 
     return 0;
   }

   result = sscanf(line, "%d %d %d", &i, &e, &j);

   if (result <= 2)
   {
     log_aas_err(AAS_TRANS_UNKNOWN, aas_line_num, -1);
     return AAS_TRANS_UNKNOWN;
   }

   if (i < 0)
   {
     log_aas_err(AAS_EXIT_STATE_TOO_SMALL, aas_line_num, -1);
     err = AAS_EXIT_STATE_TOO_SMALL;
   }

   if (i >= s)
   {
     log_aas_err(AAS_EXIT_STATE_TOO_LARGE, aas_line_num, -1);
     err = AAS_EXIT_STATE_TOO_LARGE;
   }

   if (e < 1)  /* Zero is not a valid event label in ADS */
   {
     log_aas_err(AAS_TRANS_TOO_SMALL, aas_line_num, -1);
     err = AAS_TRANS_TOO_SMALL;
   }

   if (e > MAX_TRANSITIONS)
   {
     log_aas_err(AAS_TRANS_TOO_LARGE, aas_line_num, -1);
     err = AAS_TRANS_TOO_LARGE;
   }

   if (j < 0)
   {
     log_aas_err(AAS_ENTRANCE_STATE_TOO_SMALL, aas_line_num, -1);
     err = AAS_ENTRANCE_STATE_TOO_SMALL;
   }

   if (j >= s)
   {
     log_aas_err(AAS_ENTRANCE_STATE_TOO_LARGE, aas_line_num, -1);
     err = AAS_ENTRANCE_STATE_TOO_LARGE;
   }

   if (err != 0)
      return err;

   /* Check for non-deterministic transitions */
   for (jj=0; jj < t[i].numelts; jj++) {
      if ( (e == t[i].next[jj].data1) &&
           (j != t[i].next[jj].data2) )
      {
         /* Find the line number that mismatch with this transition */
         for (ii =0; ii < s_tranList; ii++)
         {
            if ( (tranList[ii].i == i) &&
                 (tranList[ii].e == e))
               *line_num2 = tranList[ii].line;
         }

         log_aas_err(AAS_NONDETERMINISTIC, aas_line_num, *line_num2);
         return AAS_NONDETERMINISTIC;
      }
   }

   /* Record transition and line number */
   tranList = (tranList_t*) realloc(tranList, sizeof(tranList_t)*(s_tranList+1));
   if (tranList == NULL)
   {
      mem_result = 1;
      return 0;
   }
   tranList[s_tranList].i = i;
   tranList[s_tranList].e = e;
   tranList[s_tranList].j = j;
   tranList[s_tranList].line = *line_num;
   s_tranList++;

   addordlist1((INT_T) e, (INT_S) j, &t[i].next, t[i].numelts, &ok);
   if (ok) t[i].numelts++;
   return 0;
}

static int A2D_TimeLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Event time bounds:") != 0)
   {
       log_aas_err(AAS_TIME_LABEL_EXPECTED, aas_line_num, -1);
       return AAS_TIME_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

static int A2D_ReadTime(char* line)
{
   int label, low, upper;
   int result;
   int err = 0;
   INT_B ok;

   if (*line == '\0')
      return 0;

   if (strcmp(line, "Forcible events:") == 0)
   {
      a2d_state++;
      a2d_state++;

      if (ss != temp_ss)
      {
	 /* Missing events */
         log_aas_err(AAS_TIME_MISSING_EVENTS, aas_line_num, -1);
         return AAS_TIME_MISSING_EVENTS;
      }

      return 0;
   }

   result = sscanf(line, "%d %d %d", &label, &low, &upper); 

   if (result <= 2)
   {
      log_aas_err(AAS_TIME_UNKNOWN, aas_line_num, -1);
      return AAS_TIME_UNKNOWN;
   }

   if (label < 1)
   {
      log_aas_err(AAS_TRANS_TOO_SMALL, aas_line_num, -1);
      err = AAS_TRANS_TOO_SMALL;
   }
  
   if (label > MAX_TRANSITIONS)
   {
      log_aas_err(AAS_TRANS_TOO_LARGE, aas_line_num, -1);
      err = AAS_TRANS_TOO_LARGE;
   }

   if (low < 0)
   {
      log_aas_err(AAS_TIME_LOW_TOO_SMALL, aas_line_num, -1);
      err = AAS_TIME_LOW_TOO_SMALL;
   }

   if (low > 1000)
   {
      log_aas_err(AAS_TIME_LOW_TOO_LARGE, aas_line_num, -1);
      err = AAS_TIME_LOW_TOO_LARGE;
   }

   if (upper < low)
   {
      log_aas_err(AAS_TIME_UPPER_TOO_SMALL, aas_line_num, -1);
      err = AAS_TIME_UPPER_TOO_SMALL;
   }

   if (upper > 1000)
   {
      log_aas_err(AAS_TIME_UPPER_TOO_LARGE, aas_line_num, -1);
      err = AAS_TIME_UPPER_TOO_LARGE;
   } 

   if (err != 0)
      return err;

   /* Event must be present */
   if (!inlist(label, temp_tt, temp_ss))
   {
      log_aas_err(AAS_TIME_EVENT_NOT_IN_LIST, aas_line_num, -1);
      return AAS_TIME_EVENT_NOT_IN_LIST;
   }

   /* Try to add it to list. */
   addordlist_time((INT_T) label, low, upper, &tt, ss, &ok);
   if (ok) {
      ss++;
   } else {
      log_aas_err(AAS_TIME_EVENT_EXIST, aas_line_num, -1);
      return AAS_TIME_EVENT_EXIST;
   }

   return 0;     
}

static int A2D_ForceLabel(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Forcible events:") != 0)
   {
      log_aas_err(AAS_FORCE_LABEL_EXPECTED, aas_line_num, -1);
      return AAS_FORCE_LABEL_EXPECTED;
   }

   a2d_state++;
   return 0;
}

static int A2D_ReadForce(char *line)
{
   int event;
   int result;
   INT_S i;
//   INT_B found;

   if (*line == '\0')
      return AAS_FORCE_UNKNOWN;

   if ( (strcmp(line, "*") == 0) ||
        (strcmp(line, " *") == 0) )
   {
      a2d_state++;

      /* All events are forcible */
      for (i=0; i < ss; i++) 
         tt[i].forcible = true;

      return 0;
   }

   result = sscanf(line, "%d", &event);

   if (result <= 0)
   {
      log_aas_err(AAS_FORCE_UNKNOWN, aas_line_num, -1);
      return AAS_FORCE_UNKNOWN;
   }

   if (event < 1)  /* Zero event is invalid here */
   {
      log_aas_err(AAS_TRANS_TOO_SMALL, aas_line_num, -1);
      return AAS_TRANS_TOO_SMALL;
   }

   if (event > MAX_TRANSITIONS)
   {
      log_aas_err(AAS_TRANS_TOO_LARGE, aas_line_num, -1);
      return AAS_TRANS_TOO_LARGE; 
   }

   /* Events must be present */
   if (!inlist(event, temp_tt, temp_ss))
   {
      log_aas_err(AAS_FORCE_NOT_IN_LIST, aas_line_num, -1);
      return AAS_FORCE_NOT_IN_LIST;
   }

   /* Set the bit */
   for (i=0; i < ss; i++)
   {
       if (tt[i].label == ((INT_T) event))
          tt[i].forcible = true;
   }

   return 0;
}

static int A2D_ProcessLine(char* line, long* line_num, long* line_num2)
{
//   char arg[256];
   int err = 0;

   switch( a2d_state ) {
      case A2D_NAME:     err = A2D_ReadName(line);   break;
      case A2D_STATE_L:  err = A2D_StateLabel(line); break;
      case A2D_STATE:    err = A2D_ReadState(line);  break;
      case A2D_MARK_L:   err = A2D_MarkLabel(line);  break;
      case A2D_MARK:     err = A2D_ReadMark(line);   break;
      case A2D_VOCAL_L:  err = A2D_VocalLabel(line); break;
      case A2D_VOCAL:    err = A2D_ReadVocal(line);  break;
      case A2D_TRANS_L:  err = A2D_TransLabel(line); break;
      case A2D_TRANS:    err = A2D_ReadTrans(line, line_num, line_num2);  break;
      case A2D_TIME_L:   err = A2D_TimeLabel(line);  break;
      case A2D_TIME:     err = A2D_ReadTime(line);   break;
      case A2D_FORCE_L:  err = A2D_ForceLabel(line); break;
      case A2D_FORCE:    err = A2D_ReadForce(line);  break;
   default:
      log_aas_err(AAS_UNKNOWN, aas_line_num, -1);
      err = AAS_UNKNOWN;
      break;
   }
   return err;
}

int aas_2_ads(char* name, aas_err_log_t** aas_list, long *aas_num_err,
              state_node** t1, INT_S* s1, timed_event **t2, INT_T *s2)
{
   FILE *in;
   char line[256];
   int err;

   in = fopen(name, "r");
   if (in == NULL) {
      log_aas_err(AAS_FILENAME_EMPTY, -1, -1);
      *aas_list    = aas_err_list;
      *aas_num_err = aas_err_num;
      return AAS_FILE_DOES_NOT_EXIST;
   }

   tranList = NULL;
   s_tranList = 0;

   aas_err_list = NULL;
   aas_err_num = 0;

   a2d_state = A2D_NAME;
   aas_line_num = 0;
   s = *s1;
   t = *t1;
   ss = *s2;
   tt = *t2;
   temp_ss = 0;
   temp_tt = NULL;

   do {
      fgets(line, 255, in);
      if (feof(in)) break;
      aas_line_num++;
      if (line[0] != '#') {
         line[strlen(line)-1] = '\0';
         err = A2D_ProcessLine(line, &aas_line_num, &aas_line_num2);
      }
   } while ((!feof(in)) && (a2d_state <= A2D_FORCE));

   if (aas_err_num == 0)
   {
      if (a2d_state < A2D_FORCE_L)
         log_aas_err(AAS_FILE_TOO_SHORT, aas_line_num, -1);
   }

   if (aas_err_num == 0)
   {
      *t1 = t;
      *s1 = s;
      *t2 = tt;
      *s2 = ss;
   }

   free(tranList);
   free(temp_tt);
   fclose(in);

   *aas_list    = aas_err_list;
   *aas_num_err = aas_err_num;

   return aas_err_num;
}

/***********************************/
/***     For "ALL" AAS->ADS      ***/
/***********************************/

static int A2D_ReadName_all(char* line)
{
   int len;

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", des_filename);
   len = (int)strlen(des_filename);

   if (len <= 0)
      return AAS_FILENAME_EMPTY;

/*   if (len > MAX_DES_NAME_LEN)
      return AAS_FILENAME_TOO_LONG;
*/
   a2d_state++;
   return 0;
}

static int A2D_StateLabel_all(char * line)
{
   char label[80];

   if (strcmp(line, "") == 0)
      return 0;

   sscanf(line, "%s", label);

   if (strcmp(label, "State") != 0)
      return AAS_STATE_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

static int A2D_ReadState_all(char* line)
{
   int max_states = -1;
   int result = 0;

   if (strcmp(line, "") == 0)
      return 0;

   result = sscanf(line, "%ld", &max_states);
   if (result <= 0)
      return AAS_STATE_UNKNOWN;

   if (max_states < 0)
      return AAS_STATE_TOO_SMALL;

   if (max_states > MAX_STATES)
      return AAS_STATE_TOO_LARGE;

   s = (INT_S) max_states;
   t = newdes(s);
   if (s != 0) {
     if (t == NULL) {
        mem_result = 1;
        return -1;
     }
   }

   a2d_state++;
   return 0;
}

static int A2D_MarkLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Marker states:") != 0)
      return AAS_MARK_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

static int A2D_ReadMark_all(char* line)
{
   int mark;
   INT_S i;
   int result;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/
   if (*line == '\0')
      return 0;

   if (strcmp(line, "Vocal states:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   if ( (strcmp(line, "*") == 0) ||
        (strcmp(line, " *") == 0) )
   {
      a2d_state++;

      for (i=0; i < s; i++)
         t[i].marked = true;
      return 0;
   }

   result = sscanf(line, "%d", &mark);

   if (result <= 0)
     return AAS_MARK_UNKNOWN;

   if (mark < 0)
     return AAS_MARK_TOO_SMALL;

   if (mark >= s)
     return AAS_MARK_TOO_LARGE;

   t[mark].marked = true;
   return 0;
}

static int A2D_VocalLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Vocal states:") != 0)
      return AAS_VOCAL_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

static int A2D_ReadVocal_all(char* line)
{
   int state;
   int vocal;
   int result;

/*   if (*line == '\0')
   {
     a2d_state++;
     return 0;
   }
*/

   if (*line == '\0')
      return 0;

   if (strcmp(line, "Transitions:") == 0)
   {
      a2d_state++;
      a2d_state++;
      return 0;
   }

   result = sscanf(line, "%d %d", &state, &vocal);
   if (result <= 1)
     return AAS_VOCAL_UNKNOWN;

   if (state < 0)
     return AAS_STATE_TOO_SMALL;

   if (state >= s)
     return AAS_STATE_TOO_LARGE;

   if (vocal <= 9)
     return AAS_VOCAL_TOO_SMALL;

   if (vocal > 99)
     return AAS_VOCAL_TOO_LARGE;

   t[state].vocal = (INT_V) vocal;
   return 0;
}

static int A2D_TransLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Transitions:") != 0)
      return AAS_TRANS_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

static int A2D_ReadTrans_all(char* line, long *line_num, long *line_num2)
{
   int i, e, j, jj;
   INT_B ok;
   int result;
   long ii;

   if (*line == '\0')
     return 0;

   if (strcmp(line, "Event time bounds:") == 0)
   {
     a2d_state++;
     a2d_state++;

     gentranlist(s, t, &temp_ss, &temp_tt);
     return 0;
   }

   result = sscanf(line, "%d %d %d", &i, &e, &j);

   if (result <= 2)
     return AAS_TRANS_UNKNOWN;

   if (i < 0)
     return AAS_EXIT_STATE_TOO_SMALL;

   if (i >= s)
     return AAS_EXIT_STATE_TOO_LARGE;

   if (e < 1) /* Zero is not valid here */
     return AAS_TRANS_TOO_SMALL;

   if (e > MAX_TRANSITIONS)
     return AAS_TRANS_TOO_LARGE;

   if (j < 0)
     return AAS_ENTRANCE_STATE_TOO_SMALL;

   if (j >= s)
     return AAS_ENTRANCE_STATE_TOO_LARGE;

   /* Check for non-deterministic transitions */
   for (jj=0; jj < t[i].numelts; jj++) {
      if ( (e == t[i].next[jj].data1) &&
           (j != t[i].next[jj].data2) )
      {
         /* Find the line number that mismatch with this transition */
         for (ii =0; ii < s_tranList; ii++)
         {
            if ( (tranList[ii].i == i) &&
                 (tranList[ii].e == e))
               *line_num2 = tranList[ii].line;
         }

         return AAS_NONDETERMINISTIC;
      }
   }

   /* Record transition and line number */
   tranList = (tranList_t*) realloc(tranList, sizeof(tranList_t)*(s_tranList+1));
   if (tranList == NULL)
   {
      mem_result = 1;
      return 0;
   }
   tranList[s_tranList].i = i;
   tranList[s_tranList].e = e;
   tranList[s_tranList].j = j;
   tranList[s_tranList].line = *line_num;
   s_tranList++;

   addordlist1((INT_T) e, (INT_S) j, &t[i].next, t[i].numelts, &ok);
   if (ok) t[i].numelts++;
   return 0;
}

static int A2D_TimeLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Event time bounds:") != 0)
      return AAS_TIME_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

static int A2D_ReadTime_all(char* line)
{
   int label, low, upper;
   int result;
   INT_B ok;

   if (*line == '\0')
      return 0;

   if (strcmp(line, "Forcible events:") == 0)
   {
      a2d_state++;
      a2d_state++;

      if (ss != temp_ss)
      {
	 /* Missing events */
         log_aas_err(AAS_TIME_MISSING_EVENTS, aas_line_num, -1);
         return AAS_TIME_MISSING_EVENTS;
      }

      return 0;
   }

   result = sscanf(line, "%d %d %d", &label, &low, &upper);

   if (result <= 2)
      return AAS_TIME_UNKNOWN;

   if (label < 1)
      return AAS_TRANS_TOO_SMALL;
  
   if (label > MAX_TRANSITIONS)
      return AAS_TRANS_TOO_LARGE;

   if (low < 0) 
      return AAS_TIME_LOW_TOO_SMALL;

   if (low > 1000)
      return AAS_TIME_LOW_TOO_LARGE;

   if (upper < low)
      return  AAS_TIME_UPPER_TOO_SMALL;

   if (upper > 1000)
      return AAS_TIME_UPPER_TOO_LARGE;

   /* Event must be present */
   if (!inlist(label, temp_tt, temp_ss))
      return AAS_TIME_EVENT_NOT_IN_LIST;

   /* Try to add it to list. */
   addordlist_time(label, low, upper, &tt, ss, &ok);
   if (ok) {
      ss++;
   } else {
      return AAS_TIME_EVENT_EXIST;
   }

   return 0;     
}

static int A2D_ForceLabel_all(char* line)
{
   if (strcmp(line, "") == 0)
      return 0;

   if (strcmp(line, "Forcible events:") != 0)
      return AAS_FORCE_LABEL_EXPECTED;

   a2d_state++;
   return 0;
}

static int A2D_ReadForce_all(char *line)
{
   int event;
   int result;
   INT_S i;
//   INT_B found;

   if (*line == '\0')
      return 0;

   if ( (strcmp(line, "*") == 0) ||
        (strcmp(line, " *") == 0) )
   {
      a2d_state++;

      /* All events are forcible */
      for (i=0; i < ss; i++)
         tt[i].forcible = true;

      return 0;
   }

   result = sscanf(line, "%d", &event);

   if (result <= 0)
      return AAS_FORCE_UNKNOWN;

   if (event < 1)    /* Zero event is invalid here */
      return AAS_TRANS_TOO_SMALL;

   if (event > MAX_TRANSITIONS)
      return AAS_TRANS_TOO_LARGE; 

   if (!inlist(event, temp_tt, temp_ss))
     return AAS_FORCE_NOT_IN_LIST;

   /* Set the bit */
   for (i=0; i < ss; i++)
   {
       if (tt[i].label == event) 
          tt[i].forcible = true;
   }

   return 0;
}

static int A2D_ProcessLine_all(char* line, long* line_num, long* line_num2)
{
//   char arg[256];
   int err = 0;

   switch( a2d_state ) {
      case A2D_NAME:     err = A2D_ReadName_all(line);   break;
      case A2D_STATE_L:  err = A2D_StateLabel_all(line); break;
      case A2D_STATE:    err = A2D_ReadState_all(line);  break;
      case A2D_MARK_L:   err = A2D_MarkLabel_all(line);  break;
      case A2D_MARK:     err = A2D_ReadMark_all(line);   break;
      case A2D_VOCAL_L:  err = A2D_VocalLabel_all(line); break;
      case A2D_VOCAL:    err = A2D_ReadVocal_all(line);  break;
      case A2D_TRANS_L:  err = A2D_TransLabel_all(line); break;
      case A2D_TRANS:    err = A2D_ReadTrans_all(line, line_num, line_num2);  break;
      case A2D_TIME_L:   err = A2D_TimeLabel_all(line);  break;
      case A2D_TIME:     err = A2D_ReadTime_all(line);   break;
      case A2D_FORCE_L:  err = A2D_ForceLabel_all(line); break;
      case A2D_FORCE:    err = A2D_ReadForce_all(line);  break;
   default:
      err = AAS_UNKNOWN;
      break;
   }
   return err;
}

int aas_2_ads_all(char* name, long* line_num, long *line_num2, state_node** t1, INT_S* s1,
                  timed_event **t2, INT_T *s2)
{
   FILE *in;
   char line[256];
   int err;
   
   tranList = NULL;
   s_tranList = 0;

   in = fopen(name, "r");
   if (in == NULL) {
      return AAS_FILE_DOES_NOT_EXIST;
   }

   err = 0;
   a2d_state = A2D_NAME;
   *line_num = 0;
   s = *s1;
   t = *t1;
   ss = *s2;
   tt = *t2;
   temp_ss = 0;
   temp_tt = NULL;

   do {
      fgets(line, 255, in);
      if (feof(in)) break;
      (*line_num)++;
      if (line[0] != '#') {
         line[strlen(line)-1] = '\0';
         err = A2D_ProcessLine_all(line, line_num, line_num2);
      }
   } while ((!feof(in)) && (a2d_state <= A2D_FORCE) && (err == 0));

   if (err == 0)
   {
      if (a2d_state < A2D_FORCE_L)
         err = AAS_FILE_TOO_SHORT;
   }

   if (err == 0)
   {
      *t1 = t;
      *s1 = s;
      *t2 = tt;
      *s2 = ss;
   }

   free(tranList);
   free(temp_tt);

   fclose(in);
   return err;
}

int generate_aas_file(char *longname, char *shortname)
{
   FILE *out;

   out = fopen(longname, "wt");
   if (out == NULL)
      return 1;

   fprintf(out, "# TTCT AAS Template\n");
   fprintf(out, "\n");
   fprintf(out, "%s\n", shortname);
   fprintf(out, "\n");
   fprintf(out, "State size (State set will be (0,1....,size-1)):\n");
   fprintf(out, "# <-- Enter state size, in range 0 to 2000000, on line below.\n");
   fprintf(out, "\n");

   fprintf(out, "Marker states:\n");
   fprintf(out, "# <-- Enter marker states, one per line.\n");
   fprintf(out, "# To mark all states, enter *.\n");
   fprintf(out, "# If no marker states, leave line blank.\n");
   fprintf(out, "# End marker list with blank line.\n");
   fprintf(out, "\n");

   fprintf(out, "Vocal states:\n");
   fprintf(out, "# <-- Enter vocal output states, one per line.\n");
   fprintf(out, "# Format: State  Vocal_Output.  Vocal_Output in range 10 to 99.\n");
   fprintf(out, "# Example: 0 10\n");
   fprintf(out, "# If no vocal states, leave line blank.\n");
   fprintf(out, "# End vocal list with blank line.\n");
   fprintf(out, "\n");

   fprintf(out, "Transitions:\n");
   fprintf(out, "# <-- Enter transition triple, one per line.\n");
   fprintf(out, "# Format: Exit_(Source)_State  Transition_Label  Entrance_(Target)_State.\n");
   fprintf(out, "# Transition_Label in range 1 to 999.\n");
   fprintf(out, "# Example: 2 1 1 (for transition labeled 1 from state 2 to state 1).\n");
   fprintf(out, "\n");

   fprintf(out, "Event time bounds:\n");
   fprintf(out, "# <-- Enter time bound triple, one per line.\n");
   fprintf(out, "# Format: Event    Lower_Time_Bound   Upper_Time_Bound\n");
   fprintf(out, "# Event_Label in range 1 to 999.\n");
   fprintf(out, "# Lower Time Bound in range 0..1000\n");
   fprintf(out, "# Upper Time Bound in range 0..1000 [Note: 1000 = Infinity].\n");
   fprintf(out, "# Example: 1 0 10 (for event labeled 1 with lower time bound of 0 and upper 10).\n");
   fprintf(out, "\n");

   fprintf(out, "Forcible events:\n");
   fprintf(out, "# <-- Enter forcible events, one per line.\n");
   fprintf(out, "# To mark all events, enter *.\n");
   fprintf(out, "\n");

   fclose(out);
   return 0;
}

int ads_to_aas(char *shortname,
               FILE *out,
               state_node *t1,
               INT_S s1,
               timed_event *t2,
               INT_T s2)
{
   INT_S i;
   INT_T j;

   fprintf(out, "# TTCT AAS auto-generated\n");
   fprintf(out, "\n");
   fprintf(out, "%s\n", shortname);
   fprintf(out, "\n");
   fprintf(out, "State size (State set will be (0,1....,size-1)):\n");
   fprintf(out, "# <-- Enter state size, in range 0 to 2000000, on line below.\n");
   fprintf(out, "%d\n", s1);
   fprintf(out, "\n");

   fprintf(out, "Marker states:\n");
   fprintf(out, "# <-- Enter marker states, one per line.\n");
   fprintf(out, "# To mark all states, enter *.\n");
   fprintf(out, "# If no marker states, leave line blank.\n");
   fprintf(out, "# End marker list with blank line.\n");
   for (i=0; i < s1; i++)
   {
      if (t1[i].marked)
        fprintf(out, "%d\n", i);
   }
   fprintf(out, "\n");

   fprintf(out, "Vocal states:\n");
   fprintf(out, "# <-- Enter vocal output states, one per line.\n");
   fprintf(out, "# Format: State  Vocal_Output.  Vocal_Output in range 10 to 99.\n");
   fprintf(out, "# Example: 0 10\n");
   fprintf(out, "# If no vocal states, leave line blank.\n");
   fprintf(out, "# End vocal list with blank line.\n");
   for (i=0; i < s1; i++)
   {
     if (t1[i].vocal > 0)
       fprintf(out, "%-5ld %-4d\n", i, t1[i].vocal);
   }
   fprintf(out, "\n");

   fprintf(out, "Transitions:\n");
   fprintf(out, "# <-- Enter transition triple, one per line.\n");
   fprintf(out, "# Format: Exit_(Source)_State  Transition_Label  Entrance_(Target)_State.\n");
   fprintf(out, "# Transition_Label in range 0 to 999.\n");
   fprintf(out, "# Example: 2 0 1 (for transition labeled 0 from state 2 to state 1).\n");
   for (i=0; i < s1; i++) {
      for (j=0; j < t1[i].numelts; j++)
         fprintf(out, "%-5ld %-3d %-5ld\n", i, t1[i].next[j].data1, t1[i].next[j].data2);
   }
   fprintf(out, "\n");

   fprintf(out, "Event time bounds:\n");
   fprintf(out, "# <-- Enter time bound triple, one per line.\n");
   fprintf(out, "# Format: Event    Lower_Time_Bound   Upper_Time_Bound\n");
   fprintf(out, "# Event_Label in range 1 to 999.\n");
   fprintf(out, "# Lower Time Bound in range 0..1000\n");
   fprintf(out, "# Upper Time Bound in range 0..1000 [Note: 1000 = Infinity].\n");
   fprintf(out, "# Example: 1 0 10 (for event labeled 1 with lower time bound of 0 and upper 10).\n");
   for (i=0; i < s2; i++) {
      fprintf(out, "%-5d %-5d %-5d\n", t2[i].label, t2[i].low, t2[i].upper);
   }
   fprintf(out, "\n");

   fprintf(out, "Forcible events:\n");
   fprintf(out, "# <-- Enter forcible events, one per line.\n");
   fprintf(out, "# To mark all events, enter *.\n");
   for (i=0; i < s2; i++) {
      if (t2[i].forcible)
         fprintf(out, "%d\n", t2[i].label);
   }
   fprintf(out, "\n");

   return 0;
}



