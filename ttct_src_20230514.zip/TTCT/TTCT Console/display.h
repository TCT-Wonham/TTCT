#ifndef _DISPLAY_H
#define _DISPLAY_H

extern void advance_menu();
extern void main_menu();
extern void tct_logo(char*);

extern void adv_act_menu();

extern void esc_footer();
extern void overwriteYN(char*);
extern void doesNotExist(char*);
extern void OutOfMemoryMsg();
extern void continue_page(char*);
extern void continue2_page(char*, char*);

#endif

