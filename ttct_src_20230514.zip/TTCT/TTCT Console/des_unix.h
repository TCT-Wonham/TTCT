#ifndef _DES_UNIX_H
#define _DES_UNIX_H

#include "windows.h"

/* Try to pack in as much as possible */
typedef struct tran_node {
   INT_S data2:22;                /* data2 = entrance state, usually */
   INT_T data1:10;                /* data1 = event label, usually    */
} tran_node;

/* Try to pack in as much as possible */
typedef struct recode_node {
   INT_S   recode :31;
   INT_B reached:1;
} recode_node;

/* State map */
typedef struct state_map {
   INT_B marked :1;
   INT_S state    :31;
   INT_S numelts;
   INT_S *next;
} state_map;

#endif

