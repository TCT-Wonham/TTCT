#ifndef _SETUP_H
#define _SETUP_H

extern int ring_active;
extern int debug_mode;
extern int timing_mode;
extern char path[80];
extern char prefix[80];
extern char ttct_ini_file[256];
extern char info_file[256];

#ifdef __GO32__
#define INIFILE "_ttct"
#else
#define INIFILE ".ttct"
#endif
#endif
